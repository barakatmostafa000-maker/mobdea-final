# توثيق منصة البث المباشر والألعاب الجماعية (Sprint 2 - Live Classroom & Multiplayer System)

تم بناء وتنفيذ النظام المباشر والتفاعلي والألعاب الجماعية بالكامل لمنصة **المُبدع التعليمية** باستخدام **Clean Architecture** و **Supabase Realtime** و **WebRTC Signaling**.

---

## 📁 الهيكل التنظيمي للملفات والوحدات (Files & Modules Architecture)

```
/src
├── db
│   └── schema.sql                        # قاعدة البيانات الشاملة والجداول وسياسات الأمن RLS والفهارس
├── services
│   ├── realtime
│   │   └── realtimeSync.js               # محرك المزامنة اللحظية والقنوات وقوائم الحضور Presence
│   ├── live
│   │   ├── liveClassroomService.js       # إدارة الحصص المباشرة والرموز والتحكم بالطلاب ورفع اليد والتحديات
│   │   ├── screenShareService.js         # مشاركة الشاشة وبث إشارات WebRTC (شاشة كاملة، نافذة، متصفح)
│   │   ├── whiteboardService.js          # السبورة التفاعلية المتزامنة ومتجهات الرسم والأشكال والتكبير
│   │   └── recordingService.js           # تسجيل الحصص وإدارة ملفات الفيديو والتنسيق والمشاركة
│   └── multiplayer
│       ├── gameService.js                # محرك الألعاب (PvP, PvAI, Team vs Team, Class vs Class)
│       ├── inviteService.js              # نظام دعوة الأصدقاء عبر الروابط والأكواد المباشرة
│       ├── teamService.js                # نظام الفرق وإدارة الأعضاء والنقاط وترتيب الفرق
│       └── tournamentService.js          # نظام البطولات والمواجهات وشجرة التصفيات Brackets
```

---

## 1. محرك المزامنة اللحظية (`realtimeSync.js`)

يربط كافة الوحدات بالبث اللحظي عبر **Supabase Realtime Channels**:
- **`subscribeChannel(channelName, onBroadcast, onPresence)`**: الاشتراك بالقناة.
- **`trackPresence(channelName, userInfo)`**: تتبع تواجد الطلاب والمعلمين لحظياً.
- **`sendBroadcast(channelName, event, payload)`**: إرسال الأحداث اللحظية.
- **`unsubscribeChannel(channelName)`**: مغادرة القناة وإلغاء الاشتراك.

---

## 2. نظام الحصص المباشرة (`liveClassroomService.js`)

يقدم التحكم الكامل للمعلم والطالب:
- **`createLiveSession({ title, groupName, teacherId, settings })`**: إنشاء حصة وتوليد رمز دخول آلي.
- **`updateSessionStatus(sessionId, status)`**: بدء/إيقاف/إنهاء الحصة وإعلام المشاركين.
- **`joinSessionByCode(joinCode, user)`**: دخول الطالب للحصة عبر الرمز.
- **`toggleRaiseHand(sessionId, userId, isRaised)`**: رفع/خافض اليد أثناء الشرح.
- **`grantPermission(sessionId, studentId, permissionType, granted)`**: منح الطالب الميكروفون، الرسم على السبورة، أو مشاركة الشاشة.
- **`startLiveChallenge(sessionId, student1, student2, question)`**: إطلاق تحدي مباشر بين طالبين أثناء الحصة.

---

## 3. مشاركة الشاشة (`screenShareService.js`)

دعم التقاط بث الشاشة وإشارات WebRTC:
- **`startScreenCapture(streamType)`**: دعم (شاشة كاملة `screen` / نافذة `window` / متصفح `tab`).
- **`broadcastScreenOffer(...)` / `sendAnswerSignal(...)`**: تبادل إشارات الاتصال المباشر WebRTC Offer/Answer/ICE.
- **`stopScreenShare(sessionId)`**: إنهاء مشاركة الشاشة وإعلام الطلاب.

---

## 4. السبورة التفاعلية المتزامنة (`whiteboardService.js`)

- **`addStroke(sessionId, strokeData, userId)`**: إضافة رسم، خط، مربع، دائرة، نص، أو مسح قطعة متجهة ومزامنتها فوراً.
- **`clearCanvas(sessionId, userId)`**: مسح السبورة للجميع.
- **`saveWhiteboardState / loadWhiteboardState`**: حفظ واسترجاع حالة السبورة في قاعدة البيانات.
- **`updateZoomAndPan(scale, offsetX, offsetY)`**: التحكم في التكبير والتصغير (50% إلى 300%).

---

## 5. نظام تسجيل الحصص (`recordingService.js`)

- **`startRecording(sessionId, stream, teacherId)`**: بدء التسجيل المباشر وتجميع المقاطع.
- **`pauseRecording` / `resumeRecording`**: إيقاف مؤقت واستئناف.
- **`stopRecording(sessionId, title, teacherId)`**: إيقاف وحفظ الفيديو وحجمه وتاريخه.
- **`getRecordingsList(teacherId)`**: جلب مكتبة التسجيلات للعرض أو التنزيل أو التشارك.

---

## 6. نظام الألعاب والفرق والبطولات (`gameService.js` / `teamService.js` / `tournamentService.js`)

- **نموذج اللعب الرباعي**: (PvP / Player vs AI 🤖 / Team vs Team / Class vs Class).
- **دعوة الأصدقاء**: إنشاء كود/رابط فريد مثل `INV-4892` للدخول الفوري.
- **إدارة الفرق**: إنشاء الفرق، إضافة الطلاب، حذفهم، ولائحة متصدري الفرق.
- **البطولات**: توليد شجرة التصفيات `generateBrackets` والنتائج ولوحة الشرف.

---

## 7. مخطط قاعدة البيانات الشامل (`schema.sql`)

تم إنشاء الجداول التالية مع تفعيل Row Level Security (RLS) وفهارس الاستعلام السريع:
- `live_sessions` & `session_participants`
- `screen_share_sessions` & `whiteboard_states`
- `recordings` & `teams` & `team_members`
- `game_rooms` & `game_invites` & `tournaments` & `matches` & `leaderboards`
