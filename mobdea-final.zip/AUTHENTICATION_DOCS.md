# توثيق نظام الهوية والمصادقة (Authentication & Authorization System Documentation)

تم إنشاء وتطوير نظام المصادقة وإدارة الهوية بالكامل باستخدام **Supabase Auth** و **Clean Architecture** لمنصة المُبدع التعليمية.

---

## 📁 الهيكل التنظيمي للملفات المنفذة (Created Files Architecture)

```
/src
├── lib
│   └── supabaseClient.js      # إعداد وعميل اتصالات Supabase Client
├── services
│   └── auth
│       ├── authService.js     # خدمة عمليات التسجيل والدخول وإعادة كلمة المرور (Authentication Service)
│       ├── sessionManager.js  # إدارة الجلسات، التخزين المؤقت والتحقق التلقائي (Session Manager)
│       ├── roleManager.js     # إدارة الأدوار، الصلاحيات ومصفوفة الوصول (Role Manager)
│       ├── routeGuard.js      # حماية المسارات وتأمين التنقل (Route Protection)
│       └── index.js           # المصدّر الموحد لجميع خدمات المصادقة
└── context
    └── AuthContext.jsx        # مزود الحالة العامة وقاطعة الاتصال بالمصادقة (React Context & Hook)
```

---

## 1. خدمة المصادقة (`authService.js`)

تتيح تنفيذ جميع عمليات المصادقة والأمان:
- **`login({ email, password })`**: تسجيل الدخول مع التحقق من صحة المدخلات وجلب دور المستخدم.
- **`signUp({ email, password, fullName, role, phone })`**: إنشاء حساب جديد مع تخصيص الدور (`admin`, `teacher`, `student`, `parent`) وإنشاء الملف الشخصي في قاعدة البيانات.
- **`logout()`**: تسجيل الخروج بأمان ومسح بيانات الجلسة.
- **`resetPassword(email)`**: إرسال رابط إعادة ضبط كلمة المرور عبر البريد الإلكتروني.
- **`updatePassword(newPassword)`**: تحديث كلمة المرور للحساب الحالي.
- **`validateEmail(email)` / `validatePassword(password)`**: دواء التحقق الصارم من المدخلات ومطابقتها للشروط.

---

## 2. مدير الجلسات والتسجيل التلقائي (`sessionManager.js`)

- **`saveSession(user, session)`**: حفظ رموز الوصول الجلسة وحالة المستخدم في `localStorage` والذاكرة.
- **`getStoredSession()`**: استرجاع الجلسة الحالية مع التحقق من الصلاحية والانتهاء.
- **`clearSession()`**: مسح كافة البيانات والتصاريح المخزنة.
- **`initAutoLogin(onSuccess, onError)`**: تسجيل الدخول التلقائي فور فتح التطبيق عبر فحص جلسة Supabase القائمة أو التخزين الآمن.
- **`subscribeToAuthChanges(onAuthChange)`**: الاستماع الفوري لتغيرات حالة التسجيل (تسجيل الدخول، الخروج، تجديد الرمز).

---

## 3. مدير الأدوار والصلاحيات (`roleManager.js`)

يدعم 4 أدواري رئيسية:
1. **`admin`**: مدير النظام (وصول شامل لكافة الصفحات والإعدادات).
2. **`teacher`**: المعلم (اللوحة، وضع الحصة المباشرة، الطلاب، الحضور، الدرجات، بنك الأسئلة، المسابقات، المساعد الذكي).
3. **`student`**: الطالب (اللوحة، كارت الطالب، بنك الأسئلة، الألعاب، تحدي الخرائط، سجل درجاته).
4. **`parent`**: ولي الأمر (اللوحة، تقارير الحضور والغياب، الدرجات، المدفوعات والاشتراكات، رسائل وتنبيهات واتساب).

---

## 4. حماية المسارات والتبويبات (`routeGuard.js` & `AuthContext.jsx`)

- **`canAccessRoute(role, targetRoute)`**: فحص صلاحية الدور قبل السماح بالانتقال للصفحة.
- **`routeGuard.filterMenuItems(items, role)`**: تصفية قائمة القائم الجانبية تلقائياً وإخفاء التبويبات غير المسموح بها حسب دور المستخدم.
- **`useRouteGuard(user, currentRoute)`**: هوك جاهز للاستخدام في واجهات المستخدم يحدد السماح أو التوجيه البديل.

---

## 💡 كيفية ربط الواجهات المستقبلية (UI Integration Example)

```jsx
import { useAuth } from './context/AuthContext';

function LoginScreen() {
  const { login, loading, authError } = useAuth();

  const handleLogin = async () => {
    try {
      await login({ email: 'teacher@mobdea.com', password: 'secretpassword' });
      alert('تم تسجيل الدخول بنجاح');
    } catch (err) {
      console.error(err.message);
    }
  };
}
```
