package com.mobdea.education.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobdea.education.data.model.Student

@Composable
fun MessagesScreen(students: List<Student>) {
    var selectedTemplate by remember { MutableStateOf("تقرير الحضور والغياب") }
    val templates = listOf("تقرير الحضور والغياب", "تقرير درجات الاختبارات", "تذكير بالاشتراك الشاهري")
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "إرسال رسائل وتنبيهات أولياء الأمور",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Template Selector
        ScrollableTabRow(
            selectedTabIndex = templates.indexOf(selectedTemplate).coerceAtLeast(0),
            edgePadding = 0.dp
        ) {
            templates.forEach { tmpl ->
                Tab(
                    selected = selectedTemplate == tmpl,
                    onClick = { selectedTemplate = tmpl },
                    text = { Text(tmpl, fontSize = 13.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(students) { student ->
                val messageText = when (selectedTemplate) {
                    "تقرير الحضور والغياب" -> "ولي أمر الطالب/ة ${student.name}، نود إحاطتكم بحضور ومتابعة الطالب لمواعيد حوافز الدرس بنجاح."
                    "تقرير درجات الاختبارات" -> "ولي أمر الطالب/ة ${student.name}، تم إدراج درجات الاختبار الدوري للمادة عبر منصة المُبدع."
                    else -> "ولي أمر الطالب/ة ${student.name}، تذكير بموعد سداد اشتراك الحصص للمجموعة."
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = student.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = student.guardianPhone,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = messageText,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = {
                                    val sendIntent = Intent(Intent.ACTION_VIEW).apply {
                                        data = Uri.parse("https://api.whatsapp.com/send?phone=${student.guardianPhone}&text=${Uri.encode(messageText)}")
                                    }
                                    runCatching { context.startActivity(sendIntent) }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                            ) {
                                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إرسال عبر واتساب")
                            }
                        }
                    }
                }
            }
        }
    }
}
