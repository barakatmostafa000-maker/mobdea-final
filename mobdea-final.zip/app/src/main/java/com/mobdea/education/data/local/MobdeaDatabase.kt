package com.mobdea.education.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        StudentEntity::class,
        SessionEntity::class,
        AttendanceEntity::class,
        GradeEntity::class,
        QuestionEntity::class,
        PaymentEntity::class,
        ContentEntity::class,
        SettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MobdeaDatabase : RoomDatabase() {

    abstract fun studentDao(): StudentDao
    abstract fun sessionDao(): SessionDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun gradeDao(): GradeDao
    abstract fun questionDao(): QuestionDao
    abstract fun paymentDao(): PaymentDao
    abstract fun contentDao(): ContentDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile
        private var INSTANCE: MobdeaDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): MobdeaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MobdeaDatabase::class.java,
                    "mobdea_database"
                )
                .addCallback(MobdeaDatabaseCallback(scope))
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class MobdeaDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateDatabase(database)
                    }
                }
            }

            suspend fun populateDatabase(db: MobdeaDatabase) {
                db.studentDao().insertAll(SeedData.students)
                db.sessionDao().insertAll(SeedData.sessions)
                db.gradeDao().insertGrade(SeedData.grades[0])
                db.gradeDao().insertGrade(SeedData.grades[1])
                db.contentDao().insertAll(SeedData.content)
                db.settingsDao().saveSettings(SeedData.defaultSettings)
                db.questionDao().insertAll(SeedData.initialQuestions)
            }
        }
    }
}
