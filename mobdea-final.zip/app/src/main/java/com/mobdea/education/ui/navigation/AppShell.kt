package com.mobdea.education.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

data class NavItem(
    val id: String,
    val title: String,
    val icon: ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppShell(
    activeRoute: String,
    onNavigate: (String) -> Unit,
    onLockApp: () -> Unit,
    content: @Composable () -> Unit
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val navItems = listOf(
        NavItem("dashboard", "الرئيسية", Icons.Default.Dashboard),
        NavItem("classMode", "وضع الحصة المباشرة", Icons.Default.PlayArrow),
        NavItem("students", "إدارة الطلاب", Icons.Default.Group),
        NavItem("studentCards", "كروت الطلاب الكودية", Icons.Default.QrCode),
        NavItem("sessions", "المجموعات والحصص", Icons.Default.Class),
        NavItem("attendance", "الحضور والغياب", Icons.Default.Checklist),
        NavItem("grades", "الدرجات والامتحانات", Icons.Default.Grade),
        NavItem("gradeScanner", "الماسح الضوئي للدرجات", Icons.Default.QrCodeScanner),
        NavItem("questionBank", "بنك الأسئلة الشامل", Icons.Default.Quiz),
        NavItem("games", "المسابقات والألعاب", Icons.Default.EmojiEvents),
        NavItem("mapChallenge", "تحدي الخريطة", Icons.Default.Map),
        NavItem("payments", "المدفوعات والاشتراكات", Icons.Default.Payments),
        NavItem("reports", "التقارير والإحصائيات", Icons.Default.Assessment),
        NavItem("messages", "رسائل أولياء الأمور", Icons.Default.Message),
        NavItem("smartAssistant", "المساعد الذكي للمعلم", Icons.Default.AutoAwesome),
        NavItem("contentLibrary", "مكتبة المحتوى التعليمي", Icons.Default.Description),
        NavItem("settings", "الإعدادات والأمان", Icons.Default.Settings)
    )

    val currentTitle = navItems.find { it.id == activeRoute }?.title ?: "منصة المُبدع"

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    modifier = Modifier.width(300.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Header
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 16.dp)
                        ) {
                            Surface(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape),
                                color = MaterialTheme.colorScheme.primary
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("م", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("منصة المُبدع", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Text("تعليم ممتع ومبتكر", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                        // Nav Items List
                        navItems.forEach { item ->
                            val isSelected = activeRoute == item.id
                            NavigationDrawerItem(
                                label = { Text(item.title, fontSize = 14.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                icon = { Icon(item.icon, contentDescription = null) },
                                selected = isSelected,
                                onClick = {
                                    onNavigate(item.id)
                                    scope.launch { drawerState.close() }
                                },
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Text(
                                text = currentTitle,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "القائمة")
                            }
                        },
                        actions = {
                            IconButton(onClick = onLockApp) {
                                Icon(Icons.Default.Lock, contentDescription = "قفل التطبيق", tint = MaterialTheme.colorScheme.primary)
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                }
            ) { padding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                ) {
                    content()
                }
            }
        }
    }
}
