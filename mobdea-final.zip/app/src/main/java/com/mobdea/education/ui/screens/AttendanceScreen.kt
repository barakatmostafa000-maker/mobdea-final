package com.mobdea.education.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobdea.education.data.model.AttendanceRecord
import com.mobdea.education.data.model.Session
import com.mobdea.education.data.model.Student
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(
    students: List<Student>,
    sessions: List<Session>,
    attendance: List<AttendanceRecord>,
    onRecordAttendance: (Long, Long, String, String) -> Unit
) {
    var selectedSessionId by remember { MutableStateOf(sessions.firstOrNull()?.id ?: 0L) }
    var selectedDate by remember { MutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }

    val selectedSession = sessions.find { it.id == selectedSessionId }
    val groupStudents = if (selectedSession != null) {
        students.filter { it.grade == selectedSession.title || it.group == selectedSession.group }
    } else students

    val sessionAttendance = attendance.filter { it.sessionId == selectedSessionId && it.date == selectedDate }
    val presentCount = sessionAttendance.count { it.status == "حاضر" }
    val absentCount = sessionAttendance.count { it.status == "غائب" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "تسجيل الحضور والغياب",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Session Dropdown / Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = selectedDate,
                onValueChange = { selectedDate = it },
                label = { Text("التاريخ (YYYY-MM-DD)") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        ScrollableTabRow(
            selectedTabIndex = sessions.indexOfFirst { it.id == selectedSessionId }.coerceAtLeast(0),
            edgePadding = 0.dp
        ) {
            sessions.forEach { sess ->
                Tab(
                    selected = selectedSessionId == sess.id,
                    onClick = { selectedSessionId = sess.id },
                    text = { Text(sess.title, fontSize = 13.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Attendance Overview Summary
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("الإجمالي", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("${groupStudents.size}", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("الحاضرون", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("$presentCount", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("الغياب", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("$absentCount", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Students List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(groupStudents, key = { it.id }) { student ->
                val record = sessionAttendance.find { it.studentId == student.id }
                val currentStatus = record?.status ?: "لم يسجل"

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${student.code}. ${student.name}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "الحالة: $currentStatus",
                                fontSize = 12.sp,
                                color = when (currentStatus) {
                                    "حاضر" -> MaterialTheme.colorScheme.secondary
                                    "غائب" -> MaterialTheme.colorScheme.error
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(onClick = { onRecordAttendance(student.id, selectedSessionId, selectedDate, "حاضر") }) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = "حاضر",
                                    tint = if (currentStatus == "حاضر") MaterialTheme.colorScheme.secondary else Color.Gray
                                )
                            }
                            IconButton(onClick = { onRecordAttendance(student.id, selectedSessionId, selectedDate, "غائب") }) {
                                Icon(
                                    Icons.Default.Cancel,
                                    contentDescription = "غائب",
                                    tint = if (currentStatus == "غائب") MaterialTheme.colorScheme.error else Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
