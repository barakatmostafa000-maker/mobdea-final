package com.mobdea.education.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class StudentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: Int,
    val name: String,
    val grade: String,
    val group: String,
    val guardianPhone: String,
    val sessionPrice: Int,
    val gamesPermission: Boolean,
    val gradesPermission: Boolean,
    val contentPermission: Boolean,
    val parentAttendancePermission: Boolean,
    val parentGradesPermission: Boolean,
    val parentDuesPermission: Boolean
)

@Entity(tableName = "sessions")
data class SessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val group: String,
    val day: String,
    val time: String,
    val price: Int,
    val current: Boolean
)

@Entity(tableName = "attendance")
data class AttendanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val sessionId: Long,
    val date: String,
    val status: String,
    val notes: String
)

@Entity(tableName = "grades")
data class GradeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val exam: String,
    val score: Int,
    val total: Int,
    val date: String,
    val weakness: String,
    val strength: String
)

@Entity(tableName = "questions")
data class QuestionEntity(
    @PrimaryKey val id: String,
    val gradeKey: String,
    val grade: String,
    val term: String,
    val unit: String,
    val lesson: String,
    val topic: String,
    val type: String,
    val text: String,
    val maxScore: Int,
    val difficulty: String,
    val optionsJson: String,
    val answerIndex: Int,
    val answer: String,
    val cluesJson: String,
    val eventsJson: String
)

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val amount: Int,
    val date: String,
    val period: String,
    val notes: String
)

@Entity(tableName = "content")
data class ContentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val grade: String,
    val term: String,
    val unit: String,
    val lesson: String,
    val type: String,
    val url: String,
    val notes: String,
    val tagsJson: String
)

@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = 1,
    val adminPin: String,
    val lockEnabled: Boolean,
    val lockAfterMinutes: Int,
    val voiceEnabled: Boolean,
    val welcomeVoice: Boolean,
    val visibleGames: Boolean,
    val visibleGrades: Boolean,
    val visiblePayments: Boolean,
    val visibleReports: Boolean,
    val visibleMessages: Boolean
)
