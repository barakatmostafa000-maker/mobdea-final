package com.mobdea.education.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Grade
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobdea.education.data.model.GradeRecord
import com.mobdea.education.data.model.Student

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GradesScreen(
    students: List<Student>,
    grades: List<GradeRecord>,
    onAddGrade: (Long, String, Int, Int, String, String) -> Unit
) {
    var showDialog by remember { MutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showDialog = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة درجة", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "سجل درجات الاختبارات والامتحانات",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(grades) { grade ->
                    val student = students.find { it.id == grade.studentId }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = student?.name ?: "طالب #${grade.studentId}",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${grade.exam} • ${grade.date}",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (grade.strength.isNotEmpty() || grade.weakness.isNotEmpty()) {
                                    Text(
                                        text = "نقاط القوة: ${grade.strength} | تحتاج مراجعة: ${grade.weakness}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = "${grade.score} / ${grade.total}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        GradeFormDialog(
            students = students,
            onDismiss = { showDialog = false },
            onSave = { studentId, exam, score, total, strength, weakness ->
                onAddGrade(studentId, exam, score, total, strength, weakness)
                showDialog = false
            }
        )
    }
}

@Composable
fun GradeFormDialog(
    students: List<Student>,
    onDismiss: () -> Unit,
    onSave: (Long, String, Int, Int, String, String) -> Unit
) {
    var selectedStudentId by remember { MutableStateOf(students.firstOrNull()?.id ?: 0L) }
    var examTitle by remember { MutableStateOf("اختبار الوحدة الأولى") }
    var score by remember { MutableStateOf("18") }
    var total by remember { MutableStateOf("20") }
    var strength by remember { MutableStateOf("المفاهيم الأساسية") }
    var weakness by remember { MutableStateOf("التواريخ والشخصيات") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسجيل درجة جديدة") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("اختر الطالب:", fontWeight = FontWeight.Bold)
                ScrollableTabRow(
                    selectedTabIndex = students.indexOfFirst { it.id == selectedStudentId }.coerceAtLeast(0),
                    edgePadding = 0.dp
                ) {
                    students.forEach { std ->
                        Tab(
                            selected = selectedStudentId == std.id,
                            onClick = { selectedStudentId = std.id },
                            text = { Text(std.name, fontSize = 12.sp) }
                        )
                    }
                }

                OutlinedTextField(value = examTitle, onValueChange = { examTitle = it }, label = { Text("اسم الامتحان") })
                OutlinedTextField(value = score, onValueChange = { score = it }, label = { Text("الدرجة المحصلة") })
                OutlinedTextField(value = total, onValueChange = { total = it }, label = { Text("الدرجة الكلية") })
                OutlinedTextField(value = strength, onValueChange = { strength = it }, label = { Text("نقاط القوة (اختياري)") })
                OutlinedTextField(value = weakness, onValueChange = { weakness = it }, label = { Text("تحتاج مراجعة (اختياري)") })
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(
                    selectedStudentId,
                    examTitle,
                    score.toIntOrNull() ?: 0,
                    total.toIntOrNull() ?: 20,
                    strength,
                    weakness
                )
            }) { Text("حفظ الدرجة") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
