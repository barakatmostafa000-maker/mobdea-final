package com.mobdea.education.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobdea.education.data.model.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClassModeScreen(
    students: List<Student>,
    sessions: List<Session>,
    attendance: List<AttendanceRecord>,
    questions: List<Question>,
    onRecordAttendance: (Long, Long, String, String) -> Unit,
    onNavigate: (String) -> Unit
) {
    val currentSession = sessions.find { it.current } ?: sessions.firstOrNull()
    var selectedQuestion by remember { MutableStateOf<Question?>(null) }
    var pointsMap by remember { MutableStateOf(mutableStateMapOf<Long, Int>()) }
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }

    val groupStudents = remember(students, currentSession) {
        if (currentSession != null) {
            students.filter { it.grade == currentSession.title || it.group == currentSession.group }
        } else students
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Live Session Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFEF4444),
                            modifier = Modifier.size(12.dp)
                        ) {}
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "بث مباشر — وضع الحصة",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }

                    Button(
                        onClick = {
                            val q = questions.filter { it.grade == (currentSession?.title ?: "") }.randomOrNull()
                                ?: questions.randomOrNull()
                            selectedQuestion = q
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Help, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("سؤال عشوائي")
                    }
                }

                if (currentSession != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "${currentSession.title} (${currentSession.group})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        // Question Popup Card
        if (selectedQuestion != null) {
            val q = selectedQuestion!!
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "سؤال تفاعلي للطلاب 🎯",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        IconButton(onClick = { selectedQuestion = null }) {
                            Icon(Icons.Default.Close, contentDescription = null)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = q.text,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    if (q.options.isNotEmpty()) {
                        q.options.forEachIndexed { idx, opt ->
                            Text(
                                text = "${idx + 1}. $opt",
                                fontSize = 14.sp,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "الإجابة الصحيحة: ${q.answer}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "قائمة الطلاب الحاضرين (${groupStudents.size})",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Student Roster
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(groupStudents) { student ->
                val currentStatus = attendance.find {
                    it.studentId == student.id &&
                            (currentSession == null || it.sessionId == currentSession.id) &&
                            it.date == today
                }?.status ?: "لم يسجل"

                val studentPoints = pointsMap[student.id] ?: 0

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${student.code}. ${student.name}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "النقاط: ⭐ $studentPoints",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Attendance Status Badges
                            FilterChip(
                                selected = currentStatus == "حاضر",
                                onClick = {
                                    if (currentSession != null) {
                                        onRecordAttendance(student.id, currentSession.id, today, "حاضر")
                                    }
                                },
                                label = { Text("حاضر", fontSize = 11.sp) }
                            )
                            FilterChip(
                                selected = currentStatus == "غائب",
                                onClick = {
                                    if (currentSession != null) {
                                        onRecordAttendance(student.id, currentSession.id, today, "غائب")
                                    }
                                },
                                label = { Text("غائب", fontSize = 11.sp) }
                            )

                            IconButton(
                                onClick = { pointsMap[student.id] = studentPoints + 1 }
                            ) {
                                Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFF59E0B))
                            }
                        }
                    }
                }
            }
        }
    }
}
