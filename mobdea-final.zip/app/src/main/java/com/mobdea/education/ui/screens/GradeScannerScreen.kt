package com.mobdea.education.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobdea.education.data.model.Student
import kotlinx.coroutines.delay

@Composable
fun GradeScannerScreen(
    students: List<Student>,
    onAddGrade: (Long, String, Int, Int, String, String) -> Unit
) {
    var isScanning by remember { MutableStateOf(false) }
    var scannedResult by remember { MutableStateOf<Pair<Student, Int>?>(null) }
    var selectedStudent by remember { MutableStateOf(students.firstOrNull()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "الماسح الضوئي الذكي لتصحيح الأوراق",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = "وجه الكاميرا نحو ورقة الإجابة المظللة أو اختر الطالب للتصحيح التلقائي",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Scanner Viewfinder Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                // Target frame box
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .border(
                            width = 3.dp,
                            color = if (isScanning) Color(0xFF10B981) else Color(0xFF6366F1),
                            shape = RoundedCornerShape(16.dp)
                        )
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isScanning) "جارٍ المسح وتحليل الفقرات..." else "جاهز للمسح الضوئي",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Select Student for Scan Simulation
        if (students.isNotEmpty()) {
            Text("اختر الطالب للنموذج:", fontWeight = FontWeight.Bold)
            ScrollableTabRow(
                selectedTabIndex = students.indexOfFirst { it.id == selectedStudent?.id }.coerceAtLeast(0),
                edgePadding = 0.dp
            ) {
                students.forEach { std ->
                    Tab(
                        selected = selectedStudent?.id == std.id,
                        onClick = { selectedStudent = std },
                        text = { Text(std.name, fontSize = 12.sp) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (selectedStudent != null) {
                    isScanning = true
                    scannedResult = null
                }
            },
            enabled = !isScanning && selectedStudent != null,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.CameraAlt, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("التقاط ومسح الورقة")
        }

        LaunchedEffect(isScanning) {
            if (isScanning && selectedStudent != null) {
                delay(1500)
                val generatedScore = (16..20).random()
                scannedResult = Pair(selectedStudent!!, generatedScore)
                isScanning = false
            }
        }

        if (scannedResult != null) {
            val (student, score) = scannedResult!!
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تم التصحيح بنجاح! 🎉",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("الطالب: ${student.name}")
                    Text("النتيجة: $score / 20", fontWeight = FontWeight.Bold, fontSize = 18.sp)

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            onAddGrade(student.id, "اختبار مسح تلقائي", score, 20, "الإجابات المظللة", "الفقرة 4")
                            scannedResult = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Text("اعتماد وسحب الدرجة للسجل")
                    }
                }
            }
        }
    }
}
