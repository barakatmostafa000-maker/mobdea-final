package com.mobdea.education.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobdea.education.data.model.ContentItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContentLibraryScreen(
    contentList: List<ContentItem>,
    onAddContent: (ContentItem) -> Unit
) {
    var showDialog by remember { MutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showDialog = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة ملخص", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "مكتبة المذكرات والمحتوى التعليمي",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(contentList) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (item.type == "map") Icons.Default.Map else Icons.Default.Description,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(item.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text("${item.grade} • ${item.unit}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(item.notes, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = item.type.uppercase(),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        ContentFormDialog(
            onDismiss = { showDialog = false },
            onSave = { item ->
                onAddContent(item)
                showDialog = false
            }
        )
    }
}

@Composable
fun ContentFormDialog(
    onDismiss: () -> Unit,
    onSave: (ContentItem) -> Unit
) {
    var title by remember { MutableStateOf("") }
    var grade by remember { MutableStateOf("الصف السادس الابتدائي") }
    var unit by remember { MutableStateOf("الوحدة الأولى") }
    var type by remember { MutableStateOf("pdf") }
    var notes by remember { MutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة ملف تعليمي للمكتبة") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("عنوان الملف / المذكرة") })
                OutlinedTextField(value = grade, onValueChange = { grade = it }, label = { Text("الصف الدراسي") })
                OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("الوحدة") })
                OutlinedTextField(value = type, onValueChange = { type = it }, label = { Text("نوع الملف (pdf / map)") })
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("ملاحظات وشرح مختصر") })
            }
        },
        confirmButton = {
            Button(onClick = {
                if (title.isNotEmpty()) {
                    onSave(ContentItem(title = title, grade = grade, term = "الترم الأول", unit = unit, lesson = "عام", type = type, notes = notes))
                }
            }) { Text("حفظ الملف") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
