package com.mobdea.education.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Class
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobdea.education.data.model.Session

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SessionsScreen(
    sessions: List<Session>,
    onSaveSession: (Session) -> Unit,
    onSetCurrentSession: (Long) -> Unit
) {
    var showDialog by remember { MutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showDialog = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة مجموعة", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "مجموعات وحصص الطلاب",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(sessions) { session ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (session.current) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Class, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = session.title,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${session.group} • ${session.day} الساعة ${session.time}",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "سعر الحصة: ${session.price} ج.م",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Button(
                                onClick = { onSetCurrentSession(session.id) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (session.current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                                )
                            ) {
                                Text(if (session.current) "الحصة الحالية" else "تحديد كحالية")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        SessionFormDialog(
            onDismiss = { showDialog = false },
            onSave = { session ->
                onSaveSession(session)
                showDialog = false
            }
        )
    }
}

@Composable
fun SessionFormDialog(
    onDismiss: () -> Unit,
    onSave: (Session) -> Unit
) {
    var title by remember { MutableStateOf("الصف السادس الابتدائي") }
    var group by remember { MutableStateOf("مجموعة 5 مساءً") }
    var day by remember { MutableStateOf("الأربعاء") }
    var time by remember { MutableStateOf("17:00") }
    var price by remember { MutableStateOf("50") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة مجموعة حصص جديدة") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("عنوان المادة / الصف") })
                OutlinedTextField(value = group, onValueChange = { group = it }, label = { Text("اسم المجموعة") })
                OutlinedTextField(value = day, onValueChange = { day = it }, label = { Text("اليوم") })
                OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("الوقت") })
                OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("سعر الحصة") })
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(Session(title = title, group = group, day = day, time = time, price = price.toIntOrNull() ?: 50))
            }) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
