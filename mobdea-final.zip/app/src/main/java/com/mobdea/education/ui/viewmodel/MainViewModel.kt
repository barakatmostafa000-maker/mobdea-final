package com.mobdea.education.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mobdea.education.data.local.MobdeaDatabase
import com.mobdea.education.data.model.*
import com.mobdea.education.data.repository.MobdeaRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = MobdeaDatabase.getDatabase(application, viewModelScope)
    val repository = MobdeaRepository(db)

    val students: StateFlow<List<Student>> = repository.students
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sessions: StateFlow<List<Session>> = repository.sessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val attendance: StateFlow<List<AttendanceRecord>> = repository.attendance
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val grades: StateFlow<List<GradeRecord>> = repository.grades
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val questions: StateFlow<List<Question>> = repository.questions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payments: StateFlow<List<PaymentRecord>> = repository.payments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val content: StateFlow<List<ContentItem>> = repository.content
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<AppSettings> = repository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    // App lock state
    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    fun unlockApp(pin: String): Boolean {
        val currentSettings = settings.value
        return if (pin == currentSettings.adminPin) {
            _isUnlocked.value = true
            true
        } else {
            false
        }
    }

    fun lockApp() {
        _isUnlocked.value = false
    }

    fun saveStudent(student: Student) {
        viewModelScope.launch {
            repository.saveStudent(student)
        }
    }

    fun deleteStudent(student: Student) {
        viewModelScope.launch {
            repository.deleteStudent(student)
        }
    }

    fun saveSession(session: Session) {
        viewModelScope.launch {
            repository.saveSession(session)
        }
    }

    fun setCurrentSession(sessionId: Long) {
        viewModelScope.launch {
            repository.setCurrentSession(sessionId)
        }
    }

    fun recordAttendance(studentId: Long, sessionId: Long, date: String = currentDateString(), status: String, notes: String = "") {
        viewModelScope.launch {
            repository.recordAttendance(studentId, sessionId, date, status, notes)
        }
    }

    fun addGrade(studentId: Long, examTitle: String, score: Int, total: Int = 20, strength: String = "", weakness: String = "") {
        viewModelScope.launch {
            repository.addGrade(
                GradeRecord(
                    studentId = studentId,
                    exam = examTitle,
                    score = score,
                    total = total,
                    date = currentDateString(),
                    strength = strength,
                    weakness = weakness
                )
            )
        }
    }

    fun addPayment(studentId: Long, amount: Int, period: String = "حصة", notes: String = "") {
        viewModelScope.launch {
            repository.addPayment(
                PaymentRecord(
                    studentId = studentId,
                    amount = amount,
                    date = currentDateString(),
                    period = period,
                    notes = notes
                )
            )
        }
    }

    fun addQuestion(question: Question) {
        viewModelScope.launch {
            repository.addQuestion(question)
        }
    }

    fun addContent(contentItem: ContentItem) {
        viewModelScope.launch {
            repository.addContent(contentItem)
        }
    }

    fun updateSettings(newSettings: AppSettings) {
        viewModelScope.launch {
            repository.updateSettings(newSettings)
        }
    }

    private fun currentDateString(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }
}
