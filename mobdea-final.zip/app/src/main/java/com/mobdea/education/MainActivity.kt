package com.mobdea.education

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.mobdea.education.ui.navigation.AppShell
import com.mobdea.education.ui.screens.*
import com.mobdea.education.ui.theme.MobdeaTheme
import com.mobdea.education.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MobdeaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val isUnlocked by viewModel.isUnlocked.collectAsState()
                    val settings by viewModel.settings.collectAsState()

                    val students by viewModel.students.collectAsState()
                    val sessions by viewModel.sessions.collectAsState()
                    val attendance by viewModel.attendance.collectAsState()
                    val grades by viewModel.grades.collectAsState()
                    val questions by viewModel.questions.collectAsState()
                    val payments by viewModel.payments.collectAsState()
                    val contentList by viewModel.content.collectAsState()

                    var activeRoute by remember { MutableStateOf("dashboard") }

                    if (settings.lockEnabled && !isUnlocked) {
                        LockScreen(
                            correctPin = settings.adminPin,
                            onUnlock = { pin -> viewModel.unlockApp(pin) }
                        )
                    } else {
                        AppShell(
                            activeRoute = activeRoute,
                            onNavigate = { activeRoute = it },
                            onLockApp = { viewModel.lockApp() }
                        ) {
                            when (activeRoute) {
                                "dashboard" -> DashboardScreen(
                                    students = students,
                                    sessions = sessions,
                                    attendance = attendance,
                                    grades = grades,
                                    payments = payments,
                                    onNavigate = { activeRoute = it }
                                )
                                "classMode" -> ClassModeScreen(
                                    students = students,
                                    sessions = sessions,
                                    attendance = attendance,
                                    questions = questions,
                                    onRecordAttendance = { stdId, sessId, date, status ->
                                        viewModel.recordAttendance(stdId, sessId, date, status)
                                    },
                                    onNavigate = { activeRoute = it }
                                )
                                "students" -> StudentsScreen(
                                    students = students,
                                    onSaveStudent = { student -> viewModel.saveStudent(student) },
                                    onDeleteStudent = { student -> viewModel.deleteStudent(student) }
                                )
                                "studentCards" -> StudentCardsScreen(students = students)
                                "sessions" -> SessionsScreen(
                                    sessions = sessions,
                                    onSaveSession = { session -> viewModel.saveSession(session) },
                                    onSetCurrentSession = { sessId -> viewModel.setCurrentSession(sessId) }
                                )
                                "attendance" -> AttendanceScreen(
                                    students = students,
                                    sessions = sessions,
                                    attendance = attendance,
                                    onRecordAttendance = { stdId, sessId, date, status ->
                                        viewModel.recordAttendance(stdId, sessId, date, status)
                                    }
                                )
                                "grades" -> GradesScreen(
                                    students = students,
                                    grades = grades,
                                    onAddGrade = { stdId, exam, score, total, strength, weakness ->
                                        viewModel.addGrade(stdId, exam, score, total, strength, weakness)
                                    }
                                )
                                "gradeScanner" -> GradeScannerScreen(
                                    students = students,
                                    onAddGrade = { stdId, exam, score, total, strength, weakness ->
                                        viewModel.addGrade(stdId, exam, score, total, strength, weakness)
                                    }
                                )
                                "questionBank" -> QuestionBankScreen(
                                    questions = questions,
                                    onAddQuestion = { q -> viewModel.addQuestion(q) }
                                )
                                "games" -> GamesScreen(questions = questions)
                                "mapChallenge" -> MapChallengeScreen()
                                "payments" -> PaymentsScreen(
                                    students = students,
                                    payments = payments,
                                    onAddPayment = { stdId, amount, period, notes ->
                                        viewModel.addPayment(stdId, amount, period, notes)
                                    }
                                )
                                "reports" -> ReportsScreen(
                                    students = students,
                                    grades = grades,
                                    attendance = attendance,
                                    payments = payments
                                )
                                "messages" -> MessagesScreen(students = students)
                                "smartAssistant" -> SmartAssistantScreen(students = students)
                                "contentLibrary" -> ContentLibraryScreen(
                                    contentList = contentList,
                                    onAddContent = { item -> viewModel.addContent(item) }
                                )
                                "settings" -> SettingsScreen(
                                    settings = settings,
                                    onUpdateSettings = { newSett -> viewModel.updateSettings(newSett) }
                                )
                                else -> DashboardScreen(
                                    students = students,
                                    sessions = sessions,
                                    attendance = attendance,
                                    grades = grades,
                                    payments = payments,
                                    onNavigate = { activeRoute = it }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
