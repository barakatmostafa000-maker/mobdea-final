package com.mobdea.education.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobdea.education.data.model.Student

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentsScreen(
    students: List<Student>,
    onSaveStudent: (Student) -> Unit,
    onDeleteStudent: (Student) -> Unit
) {
    var searchQuery by remember { MutableStateOf("") }
    var selectedGrade by remember { MutableStateOf("الكل") }
    var showDialog by remember { MutableStateOf(false) }
    var editingStudent by remember { MutableStateOf<Student?>(null) }

    val context = LocalContext.current

    val grades = listOf("الكل", "الصف الرابع الابتدائي", "الصف الخامس الابتدائي", "الصف السادس الابتدائي", "الصف الأول الإعدادي", "الصف الثاني الإعدادي")

    val filteredStudents = students.filter { student ->
        (selectedGrade == "الكل" || student.grade == selectedGrade) &&
                (searchQuery.isEmpty() || student.name.contains(searchQuery) || student.code.toString().contains(searchQuery))
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingStudent = null
                    showDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة طالب", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("بحث عن طالب بالإسم أو الكود") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Grade Filter Chips
            ScrollableTabRow(
                selectedTabIndex = grades.indexOf(selectedGrade).coerceAtLeast(0),
                edgePadding = 0.dp
            ) {
                grades.forEach { grade ->
                    Tab(
                        selected = selectedGrade == grade,
                        onClick = { selectedGrade = grade },
                        text = { Text(grade, fontSize = 13.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "عدد الطلاب: ${filteredStudents.size}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Students Roster
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredStudents, key = { it.id }) { student ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${student.code}. ${student.name}",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${student.grade} • ${student.group}",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "ولي الأمر: ${student.guardianPhone} | سعر الحصة: ${student.sessionPrice} ج.م",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Row {
                                IconButton(onClick = {
                                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${student.guardianPhone}"))
                                    context.startActivity(intent)
                                }) {
                                    Icon(Icons.Default.Phone, contentDescription = "اتصال", tint = MaterialTheme.colorScheme.secondary)
                                }

                                IconButton(onClick = {
                                    editingStudent = student
                                    showDialog = true
                                }) {
                                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
                                }

                                IconButton(onClick = { onDeleteStudent(student) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        StudentFormDialog(
            student = editingStudent,
            nextCode = (students.maxOfOrNull { it.code } ?: 0) + 1,
            onDismiss = { showDialog = false },
            onSave = { student ->
                onSaveStudent(student)
                showDialog = false
            }
        )
    }
}

@Composable
fun StudentFormDialog(
    student: Student?,
    nextCode: Int,
    onDismiss: () -> Unit,
    onSave: (Student) -> Unit
) {
    var code by remember { MutableStateOf(student?.code?.toString() ?: nextCode.toString()) }
    var name by remember { MutableStateOf(student?.name ?: "") }
    var grade by remember { MutableStateOf(student?.grade ?: "الصف السادس الابتدائي") }
    var group by remember { MutableStateOf(student?.group ?: "مجموعة 5 مساءً") }
    var phone by remember { MutableStateOf(student?.guardianPhone ?: "010") }
    var price by remember { MutableStateOf(student?.sessionPrice?.toString() ?: "50") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (student == null) "إضافة طالب جديد" else "تعديل بيانات طالب") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("كود الطالب") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الطالب الرباعي") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = grade,
                    onValueChange = { grade = it },
                    label = { Text("الصف الدراسي") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = group,
                    onValueChange = { group = it },
                    label = { Text("المجموعة / الوقت") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم هاتف ولي الأمر") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = price,
                    onValueChange = { price = it },
                    label = { Text("سعر الحصة (ج.م)") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotEmpty()) {
                        onSave(
                            Student(
                                id = student?.id ?: 0,
                                code = code.toIntOrNull() ?: nextCode,
                                name = name,
                                grade = grade,
                                group = group,
                                guardianPhone = phone,
                                sessionPrice = price.toIntOrNull() ?: 50
                            )
                        )
                    }
                }
            ) {
                Text("حفظ البيانات")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
