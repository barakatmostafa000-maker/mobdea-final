package com.mobdea.education.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobdea.education.data.model.PaymentRecord
import com.mobdea.education.data.model.Student

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentsScreen(
    students: List<Student>,
    payments: List<PaymentRecord>,
    onAddPayment: (Long, Int, String, String) -> Unit
) {
    var showDialog by remember { MutableStateOf(false) }
    val totalAmount = payments.sumOf { it.amount }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showDialog = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "تسجيل دفع", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "إدارة المدفوعات والاشتراكات",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("إجمالي الإيرادات المسجلة", fontSize = 13.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text("$totalAmount ج.م", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(36.dp), tint = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(payments) { payment ->
                    val student = students.find { it.id == payment.studentId }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = student?.name ?: "طالب #${payment.studentId}",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "الفترة: ${payment.period} • التاريخ: ${payment.date}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.secondaryContainer
                            ) {
                                Text(
                                    text = "+${payment.amount} ج.م",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        PaymentFormDialog(
            students = students,
            onDismiss = { showDialog = false },
            onSave = { studentId, amount, period, notes ->
                onAddPayment(studentId, amount, period, notes)
                showDialog = false
            }
        )
    }
}

@Composable
fun PaymentFormDialog(
    students: List<Student>,
    onDismiss: () -> Unit,
    onSave: (Long, Int, String, String) -> Unit
) {
    var selectedStudentId by remember { MutableStateOf(students.firstOrNull()?.id ?: 0L) }
    var amount by remember { MutableStateOf("50") }
    var period by remember { MutableStateOf("حصة") }
    var notes by remember { MutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسجيل عملية دفع") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("اختر الطالب:", fontWeight = FontWeight.Bold)
                ScrollableTabRow(
                    selectedTabIndex = students.indexOfFirst { it.id == selectedStudentId }.coerceAtLeast(0),
                    edgePadding = 0.dp
                ) {
                    students.forEach { std ->
                        Tab(
                            selected = selectedStudentId == std.id,
                            onClick = {
                                selectedStudentId = std.id
                                amount = std.sessionPrice.toString()
                            },
                            text = { Text(std.name, fontSize = 12.sp) }
                        )
                    }
                }

                OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("المبلغ (ج.م)") })
                OutlinedTextField(value = period, onValueChange = { period = it }, label = { Text("نوع الدفع (حصة / شهر)") })
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("ملاحظات") })
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(selectedStudentId, amount.toIntOrNull() ?: 50, period, notes)
            }) { Text("حفظ الدفعة") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
