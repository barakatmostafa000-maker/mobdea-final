package com.mobdea.education.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobdea.education.data.model.Question

@Composable
fun GamesScreen(questions: List<Question>) {
    var gameStarted by remember { MutableStateOf(false) }
    var score by remember { MutableStateOf(0) }
    var currentQuestionIndex by remember { MutableStateOf(0) }
    var selectedOption by remember { MutableStateOf<Int?>(null) }
    var isAnswered by remember { MutableStateOf(false) }

    val gameQuestions = remember(questions) {
        questions.filter { it.options.isNotEmpty() }.shuffled().take(5)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Game Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.EmojiEvents, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color(0xFFF59E0B))
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "مسابقة المبدع السريعة 🏆",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = "تحدي الأسئلة التفاعلي لطلاب الحصة",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (!gameStarted) {
            Button(
                onClick = {
                    gameStarted = true
                    score = 0
                    currentQuestionIndex = 0
                    selectedOption = null
                    isAnswered = false
                },
                modifier = Modifier.height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("بدء اللعبة الآن", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        } else if (currentQuestionIndex < gameQuestions.size) {
            val q = gameQuestions[currentQuestionIndex]

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("سؤال ${currentQuestionIndex + 1} من ${gameQuestions.size}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("النقاط: $score", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = q.text,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    q.options.forEachIndexed { idx, opt ->
                        val isCorrect = idx == q.answerIndex
                        val isSelected = selectedOption == idx

                        OutlinedButton(
                            onClick = {
                                if (!isAnswered) {
                                    selectedOption = idx
                                    isAnswered = true
                                    if (isCorrect) score += 10
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (isAnswered && isCorrect) Color(0xFFD1FAE5)
                                else if (isAnswered && isSelected && !isCorrect) Color(0xFFFEE2E2)
                                else MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Text(
                                text = opt,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(vertical = 4.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    if (isAnswered) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                currentQuestionIndex += 1
                                selectedOption = null
                                isAnswered = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("السؤال التالي")
                        }
                    }
                }
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("انتهت المسابقة! 🎉", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("النتيجة النهائية: $score نقطة", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            gameStarted = false
                        }
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إعادة اللعب")
                    }
                }
            }
        }
    }
}
