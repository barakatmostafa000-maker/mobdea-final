package com.mobdea.education.data.repository

import com.mobdea.education.data.local.*
import com.mobdea.education.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json

class MobdeaRepository(private val db: MobdeaDatabase) {

    val students: Flow<List<Student>> = db.studentDao().getAllStudents().map { list ->
        list.map { entity ->
            Student(
                id = entity.id,
                code = entity.code,
                name = entity.name,
                grade = entity.grade,
                group = entity.group,
                guardianPhone = entity.guardianPhone,
                sessionPrice = entity.sessionPrice,
                permissions = StudentPermissions(
                    games = entity.gamesPermission,
                    grades = entity.gradesPermission,
                    content = entity.contentPermission
                ),
                parentPermissions = ParentPermissions(
                    attendance = entity.parentAttendancePermission,
                    grades = entity.parentGradesPermission,
                    dues = entity.parentDuesPermission
                )
            )
        }
    }

    val sessions: Flow<List<Session>> = db.sessionDao().getAllSessions().map { list ->
        list.map { entity ->
            Session(
                id = entity.id,
                title = entity.title,
                group = entity.group,
                day = entity.day,
                time = entity.time,
                price = entity.price,
                current = entity.current
            )
        }
    }

    val attendance: Flow<List<AttendanceRecord>> = db.attendanceDao().getAllAttendance().map { list ->
        list.map { entity ->
            AttendanceRecord(
                id = entity.id,
                studentId = entity.studentId,
                sessionId = entity.sessionId,
                date = entity.date,
                status = entity.status,
                notes = entity.notes
            )
        }
    }

    val grades: Flow<List<GradeRecord>> = db.gradeDao().getAllGrades().map { list ->
        list.map { entity ->
            GradeRecord(
                id = entity.id,
                studentId = entity.studentId,
                exam = entity.exam,
                score = entity.score,
                total = entity.total,
                date = entity.date,
                weakness = entity.weakness,
                strength = entity.strength
            )
        }
    }

    val questions: Flow<List<Question>> = db.questionDao().getAllQuestions().map { list ->
        list.map { entity ->
            val options = runCatching { Json.decodeFromString<List<String>>(entity.optionsJson) }.getOrDefault(emptyList())
            val clues = runCatching { Json.decodeFromString<List<String>>(entity.cluesJson) }.getOrDefault(emptyList())
            val events = runCatching { Json.decodeFromString<List<String>>(entity.eventsJson) }.getOrDefault(emptyList())
            Question(
                id = entity.id,
                gradeKey = entity.gradeKey,
                grade = entity.grade,
                term = entity.term,
                unit = entity.unit,
                lesson = entity.lesson,
                topic = entity.topic,
                type = entity.type,
                text = entity.text,
                maxScore = entity.maxScore,
                difficulty = entity.difficulty,
                options = options,
                answerIndex = entity.answerIndex,
                answer = entity.answer,
                clues = clues,
                events = events
            )
        }
    }

    val payments: Flow<List<PaymentRecord>> = db.paymentDao().getAllPayments().map { list ->
        list.map { entity ->
            PaymentRecord(
                id = entity.id,
                studentId = entity.studentId,
                amount = entity.amount,
                date = entity.date,
                period = entity.period,
                notes = entity.notes
            )
        }
    }

    val content: Flow<List<ContentItem>> = db.contentDao().getAllContent().map { list ->
        list.map { entity ->
            val tags = runCatching { Json.decodeFromString<List<String>>(entity.tagsJson) }.getOrDefault(emptyList())
            ContentItem(
                id = entity.id,
                title = entity.title,
                grade = entity.grade,
                term = entity.term,
                unit = entity.unit,
                lesson = entity.lesson,
                type = entity.type,
                url = entity.url,
                notes = entity.notes,
                tags = tags
            )
        }
    }

    val settings: Flow<AppSettings> = db.settingsDao().getSettings().map { entity ->
        entity?.let {
            AppSettings(
                adminPin = it.adminPin,
                lockEnabled = it.lockEnabled,
                lockAfterMinutes = it.lockAfterMinutes,
                voiceEnabled = it.voiceEnabled,
                welcomeVoice = it.welcomeVoice,
                visibleGames = it.visibleGames,
                visibleGrades = it.visibleGrades,
                visiblePayments = it.visiblePayments,
                visibleReports = it.visibleReports,
                visibleMessages = it.visibleMessages
            )
        } ?: AppSettings()
    }

    suspend fun saveStudent(student: Student) {
        val entity = StudentEntity(
            id = student.id,
            code = student.code,
            name = student.name,
            grade = student.grade,
            group = student.group,
            guardianPhone = student.guardianPhone,
            sessionPrice = student.sessionPrice,
            gamesPermission = student.permissions.games,
            gradesPermission = student.permissions.grades,
            contentPermission = student.permissions.content,
            parentAttendancePermission = student.parentPermissions.attendance,
            parentGradesPermission = student.parentPermissions.grades,
            parentDuesPermission = student.parentPermissions.dues
        )
        db.studentDao().insertStudent(entity)
    }

    suspend fun deleteStudent(student: Student) {
        val entity = StudentEntity(
            id = student.id,
            code = student.code,
            name = student.name,
            grade = student.grade,
            group = student.group,
            guardianPhone = student.guardianPhone,
            sessionPrice = student.sessionPrice,
            gamesPermission = student.permissions.games,
            gradesPermission = student.permissions.grades,
            contentPermission = student.permissions.content,
            parentAttendancePermission = student.parentPermissions.attendance,
            parentGradesPermission = student.parentPermissions.grades,
            parentDuesPermission = student.parentPermissions.dues
        )
        db.studentDao().deleteStudent(entity)
    }

    suspend fun saveSession(session: Session) {
        val entity = SessionEntity(
            id = session.id,
            title = session.title,
            group = session.group,
            day = session.day,
            time = session.time,
            price = session.price,
            current = session.current
        )
        db.sessionDao().insertSession(entity)
    }

    suspend fun setCurrentSession(sessionId: Long) {
        db.sessionDao().setCurrentSession(sessionId)
    }

    suspend fun recordAttendance(studentId: Long, sessionId: Long, date: String, status: String, notes: String = "") {
        db.attendanceDao().insertAttendance(
            AttendanceEntity(studentId = studentId, sessionId = sessionId, date = date, status = status, notes = notes)
        )
    }

    suspend fun removeAttendance(studentId: Long, sessionId: Long, date: String) {
        db.attendanceDao().deleteAttendanceRecord(studentId, sessionId, date)
    }

    suspend fun addGrade(grade: GradeRecord) {
        db.gradeDao().insertGrade(
            GradeEntity(
                studentId = grade.studentId,
                exam = grade.exam,
                score = grade.score,
                total = grade.total,
                date = grade.date,
                weakness = grade.weakness,
                strength = grade.strength
            )
        )
    }

    suspend fun addPayment(payment: PaymentRecord) {
        db.paymentDao().insertPayment(
            PaymentEntity(
                studentId = payment.studentId,
                amount = payment.amount,
                date = payment.date,
                period = payment.period,
                notes = payment.notes
            )
        )
    }

    suspend fun addQuestion(question: Question) {
        db.questionDao().insertQuestion(
            QuestionEntity(
                id = question.id.ifEmpty { "q-${System.currentTimeMillis()}" },
                gradeKey = question.gradeKey,
                grade = question.grade,
                term = question.term,
                unit = question.unit,
                lesson = question.lesson,
                topic = question.topic,
                type = question.type,
                text = question.text,
                maxScore = question.maxScore,
                difficulty = question.difficulty,
                optionsJson = Json.encodeToString(question.options),
                answerIndex = question.answerIndex,
                answer = question.answer,
                cluesJson = Json.encodeToString(question.clues),
                eventsJson = Json.encodeToString(question.events)
            )
        )
    }

    suspend fun addContent(contentItem: ContentItem) {
        db.contentDao().insertContent(
            ContentEntity(
                title = contentItem.title,
                grade = contentItem.grade,
                term = contentItem.term,
                unit = contentItem.unit,
                lesson = contentItem.lesson,
                type = contentItem.type,
                url = contentItem.url,
                notes = contentItem.notes,
                tagsJson = Json.encodeToString(contentItem.tags)
            )
        )
    }

    suspend fun updateSettings(appSettings: AppSettings) {
        db.settingsDao().saveSettings(
            SettingsEntity(
                id = 1,
                adminPin = appSettings.adminPin,
                lockEnabled = appSettings.lockEnabled,
                lockAfterMinutes = appSettings.lockAfterMinutes,
                voiceEnabled = appSettings.voiceEnabled,
                welcomeVoice = appSettings.welcomeVoice,
                visibleGames = appSettings.visibleGames,
                visibleGrades = appSettings.visibleGrades,
                visiblePayments = appSettings.visiblePayments,
                visibleReports = appSettings.visibleReports,
                visibleMessages = appSettings.visibleMessages
            )
        )
    }
}
