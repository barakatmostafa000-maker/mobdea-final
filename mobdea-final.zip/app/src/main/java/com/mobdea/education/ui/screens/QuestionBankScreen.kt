package com.mobdea.education.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobdea.education.data.model.Question

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuestionBankScreen(
    questions: List<Question>,
    onAddQuestion: (Question) -> Unit
) {
    var selectedGradeKey by remember { MutableStateOf("الكل") }
    var selectedType by remember { MutableStateOf("الكل") }
    var showDialog by remember { MutableStateOf(false) }

    val filteredQuestions = questions.filter { q ->
        (selectedGradeKey == "الكل" || q.gradeKey == selectedGradeKey || q.grade == selectedGradeKey) &&
                (selectedType == "الكل" || q.type == selectedType)
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showDialog = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة سؤال", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "بنك الأسئلة والاختبارات التفاعلي",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Grade Filters
            ScrollableTabRow(
                selectedTabIndex = listOf("الكل", "4", "5", "6", "7", "8").indexOf(selectedGradeKey).coerceAtLeast(0),
                edgePadding = 0.dp
            ) {
                listOf("الكل", "4", "5", "6", "7", "8").forEach { grade ->
                    val label = when (grade) {
                        "4" -> "رابع"
                        "5" -> "خامس"
                        "6" -> "سادس"
                        "7" -> "أولى إعدادي"
                        "8" -> "ثانية إعدادي"
                        else -> "جميع الصفوف"
                    }
                    Tab(
                        selected = selectedGradeKey == grade,
                        onClick = { selectedGradeKey = grade },
                        text = { Text(label, fontSize = 12.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "عدد الأسئلة المتاحة: ${filteredQuestions.size}",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredQuestions, key = { it.id }) { q ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Text(
                                        text = "${q.grade} • ${q.unit}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer
                                ) {
                                    Text(
                                        text = q.type.uppercase(),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = q.text,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )

                            if (q.options.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                q.options.forEachIndexed { idx, opt ->
                                    val isCorrect = idx == q.answerIndex
                                    Text(
                                        text = "• $opt",
                                        fontSize = 13.sp,
                                        color = if (isCorrect) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = if (isCorrect) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }

                            if (q.clues.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("تلميحات: ${q.clues.joinToString(" ، ")}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                Text("الإجابة: ${q.answer}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        QuestionFormDialog(
            onDismiss = { showDialog = false },
            onSave = { question ->
                onAddQuestion(question)
                showDialog = false
            }
        )
    }
}

@Composable
fun QuestionFormDialog(
    onDismiss: () -> Unit,
    onSave: (Question) -> Unit
) {
    var text by remember { MutableStateOf("") }
    var grade by remember { MutableStateOf("الصف السادس الابتدائي") }
    var gradeKey by remember { MutableStateOf("6") }
    var unit by remember { MutableStateOf("الوحدة الأولى") }
    var lesson by remember { MutableStateOf("وطننا العربي") }
    var opt1 by remember { MutableStateOf("") }
    var opt2 by remember { MutableStateOf("") }
    var opt3 by remember { MutableStateOf("") }
    var opt4 by remember { MutableStateOf("") }
    var answer by remember { MutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة سؤال جديد للبنك") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("نص السؤال") })
                OutlinedTextField(value = grade, onValueChange = { grade = it }, label = { Text("الصف الدراسي") })
                OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("الوحدة") })
                OutlinedTextField(value = opt1, onValueChange = { opt1 = it }, label = { Text("الخيار الأول") })
                OutlinedTextField(value = opt2, onValueChange = { opt2 = it }, label = { Text("الخيار الثاني") })
                OutlinedTextField(value = answer, onValueChange = { answer = it }, label = { Text("الإجابة الصحيحة") })
            }
        },
        confirmButton = {
            Button(onClick = {
                if (text.isNotEmpty()) {
                    val opts = listOf(opt1, opt2).filter { it.isNotEmpty() }
                    onSave(
                        Question(
                            id = "q-custom-${System.currentTimeMillis()}",
                            gradeKey = gradeKey,
                            grade = grade,
                            term = "الترم الأول",
                            unit = unit,
                            lesson = lesson,
                            topic = "عام",
                            type = "mcq",
                            text = text,
                            options = opts,
                            answer = answer
                        )
                    )
                }
            }) { Text("حفظ السؤال") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
