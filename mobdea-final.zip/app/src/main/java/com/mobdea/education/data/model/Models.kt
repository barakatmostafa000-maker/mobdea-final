package com.mobdea.education.data.model

import kotlinx.serialization.Serializable

@Serializable
data class StudentPermissions(
    val games: Boolean = true,
    val grades: Boolean = true,
    val content: Boolean = true
)

@Serializable
data class ParentPermissions(
    val attendance: Boolean = true,
    val grades: Boolean = true,
    val dues: Boolean = true
)

data class Student(
    val id: Long = 0,
    val code: Int,
    val name: String,
    val grade: String,
    val group: String,
    val guardianPhone: String,
    val sessionPrice: Int = 50,
    val permissions: StudentPermissions = StudentPermissions(),
    val parentPermissions: ParentPermissions = ParentPermissions()
)

data class Session(
    val id: Long = 0,
    val title: String,
    val group: String,
    val day: String,
    val time: String,
    val price: Int,
    val current: Boolean = false
)

data class AttendanceRecord(
    val id: Long = 0,
    val studentId: Long,
    val studentName: String = "",
    val sessionId: Long,
    val sessionTitle: String = "",
    val date: String,
    val status: String, // "حاضر", "غائب", "متأخر"
    val notes: String = ""
)

data class GradeRecord(
    val id: Long = 0,
    val studentId: Long,
    val studentName: String = "",
    val exam: String,
    val score: Int,
    val total: Int = 20,
    val date: String,
    val weakness: String = "",
    val strength: String = ""
)

data class Question(
    val id: String,
    val gradeKey: String,
    val grade: String,
    val term: String,
    val unit: String,
    val lesson: String,
    val topic: String,
    val type: String, // "mcq", "tf", "character", "timeline"
    val text: String,
    val maxScore: Int = 1,
    val difficulty: String = "متوسط",
    val options: List<String> = emptyList(),
    val answerIndex: Int = 0,
    val answer: String = "",
    val clues: List<String> = emptyList(),
    val events: List<String> = emptyList()
)

data class Exam(
    val id: String,
    val title: String,
    val grade: String,
    val questionIds: List<String>,
    val active: Boolean = true
)

data class PaymentRecord(
    val id: Long = 0,
    val studentId: Long,
    val studentName: String = "",
    val amount: Int,
    val date: String,
    val period: String, // "حصة" or "شهر"
    val notes: String = ""
)

data class ContentItem(
    val id: Long = 0,
    val title: String,
    val grade: String,
    val term: String,
    val unit: String,
    val lesson: String,
    val type: String, // "pdf", "map", "summary"
    val url: String = "#",
    val notes: String = "",
    val tags: List<String> = emptyList()
)

data class AppSettings(
    val adminPin: String = "123456",
    val lockEnabled: Boolean = true,
    val lockAfterMinutes: Int = 10,
    val voiceEnabled: Boolean = true,
    val welcomeVoice: Boolean = true,
    val visibleGames: Boolean = true,
    val visibleGrades: Boolean = true,
    val visiblePayments: Boolean = true,
    val visibleReports: Boolean = true,
    val visibleMessages: Boolean = true
)
