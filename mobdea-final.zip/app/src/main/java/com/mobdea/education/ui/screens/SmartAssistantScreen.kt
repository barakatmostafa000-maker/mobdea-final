package com.mobdea.education.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobdea.education.data.model.Student

data class ChatMessage(val sender: String, val text: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartAssistantScreen(students: List<Student>) {
    var userPrompt by remember { MutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("ai", "أهلاً بك! أنا المساعد التعليمي الذكي لمنصة المُبدع. كيف يمكنني مساعدتك في تحضير الحصص أو صياغة الأسئلة اليوم؟")
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "المساعد الذكي للمعلم",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Preset Prompt Quick Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = {
                    val prompt = "اقترح 3 أسئلة اختيار من متعدد عن موقع الوطن العربي للصف السادس."
                    messages.add(ChatMessage("user", prompt))
                    messages.add(ChatMessage("ai", "إليك الأسئلة المقترحة:\n1. الدولة العربية التي تقع في المحيط الهندي؟ (جزر القمر)\n2. أكبر الهضاب مساحة في الوطن العربي؟ (إفريقيا الشمالية)\n3. يمر مدار السرطان في جنوب الوطن العربي؟ (صح)"))
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("صياغة أسئلة", fontSize = 11.sp)
            }

            OutlinedButton(
                onClick = {
                    val prompt = "اكتب خطة درس لمراجعة الوحدة الأولى."
                    messages.add(ChatMessage("user", prompt))
                    messages.add(ChatMessage("ai", "خطة الدرس المقترحة:\n• 10 دقائق: عصف ذهني لمفاهيم الخريطة والموقع الفلكي.\n• 20 دقيقة: حل أسئلة بنك الأسئلة التفاعلية.\n• 15 دقيقة: مسابقة سريعة بين الطلاب."))
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("خطة درس", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Chat History
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { msg ->
                val isUser = msg.sender == "user"
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.widthIn(max = 280.dp)
                    ) {
                        Text(
                            text = msg.text,
                            modifier = Modifier.padding(12.dp),
                            color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Message Input
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = userPrompt,
                onValueChange = { userPrompt = it },
                placeholder = { Text("اكتب استفسارك هنا...") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                singleLine = true
            )

            IconButton(
                onClick = {
                    if (userPrompt.isNotEmpty()) {
                        val text = userPrompt
                        userPrompt = ""
                        messages.add(ChatMessage("user", text))
                        messages.add(ChatMessage("ai", "تم تحليل الطلب: \"$text\". جاري معالجة البيانات وإعداد الإجابة التعليمية المناسبة."))
                    }
                },
                colors = IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.Send, contentDescription = null, tint = Color.White)
            }
        }
    }
}
