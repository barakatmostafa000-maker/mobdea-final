-- SPRINT 2: Live Learning Platform & Multiplayer System Database Schema
-- Includes RLS (Row Level Security), Foreign Keys, and Performance Indexes

-- 1. Live Sessions Table
CREATE TABLE IF NOT EXISTS public.live_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    teacher_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    group_name VARCHAR(100),
    join_code VARCHAR(10) UNIQUE NOT NULL,
    status VARCHAR(20) DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'live', 'paused', 'ended')),
    recording_status VARCHAR(20) DEFAULT 'idle' CHECK (recording_status IN ('idle', 'recording', 'paused', 'stopped')),
    settings JSONB DEFAULT '{"allow_mic": true, "allow_chat": true, "allow_whiteboard": false}'::jsonb,
    started_at TIMESTAMPTZ,
    ended_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 2. Session Participants Table
CREATE TABLE IF NOT EXISTS public.session_participants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES public.live_sessions(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    user_name VARCHAR(100) NOT NULL,
    user_role VARCHAR(20) NOT NULL,
    hand_raised BOOLEAN DEFAULT false,
    mic_granted BOOLEAN DEFAULT false,
    whiteboard_granted BOOLEAN DEFAULT false,
    screen_share_granted BOOLEAN DEFAULT false,
    joined_at TIMESTAMPTZ DEFAULT now(),
    left_at TIMESTAMPTZ,
    UNIQUE(session_id, user_id)
);

-- 3. Screen Share Sessions Table
CREATE TABLE IF NOT EXISTS public.screen_share_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES public.live_sessions(id) ON DELETE CASCADE,
    presenter_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    stream_type VARCHAR(50) DEFAULT 'screen' CHECK (stream_type IN ('screen', 'window', 'tab')),
    is_active BOOLEAN DEFAULT true,
    webrtc_offer JSONB,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 4. Whiteboard States Table
CREATE TABLE IF NOT EXISTS public.whiteboard_states (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES public.live_sessions(id) ON DELETE CASCADE,
    strokes JSONB DEFAULT '[]'::jsonb,
    background_color VARCHAR(20) DEFAULT '#ffffff',
    updated_by UUID REFERENCES auth.users(id),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- 5. Recordings Table
CREATE TABLE IF NOT EXISTS public.recordings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID REFERENCES public.live_sessions(id) ON DELETE SET NULL,
    title VARCHAR(255) NOT NULL,
    teacher_id UUID NOT NULL REFERENCES auth.users(id),
    file_url TEXT NOT NULL,
    duration_seconds INT DEFAULT 0,
    size_bytes BIGINT DEFAULT 0,
    is_shared BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 6. Teams Table
CREATE TABLE IF NOT EXISTS public.teams (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    created_by UUID NOT NULL REFERENCES auth.users(id),
    logo_url TEXT,
    points INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 7. Team Members Table
CREATE TABLE IF NOT EXISTS public.team_members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    team_id UUID NOT NULL REFERENCES public.teams(id) ON DELETE CASCADE,
    student_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    role VARCHAR(20) DEFAULT 'member' CHECK (role IN ('leader', 'member')),
    joined_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(team_id, student_id)
);

-- 8. Game Rooms Table
CREATE TABLE IF NOT EXISTS public.game_rooms (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(10) UNIQUE NOT NULL,
    mode VARCHAR(30) NOT NULL CHECK (mode IN ('pvp', 'pvai', 'team_vs_team', 'class_vs_class')),
    status VARCHAR(20) DEFAULT 'waiting' CHECK (status IN ('waiting', 'active', 'finished')),
    created_by UUID NOT NULL REFERENCES auth.users(id),
    game_state JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 9. Game Invites Table
CREATE TABLE IF NOT EXISTS public.game_invites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID NOT NULL REFERENCES public.game_rooms(id) ON DELETE CASCADE,
    inviter_id UUID NOT NULL REFERENCES auth.users(id),
    invite_code VARCHAR(12) UNIQUE NOT NULL,
    is_used BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 10. Tournaments Table
CREATE TABLE IF NOT EXISTS public.tournaments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(255) NOT NULL,
    type VARCHAR(20) NOT NULL CHECK (type IN ('individual', 'team')),
    status VARCHAR(20) DEFAULT 'upcoming' CHECK (status IN ('upcoming', 'ongoing', 'completed')),
    created_by UUID NOT NULL REFERENCES auth.users(id),
    brackets JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 11. Matches Table
CREATE TABLE IF NOT EXISTS public.matches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tournament_id UUID REFERENCES public.tournaments(id) ON DELETE CASCADE,
    round_number INT NOT NULL,
    participant_a_id UUID REFERENCES auth.users(id),
    participant_b_id UUID REFERENCES auth.users(id),
    winner_id UUID REFERENCES auth.users(id),
    score_a INT DEFAULT 0,
    score_b INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'live', 'finished')),
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 12. Leaderboards Table
CREATE TABLE IF NOT EXISTS public.leaderboards (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_id UUID NOT NULL,
    entity_type VARCHAR(20) NOT NULL CHECK (entity_type IN ('student', 'team', 'class')),
    entity_name VARCHAR(100) NOT NULL,
    score INT DEFAULT 0,
    rank INT DEFAULT 0,
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Row Level Security (RLS) Policies
ALTER TABLE public.live_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.session_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.recordings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.game_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tournaments ENABLE ROW LEVEL SECURITY;

-- Read Policies (All authenticated users can read)
CREATE POLICY "Allow authenticated read live_sessions" ON public.live_sessions FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read participants" ON public.session_participants FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read recordings" ON public.recordings FOR SELECT TO authenticated USING (is_shared = true OR teacher_id = auth.uid());
CREATE POLICY "Allow authenticated read teams" ON public.teams FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read game_rooms" ON public.game_rooms FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read tournaments" ON public.tournaments FOR SELECT TO authenticated USING (true);

-- Indexes for Query Performance
CREATE INDEX IF NOT EXISTS idx_live_sessions_join_code ON public.live_sessions(join_code);
CREATE INDEX IF NOT EXISTS idx_session_participants_session ON public.session_participants(session_id);
CREATE INDEX IF NOT EXISTS idx_game_rooms_code ON public.game_rooms(code);
CREATE INDEX IF NOT EXISTS idx_game_invites_code ON public.game_invites(invite_code);
