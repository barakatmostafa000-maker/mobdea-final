import React, { useState, useEffect } from 'react';
import { 
  Lightbulb, ArrowRight, Clock, Award, Flame, CheckCircle2, 
  XCircle, AlertCircle, RefreshCw, Zap, Trophy, Shield
} from 'lucide-react';

export default function QuestionPanelCard({ 
  currentQuestion, 
  questionIndex, 
  totalQuestions, 
  score, 
  combo, 
  accuracy, 
  onAnswer, 
  onNextQuestion, 
  onUseClue, 
  cluesUsed,
  lastFeedback,
  attemptsLeft,
  maxAttempts,
  timeLeft
}) {

  const [selectedOption, setSelectedOption] = useState(null);
  const [showClue, setShowClue] = useState(false);

  // Reset selected state when question changes
  useEffect(() => {
    setSelectedOption(null);
    setShowClue(false);
  }, [currentQuestion]);

  if (!currentQuestion) {
    return (
      <div className="w-full sm:w-80 bg-slate-900/90 border-2 border-amber-600/70 p-6 rounded-3xl backdrop-blur-xl text-center text-amber-200">
        <Trophy className="w-12 h-12 text-amber-400 mx-auto mb-3 animate-bounce" />
        <h3 className="font-reem text-xl font-bold text-amber-300">أحسنت! أكملت التحدي بنجاح 🏆</h3>
        <p className="text-xs text-amber-200/80 mt-2 font-ibm">
          نقاطك الإجمالية: <span className="font-extrabold text-amber-400 text-sm">{score}</span>
        </p>
      </div>
    );
  }

  const handleOptionClick = (optionText) => {
    setSelectedOption(optionText);
    onAnswer(optionText);
  };

  const handleToggleClue = () => {
    setShowClue(!showClue);
    onUseClue();
  };

  // Format time as MM:SS
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="w-full sm:w-80 lg:w-90 bg-slate-950/90 border-2 border-amber-600/70 rounded-3xl p-5 shadow-2xl backdrop-blur-2xl text-amber-100 font-ibm relative z-20 flex flex-col justify-between space-y-4">
      
      {/* HEADER SECTION */}
      <div>
        <div className="flex items-center justify-between text-xs font-bold text-amber-400 mb-2">
          <span className="bg-amber-950/80 border border-amber-700/60 px-3 py-1 rounded-xl shadow-inner">
            السؤال الحالي ({questionIndex + 1}/{totalQuestions})
          </span>
          <span className="flex items-center gap-1 text-amber-300">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-mono text-sm">{formatTime(timeLeft)}</span>
          </span>
        </div>

        {/* QUESTION TEXT */}
        <h3 className="font-reem text-base sm:text-lg font-bold text-amber-200 leading-snug mb-3">
          {currentQuestion.text}
        </h3>

        {/* PROGRESS BAR */}
        <div className="w-full h-2 bg-slate-900 rounded-full border border-amber-900/60 overflow-hidden mb-4">
          <div 
            className="h-full bg-gradient-to-r from-amber-600 to-amber-300 rounded-full transition-all duration-300"
            style={{ width: `${((questionIndex + 1) / totalQuestions) * 100}%` }}
          ></div>
        </div>

        {/* STATS METRICS GRID */}
        <div className="grid grid-cols-2 gap-2 text-center mb-4">
          
          <div className="bg-slate-900/80 border border-amber-900/60 p-2 rounded-2xl">
            <span className="text-[10px] text-amber-300/70 block font-bold">النقاط المحتسبة</span>
            <span className="text-sm font-black text-amber-400 font-mono">{score.toLocaleString()}</span>
          </div>

          <div className="bg-slate-900/80 border border-amber-900/60 p-2 rounded-2xl">
            <span className="text-[10px] text-amber-300/70 block font-bold">معامل الكومبو</span>
            <span className="text-sm font-black text-amber-300 font-mono">X{combo.toFixed(1)}</span>
          </div>

          <div className="bg-slate-900/80 border border-amber-900/60 p-2 rounded-2xl">
            <span className="text-[10px] text-amber-300/70 block font-bold">نسبة الدقة</span>
            <span className="text-sm font-black text-amber-300 font-mono">{accuracy}%</span>
          </div>

          <div className="bg-slate-900/80 border border-amber-900/60 p-2 rounded-2xl">
            <span className="text-[10px] text-amber-300/70 block font-bold">المحاولات المتبقية</span>
            <span className="text-sm font-black text-amber-400 font-mono">{attemptsLeft}/{maxAttempts}</span>
          </div>

        </div>

        {/* HINT / CLUE BOX IF OPEN */}
        {showClue && currentQuestion.clues && currentQuestion.clues.length > 0 && (
          <div className="p-3 bg-amber-950/80 border border-amber-500/60 rounded-2xl text-xs text-amber-200 font-bold space-y-1 mb-4 animate-fade-in shadow-inner">
            <div className="flex items-center gap-1.5 text-amber-400 mb-1">
              <Lightbulb className="w-4 h-4 fill-amber-400" />
              <span>دليل المساعدة:</span>
            </div>
            {currentQuestion.clues.map((clueText, idx) => (
              <p key={idx} className="text-[11px] leading-relaxed text-amber-100">
                • {clueText}
              </p>
            ))}
          </div>
        )}

        {/* MULTIPLE CHOICE OPTIONS */}
        <div className="space-y-2 mb-4">
          {currentQuestion.options.map((opt, i) => {
            const isSelected = selectedOption === opt;
            const isCorrect = opt === currentQuestion.correctAnswer;
            
            let btnStyle = "bg-slate-900/80 border-amber-900/60 text-amber-200 hover:bg-slate-900 hover:border-amber-500";
            if (selectedOption) {
              if (isCorrect) {
                btnStyle = "bg-emerald-950 border-emerald-500 text-emerald-200 font-black shadow-lg shadow-emerald-500/20";
              } else if (isSelected) {
                btnStyle = "bg-rose-950 border-rose-500 text-rose-200 font-black shadow-lg shadow-rose-500/20";
              }
            }

            return (
              <button
                key={i}
                onClick={() => handleOptionClick(opt)}
                disabled={selectedOption !== null}
                className={`w-full p-3 rounded-2xl border text-xs font-bold transition flex items-center justify-between text-right ${btnStyle}`}
              >
                <span>{opt}</span>
                {selectedOption && isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                {selectedOption && isSelected && !isCorrect && <XCircle className="w-4 h-4 text-rose-400" />}
              </button>
            );
          })}
        </div>

      </div>

      {/* ACTION BUTTONS (HINT & NEXT) */}
      <div className="space-y-3 pt-2 border-t border-amber-900/40">
        
        <div className="flex items-center gap-2">
          
          {/* Hint Button */}
          <button
            onClick={handleToggleClue}
            className={`p-3 rounded-2xl border transition flex items-center justify-center gap-1 text-xs font-bold ${
              showClue 
                ? 'bg-amber-500 text-slate-950 border-amber-400 font-extrabold'
                : 'bg-slate-900 text-amber-300 border-amber-800 hover:border-amber-500'
            }`}
            title="تلميح"
          >
            <Lightbulb className="w-4 h-4" />
          </button>

          {/* Next Button */}
          <button
            onClick={onNextQuestion}
            className="flex-1 py-3 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-reem font-extrabold text-xs sm:text-sm rounded-2xl shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2 transition"
          >
            <span>السؤال التالي</span>
            <ArrowRight className="w-4 h-4 rotate-180" />
          </button>

        </div>

        {/* FEEDBACK TOAST / BANNER */}
        {lastFeedback && (
          <div className={`p-3 rounded-2xl border text-xs font-bold flex items-center gap-2 animate-fade-in ${
            lastFeedback.isCorrect 
              ? 'bg-emerald-950/90 border-emerald-500 text-emerald-200' 
              : 'bg-rose-950/90 border-rose-500 text-rose-200'
          }`}>
            {lastFeedback.isCorrect ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-rose-400" />}
            <span>{lastFeedback.message}</span>
          </div>
        )}

        {/* EARNED REWARDS BANNER */}
        <div className="flex items-center justify-around text-[10px] font-extrabold text-amber-300/80 bg-slate-900/60 p-2 rounded-xl border border-amber-900/40">
          <span>+350 XP</span>
          <span>+50 ⭐</span>
          <span>+120 GC</span>
        </div>

      </div>

    </div>
  );
}
