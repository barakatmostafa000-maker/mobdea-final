import React, { useState } from 'react';
import { ICON_LIBRARY } from './MapData';
import { X, Search, Stamp, Sparkles } from 'lucide-react';

export default function IconLibraryDrawer({ isOpen, onClose, onAddIconToMap }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('الكل');

  if (!isOpen) return null;

  const categories = ['الكل', 'تضاريس', 'مسطحات', 'بيئة', 'موارد', 'صناعة', 'زراعة', 'مدن', 'مواصلات', 'علامات'];

  const filteredIcons = ICON_LIBRARY.filter((item) => {
    const matchesSearch = item.name.includes(searchTerm);
    const matchesCategory = activeCategory === 'الكل' || item.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-80 bg-slate-950/95 border-l-2 border-amber-600/70 p-5 shadow-2xl backdrop-blur-2xl flex flex-col justify-between animate-fade-in text-amber-100 font-ibm">
      
      {/* HEADER */}
      <div>
        <div className="flex items-center justify-between pb-3 border-b border-amber-900/60 mb-4">
          <div className="flex items-center gap-2">
            <Stamp className="w-5 h-5 text-amber-400" />
            <h2 className="font-reem text-lg font-bold text-amber-300">مكتبة الأيقونات الجغرافية</h2>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-xl bg-slate-900 text-amber-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* SEARCH INPUT */}
        <div className="relative mb-3">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث عن أيقونة (جبل، بترول، سد...)"
            className="w-full bg-slate-900 border border-amber-900/80 focus:border-amber-400 rounded-2xl py-2 px-3 pr-9 text-xs text-amber-100 placeholder-amber-400/40 outline-none transition"
          />
          <Search className="w-4 h-4 text-amber-400 absolute right-3 top-2.5 pointer-events-none" />
        </div>

        {/* CATEGORY TABS */}
        <div className="flex items-center gap-1 overflow-x-auto custom-scrollbar pb-2 mb-3 text-[11px] font-bold">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-2.5 py-1 rounded-xl whitespace-nowrap transition ${
                activeCategory === cat
                  ? 'bg-amber-500 text-slate-950 font-extrabold'
                  : 'bg-slate-900 text-amber-200/80 hover:bg-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* ICONS GRID */}
        <div className="grid grid-cols-3 gap-2.5 max-h-[calc(100vh-280px)] overflow-y-auto custom-scrollbar pr-1">
          {filteredIcons.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                onAddIconToMap(item);
                onClose();
              }}
              className="p-3 bg-slate-900/80 hover:bg-amber-950/80 border border-amber-900/60 hover:border-amber-500 rounded-2xl flex flex-col items-center justify-center gap-1 transition group shadow-md"
            >
              <span className="text-2xl group-hover:scale-125 transition-transform">{item.icon}</span>
              <span className="text-[10px] font-bold text-amber-200/90 text-center truncate w-full">{item.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* FOOTER INSTRUCTION */}
      <div className="pt-3 border-t border-amber-900/40 text-[10px] text-amber-300/80 text-center flex items-center justify-center gap-1">
        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
        <span>انقر على الأيقونة لإدراجها مباشرة على الخريطة</span>
      </div>

    </div>
  );
}
