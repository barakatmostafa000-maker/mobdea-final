import React, { useState } from 'react';
import { 
  Sparkles, Bell, Music, VolumeX, Settings, Maximize2, Minimize2, 
  Zap, Star, Award, ShieldCheck, UserCircle, Flame, Layers
} from 'lucide-react';

export default function TopMapHeader({ userStats, onToggleSound, soundEnabled, onOpenSettings }) {
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => console.log(err));
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
        setIsFullscreen(false);
      }
    }
  };

  const xpPercent = Math.min(100, Math.round((userStats.xp / userStats.maxXp) * 100));

  return (
    <header className="w-full bg-slate-950/95 border-b border-amber-500/30 px-3 py-2.5 sm:px-6 sm:py-3 flex flex-wrap items-center justify-between gap-3 text-amber-100 relative z-30 shadow-2xl backdrop-blur-xl">
      
      {/* BRANDING LOGO & EMBLEM */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-amber-600 via-amber-400 to-amber-200 p-0.5 shadow-lg shadow-amber-500/20 shrink-0">
          <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center border border-amber-900/80">
            <span className="font-reem text-base sm:text-lg font-black text-transparent bg-clip-text bg-gradient-to-tr from-amber-300 via-amber-200 to-amber-500">
              المُبدِع
            </span>
          </div>
        </div>

        <div className="hidden sm:block">
          <h1 className="font-reem text-lg sm:text-xl font-black text-amber-300 tracking-wide leading-tight">
            تحدي الخرائط
          </h1>
          <p className="text-[10px] sm:text-xs text-amber-200/70 font-ibm">
            تعليم تفاعلي • مسابقات وجغرافيا
          </p>
        </div>
      </div>

      {/* USER PROFILE & LEVEL PROGRESS */}
      <div className="flex items-center gap-3 bg-slate-900/90 border border-amber-900/60 px-3 py-1.5 rounded-2xl shadow-inner">
        
        {/* User Avatar */}
        <div className="relative">
          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-amber-300 p-0.5">
            <img 
              src={userStats.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150"} 
              alt={userStats.name} 
              className="w-full h-full rounded-full object-cover"
            />
          </div>
          <span className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 text-[9px] font-black px-1 rounded-full border border-slate-950">
            Lv.{userStats.level}
          </span>
        </div>

        {/* User Details & XP Bar */}
        <div className="min-w-[120px] sm:min-w-[160px]">
          <div className="flex items-center justify-between text-xs font-bold mb-0.5">
            <span className="text-amber-200 truncate max-w-[100px] sm:max-w-[130px]">{userStats.name}</span>
            <span className="text-[10px] text-amber-400/90 font-mono">{userStats.level} مستوى</span>
          </div>
          
          {/* XP Progress Bar */}
          <div className="w-full h-2 bg-slate-950 rounded-full border border-amber-900/50 overflow-hidden relative">
            <div 
              className="h-full bg-gradient-to-r from-amber-600 via-amber-400 to-amber-300 rounded-full transition-all duration-500"
              style={{ width: `${xpPercent}%` }}
            ></div>
          </div>
          <div className="flex justify-between items-center text-[9px] text-amber-400/70 font-mono mt-0.5">
            <span>{userStats.xp} / {userStats.maxXp} XP</span>
            <span>{xpPercent}%</span>
          </div>
        </div>

      </div>

      {/* STAT COUNTERS (COINS, STARS, ENERGY, STREAK) */}
      <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
        
        {/* Gold Coins */}
        <div className="flex items-center gap-1.5 bg-slate-900/90 border border-amber-600/40 px-2.5 py-1 rounded-xl text-xs font-bold text-amber-300 shadow">
          <span className="text-sm">🟡</span>
          <span className="font-mono">{userStats.goldCoins.toLocaleString()}</span>
        </div>

        {/* Stars */}
        <div className="flex items-center gap-1.5 bg-slate-900/90 border border-amber-600/40 px-2.5 py-1 rounded-xl text-xs font-bold text-amber-300 shadow">
          <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
          <span className="font-mono">{userStats.stars}</span>
        </div>

        {/* Energy */}
        <div className="flex items-center gap-1.5 bg-slate-900/90 border border-amber-600/40 px-2.5 py-1 rounded-xl text-xs font-bold text-amber-300 shadow">
          <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
          <span className="font-mono">{userStats.energy}/{userStats.maxEnergy}</span>
        </div>

        {/* Daily Streak */}
        <div className="hidden md:flex items-center gap-1.5 bg-gradient-to-r from-amber-950 to-amber-900 border border-amber-500/60 px-3 py-1 rounded-xl text-xs font-extrabold text-amber-300 shadow shadow-amber-500/10">
          <Flame className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
          <span>{userStats.streak} يوم متتالي</span>
        </div>

      </div>

      {/* QUICK UTILITY CONTROLS */}
      <div className="flex items-center gap-1.5">
        
        {/* Notifications */}
        <button 
          className="relative p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-amber-900/50 text-amber-300 transition"
          title="التنبيهات"
        >
          <Bell className="w-4 h-4" />
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white text-[9px] font-black rounded-full flex items-center justify-center">
            3
          </span>
        </button>

        {/* Music Sound */}
        <button 
          onClick={onToggleSound}
          className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-amber-900/50 text-amber-300 transition"
          title={soundEnabled ? "إيقاف الصوت" : "تشغيل الصوت"}
        >
          {soundEnabled ? <Music className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
        </button>

        {/* Fullscreen Toggle */}
        <button 
          onClick={toggleFullscreen}
          className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-amber-900/50 text-amber-300 transition hidden sm:flex"
          title="ملء الشاشة"
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>

        {/* Settings */}
        <button 
          onClick={onOpenSettings}
          className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-amber-900/50 text-amber-300 transition"
          title="الإعدادات"
        >
          <Settings className="w-4 h-4" />
        </button>

      </div>

    </header>
  );
}
