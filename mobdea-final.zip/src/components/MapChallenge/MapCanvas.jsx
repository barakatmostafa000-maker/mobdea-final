import React, { useState, useRef, useEffect } from 'react';
import { MAP_ENTITIES } from './MapData';
import { ZoomIn, ZoomOut, RefreshCw, Move, Trash2, RotateCw, Sparkles, MapPin } from 'lucide-react';

export default function MapCanvas({ 
  regionId, 
  layersState, 
  nightMode, 
  highlightedEntityId, 
  onEntityClick, 
  activeTool, 
  penColor, 
  placedIcons, 
  onUpdatePlacedIcons,
  activeMode
}) {

  // Canvas Viewport Transformation (Zoom & Pan)
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [startPan, setStartPan] = useState({ x: 0, y: 0 });

  // Whiteboard Drawing State
  const drawingCanvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [selectedPlacedIconId, setSelectedPlacedIconId] = useState(null);

  const containerRef = useRef(null);

  // Get current region entities
  const entities = MAP_ENTITIES[regionId] || MAP_ENTITIES.arab_world;

  // Handle Zoom In / Out
  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.3, 3.5));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.3, 0.6));
  const handleResetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Pan Mouse Handlers
  const handleMouseDown = (e) => {
    if (activeTool === 'select') {
      setIsPanning(true);
      setStartPan({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  };

  const handleMouseMove = (e) => {
    if (isPanning) {
      setPan({ x: e.clientX - startPan.x, y: e.clientY - startPan.y });
    }
  };

  const handleMouseUp = () => setIsPanning(false);

  // Whiteboard Drawing Handlers
  useEffect(() => {
    const canvas = drawingCanvasRef.current;
    if (!canvas) return;

    // Resize canvas to match container
    canvas.width = canvas.parentElement.clientWidth;
    canvas.height = canvas.parentElement.clientHeight;

    const ctx = canvas.getContext('2d');
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  }, [regionId]);

  const startCanvasDrawing = (e) => {
    if (activeTool !== 'pen' && activeTool !== 'eraser') return;
    setIsDrawing(true);

    const canvas = drawingCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();

    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
  };

  const drawOnCanvas = (e) => {
    if (!isDrawing) return;
    const canvas = drawingCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();

    if (activeTool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.arc(e.clientX - rect.left, e.clientY - rect.top, 15, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = penColor || '#f59e0b';
      ctx.lineWidth = 4;
      ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
      ctx.stroke();
    }
  };

  const stopCanvasDrawing = () => setIsDrawing(false);

  // Handle Placed Icon Move / Delete
  const handleDeleteIcon = (id) => {
    onUpdatePlacedIcons(placedIcons.filter((ic) => ic.id !== id));
    setSelectedPlacedIconId(null);
  };

  return (
    <div 
      ref={containerRef}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className={`relative w-full h-full min-h-[500px] lg:min-h-[600px] overflow-hidden rounded-3xl border-2 border-amber-600/50 shadow-2xl transition-colors duration-500 font-ibm select-none ${
        nightMode 
          ? 'bg-slate-950' 
          : layersState.satellite
          ? 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-amber-950/40 to-slate-950'
          : 'bg-slate-900'
      }`}
    >
      
      {/* SATELLITE TEXTURE GRID / AMBIENT SHADOWS */}
      <div className="absolute inset-0 bg-[radial-gradient(#d4af37_1px,transparent_1px)] [background-size:24px_24px] opacity-10 pointer-events-none"></div>

      {/* FLOATING ZOOM CONTROLS */}
      <div className="absolute top-4 left-4 z-30 flex flex-col gap-2 bg-slate-950/90 border border-amber-600/70 p-1.5 rounded-2xl shadow-xl backdrop-blur-md text-amber-200">
        <button 
          onClick={handleZoomIn} 
          className="p-2 hover:bg-slate-800 hover:text-amber-300 rounded-xl transition"
          title="تكبير"
        >
          <ZoomIn className="w-5 h-5" />
        </button>
        <button 
          onClick={handleZoomOut} 
          className="p-2 hover:bg-slate-800 hover:text-amber-300 rounded-xl transition"
          title="تصغير"
        >
          <ZoomOut className="w-5 h-5" />
        </button>
        <button 
          onClick={handleResetView} 
          className="p-2 hover:bg-slate-800 hover:text-amber-300 rounded-xl transition"
          title="إعادة ضبط"
        >
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>

      {/* MAIN VECTOR MAP SVG LAYER */}
      <div 
        className="w-full h-full flex items-center justify-center transition-transform duration-100 ease-out cursor-grab active:cursor-grabbing"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
        }}
      >
        <svg 
          viewBox="0 0 800 600" 
          className="w-full h-full max-w-[900px] max-h-[650px] drop-shadow-[0_10px_25px_rgba(212,175,55,0.15)]"
        >
          <defs>
            {/* Glowing filter for highlighted region */}
            <filter id="goldGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="6" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
            
            {/* Linear Gradient for Sea & Water */}
            <linearGradient id="seaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0f172a" />
              <stop offset="100%" stopColor="#1e293b" />
            </linearGradient>
          </defs>

          {/* WATER & BACKGROUND REGION SHAPES */}
          <rect width="800" height="600" fill="url(#seaGrad)" rx="20" />

          {/* RENDER GEOGRAPHICAL ENTITIES */}
          {entities.map((ent) => {
            const isHighlighted = highlightedEntityId === ent.id;

            if (ent.type === 'country') {
              return (
                <g key={ent.id} onClick={() => onEntityClick(ent)} className="cursor-pointer group">
                  <path
                    d={ent.path}
                    className={`transition-all duration-300 ${
                      isHighlighted
                        ? 'fill-amber-500/40 stroke-amber-300 stroke-[4] filter drop-shadow-[0_0_12px_rgba(245,158,11,0.8)]'
                        : 'fill-slate-800/80 hover:fill-amber-900/60 stroke-amber-700/60 hover:stroke-amber-400 stroke-[2]'
                    }`}
                  />
                  {/* Entity Country Label */}
                  {layersState.names && ent.labelPos && (
                    <text
                      x={ent.labelPos.x}
                      y={ent.labelPos.y}
                      textAnchor="middle"
                      className={`text-[13px] font-bold fill-amber-200 pointer-events-none font-ibm ${
                        isHighlighted ? 'fill-amber-300 font-extrabold text-[15px]' : ''
                      }`}
                    >
                      {ent.name}
                    </text>
                  )}
                </g>
              );
            }

            if (ent.type === 'river' && layersState.rivers) {
              return (
                <g key={ent.id} onClick={() => onEntityClick(ent)} className="cursor-pointer">
                  <path
                    d={ent.path}
                    fill="none"
                    className="stroke-cyan-400 stroke-[4] stroke-linecap-round filter drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]"
                  />
                </g>
              );
            }

            if (ent.type === 'mountain' && layersState.mountains) {
              return (
                <g key={ent.id} onClick={() => onEntityClick(ent)} className="cursor-pointer">
                  <path
                    d={ent.path}
                    fill="none"
                    className="stroke-amber-600 stroke-[5] stroke-dasharray-[6,4]"
                  />
                </g>
              );
            }

            if (ent.type === 'city' && layersState.capitals) {
              return (
                <g key={ent.id} onClick={() => onEntityClick(ent)} className="cursor-pointer group">
                  <circle
                    cx={ent.labelPos.x}
                    cy={ent.labelPos.y}
                    r="6"
                    className="fill-rose-500 stroke-amber-300 stroke-[2] group-hover:scale-125 transition-transform"
                  />
                  {layersState.names && (
                    <text
                      x={ent.labelPos.x}
                      y={ent.labelPos.y - 10}
                      textAnchor="middle"
                      className="text-[11px] font-extrabold fill-amber-200 font-ibm"
                    >
                      {ent.name}
                    </text>
                  )}
                </g>
              );
            }

            return null;
          })}

          {/* RENDER PLACED DRAGGABLE ICONS */}
          {placedIcons.map((ic) => (
            <g
              key={ic.id}
              onClick={() => setSelectedPlacedIconId(ic.id)}
              className="cursor-pointer"
              transform={`translate(${ic.x}, ${ic.y})`}
            >
              <text textAnchor="middle" className="text-2xl select-none">
                {ic.icon}
              </text>
              {selectedPlacedIconId === ic.id && (
                <circle r="18" className="fill-none stroke-amber-400 stroke-2 stroke-dasharray-[3,3] animate-spin" />
              )}
            </g>
          ))}

        </svg>
      </div>

      {/* WHITEBOARD CANVAS LAYER OVERLAY */}
      <canvas
        ref={drawingCanvasRef}
        onMouseDown={startCanvasDrawing}
        onMouseMove={drawOnCanvas}
        onMouseUp={stopCanvasDrawing}
        className={`absolute inset-0 z-20 ${
          activeTool === 'pen' || activeTool === 'eraser' ? 'pointer-events-auto cursor-crosshair' : 'pointer-events-none'
        }`}
      />

      {/* PLACED ICON TOOLBAR ACTIONS IF SELECTED */}
      {selectedPlacedIconId && (
        <div className="absolute top-4 right-4 z-40 bg-slate-950/90 border border-amber-600/80 p-2 rounded-2xl shadow-2xl backdrop-blur-md flex items-center gap-2 text-xs font-bold text-amber-200">
          <span>أيقونة محددة</span>
          <button
            onClick={() => handleDeleteIcon(selectedPlacedIconId)}
            className="p-1.5 bg-rose-900/80 hover:bg-rose-600 text-white rounded-xl transition"
            title="حذف الأيقونة"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* LESSON MODE OVERLAY INDICATOR */}
      {activeMode === 'lesson' && (
        <div className="absolute bottom-4 left-4 z-30 bg-purple-950/90 border border-purple-500/80 px-3 py-1.5 rounded-2xl text-xs font-extrabold text-purple-200 flex items-center gap-1.5 shadow-lg">
          <Sparkles className="w-4 h-4 text-purple-300" />
          <span>سبورة الشرح الجغرافي نشطة</span>
        </div>
      )}

    </div>
  );
}
