import React, { useState } from 'react';
import { 
  Eye, EyeOff, Layers, MapPin, PenTool, Eraser, Highlighting, 
  Moon, Sun, RefreshCw, Sparkles, Image, Shield, Type, Plus,
  Crosshair, Globe, Shuffle, Stamp, Palette, Download, Save
} from 'lucide-react';

export default function BottomToolbar({ 
  layersState, 
  onToggleLayer, 
  activeTool, 
  onSelectTool, 
  onResetMap, 
  onRandomCountry,
  onOpenIconLibrary,
  onSaveLesson,
  onExportMap,
  nightMode,
  onToggleNightMode,
  penColor,
  onChangePenColor
}) {

  const [showLayerMenu, setShowLayerMenu] = useState(false);

  const colors = ['#f59e0b', '#ef4444', '#10b981', '#3b82f6', '#ec4899', '#ffffff'];

  return (
    <div className="w-full bg-slate-950/95 border-t border-amber-600/40 p-2 sm:p-3 backdrop-blur-xl relative z-30 font-ibm">
      
      {/* LAYER TOGGLE MODAL / POPUP IF OPEN */}
      {showLayerMenu && (
        <div className="absolute bottom-full mb-2 right-4 sm:right-12 bg-slate-900/95 border-2 border-amber-600/80 p-4 rounded-3xl shadow-2xl backdrop-blur-2xl w-72 max-h-80 overflow-y-auto custom-scrollbar animate-fade-in text-amber-100 z-50">
          <div className="flex items-center justify-between pb-2 border-b border-amber-900/60 mb-3">
            <span className="font-reem font-bold text-sm text-amber-300 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-amber-400" />
              <span>التحكم في طبقات الخريطة</span>
            </span>
            <button onClick={() => setShowLayerMenu(false)} className="text-xs text-amber-400 hover:text-white">إغلاق</button>
          </div>

          <div className="space-y-2 text-xs">
            {[
              { id: 'borders', label: 'الحدود السياسية' },
              { id: 'names', label: 'أسماء الدول والمدن' },
              { id: 'rivers', label: 'الأنهار والمسطحات المائية' },
              { id: 'mountains', label: 'الجبال والتضاريس' },
              { id: 'capitals', label: 'العواصم والمدن الرئيسية' },
              { id: 'climate', label: 'الأقاليم المناخية' },
              { id: 'resources', label: 'الموارد والثروات' },
              { id: 'satellite', label: 'خلفية الأقمار الصناعية' },
            ].map((layer) => (
              <label key={layer.id} className="flex items-center justify-between p-2 rounded-xl bg-slate-950 hover:bg-slate-800 cursor-pointer select-none transition border border-amber-900/40">
                <span className="font-bold text-amber-200">{layer.label}</span>
                <input 
                  type="checkbox" 
                  checked={!!layersState[layer.id]} 
                  onChange={() => onToggleLayer(layer.id)}
                  className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                />
              </label>
            ))}
          </div>
        </div>
      )}

      {/* MAIN TOOLBAR WRAPPER */}
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 overflow-x-auto custom-scrollbar pb-1">
        
        {/* LEFT GROUP: LAYERS & MAP TOOLS */}
        <div className="flex items-center gap-1.5 shrink-0">
          
          {/* Toggle Layers Popup */}
          <button
            onClick={() => setShowLayerMenu(!showLayerMenu)}
            className={`px-3 py-2 rounded-2xl text-xs font-bold border transition flex items-center gap-1.5 ${
              showLayerMenu ? 'bg-amber-500 text-slate-950 border-amber-400 font-extrabold' : 'bg-slate-900 text-amber-300 border-amber-800 hover:border-amber-500'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span className="hidden md:inline">الطبقات</span>
          </button>

          {/* Satellite Layer Quick Switcher */}
          <button
            onClick={() => onToggleLayer('satellite')}
            className={`px-3 py-2 rounded-2xl text-xs font-bold border transition flex items-center gap-1.5 ${
              layersState.satellite ? 'bg-amber-500 text-slate-950 border-amber-400 font-extrabold' : 'bg-slate-900 text-amber-300 border-amber-800 hover:border-amber-500'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span className="hidden md:inline">الأقمار الصناعية</span>
          </button>

          {/* Night Mode Switcher */}
          <button
            onClick={onToggleNightMode}
            className={`px-3 py-2 rounded-2xl text-xs font-bold border transition flex items-center gap-1.5 ${
              nightMode ? 'bg-amber-500 text-slate-950 border-amber-400 font-extrabold' : 'bg-slate-900 text-amber-300 border-amber-800 hover:border-amber-500'
            }`}
            title="الوضع الليلي"
          >
            {nightMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            <span className="hidden md:inline">الوضع الليلي</span>
          </button>

          {/* Reset Map View */}
          <button
            onClick={onResetMap}
            className="px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-amber-800 hover:border-amber-500 text-amber-300 rounded-2xl text-xs font-bold transition flex items-center gap-1.5"
            title="إعادة ضبط الخريطة"
          >
            <RefreshCw className="w-4 h-4" />
            <span className="hidden md:inline">إعادة ضبط</span>
          </button>

        </div>

        {/* CENTER GROUP: WHITEBOARD DRAWING TOOLS (LESSON MODE) */}
        <div className="flex items-center gap-1.5 bg-slate-900/90 border border-amber-800/60 p-1 rounded-2xl shrink-0">
          
          {/* Select Mode */}
          <button
            onClick={() => onSelectTool('select')}
            className={`p-2 rounded-xl text-xs transition ${
              activeTool === 'select' ? 'bg-amber-500 text-slate-950 font-black' : 'text-amber-300 hover:bg-slate-800'
            }`}
            title="أداة التحديد والتحريك"
          >
            <Crosshair className="w-4 h-4" />
          </button>

          {/* Pen Tool */}
          <button
            onClick={() => onSelectTool('pen')}
            className={`p-2 rounded-xl text-xs transition ${
              activeTool === 'pen' ? 'bg-amber-500 text-slate-950 font-black' : 'text-amber-300 hover:bg-slate-800'
            }`}
            title="أداة القلم والشرح"
          >
            <PenTool className="w-4 h-4" />
          </button>

          {/* Eraser */}
          <button
            onClick={() => onSelectTool('eraser')}
            className={`p-2 rounded-xl text-xs transition ${
              activeTool === 'eraser' ? 'bg-amber-500 text-slate-950 font-black' : 'text-amber-300 hover:bg-slate-800'
            }`}
            title="الممحاة"
          >
            <Eraser className="w-4 h-4" />
          </button>

          {/* Color Palette Selector */}
          <div className="hidden sm:flex items-center gap-1 px-1 border-r border-amber-900/60">
            {colors.map((c) => (
              <button
                key={c}
                onClick={() => onChangePenColor(c)}
                className={`w-4 h-4 rounded-full border border-slate-950 transition ${
                  penColor === c ? 'scale-125 ring-2 ring-amber-400' : 'opacity-80 hover:opacity-100'
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>

        </div>

        {/* RIGHT GROUP: DRAGGABLE ICONS & ACTIONS */}
        <div className="flex items-center gap-1.5 shrink-0">
          
          {/* Icon Library Drawer Toggle */}
          <button
            onClick={onOpenIconLibrary}
            className="px-3 py-2 bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 rounded-2xl text-xs font-black transition flex items-center gap-1.5 shadow-md shadow-amber-500/20"
          >
            <Stamp className="w-4 h-4" />
            <span>مكتبة الأيقونات</span>
          </button>

          {/* Random Country Generator */}
          <button
            onClick={onRandomCountry}
            className="px-3 py-2 bg-slate-900 hover:bg-amber-950 border border-amber-700/80 rounded-2xl text-xs font-bold text-amber-300 transition flex items-center gap-1.5"
            title="مولد دولة عشوائية"
          >
            <Shuffle className="w-4 h-4 text-amber-400" />
            <span className="hidden lg:inline">دولة عشوائية</span>
          </button>

          {/* Save Lesson Annotations */}
          <button
            onClick={onSaveLesson}
            className="p-2 bg-slate-900 hover:bg-slate-800 border border-amber-800 text-amber-300 rounded-2xl text-xs font-bold transition"
            title="حفظ الشرح"
          >
            <Save className="w-4 h-4" />
          </button>

          {/* Export Screenshot */}
          <button
            onClick={onExportMap}
            className="p-2 bg-slate-900 hover:bg-slate-800 border border-amber-800 text-amber-300 rounded-2xl text-xs font-bold transition"
            title="تصدير صورة الخريطة"
          >
            <Download className="w-4 h-4" />
          </button>

        </div>

      </div>

    </div>
  );
}
