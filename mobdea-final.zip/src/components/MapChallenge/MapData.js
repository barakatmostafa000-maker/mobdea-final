// Data definitions for Interactive Map Challenge system in منصة المُبدع

export const MAP_REGIONS = [
  { id: 'arab_world', name: 'الوطن العربي', icon: '🌍', flag: '🇸🇦' },
  { id: 'egypt', name: 'جمهورية مصر العربية', icon: '🇪🇬', flag: '🇪🇬' },
  { id: 'africa', name: 'قارة إفريقيا', icon: '🌍', flag: '🌍' },
  { id: 'asia', name: 'قارة آسيا', icon: '🌏', flag: '🌏' },
  { id: 'europe', name: 'قارة أوروبا', icon: '🌍', flag: '🌍' },
  { id: 'north_america', name: 'أمريكا الشمالية', icon: '🌎', flag: '🌎' },
  { id: 'south_america', name: 'أمريكا الجنوبية', icon: '🌎', flag: '🌎' },
  { id: 'australia', name: 'أستراليا والأوقيانوسيا', icon: '🌏', flag: '🌏' },
];

export const MAP_CATEGORIES = [
  { id: 'all', label: 'الكل' },
  { id: 'countries', label: 'الدول' },
  { id: 'capitals', label: 'العواصم' },
  { id: 'rivers', label: 'الأنهار' },
  { id: 'mountains', label: 'الجبال' },
  { id: 'lakes', label: 'البحيرات' },
  { id: 'deserts', label: 'الصحاري' },
  { id: 'climate', label: 'المناخ' },
  { id: 'resources', label: 'الموارد الطبيعية' },
  { id: 'population', label: 'السكان' },
  { id: 'random', label: 'التحدي العشوائي' },
  { id: 'training', label: 'وضع التدريب' },
  { id: 'exam', label: 'وضع الامتحان' },
];

// Rich Geo Entities for Maps
export const MAP_ENTITIES = {
  arab_world: [
    {
      id: 'dz',
      name: 'الجزائر',
      type: 'country',
      category: 'countries',
      capital: 'الجزائر العاصمة',
      population: '45 مليون',
      resources: 'بترول وغاز طبيعي',
      path: 'M 220 280 L 290 270 L 320 330 L 300 420 L 220 400 L 190 350 Z',
      labelPos: { x: 255, y: 340 },
      clues: ['أكبر دولة في الوطن العربي وإفريقيا من حيث المساحة', 'تلقب ببلد المليون ونصف المليون شهيد', 'تقع في شمال إفريقيا وتطل على البحر المتوسط']
    },
    {
      id: 'eg',
      name: 'مصر',
      type: 'country',
      category: 'countries',
      capital: 'القاهرة',
      population: '105 مليون',
      resources: 'بترول، غاز، زراعة، سياحة، قناة السويس',
      path: 'M 390 310 L 450 310 L 460 380 L 390 380 Z',
      labelPos: { x: 420, y: 345 },
      clues: ['تقع في شمال شرق إفريقيا وتمر بها قناة السويس', 'يجري فيها نهر النيل من الجنوب إلى الشمال', 'عاصمتها القاهرة وبها أهرامات الجيزة']
    },
    {
      id: 'sa',
      name: 'السعودية',
      type: 'country',
      category: 'countries',
      capital: 'الرياض',
      population: '36 مليون',
      resources: 'النفط والغاز الطبيعي',
      path: 'M 480 340 L 560 350 L 570 440 L 490 420 Z',
      labelPos: { x: 525, y: 385 },
      clues: ['تضم الحرمين الشريفين في مكة المكرمة والمدينة المنورة', 'أكبر دول شبه الجزيرة العربية مساحة', 'تطل على البحر الأحمر غرباً والخليج العربي شرقاً']
    },
    {
      id: 'sd',
      name: 'السودان',
      type: 'country',
      category: 'countries',
      capital: 'الخرطوم',
      population: '48 مليون',
      resources: 'زراعة، ثروة حيوانية، ذهب',
      path: 'M 390 385 L 450 385 L 440 470 L 370 450 Z',
      labelPos: { x: 410, y: 430 },
      clues: ['يلتقي فيه النيل الأبيض والنيل الأزرق عند الخرطوم', 'يحد مصر من جهة الجنوب', 'غني بالثروة الحيوانية والأراضي الزراعية']
    },
    {
      id: 'ma',
      name: 'المغرب',
      type: 'country',
      category: 'countries',
      capital: 'الرباط',
      population: '37 مليون',
      resources: 'فوسفات، سياحة، ثروة سمكية',
      path: 'M 160 270 L 215 280 L 190 340 L 150 310 Z',
      labelPos: { x: 180, y: 300 },
      clues: ['يقع في أقصى غرب الوطن العربي', 'يطل على المحيط الأطلسي والبحر المتوسط ويشرف على مضيق جبل طارق', 'توجد به سلسلة جبال أطلس']
    },
    {
      id: 'iq',
      name: 'العراق',
      type: 'country',
      category: 'countries',
      capital: 'بغداد',
      population: '43 مليون',
      resources: 'نفط، زراعة النخيل، مياه',
      path: 'M 490 280 L 530 285 L 520 335 L 485 320 Z',
      labelPos: { x: 505, y: 305 },
      clues: ['بلاد الرافدين دجلة والفرات', 'يقع في شمال شرق الوطن العربي', 'عاصمتها بغداد التاريخية']
    },
    {
      id: 'sy',
      name: 'سوريا',
      type: 'country',
      category: 'countries',
      capital: 'دمشق',
      population: '22 مليون',
      resources: 'زراعة، نفط، سياحة',
      path: 'M 470 270 L 500 265 L 490 290 L 465 285 Z',
      labelPos: { x: 480, y: 278 },
      clues: ['دولة عربية في بلاد الشام عاصمتها دمشق', 'تطل على البحر المتوسط غرباً', 'يجري بها نهر الفرات و نهر العاصي']
    },
    {
      id: 'ye',
      name: 'اليمن',
      type: 'country',
      category: 'countries',
      capital: 'صنعاء',
      population: '33 مليون',
      resources: 'زراعة، ثروة سمكية، موانئ',
      path: 'M 500 425 L 560 440 L 530 475 L 490 450 Z',
      labelPos: { x: 520, y: 450 },
      clues: ['تطل على مضيق باب المندب الاستراتيجي', 'تقع في جنوب شبه الجزيرة العربية', 'تلقب بـ "اليمن السعيد"']
    },
    {
      id: 'nile_river',
      name: 'نهر النيل',
      type: 'river',
      category: 'rivers',
      path: 'M 430 460 Q 425 410 425 380 T 425 315',
      clues: ['أطول نهر في العالم يمر بـ 11 دولة إفريقية', 'ينبع من بحيرة فيكتوريا ويصب في البحر المتوسط', 'شريان الحياة الرئيسي في مصر والسودان']
    },
    {
      id: 'atlas_mts',
      name: 'جبال أطلس',
      type: 'mountain',
      category: 'mountains',
      path: 'M 170 285 C 200 290 230 295 260 300',
      clues: ['سلسلة جبلية تمتد في المغرب والجزائر وتونس', 'أعلى قمة فيها قمة جبل تبقال في المغرب', 'تحصر بينها هضبة الشطوط']
    },
    {
      id: 'suez_canal',
      name: 'قناة السويس',
      type: 'canal',
      category: 'resources',
      labelPos: { x: 442, y: 320 },
      clues: ['ممر مائي اصطناعي يربط بين البحر المتوسط والبحر الأحمر', 'أهم ممر ملاحي عالمي يقع كاملاً في مصر', 'يوفر ملايين الدولارات للتجارة العالمية']
    },
    {
      id: 'gibraltar_strait',
      name: 'مضيق جبل طارق',
      type: 'strait',
      category: 'resources',
      labelPos: { x: 175, y: 255 },
      clues: ['يربط بين البحر المتوسط والمحيط الأطلسي', 'يفصل بين قارة إفريقيا (المغرب) وقارة أوروبا (إسبانيا)']
    },
    {
      id: 'bab_mandeb',
      name: 'مضيق باب المندب',
      type: 'strait',
      category: 'resources',
      labelPos: { x: 485, y: 455 },
      clues: ['يربط بين البحر الأحمر وخليج عدن والمحيط الهندي', 'مدخل استراتيجي جنوبي للبحر الأحمر وقناة السويس']
    }
  ],

  egypt: [
    {
      id: 'cairo',
      name: 'محافظة القاهرة',
      type: 'city',
      category: 'capitals',
      labelPos: { x: 400, y: 250 },
      clues: ['عاصمة جمهورية مصر العربية وأكبر مدنها', 'تلقب بمدينة الألف مأذنة', 'تقع عند رأس دلتا النيل']
    },
    {
      id: 'alexandria',
      name: 'محافظة الإسكندرية',
      type: 'city',
      category: 'capitals',
      labelPos: { x: 330, y: 200 },
      clues: ['عروس البحر الأبيض المتوسط والعاصمة الثانية لمصر', 'تضم مكتبة الإسكندرية الشهيرة وميناء مصر الرئيسي']
    },
    {
      id: 'aswan',
      name: 'محافظة أسوان',
      type: 'city',
      category: 'capitals',
      labelPos: { x: 430, y: 450 },
      clues: ['بوابة مصر الجنوبية وتضم السد العالي وبحيرة ناصر', 'موطن النوبة ومعابد فيلة وأبو سمبل']
    },
    {
      id: 'sinai',
      name: 'شبه جزيرة سيناء',
      type: 'peninsula',
      category: 'deserts',
      labelPos: { x: 470, y: 240 },
      clues: ['أرض الفيروز وبوابة مصر الشرقية', 'تضم دير سانت كاترين وجبل موسى أعلى قمة بمصر']
    },
    {
      id: 'western_desert',
      name: 'الصحراء الغربية',
      type: 'desert',
      category: 'deserts',
      labelPos: { x: 260, y: 350 },
      clues: ['تشكل حوالي 68% من مساحة مصر وتضم الواحات والمنخفضات', 'غنية بالمياه الجوفية والحديد والفوسفات']
    },
    {
      id: 'eastern_desert',
      name: 'الصحراء الشرقية',
      type: 'desert',
      category: 'deserts',
      labelPos: { x: 450, y: 360 },
      clues: ['تتميز بجبال البحر الأحمر والأودية الجافة', 'غنية بالذهب والفوسفات والبترول']
    },
    {
      id: 'nasser_lake',
      name: 'بحيرة ناصر',
      type: 'lake',
      category: 'lakes',
      labelPos: { x: 430, y: 480 },
      clues: ['أكبر بحيرة صناعية في العالم تكونت خلف السد العالي', 'مخزون مصر الاستراتيجي من المياه العذبة والثروة السمكية']
    }
  ]
};

// Questions Bank mapped by topic and level
export const MAP_QUESTIONS_BANK = [
  {
    id: 'mq1',
    region: 'arab_world',
    category: 'countries',
    text: 'ما هي هذه الدولة المظللة على خريطة الوطن العربي؟',
    targetEntityId: 'dz',
    targetName: 'الجزائر',
    questionType: 'identify_country',
    options: ['الجزائر', 'المغرب', 'السودان', 'مصر'],
    correctAnswer: 'الجزائر',
    clues: ['أكبر دولة في الوطن العربي وإفريقيا مساحة', 'عاصمتها تحمل نفس اسم الدولة'],
    points: 1500,
    difficulty: 'سهل'
  },
  {
    id: 'mq2',
    region: 'arab_world',
    category: 'capitals',
    text: 'ما هي عاصمة دولة مصر المقابلة للنقطة الحمراء على النيل؟',
    targetEntityId: 'eg',
    targetName: 'القاهرة',
    questionType: 'identify_capital',
    options: ['الإسكندرية', 'القاهرة', 'أسوان', 'الجيزة'],
    correctAnswer: 'القاهرة',
    clues: ['تلقب بمدينة الألف مأذنة', 'تقع عند رأس الدلتا'],
    points: 1200,
    difficulty: 'سهل'
  },
  {
    id: 'mq3',
    region: 'arab_world',
    category: 'rivers',
    text: 'حدد المسار الأزرق الممتد من الجنوب للشمال في إفريقيا (أطول نهر بالروافد):',
    targetEntityId: 'nile_river',
    targetName: 'نهر النيل',
    questionType: 'identify_river',
    options: ['نهر النيل', 'نهر دجلة', 'نهر الفرات', 'نهر السنغال'],
    correctAnswer: 'نهر النيل',
    clues: ['أطول نهر في العالم يصب في البحر المتوسط', 'يمر بمصر والسودان'],
    points: 1800,
    difficulty: 'متوسط'
  },
  {
    id: 'mq4',
    region: 'arab_world',
    category: 'mountains',
    text: 'ما اسم أحدث السلاسل الجبلية الممتدة شمال غرب إفريقيا؟',
    targetEntityId: 'atlas_mts',
    targetName: 'جبال أطلس',
    questionType: 'identify_mountain',
    options: ['جبال أطلس', 'جبال الحجاز', 'جبال الشام', 'جبال زاجروس'],
    correctAnswer: 'جبال أطلس',
    clues: ['تحصر بينها هضبة الشطوط', 'تقع في المغرب والجزائر وتونس'],
    points: 2000,
    difficulty: 'متوسط'
  },
  {
    id: 'mq5',
    region: 'arab_world',
    category: 'resources',
    text: 'حدد الممر المائي الاصطناعي الذي يربط البحر المتوسط بالبحر الأحمر:',
    targetEntityId: 'suez_canal',
    targetName: 'قناة السويس',
    questionType: 'identify_canal',
    options: ['قناة السويس', 'مضيق هرمز', 'مضيق باب المندب', 'مضيق جبل طارق'],
    correctAnswer: 'قناة السويس',
    clues: ['تم حفرها بسواعد مصرية وافتتحت 1869', 'أهم قناة ملاحية عالمية'],
    points: 1600,
    difficulty: 'سهل'
  },
  {
    id: 'mq6',
    region: 'egypt',
    category: 'lakes',
    text: 'ما اسم أكبر بحيرة ناصر الصناعية العذبة جنوب مصر؟',
    targetEntityId: 'nasser_lake',
    targetName: 'بحيرة ناصر',
    questionType: 'identify_lake',
    options: ['بحيرة ناصر', 'بحيرة قارون', 'بحيرة المنزلة', 'بحيرة البردويل'],
    correctAnswer: 'بحيرة ناصر',
    clues: ['تكونت خلف السد العالي بأسوان', 'مصدر رئيسي للأسماك والمياه'],
    points: 1400,
    difficulty: 'سهل'
  }
];

export const ICON_LIBRARY = [
  { id: 'mountain', name: 'جبل', icon: '🏔️', category: 'تضاريس' },
  { id: 'volcano', name: 'بركان / سلسلة', icon: '🌋', category: 'تضاريس' },
  { id: 'desert', name: 'صحراء', icon: '🏜️', category: 'تضاريس' },
  { id: 'river', name: 'نهر / وادي', icon: '🌊', category: 'مسطحات' },
  { id: 'lake', name: 'بحيرة / بئر', icon: '💧', category: 'مسطحات' },
  { id: 'tree', name: 'غابة / نبات', icon: '🌲', category: 'بيئة' },
  { id: 'palm', name: 'واحة / نخيل', icon: '🌴', category: 'بيئة' },
  { id: 'oil', name: 'حقل بترول / غاز', icon: '🛢️', category: 'موارد' },
  { id: 'mine', name: 'منجم / تعدين', icon: '⛏️', category: 'موارد' },
  { id: 'factory', name: 'منطقة صناعية', icon: '🏭', category: 'صناعة' },
  { id: 'wheat', name: 'محصول زراعي', icon: '🌾', category: 'زراعة' },
  { id: 'cow', name: 'ثروة حيوانية', icon: '🐄', category: 'زراعة' },
  { id: 'fish', name: 'مصايد أسماك', icon: '🐟', category: 'زراعة' },
  { id: 'capital', name: 'عاصمة / مدينة', icon: '🏛️', category: 'مدن' },
  { id: 'port', name: 'ميناء بحري', icon: '⚓', category: 'مواصلات' },
  { id: 'airport', name: 'مطار دولي', icon: '✈️', category: 'مواصلات' },
  { id: 'train', name: 'سكة حديد', icon: '🚂', category: 'مواصلات' },
  { id: 'dam', name: 'سد مائي', icon: '🧱', category: 'منشآت' },
  { id: 'pin', name: 'دبوس تحديد', icon: '📍', category: 'علامات' },
  { id: 'flag', name: 'علم علمي', icon: '🚩', category: 'علامات' },
  { id: 'star', name: 'نجمة تفوق', icon: '⭐', category: 'علامات' },
  { id: 'check', name: 'علامة صح', icon: '✅', category: 'علامات' },
  { id: 'cross', name: 'علامة خطأ', icon: '❌', category: 'علامات' },
];
