import React from 'react';
import { MAP_CATEGORIES } from './MapData';

export default function BottomCategoryBar({ activeCategory, onSelectCategory }) {
  return (
    <div className="w-full bg-slate-950/90 border-t border-amber-600/40 py-2 px-3 sm:px-6 backdrop-blur-xl relative z-20 flex items-center justify-start sm:justify-center overflow-x-auto custom-scrollbar gap-1.5 sm:gap-2">
      {MAP_CATEGORIES.map((cat) => {
        const isActive = activeCategory === cat.id;
        return (
          <button
            key={cat.id}
            onClick={() => onSelectCategory(cat.id)}
            className={`whitespace-nowrap px-3.5 py-1.5 rounded-xl text-xs font-extrabold transition-all duration-200 border ${
              isActive
                ? 'bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-slate-950 border-amber-300 shadow-md shadow-amber-500/20 scale-105'
                : 'bg-slate-900/80 hover:bg-slate-900 text-amber-200/80 border-amber-900/60 hover:border-amber-600/60'
            }`}
          >
            {cat.label}
          </button>
        );
      })}
    </div>
  );
}
