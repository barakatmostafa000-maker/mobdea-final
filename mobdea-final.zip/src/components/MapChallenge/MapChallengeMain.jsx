import React, { useState, useEffect } from 'react';
import TopMapHeader from './TopMapHeader';
import LeftNavigationSidebar from './LeftNavigationSidebar';
import MapCanvas from './MapCanvas';
import QuestionPanelCard from './QuestionPanelCard';
import BottomCategoryBar from './BottomCategoryBar';
import BottomToolbar from './BottomToolbar';
import IconLibraryDrawer from './IconLibraryDrawer';
import { MAP_QUESTIONS_BANK, MAP_REGIONS } from './MapData';
import { Trophy, Medal, CreditCard, CheckSquare, User, Settings, X, Sparkles, Award } from 'lucide-react';

export default function MapChallengeMain() {
  
  // User Stats & Experience
  const [userStats, setUserStats] = useState({
    name: 'أحمد العتيبي',
    level: 12,
    xp: 7800,
    maxXp: 10000,
    goldCoins: 25400,
    stars: 315,
    energy: 85,
    maxEnergy: 100,
    streak: 45,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150'
  });

  // Controls & Modes
  const [activeMode, setActiveMode] = useState('challenge'); // challenge, explore, teacher, lesson
  const [activeSubView, setActiveSubView] = useState(null); // achievements, leaderboard, student_card, daily_quests, profile, settings
  const [activeRegion, setActiveRegion] = useState('arab_world'); // arab_world, egypt, etc.
  const [activeCategory, setActiveCategory] = useState('all');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Layers & Map Settings
  const [layersState, setLayersState] = useState({
    borders: true,
    names: true,
    rivers: true,
    mountains: true,
    capitals: true,
    climate: false,
    resources: false,
    satellite: false,
  });
  const [nightMode, setNightMode] = useState(true);
  const [activeTool, setActiveTool] = useState('select'); // select, pen, eraser
  const [penColor, setPenColor] = useState('#f59e0b');
  const [placedIcons, setPlacedIcons] = useState([]);
  const [iconLibraryOpen, setIconLibraryOpen] = useState(false);

  // Question / Quiz Engine State
  const [questionsList, setQuestionsList] = useState(MAP_QUESTIONS_BANK);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [score, setScore] = useState(14500);
  const [combo, setCombo] = useState(1.5);
  const [accuracy, setAccuracy] = useState(96);
  const [cluesUsed, setCluesUsed] = useState(0);
  const [lastFeedback, setLastFeedback] = useState(null);
  const [attemptsLeft, setAttemptsLeft] = useState(3);
  const maxAttempts = 5;
  const [timeLeft, setTimeLeft] = useState(28);

  // Current Question
  const currentQuestion = questionsList[questionIndex] || null;

  // Countdown Timer
  useEffect(() => {
    if (activeMode !== 'challenge' || !currentQuestion) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleNextQuestion();
          return 30;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [questionIndex, activeMode, currentQuestion]);

  // Handle Layer Toggle
  const handleToggleLayer = (layerId) => {
    setLayersState((prev) => ({ ...prev, [layerId]: !prev[layerId] }));
  };

  // Answer Submission Logic
  const handleAnswer = (optionText) => {
    if (!currentQuestion) return;

    if (optionText === currentQuestion.correctAnswer) {
      const addedScore = Math.round(currentQuestion.points * combo);
      setScore((s) => s + addedScore);
      setCombo((c) => Math.min(c + 0.2, 3.0));
      setUserStats((prev) => ({
        ...prev,
        xp: prev.xp + 350,
        goldCoins: prev.goldCoins + 120,
        stars: prev.stars + 5
      }));
      setLastFeedback({
        isCorrect: true,
        message: `إجابة صحيحة! +${addedScore} نقطة 🎉`
      });
    } else {
      setCombo(1.0);
      setAttemptsLeft((a) => Math.max(a - 1, 0));
      setLastFeedback({
        isCorrect: false,
        message: `إجابة خاطئة! الإجابة الصحيحة هي: ${currentQuestion.correctAnswer}`
      });
    }
  };

  // Next Question
  const handleNextQuestion = () => {
    setLastFeedback(null);
    setTimeLeft(30);
    if (questionIndex + 1 < questionsList.length) {
      setQuestionIndex((i) => i + 1);
    } else {
      setQuestionIndex(0); // Reset or complete
    }
  };

  // Add Placed Icon
  const handleAddIconToMap = (iconItem) => {
    const newIcon = {
      id: Date.now(),
      icon: iconItem.icon,
      name: iconItem.name,
      x: 350 + (placedIcons.length * 15),
      y: 250 + (placedIcons.length * 10),
    };
    setPlacedIcons((prev) => [...prev, newIcon]);
  };

  // Entity Click
  const handleEntityClick = (entity) => {
    if (activeMode === 'challenge' && currentQuestion) {
      if (entity.name === currentQuestion.targetName || entity.capital === currentQuestion.correctAnswer) {
        handleAnswer(entity.name);
      }
    } else {
      alert(`معالم جغرافية: ${entity.name}\n${entity.capital ? 'العاصمة: ' + entity.capital : ''}\n${entity.resources ? 'الموارد: ' + entity.resources : ''}`);
    }
  };

  return (
    <div className="w-full min-h-screen bg-slate-950 text-amber-100 flex flex-col justify-between font-ibm overflow-x-hidden selection:bg-amber-500 selection:text-slate-950">
      
      {/* TOP HEADER */}
      <TopMapHeader
        userStats={userStats}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
        onOpenSettings={() => setActiveSubView('settings')}
      />

      {/* MIDDLE WORKSPACE BODY */}
      <div className="flex-1 flex flex-col lg:flex-row relative">
        
        {/* LEFT NAVIGATION SIDEBAR */}
        <LeftNavigationSidebar
          activeMode={activeMode}
          onSelectMode={(mode) => {
            setActiveMode(mode);
            setActiveSubView(null);
          }}
          activeSubView={activeSubView}
          onSelectSubView={(sub) => setActiveSubView(sub)}
          activeRegion={activeRegion}
          onSelectRegion={(reg) => setActiveRegion(reg)}
          mobileOpen={mobileSidebarOpen}
          onCloseMobile={() => setMobileSidebarOpen(false)}
        />

        {/* CENTRAL MAP WORKSPACE */}
        <main className="flex-1 p-3 sm:p-5 flex flex-col lg:flex-row gap-4 relative z-10">
          
          {/* INTERACTIVE MAP CANVAS CONTAINER */}
          <div className="flex-1 flex flex-col justify-between relative min-h-[500px]">
            <MapCanvas
              regionId={activeRegion}
              layersState={layersState}
              nightMode={nightMode}
              highlightedEntityId={currentQuestion?.targetEntityId}
              onEntityClick={handleEntityClick}
              activeTool={activeTool}
              penColor={penColor}
              placedIcons={placedIcons}
              onUpdatePlacedIcons={(updated) => setPlacedIcons(updated)}
              activeMode={activeMode}
            />
          </div>

          {/* FLOATING RIGHT OVERLAY QUESTION CARD (CHALLENGE MODE) */}
          {activeMode === 'challenge' && (
            <div className="shrink-0 flex justify-center lg:justify-start">
              <QuestionPanelCard
                currentQuestion={currentQuestion}
                questionIndex={questionIndex}
                totalQuestions={questionsList.length}
                score={score}
                combo={combo}
                accuracy={accuracy}
                onAnswer={handleAnswer}
                onNextQuestion={handleNextQuestion}
                onUseClue={() => setCluesUsed((c) => c + 1)}
                cluesUsed={cluesUsed}
                lastFeedback={lastFeedback}
                attemptsLeft={attemptsLeft}
                maxAttempts={maxAttempts}
                timeLeft={timeLeft}
              />
            </div>
          )}

        </main>

      </div>

      {/* BOTTOM CATEGORY SELECTOR */}
      <BottomCategoryBar
        activeCategory={activeCategory}
        onSelectCategory={(cat) => setActiveCategory(cat)}
      />

      {/* BOTTOM TOOLBAR */}
      <BottomToolbar
        layersState={layersState}
        onToggleLayer={handleToggleLayer}
        activeTool={activeTool}
        onSelectTool={(tool) => setActiveTool(tool)}
        onResetMap={() => setPlacedIcons([])}
        onRandomCountry={() => {
          const randomIndex = Math.floor(Math.random() * MAP_QUESTIONS_BANK.length);
          setQuestionIndex(randomIndex);
        }}
        onOpenIconLibrary={() => setIconLibraryOpen(true)}
        onSaveLesson={() => alert('تم حفظ الشرح والتوضيحات الجغرافية في ملف المادة بنجاح! 💾')}
        onExportMap={() => alert('جاري تصدير خريطة عالي الجودة للدرس... 📸')}
        nightMode={nightMode}
        onToggleNightMode={() => setNightMode(!nightMode)}
        penColor={penColor}
        onChangePenColor={(color) => setPenColor(color)}
      />

      {/* ICON LIBRARY DRAWER */}
      <IconLibraryDrawer
        isOpen={iconLibraryOpen}
        onClose={() => setIconLibraryOpen(false)}
        onAddIconToMap={handleAddIconToMap}
      />

      {/* SUB-VIEWS MODAL OVERLAY (LEADERBOARD, ACHIEVEMENTS, PROFILE, ETC.) */}
      {activeSubView && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in font-ibm">
          <div className="bg-slate-900 border-2 border-amber-600/80 rounded-3xl p-6 max-w-lg w-full text-amber-100 relative shadow-2xl">
            <button
              onClick={() => setActiveSubView(null)}
              className="absolute top-4 left-4 p-1 rounded-xl bg-slate-800 text-amber-300 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>

            {activeSubView === 'leaderboard' && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-amber-400">
                  <Medal className="w-6 h-6" />
                  <h3 className="font-reem text-xl font-bold">لوحة متصدري تحدي الخرائط 🏆</h3>
                </div>
                <div className="space-y-2">
                  {[
                    { rank: 1, name: 'فاطمة محمد', points: '18,900', badge: '🥇 المركز الأول' },
                    { rank: 2, name: 'أحمد العتيبي (أنت)', points: '14,500', badge: '🥈 المركز الثاني' },
                    { rank: 3, name: 'عمر خالد', points: '12,100', badge: '🥉 المركز الثالث' },
                  ].map((usr) => (
                    <div key={usr.rank} className="flex items-center justify-between p-3 bg-slate-950 border border-amber-900/60 rounded-2xl text-xs font-bold">
                      <span>{usr.rank}. {usr.name}</span>
                      <span className="text-amber-400 font-mono">{usr.points} نقطة</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeSubView === 'achievements' && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-amber-400">
                  <Trophy className="w-6 h-6" />
                  <h3 className="font-reem text-xl font-bold">إنجازاتك الجغرافية ⭐</h3>
                </div>
                <div className="space-y-2 text-xs">
                  <div className="p-3 bg-amber-950/80 border border-amber-600/80 rounded-2xl">
                    <span className="font-bold text-amber-300 block mb-1">🥇 خبير خريطة الوطن العربي</span>
                    <span className="text-[11px] text-amber-200/80">أكملت 50 سؤالاً دون أي خطأ في الجغرافيا الإقليمية!</span>
                  </div>
                  <div className="p-3 bg-slate-950 border border-amber-900/60 rounded-2xl">
                    <span className="font-bold text-amber-300 block mb-1">⚡ حاسبة العواصم السريعة</span>
                    <span className="text-[11px] text-amber-200/80">أجبت على 10 عواصم متتالية في أقل من دقيقتين.</span>
                  </div>
                </div>
              </div>
            )}

            {activeSubView === 'profile' && (
              <div className="space-y-4 text-center">
                <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-tr from-amber-500 to-amber-300 p-1">
                  <img src={userStats.avatar} alt="Profile" className="w-full h-full rounded-full object-cover" />
                </div>
                <h3 className="font-reem text-xl font-bold text-amber-300">{userStats.name}</h3>
                <p className="text-xs text-amber-200/70">مستوى {userStats.level} • طالب متميز بقسم الدراسات</p>
                <div className="grid grid-cols-2 gap-2 text-xs font-bold pt-2">
                  <div className="bg-slate-950 p-3 rounded-2xl border border-amber-900/60">
                    <span className="text-amber-400 block font-mono text-base">{userStats.goldCoins}</span>
                    <span className="text-[10px] text-amber-300/70">العملات الذهبية</span>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-2xl border border-amber-900/60">
                    <span className="text-amber-400 block font-mono text-base">{userStats.streak} يوم</span>
                    <span className="text-[10px] text-amber-300/70">تحدي يومي مستمر</span>
                  </div>
                </div>
              </div>
            )}

            {activeSubView === 'settings' && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-amber-400">
                  <Settings className="w-6 h-6" />
                  <h3 className="font-reem text-xl font-bold">إعدادات الخريطة والتحدي</h3>
                </div>
                <div className="space-y-2 text-xs font-bold">
                  <label className="flex items-center justify-between p-3 bg-slate-950 rounded-2xl border border-amber-900/60">
                    <span>التأثيرات الصوتية والموسيقى</span>
                    <input type="checkbox" checked={soundEnabled} onChange={() => setSoundEnabled(!soundEnabled)} className="accent-amber-500 w-4 h-4" />
                  </label>
                  <label className="flex items-center justify-between p-3 bg-slate-950 rounded-2xl border border-amber-900/60">
                    <span>الوضع الليلي التلقائي</span>
                    <input type="checkbox" checked={nightMode} onChange={() => setNightMode(!nightMode)} className="accent-amber-500 w-4 h-4" />
                  </label>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
}
