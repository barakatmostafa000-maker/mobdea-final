import React from 'react';
import { 
  Swords, Compass, GraduationCap, BookOpen, Trophy, Medal, 
  CreditCard, CheckSquare, User, Settings, Globe2, ChevronDown, Sparkles
} from 'lucide-react';
import { MAP_REGIONS } from './MapData';

export default function LeftNavigationSidebar({ 
  activeMode, 
  onSelectMode, 
  activeSubView, 
  onSelectSubView, 
  activeRegion, 
  onSelectRegion,
  mobileOpen,
  onCloseMobile
}) {

  const modes = [
    { id: 'challenge', label: 'وضع التحدي', icon: Swords, color: 'from-amber-500 to-amber-400' },
    { id: 'explore', label: 'وضع الاستكشاف', icon: Compass, color: 'from-blue-500 to-indigo-400' },
    { id: 'teacher', label: 'وضع المعلم', icon: GraduationCap, color: 'from-emerald-500 to-teal-400' },
    { id: 'lesson', label: 'وضع الحصة', icon: BookOpen, color: 'from-purple-500 to-pink-400' },
  ];

  const quickLinks = [
    { id: 'achievements', label: 'الإنجازات', icon: Trophy },
    { id: 'leaderboard', label: 'لوحة المتصدرين', icon: Medal },
    { id: 'student_card', label: 'كارت الطالب', icon: CreditCard },
    { id: 'daily_quests', label: 'المهام اليومية', icon: CheckSquare },
    { id: 'profile', label: 'الملف الشخصي', icon: User },
    { id: 'settings', label: 'الإعدادات', icon: Settings },
  ];

  return (
    <>
      {/* MOBILE BACKDROP */}
      {mobileOpen && (
        <div 
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-40 lg:hidden"
        />
      )}

      {/* SIDEBAR PANEL */}
      <aside className={`fixed lg:relative inset-y-0 right-0 z-50 w-64 bg-slate-950/95 border-l border-amber-600/40 p-4 flex flex-col justify-between transition-transform duration-300 ease-in-out ${
        mobileOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
      } shadow-2xl backdrop-blur-2xl overflow-y-auto custom-scrollbar text-amber-100 font-ibm shrink-0`}>
        
        <div className="space-y-6">

          {/* MAP REGION SELECTOR DROPDOWN */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-amber-300/80 uppercase tracking-wider flex items-center gap-1 pr-1">
              <Globe2 className="w-3.5 h-3.5 text-amber-400" />
              <span>اختر الخريطة التفاعلية:</span>
            </label>
            <div className="relative">
              <select
                value={activeRegion}
                onChange={(e) => onSelectRegion(e.target.value)}
                className="w-full bg-slate-900 border-2 border-amber-600/70 hover:border-amber-400 rounded-2xl py-2.5 px-3 pr-8 text-xs font-bold text-amber-200 outline-none appearance-none transition cursor-pointer shadow-lg"
              >
                {MAP_REGIONS.map((reg) => (
                  <option key={reg.id} value={reg.id} className="bg-slate-950 text-amber-100 py-2">
                    {reg.flag} {reg.name}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-4 h-4 text-amber-400 absolute left-3 top-3 pointer-events-none" />
            </div>
          </div>

          {/* MAIN MODES SECTION */}
          <div className="space-y-2">
            <div className="text-[11px] font-bold text-amber-400/80 pr-1 uppercase tracking-wider">
              أوضاع اللعب والشرح
            </div>
            
            <div className="space-y-1.5">
              {modes.map((m) => {
                const Icon = m.icon;
                const isActive = activeMode === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => {
                      onSelectMode(m.id);
                      if (onCloseMobile) onCloseMobile();
                    }}
                    className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-2xl text-xs font-bold transition-all relative overflow-hidden group ${
                      isActive
                        ? 'bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-slate-950 font-extrabold shadow-lg shadow-amber-500/20'
                        : 'bg-slate-900/60 hover:bg-slate-900 text-amber-200/90 border border-amber-900/40 hover:border-amber-600/60'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-slate-950' : 'text-amber-400 group-hover:scale-110 transition'
                    }`} />
                    <span className="truncate">{m.label}</span>
                    {isActive && (
                      <span className="absolute left-2 w-1.5 h-6 rounded-full bg-slate-950"></span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* QUICK NAV LINKS */}
          <div className="space-y-2">
            <div className="text-[11px] font-bold text-amber-400/80 pr-1 uppercase tracking-wider">
              القوائم والإحصائيات
            </div>

            <div className="space-y-1">
              {quickLinks.map((item) => {
                const Icon = item.icon;
                const isSelected = activeSubView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectSubView(item.id);
                      if (onCloseMobile) onCloseMobile();
                    }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
                      isSelected
                        ? 'bg-amber-950/80 border border-amber-500 text-amber-300'
                        : 'text-amber-200/80 hover:bg-slate-900 hover:text-amber-100'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-amber-400' : 'text-amber-400/70'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* SYSTEM STATUS CARD */}
        <div className="mt-6 pt-4 border-t border-amber-900/40 bg-slate-900/80 border border-amber-900/50 p-3 rounded-2xl text-center">
          <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-amber-300 mb-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>نظام الجغرافيا الذكي</span>
          </div>
          <p className="text-[10px] text-amber-200/70">
            تفاعل فوري • تصحيح تلقائي • أوسمة
          </p>
        </div>

      </aside>
    </>
  );
}
