import React, { useState } from 'react';
import { Star, Plus, Minus, MessageSquare, Check, X, BookOpen, Trophy } from 'lucide-react';
import MotivationalModal from './MotivationalModal';

export default function StudentsPanel({ students, setStudents, attendance, setAttendance, currentSessionId }) {
  const [selectedStudentForMsg, setSelectedStudentForMsg] = useState(null);

  const handlePointChange = (studentId, delta) => {
    setStudents(prev =>
      prev.map(s => {
        if (s.id === studentId) {
          const newPoints = Math.max(0, (s.points || 0) + delta);
          return { ...s, points: newPoints };
        }
        return s;
      })
    );
  };

  const handleToggleAttendance = (studentId) => {
    setAttendance(prev => {
      const existing = prev.find(a => a.studentId === studentId);
      if (existing) {
        return prev.map(a => a.studentId === studentId ? { ...a, status: a.status === 'حاضر' ? 'غائب' : 'حاضر' } : a);
      } else {
        return [...prev, { id: Date.now(), studentId, sessionId: currentSessionId, date: '2026-07-24', status: 'حاضر' }];
      }
    });
  };

  return (
    <>
      <aside className="w-full lg:w-72 xl:w-80 bg-gradient-to-b from-black via-slate-950 to-black border-2 border-amber-600/60 rounded-3xl p-3 flex flex-col shadow-2xl relative overflow-hidden">
        
        {/* Subtle background luxury ornament glow */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none"></div>

        {/* HEADER: "الطلاب والنقاط" */}
        <div className="bg-gradient-to-r from-amber-950 via-amber-900/90 to-amber-950 border border-amber-500/70 p-2.5 rounded-2xl text-center mb-3 shadow-md relative">
          <div className="flex items-center justify-center gap-2 text-amber-300">
            <Trophy className="w-4 h-4 text-amber-400" />
            <h2 className="font-reem text-base font-extrabold tracking-wide">
              الطلاب والنقاط
            </h2>
            <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
          </div>
        </div>

        {/* Table Header Labels */}
        <div className="grid grid-cols-12 gap-1 px-2 py-1 text-[11px] font-ibm font-bold text-amber-400/80 border-b border-amber-800/40 mb-2 text-center">
          <span className="col-span-5 text-right pr-1">الطالب</span>
          <span className="col-span-3">النقاط</span>
          <span className="col-span-2">التحكم</span>
          <span className="col-span-2">رسالة</span>
        </div>

        {/* STUDENTS LIST */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar max-h-[520px]">
          {students.map((student) => {
            const isPresent = attendance.some(a => a.studentId === student.id && a.status === 'حاضر');

            return (
              <div
                key={student.id}
                className="bg-slate-900/80 border border-amber-900/40 hover:border-amber-600/60 rounded-xl p-2 flex items-center justify-between text-xs transition duration-200"
              >
                {/* Student Name & Attendance Toggle */}
                <div className="col-span-5 flex items-center gap-1.5 min-w-0 pr-1 flex-1">
                  <button
                    onClick={() => handleToggleAttendance(student.id)}
                    title={isPresent ? 'حاضر (اضغط للتغيير)' : 'غائب (اضغط للتغيير)'}
                    className={`p-1 rounded-lg border text-[10px] shrink-0 font-extrabold transition ${
                      isPresent
                        ? 'bg-emerald-950 border-emerald-500 text-emerald-400'
                        : 'bg-rose-950 border-rose-800 text-rose-400'
                    }`}
                  >
                    {isPresent ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                  </button>
                  <span className="font-ibm font-bold text-amber-100 truncate text-[12px]">
                    {student.name}
                  </span>
                </div>

                {/* Points Circle with Star */}
                <div className="flex items-center gap-1 shrink-0 px-1">
                  <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-amber-950 to-slate-900 border border-amber-500/80 flex items-center justify-center font-ibm font-extrabold text-[11px] text-amber-300 shadow-inner">
                    {student.points || 0}
                  </div>
                  <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                </div>

                {/* Add / Remove Points Buttons */}
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => handlePointChange(student.id, 5)}
                    title="إضافة +5 نقاط"
                    className="p-1 bg-emerald-900/60 hover:bg-emerald-600 text-emerald-300 border border-emerald-600/50 rounded-md font-bold transition active:scale-95"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => handlePointChange(student.id, -5)}
                    title="خصم -5 نقاط"
                    className="p-1 bg-rose-900/60 hover:bg-rose-600 text-rose-300 border border-rose-600/50 rounded-md font-bold transition active:scale-95"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                </div>

                {/* Message Button */}
                <button
                  onClick={() => setSelectedStudentForMsg(student)}
                  title="فتح الرسائل التحفيزية"
                  className="p-1.5 bg-amber-950/80 hover:bg-amber-600 text-amber-300 hover:text-slate-950 border border-amber-600/60 rounded-lg transition shrink-0 ml-1"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>

        {/* BOTTOM MOTIVATIONAL QUOTE BANNER */}
        <div className="mt-3 bg-gradient-to-b from-amber-950/90 to-black border-t-2 border-amber-500/70 p-2.5 rounded-b-2xl text-center">
          <div className="flex items-center justify-center gap-2 text-amber-300 mb-1">
            <BookOpen className="w-4 h-4 text-amber-400" />
            <span className="font-reem text-xs font-bold text-amber-200">التعلم اليوم</span>
          </div>
          <p className="font-ibm text-[11px] font-extrabold text-amber-300 leading-snug">
            يصنع مستقبلك غداً
          </p>
        </div>

      </aside>

      {/* Motivational Messages Modal */}
      {selectedStudentForMsg && (
        <MotivationalModal
          student={selectedStudentForMsg}
          onClose={() => setSelectedStudentForMsg(null)}
        />
      )}
    </>
  );
}
