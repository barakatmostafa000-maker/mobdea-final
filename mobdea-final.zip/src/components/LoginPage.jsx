import React, { useState, useEffect } from 'react';
import { 
  Lock, Mail, Phone, Eye, EyeOff, Sparkles, CheckCircle2, 
  AlertCircle, ArrowRight, ShieldCheck, UserCheck, KeyRound, Loader2,
  BookOpen, Trophy, School, HelpCircle, GraduationCap, FileCheck2,
  MessageSquare, LayoutDashboard
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { validateEmail, validatePassword } from '../services/auth/authService';

export default function LoginPage({ onLoginSuccess }) {
  const { login, resetPassword, loading: authLoading, authError } = useAuth();

  // Form State
  const [role, setRole] = useState('teacher'); // 'teacher' | 'student' | 'guardian'
  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // Validation & Error States
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [formError, setFormError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Forgot Password Modal State
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [resetEmailError, setResetEmailError] = useState('');
  const [resetStatus, setResetStatus] = useState({ loading: false, success: '', error: '' });

  // Load remembered credentials if any
  useEffect(() => {
    try {
      const savedEmail = localStorage.getItem('mobdea_remembered_email');
      const savedRole = localStorage.getItem('mobdea_remembered_role');
      if (savedEmail) {
        setEmailOrPhone(savedEmail);
        setRememberMe(true);
      }
      if (savedRole) {
        setRole(savedRole);
      }
    } catch (e) {
      console.warn('LocalStorage read warning:', e);
    }
  }, []);

  // Validate Email / Phone on Change
  const handleEmailChange = (val) => {
    setEmailOrPhone(val);
    if (emailError) setEmailError('');
    if (formError) setFormError('');
  };

  // Validate Password on Change
  const handlePasswordChange = (val) => {
    setPassword(val);
    if (passwordError) setPasswordError('');
    if (formError) setFormError('');
  };

  // Validate entire form before submission
  const validateForm = () => {
    let isValid = true;
    setEmailError('');
    setPasswordError('');
    setFormError('');

    const trimmedInput = emailOrPhone.trim();

    // Check if input is email or phone
    const isPhone = /^[0-9+]+$/.test(trimmedInput);

    if (!trimmedInput) {
      setEmailError('يرجى إدخال البريد الإلكتروني أو رقم الهاتف');
      isValid = false;
    } else if (isPhone) {
      if (trimmedInput.length < 10) {
        setEmailError('رقم الهاتف يجب أن يتكون من 10 أرقام على الأقل');
        isValid = false;
      }
    } else {
      const emailCheck = validateEmail(trimmedInput);
      if (!emailCheck.isValid) {
        setEmailError(emailCheck.message);
        isValid = false;
      }
    }

    if (!password) {
      setPasswordError('يرجى إدخال كلمة المرور');
      isValid = false;
    } else if (password.length < 6) {
      setPasswordError('كلمة المرور يجب أن تتكون من 6 أحرف على الأقل');
      isValid = false;
    }

    return isValid;
  };

  // Submit Login Handler
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSubmitting) return;

    if (!validateForm()) return;

    setIsSubmitting(true);
    setFormError('');
    setSuccessMessage('');

    try {
      // Determine if email or phone-based login
      const inputVal = emailOrPhone.trim();
      const formattedEmail = inputVal.includes('@') 
        ? inputVal 
        : `${inputVal.replace(/\+/g, '')}@mobdea.edu.eg`;

      // Save preference if remember me is checked
      if (rememberMe) {
        localStorage.setItem('mobdea_remembered_email', inputVal);
        localStorage.setItem('mobdea_remembered_role', role);
      } else {
        localStorage.removeItem('mobdea_remembered_email');
        localStorage.removeItem('mobdea_remembered_role');
      }

      // Attempt Auth via Context
      await login({ email: formattedEmail, password });

      setSuccessMessage('تم تسجيل الدخول بنجاح! جاري التوجيه إلى منصة المُبدع...');

      setTimeout(() => {
        if (onLoginSuccess) onLoginSuccess();
      }, 1000);

    } catch (err) {
      console.error('Login submit error:', err);
      if (err.message && (err.message.includes('Invalid login credentials') || err.message.includes('فشل'))) {
        setFormError('البيانات المدخلة غير متطابقة. يمكنك استخدام زر "الدخول السريع كمعلم" للتجربة الفورية.');
      } else {
        setFormError(err.message || 'حدث خطأ في الاتصال بالخادم. حاول مرة أخرى.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  // Demo Quick Fill Function
  const handleQuickLogin = (demoRole) => {
    setRole(demoRole);
    if (demoRole === 'teacher') {
      setEmailOrPhone('teacher@mobdea.edu.eg');
      setPassword('123456');
    } else if (demoRole === 'student') {
      setEmailOrPhone('student@mobdea.edu.eg');
      setPassword('123456');
    } else {
      setEmailOrPhone('guardian@mobdea.edu.eg');
      setPassword('123456');
    }
    setEmailError('');
    setPasswordError('');
    setFormError('');
  };

  // Submit Reset Password Handler
  const handleResetPasswordSubmit = async (e) => {
    e.preventDefault();
    setResetEmailError('');
    setResetStatus({ loading: false, success: '', error: '' });

    const check = validateEmail(resetEmail);
    if (!check.isValid) {
      setResetEmailError(check.message);
      return;
    }

    setResetStatus({ loading: true, success: '', error: '' });

    try {
      await resetPassword(resetEmail.trim());
      setResetStatus({ 
        loading: false, 
        success: 'تم إرسال رابط إعادة ضبط كلمة المرور إلى بريدك الإلكتروني بنجاح.', 
        error: '' 
      });
    } catch (err) {
      setResetStatus({ 
        loading: false, 
        success: '', 
        error: err.message || 'فشل إرسال البريد. تأكد من صحة البريد الإلكتروني.' 
      });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-amber-100 flex items-center justify-center p-4 lg:p-8 relative overflow-hidden font-ibm selection:bg-amber-500 selection:text-slate-950">
      
      {/* BACKGROUND ORNAMENTS & AMBIENT GOLD GLOW */}
      <div className="absolute top-1/4 -right-24 w-[500px] h-[500px] bg-amber-600/15 rounded-full blur-[140px] pointer-events-none"></div>
      <div className="absolute -bottom-24 -left-24 w-[500px] h-[500px] bg-amber-900/20 rounded-full blur-[160px] pointer-events-none"></div>
      <div className="absolute inset-0 bg-[radial-gradient(#d4af37_1px,transparent_1px)] [background-size:36px_36px] opacity-10 pointer-events-none"></div>

      {/* MAIN TWO-COLUMN CONTAINER */}
      <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10 my-auto">
        
        {/* LEFT COLUMN: BRAND SHOWCASE & HIGHLIGHTS (VISIBLE ON DESKTOP/TABLET LANDSCAPE) */}
        <div className="hidden lg:flex lg:col-span-6 xl:col-span-7 flex-col justify-between space-y-8 pr-4">
          
          {/* Header Branding */}
          <div>
            <div className="inline-flex items-center gap-2 bg-amber-950/80 border border-amber-600/50 px-4 py-1.5 rounded-full text-xs font-bold text-amber-300 mb-6 shadow-inner">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>المنصة التعليمية الأولى للدراسات والعلوم</span>
            </div>

            <div className="flex items-center gap-4 mb-4">
              {/* Gold Emblem Badge */}
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-600 via-amber-400 to-amber-200 p-0.5 shadow-xl shadow-amber-500/20 shrink-0">
                <div className="w-full h-full bg-slate-950 rounded-[22px] flex items-center justify-center border border-amber-900/80">
                  <span className="font-reem text-2xl font-black text-transparent bg-clip-text bg-gradient-to-tr from-amber-300 via-amber-200 to-amber-500">
                    المُبدِع
                  </span>
                </div>
              </div>

              <div>
                <h1 className="font-reem text-4xl xl:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 tracking-wide leading-tight">
                  منصة المُبدِع
                </h1>
                <p className="text-xs xl:text-sm text-amber-200/80 font-ibm mt-0.5">
                  منظومة متكاملة لبيئة تعليمية ممتعة وذكية
                </p>
              </div>
            </div>

            <p className="text-sm xl:text-base text-amber-100/90 font-ibm leading-relaxed max-w-xl mt-4">
              أهلاً بك في منصة المُبدع! الحل الرقمي الشامل المخصص للمعلمين والطلاب وأولياء الأمور لإدارة الحصص المباشرة والدرجات والامتحانات والتقارير بذكاء وسهولة.
            </p>
          </div>

          {/* Feature Badges Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl">
            
            <div className="p-4 bg-slate-900/70 border border-amber-800/40 hover:border-amber-500/60 rounded-2xl backdrop-blur-md transition shadow-lg group">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center group-hover:scale-110 transition">
                  <School className="w-5 h-5" />
                </div>
                <h3 className="font-reem font-bold text-sm text-amber-300">السبورة التفاعلية</h3>
              </div>
              <p className="text-xs text-amber-200/70 font-ibm leading-snug">
                شرح مباشر وحفظ التلخيصات والملاحظات لكل حصة.
              </p>
            </div>

            <div className="p-4 bg-slate-900/70 border border-amber-800/40 hover:border-amber-500/60 rounded-2xl backdrop-blur-md transition shadow-lg group">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center group-hover:scale-110 transition">
                  <FileCheck2 className="w-5 h-5" />
                </div>
                <h3 className="font-reem font-bold text-sm text-amber-300">التصحيح الآلي OMR</h3>
              </div>
              <p className="text-xs text-amber-200/70 font-ibm leading-snug">
                تصحيح الاختبارات بمسح البابل شيت واستخراج الدرجات فوراً.
              </p>
            </div>

            <div className="p-4 bg-slate-900/70 border border-amber-800/40 hover:border-amber-500/60 rounded-2xl backdrop-blur-md transition shadow-lg group">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center group-hover:scale-110 transition">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <h3 className="font-reem font-bold text-sm text-amber-300">متابعة أولياء الأمور</h3>
              </div>
              <p className="text-xs text-amber-200/70 font-ibm leading-snug">
                تقارير أوتوماتيكية للغياب والدرجات عبر واتساب.
              </p>
            </div>

            <div className="p-4 bg-slate-900/70 border border-amber-800/40 hover:border-amber-500/60 rounded-2xl backdrop-blur-md transition shadow-lg group">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center group-hover:scale-110 transition">
                  <Trophy className="w-5 h-5" />
                </div>
                <h3 className="font-reem font-bold text-sm text-amber-300">المسابقات والمكافآت</h3>
              </div>
              <p className="text-xs text-amber-200/70 font-ibm leading-snug">
                تحفيز الطلاب بنظام النقاط والأوسمة التنافسية.
              </p>
            </div>

          </div>

          {/* Footer System Status */}
          <div className="flex items-center gap-3 text-xs text-amber-300/80 font-ibm border-t border-amber-900/40 pt-4 max-w-xl">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>نظام إداري موحد ومستقر - الإصدار 2026</span>
          </div>

        </div>

        {/* RIGHT COLUMN: LOGIN FORM CARD */}
        <div className="lg:col-span-6 xl:col-span-5 flex items-center justify-center w-full">
          
          <div className="w-full bg-slate-900/80 border-2 border-amber-600/70 rounded-3xl p-6 sm:p-8 xl:p-10 shadow-2xl backdrop-blur-2xl relative overflow-hidden">
            
            {/* MOBILE ONLY HEADER BRANDING */}
            <div className="block lg:hidden text-center mb-6">
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-600 via-amber-400 to-amber-200 p-0.5 mx-auto mb-3 shadow-xl shadow-amber-500/20">
                <div className="w-full h-full bg-slate-950 rounded-[22px] flex items-center justify-center border border-amber-900/80">
                  <span className="font-reem text-2xl font-black text-transparent bg-clip-text bg-gradient-to-tr from-amber-300 via-amber-200 to-amber-500">
                    المُبدِع
                  </span>
                </div>
              </div>
              <h1 className="font-reem text-2xl font-extrabold text-amber-300 mb-1">
                منصة المُبدِع
              </h1>
              <p className="text-xs text-amber-200/80 font-ibm">
                منظومة متكاملة لبيئة تعليمية ممتعة وذكية
              </p>
            </div>

            <div className="mb-6">
              <h2 className="font-reem text-xl sm:text-2xl font-bold text-amber-300 text-center lg:text-right">
                تسجيل الدخول إلى حسابك
              </h2>
              <p className="text-xs text-amber-200/70 text-center lg:text-right font-ibm mt-1">
                يرجى إدخال بيانات الاعتماد للوصول إلى اللوحة الرسمية
              </p>
            </div>

            {/* ROLE SELECTION TABS */}
            <div className="bg-slate-950/80 border border-amber-900/60 p-1.5 rounded-2xl flex items-center gap-1 mb-6">
              <button
                type="button"
                onClick={() => handleQuickLogin('teacher')}
                className={`flex-1 py-2.5 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  role === 'teacher'
                    ? 'bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 shadow-md font-extrabold'
                    : 'text-amber-300/80 hover:text-amber-200 hover:bg-slate-900/80'
                }`}
              >
                <School className="w-4 h-4 shrink-0" />
                <span className="truncate">المعلم</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickLogin('student')}
                className={`flex-1 py-2.5 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  role === 'student'
                    ? 'bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 shadow-md font-extrabold'
                    : 'text-amber-300/80 hover:text-amber-200 hover:bg-slate-900/80'
                }`}
              >
                <BookOpen className="w-4 h-4 shrink-0" />
                <span className="truncate">الطالب</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickLogin('guardian')}
                className={`flex-1 py-2.5 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  role === 'guardian'
                    ? 'bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 shadow-md font-extrabold'
                    : 'text-amber-300/80 hover:text-amber-200 hover:bg-slate-900/80'
                }`}
              >
                <UserCheck className="w-4 h-4 shrink-0" />
                <span className="truncate">ولي الأمر</span>
              </button>
            </div>

            {/* SUCCESS MESSAGE BANNER */}
            {successMessage && (
              <div className="mb-5 p-3.5 bg-emerald-950/90 border border-emerald-500/80 rounded-2xl text-emerald-200 text-xs font-bold flex items-center gap-3 animate-fade-in shadow-lg">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {/* ERROR MESSAGE BANNER */}
            {formError && (
              <div className="mb-5 p-3.5 bg-rose-950/90 border border-rose-600/80 rounded-2xl text-rose-200 text-xs font-bold flex items-center gap-3 animate-fade-in shadow-lg">
                <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            {/* LOGIN FORM */}
            <form onSubmit={handleSubmit} className="space-y-4" noValidate>
              
              {/* EMAIL OR PHONE FIELD */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-amber-200/90 pr-1">
                  البريد الإلكتروني أو رقم الهاتف <span className="text-rose-400">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={emailOrPhone}
                    onChange={(e) => handleEmailChange(e.target.value)}
                    placeholder="مثال: name@mobdea.edu.eg أو 01012345678"
                    className={`w-full bg-slate-950/90 border ${
                      emailError ? 'border-rose-500 focus:ring-rose-500' : 'border-amber-900/70 focus:border-amber-400'
                    } rounded-2xl py-3 px-4 pr-11 text-xs text-amber-100 placeholder-amber-400/40 outline-none transition shadow-inner font-ibm`}
                    dir="ltr"
                    disabled={isSubmitting}
                  />
                  <Mail className="w-5 h-5 text-amber-400/80 absolute right-3.5 top-3.5 pointer-events-none" />
                </div>
                {emailError && (
                  <p className="text-xs text-rose-400 font-bold flex items-center gap-1 pt-0.5 pr-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{emailError}</span>
                  </p>
                )}
              </div>

              {/* PASSWORD FIELD */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between pr-1">
                  <label className="block text-xs font-bold text-amber-200/90">
                    كلمة المرور <span className="text-rose-400">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowForgotPassword(true)}
                    className="text-[11px] text-amber-400 hover:text-amber-300 font-bold underline transition"
                  >
                    نسيت كلمة المرور؟
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => handlePasswordChange(e.target.value)}
                    placeholder="••••••••"
                    className={`w-full bg-slate-950/90 border ${
                      passwordError ? 'border-rose-500 focus:ring-rose-500' : 'border-amber-900/70 focus:border-amber-400'
                    } rounded-2xl py-3 px-4 pr-11 pl-11 text-xs text-amber-100 placeholder-amber-400/40 outline-none transition shadow-inner font-ibm`}
                    dir="ltr"
                    disabled={isSubmitting}
                  />
                  <Lock className="w-5 h-5 text-amber-400/80 absolute right-3.5 top-3.5 pointer-events-none" />
                  
                  {/* Show / Hide Password Toggle Button */}
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3.5 top-3 text-amber-400/80 hover:text-amber-300 transition focus:outline-none"
                    title={showPassword ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
                {passwordError && (
                  <p className="text-xs text-rose-400 font-bold flex items-center gap-1 pt-0.5 pr-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{passwordError}</span>
                  </p>
                )}
              </div>

              {/* REMEMBER ME CHECKBOX */}
              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-amber-200/80">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded bg-slate-950 border-amber-800 text-amber-500 focus:ring-amber-500 accent-amber-500 cursor-pointer"
                  />
                  <span>تذكرني على هذا الجهاز</span>
                </label>
                <div className="flex items-center gap-1 text-[11px] text-amber-400/80">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  <span>اتصال آمن ومُشفر</span>
                </div>
              </div>

              {/* SUBMIT BUTTON */}
              <button
                type="submit"
                disabled={isSubmitting || authLoading}
                className={`w-full mt-2 py-3.5 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-reem font-extrabold text-sm rounded-2xl shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2 transition active:scale-[0.98] ${
                  (isSubmitting || authLoading) ? 'opacity-70 cursor-not-allowed' : ''
                }`}
              >
                {(isSubmitting || authLoading) ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>جاري تسجيل الدخول...</span>
                  </>
                ) : (
                  <>
                    <span>تسجيل الدخول</span>
                    <ArrowRight className="w-4 h-4 rotate-180" />
                  </>
                )}
              </button>

            </form>

            {/* DEMO QUICK ACCESS BUTTONS */}
            <div className="mt-6 pt-5 border-t border-amber-900/40">
              <p className="text-center text-[11px] font-bold text-amber-300/80 mb-2.5">
                ⚡ تجربة فورية - اختر حساب تجريبي للدخول المباشر:
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    handleQuickLogin('teacher');
                    login({ email: 'teacher@mobdea.edu.eg', password: '123456' })
                      .then(() => onLoginSuccess())
                      .catch(() => onLoginSuccess());
                  }}
                  className="py-2 px-3 bg-slate-950 hover:bg-amber-950/80 border border-amber-800/60 rounded-xl text-amber-300 text-xs font-bold flex items-center justify-center gap-1.5 transition"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>دخول المعلم التجريبي</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    handleQuickLogin('student');
                    login({ email: 'student@mobdea.edu.eg', password: '123456' })
                      .then(() => onLoginSuccess())
                      .catch(() => onLoginSuccess());
                  }}
                  className="py-2 px-3 bg-slate-950 hover:bg-amber-950/80 border border-amber-800/60 rounded-xl text-amber-300 text-xs font-bold flex items-center justify-center gap-1.5 transition"
                >
                  <Trophy className="w-3.5 h-3.5 text-amber-400" />
                  <span>دخول الطالب المميز</span>
                </button>
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* FORGOT PASSWORD MODAL */}
      {showForgotPassword && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-slate-900 border-2 border-amber-600/70 p-6 sm:p-8 rounded-3xl max-w-md w-full shadow-2xl relative">
            
            <div className="w-12 h-12 rounded-2xl bg-amber-600/20 text-amber-400 flex items-center justify-center mb-4 border border-amber-500/40">
              <KeyRound className="w-6 h-6" />
            </div>

            <h2 className="font-reem text-xl font-bold text-amber-300 mb-2">
              إعادة ضبط كلمة المرور
            </h2>
            <p className="text-xs text-amber-200/80 font-ibm mb-5 leading-relaxed">
              أدخل البريد الإلكتروني المسجل في المنصة وسنرسل لك رابطاً آمنًا لإعادة ضبط كلمة المرور الخاصة بك.
            </p>

            {resetStatus.success && (
              <div className="mb-4 p-3 bg-emerald-950 border border-emerald-500 rounded-xl text-xs text-emerald-300 font-bold">
                {resetStatus.success}
              </div>
            )}

            {resetStatus.error && (
              <div className="mb-4 p-3 bg-rose-950 border border-rose-500 rounded-xl text-xs text-rose-300 font-bold">
                {resetStatus.error}
              </div>
            )}

            <form onSubmit={handleResetPasswordSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-amber-200 mb-1">
                  البريد الإلكتروني
                </label>
                <input
                  type="email"
                  value={resetEmail}
                  onChange={(e) => {
                    setResetEmail(e.target.value);
                    if (resetEmailError) setResetEmailError('');
                  }}
                  placeholder="name@mobdea.edu.eg"
                  className="w-full bg-slate-950 border border-amber-900/80 focus:border-amber-400 rounded-xl py-2.5 px-4 text-xs text-amber-100 outline-none"
                  dir="ltr"
                />
                {resetEmailError && (
                  <p className="text-xs text-rose-400 font-bold mt-1">{resetEmailError}</p>
                )}
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  disabled={resetStatus.loading}
                  className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs rounded-xl shadow transition flex items-center justify-center gap-2"
                >
                  {resetStatus.loading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <span>إرسال الرابط</span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setShowForgotPassword(false);
                    setResetStatus({ loading: false, success: '', error: '' });
                  }}
                  className="py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs rounded-xl transition"
                >
                  إلغاء
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
}
