import React from 'react';
import { FileText, Video, Image as ImageIcon, Monitor, HelpCircle, Gamepad2, Plus } from 'lucide-react';

export default function LessonResourcesBar({ activeResource, onSelectResource, onAddResource }) {
  const RESOURCES = [
    { id: 'pdf', label: 'PDF', icon: FileText, color: 'text-rose-400', bg: 'hover:bg-rose-950/40' },
    { id: 'video', label: 'فيديو', icon: Video, color: 'text-blue-400', bg: 'hover:bg-blue-950/40' },
    { id: 'image', label: 'صورة', icon: ImageIcon, color: 'text-amber-400', bg: 'hover:bg-amber-950/40' },
    { id: 'board', label: 'السبورة', icon: Monitor, color: 'text-emerald-400', bg: 'hover:bg-emerald-950/40' },
    { id: 'quiz', label: 'اختبار', icon: HelpCircle, color: 'text-purple-400', bg: 'hover:bg-purple-950/40' },
    { id: 'game', label: 'لعبة', icon: Gamepad2, color: 'text-cyan-400', bg: 'hover:bg-cyan-950/40' },
  ];

  return (
    <div className="w-full bg-gradient-to-r from-black via-slate-950 to-black border-2 border-amber-600/60 rounded-2xl px-3 py-1.5 shadow-2xl flex items-center justify-between gap-2 overflow-x-auto custom-scrollbar">
      <div className="flex items-center gap-1.5 sm:gap-2">
        {RESOURCES.map((item) => {
          const Icon = item.icon;
          const isActive = activeResource === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onSelectResource(item.id)}
              className={`px-3 py-1.5 rounded-xl border text-xs font-ibm font-extrabold flex items-center gap-1.5 transition active:scale-95 shrink-0 ${
                isActive
                  ? 'bg-amber-500 text-slate-950 border-amber-300 shadow-md shadow-amber-500/20'
                  : `bg-slate-900/90 text-amber-100 border-amber-900/50 ${item.bg}`
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-950' : item.color}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Add Resource (+ إضافة مصدر) */}
      <button
        onClick={onAddResource}
        className="px-3 py-1.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-ibm font-bold text-xs rounded-xl shadow-md flex items-center gap-1 shrink-0 transition"
      >
        <Plus className="w-3.5 h-3.5 text-slate-950" />
        <span>إضافة مصدر</span>
      </button>
    </div>
  );
}
