import React from 'react';
import { X, Send, Sparkles, MessageCircle, Heart, Star, Award, Check } from 'lucide-react';

const PREDEFINED_MOTIVATIONAL_MESSAGES = [
  { id: 1, title: 'تشجيع وتفوق 🌟', icon: Star, text: 'ممتاز يا بطل! واصل التميز والتفوق دائماً في مادة الدراسات الاجتماعية والتاريخ.' },
  { id: 2, title: 'مشاركة نموذجية 🏆', icon: Award, text: 'إجابة نموذجية ومشاركة ممتازة في حصة اليوم! استمر في هذا الأداء الرائع.' },
  { id: 3, title: 'تحسن وتقدم 👏', icon: Sparkles, text: 'تحسن ملحوظ في المستوى الأكاديمي والتفاعل أثناء الشرح، أحييك على اجتهادك!' },
  { id: 4, title: 'شكر وتقدير ✨', icon: Heart, text: 'نشكرك على الالتزام والتركيز العالي اليوم مع أستاذ مصطفى بركات.' },
  { id: 5, title: 'رسالة لولي الأمر 👍', icon: MessageCircle, text: 'متابعة ممتازة من ولي الأمر الكريم، نود إعلامكم بتألق الطالب وتفوقه في حصة اليوم.' },
  { id: 6, title: 'تنبيه المتابعة 📝', icon: Send, text: 'تنبيه بسيط: يرجى مراجعة نقاط درس اليوم وتحضير الإجابات للحصة القادمة.' }
];

export default function MotivationalModal({ student, onClose }) {
  const [selectedMsg, setSelectedMsg] = React.useState(PREDEFINED_MOTIVATIONAL_MESSAGES[0]);
  const [sentSuccess, setSentSuccess] = React.useState(false);

  if (!student) return null;

  const handleSendWhatsApp = (msgText) => {
    const fullText = `سلام عليكم ولي أمر الطالب/ة ${student.name} 🎓\n\n${msgText}\n\n— منصة المُبدع التعليمية (أستاذ مصطفى بركات)`;
    const phone = student.guardianPhone || '01012345678';
    const url = `https://api.whatsapp.com/send?phone=${phone}&text=${encodeURIComponent(fullText)}`;
    window.open(url, '_blank');
    setSentSuccess(true);
    setTimeout(() => setSentSuccess(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-black border-2 border-amber-500/80 rounded-3xl max-w-lg w-full p-6 text-amber-100 shadow-2xl relative animate-fade-in">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute left-4 top-4 text-amber-400 hover:text-white bg-slate-900/80 p-2 rounded-xl border border-amber-700/50 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6 pb-4 border-b border-amber-800/40">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-600 to-amber-400 flex items-center justify-center text-slate-950 font-bold text-xl shadow-lg">
            💬
          </div>
          <div>
            <h3 className="font-reem text-xl font-extrabold text-amber-300">
              إرسال رسالة تحفيزية للطلب
            </h3>
            <p className="text-xs text-amber-200/80 font-ibm">
              الطالب: <span className="font-bold text-white">{student.name}</span> (كود #{student.code})
            </p>
          </div>
        </div>

        {/* Messages Options */}
        <div className="space-y-3 max-h-80 overflow-y-auto pr-1 custom-scrollbar mb-6">
          {PREDEFINED_MOTIVATIONAL_MESSAGES.map((msg) => {
            const Icon = msg.icon;
            const isSelected = selectedMsg.id === msg.id;
            return (
              <div
                key={msg.id}
                onClick={() => setSelectedMsg(msg)}
                className={`p-3.5 rounded-2xl border transition cursor-pointer flex items-start gap-3 ${
                  isSelected
                    ? 'bg-amber-950/80 border-amber-400 text-amber-200 shadow-lg shadow-amber-950/50'
                    : 'bg-slate-900/60 border-amber-900/40 text-amber-100/80 hover:bg-slate-800/80'
                }`}
              >
                <div className={`p-2 rounded-xl mt-0.5 ${isSelected ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-amber-400'}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <h4 className="font-ibm font-bold text-sm text-amber-300">{msg.title}</h4>
                  <p className="font-ibm text-xs text-amber-100/90 leading-relaxed mt-1">{msg.text}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Success Alert */}
        {sentSuccess && (
          <div className="mb-4 p-3 bg-emerald-950/90 border border-emerald-500/80 text-emerald-300 rounded-xl font-ibm text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>تم فتح تطبيق واتساب لإرسال الرسالة بنجاح!</span>
          </div>
        )}

        {/* Action Button */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => handleSendWhatsApp(selectedMsg.text)}
            className="flex-1 py-3.5 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-ibm font-extrabold text-sm rounded-2xl shadow-lg shadow-emerald-950/80 flex items-center justify-center gap-2 transition"
          >
            <Send className="w-4 h-4" />
            إرسال عبر واتساب إلى ولي الأمر ({student.guardianPhone || '01012345678'})
          </button>
        </div>

      </div>
    </div>
  );
}
