import React, { useState, useEffect } from 'react';
import { 
  Search, Bell, Calendar, Clock, ArrowLeft, Folder, Gamepad2, 
  BookOpen, Trophy, CheckSquare, Users, Sparkles, AlertCircle, Play
} from 'lucide-react';

export default function DashboardHomepage({ onNavigate, currentSession, students, sessions }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [notificationsCount, setNotificationsCount] = useState(5);
  const [showNotificationToast, setShowNotificationToast] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(2120); // 00:35:20

  // Live timer countdown
  useEffect(() => {
    const interval = setInterval(() => {
      setTimerSeconds(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTimer = (totalSec) => {
    const h = String(Math.floor(totalSec / 3600)).padStart(2, '0');
    const m = String(Math.floor((totalSec % 3600) / 60)).padStart(2, '0');
    const s = String(totalSec % 60).padStart(2, '0');
    return `${h}:${m}:${s}`;
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    // Filter navigate
    if (searchQuery.includes('طالب') || searchQuery.includes('أحمد') || searchQuery.includes('عمر')) {
      onNavigate('students');
    } else if (searchQuery.includes('امتحان') || searchQuery.includes('اختبار')) {
      onNavigate('scanner');
    } else if (searchQuery.includes('لعبة') || searchQuery.includes('مسابقة')) {
      onNavigate('games');
    } else {
      onNavigate('students');
    }
  };

  return (
    <div className="space-y-6 font-ibm text-amber-100 animate-fade-in">
      
      {/* 1. TOP HEADER BAR (Search + User Profile) */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        
        {/* Search Input */}
        <form onSubmit={handleSearchSubmit} className="relative w-full sm:w-80">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث هنا..."
            className="w-full bg-slate-900/90 border border-amber-900/60 focus:border-amber-500 rounded-2xl py-2.5 px-4 pr-10 text-xs text-amber-100 placeholder-amber-400/50 outline-none shadow-inner transition"
          />
          <Search className="w-4 h-4 text-amber-400 absolute right-3.5 top-3" />
        </form>

        {/* Profile + Notifications */}
        <div className="flex items-center gap-4 self-end sm:self-auto">
          
          {/* Notification Bell */}
          <button 
            onClick={() => {
              setShowNotificationToast(true);
              setTimeout(() => setShowNotificationToast(false), 4000);
            }}
            className="relative p-2.5 bg-slate-900/90 border border-amber-800/60 hover:border-amber-500 rounded-2xl text-amber-300 transition shadow-md"
            title="التنبيهات والإشعارات"
          >
            <Bell className="w-5 h-5" />
            {notificationsCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-rose-600 text-white text-[10px] font-extrabold w-5 h-5 rounded-full flex items-center justify-center border-2 border-slate-950 animate-pulse">
                {notificationsCount}
              </span>
            )}
          </button>

          {/* User Profile Badge */}
          <div 
            onClick={() => onNavigate('settings')}
            className="flex items-center gap-3 bg-gradient-to-l from-amber-950/80 via-slate-900 to-black border border-amber-600/70 p-1.5 pr-3 rounded-2xl shadow-xl cursor-pointer hover:border-amber-400 transition"
          >
            <div className="text-right">
              <h3 className="font-reem text-sm font-extrabold text-amber-300 leading-tight">
                مرحباً بك، المبدع
              </h3>
              <p className="text-[10px] text-amber-200/70 font-ibm">
                معلم دراسات
              </p>
            </div>

            {/* Circular Teacher Avatar */}
            <div className="relative w-10 h-10 rounded-full p-0.5 bg-gradient-to-tr from-amber-300 via-amber-600 to-amber-200 shadow-md">
              <div className="w-full h-full rounded-full overflow-hidden bg-amber-950 flex items-center justify-center border border-amber-900">
                <svg className="w-full h-full" viewBox="0 0 100 100" fill="none">
                  <rect width="100" height="100" fill="#1f1008" />
                  <ellipse cx="50" cy="42" rx="18" ry="22" fill="#e0ac69" />
                  <path d="M 31 38 C 31 22, 69 22, 69 38 C 65 24, 35 24, 31 38 Z" fill="#1f150d" />
                  <circle cx="43" cy="40" r="2.5" fill="#2d1b0e" />
                  <circle cx="57" cy="40" r="2.5" fill="#2d1b0e" />
                  <path d="M 34 46 C 34 62, 66 62, 66 46 C 60 58, 40 58, 34 46 Z" fill="#261a10" />
                  <path d="M 44 49 Q 50 54 56 49" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" fill="none" />
                  <path d="M 22 88 Q 50 62 78 88 L 85 100 L 15 100 Z" fill="#4a2e1b" stroke="#d4af37" strokeWidth="2" />
                </svg>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Notification Toast Alert */}
      {showNotificationToast && (
        <div className="bg-gradient-to-r from-amber-950 via-slate-900 to-amber-950 border border-amber-500/80 p-3 rounded-2xl text-xs text-amber-200 flex items-center justify-between shadow-xl animate-fade-in">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>لديك 5 إشعارات جديدة: تم تسجيل حضور 12 طالباً وإرسال التقارير لوليات الأمور.</span>
          </div>
          <button onClick={() => setShowNotificationToast(false)} className="text-amber-400 hover:text-white font-bold">
            إغلاق
          </button>
        </div>
      )}

      {/* 2. HERO BANNER + SCHEDULE WIDGET */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* HERO BANNER (8 Cols) */}
        <div className="lg:col-span-8 bg-gradient-to-br from-[#2a170b] via-[#1a0c05] to-[#0d0502] border-2 border-amber-600/70 rounded-3xl p-6 md:p-8 relative overflow-hidden shadow-2xl flex flex-col justify-between">
          
          {/* Background Luxury Vignette & Ornament Glow */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-amber-800/10 rounded-full blur-2xl pointer-events-none"></div>

          {/* Top Historic Callout Tag */}
          <div className="flex items-center gap-2 mb-4">
            <div className="bg-amber-950/80 border border-amber-500/60 px-3.5 py-1 rounded-xl text-amber-300 text-xs font-bold flex items-center gap-1.5 shadow-inner">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>العلم نور الحياة</span>
            </div>
            <div className="text-[11px] text-amber-300/70 font-ibm">خريطة العالم في العصور الوسطى</div>
          </div>

          {/* Hero Main Content */}
          <div className="relative z-10 max-w-lg">
            <div className="text-xs font-bold text-amber-400 tracking-widest mb-1">منصة</div>
            <h1 className="font-reem text-3xl md:text-5xl font-black text-amber-300 tracking-wide drop-shadow-md mb-3 leading-tight">
              منصة المُبدَع <br />
              <span className="text-white text-2xl md:text-4xl">لتعلِيمٍ مُمتِع</span>
            </h1>
            <p className="text-amber-200/90 text-xs sm:text-sm font-ibm leading-relaxed mb-6">
              منصة متكاملة لإدارة التعليم، الحضور، الدرجات، المدفوعات، والاختبارات في مكان واحد
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => onNavigate('classMode')}
                className="px-6 py-3 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-reem font-extrabold text-sm rounded-2xl shadow-xl shadow-amber-500/20 flex items-center gap-2 transition active:scale-95"
              >
                <Play className="w-4 h-4 text-slate-950 fill-slate-950" />
                <span>ابدأ الحصة الآن</span>
              </button>

              <button
                onClick={() => onNavigate('sessions')}
                className="px-5 py-3 bg-slate-900/90 hover:bg-slate-800 text-amber-200 border border-amber-600/70 font-ibm font-bold text-sm rounded-2xl shadow-lg flex items-center gap-2 transition active:scale-95"
              >
                <Calendar className="w-4 h-4 text-amber-400" />
                <span>عرض الجدول</span>
              </button>
            </div>
          </div>

          {/* Right Historical Books Visual Motif Overlay */}
          <div className="hidden md:block absolute left-4 bottom-4 w-48 text-left pointer-events-none opacity-90">
            <div className="space-y-1 font-reem text-[11px] font-bold text-amber-300/80">
              <div className="bg-amber-950/80 border border-amber-800/80 px-2 py-0.5 rounded shadow">الحضارات القديمة</div>
              <div className="bg-amber-950/80 border border-amber-800/80 px-2 py-0.5 rounded shadow">الجغرافيا التاريخية</div>
              <div className="bg-amber-950/80 border border-amber-800/80 px-2 py-0.5 rounded shadow">دراسات اجتماعية</div>
            </div>
          </div>

        </div>

        {/* TODAY SCHEDULE WIDGET (4 Cols) */}
        <div className="lg:col-span-4 bg-gradient-to-b from-slate-950 via-slate-900 to-black border-2 border-amber-600/70 rounded-3xl p-5 shadow-2xl flex flex-col justify-between">
          
          <div>
            {/* Widget Title */}
            <div className="flex items-center justify-between border-b border-amber-800/40 pb-3 mb-3">
              <div className="flex items-center gap-2 text-amber-300 font-reem font-bold text-base">
                <Calendar className="w-4 h-4 text-amber-400" />
                <span>جدول اليوم</span>
              </div>
              <span className="text-xs text-amber-400/80 font-ibm">الأحد 20 يوليو 2025</span>
            </div>

            {/* Schedule List */}
            <div className="space-y-2.5">
              <div className="p-2.5 bg-slate-900/80 border border-amber-900/40 hover:border-amber-600/60 rounded-2xl flex items-center justify-between text-xs transition">
                <span className="text-slate-400 font-mono font-bold">2:00 م</span>
                <span className="font-bold text-amber-100">الصف الرابع الابتدائي</span>
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
              </div>

              <div className="p-2.5 bg-slate-900/80 border border-amber-900/40 hover:border-amber-600/60 rounded-2xl flex items-center justify-between text-xs transition">
                <span className="text-slate-400 font-mono font-bold">3:00 م</span>
                <span className="font-bold text-amber-100">الصف السادس الابتدائي</span>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
              </div>

              <div className="p-2.5 bg-amber-950/80 border border-amber-500/80 rounded-2xl flex items-center justify-between text-xs transition shadow-md">
                <span className="text-amber-300 font-mono font-extrabold">4:00 م</span>
                <span className="font-extrabold text-amber-200">الصف الأول الإعدادي</span>
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping"></span>
              </div>

              <div className="p-2.5 bg-slate-900/80 border border-amber-900/40 hover:border-amber-600/60 rounded-2xl flex items-center justify-between text-xs transition">
                <span className="text-slate-400 font-mono font-bold">5:00 م</span>
                <span className="font-bold text-amber-100">الصف الأول الثانوي</span>
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
              </div>
            </div>
          </div>

          {/* View Full Schedule Button */}
          <button
            onClick={() => onNavigate('sessions')}
            className="w-full mt-4 py-2.5 bg-slate-900 hover:bg-slate-800 border border-amber-700/60 text-amber-300 font-ibm font-extrabold text-xs rounded-2xl flex items-center justify-center gap-2 transition"
          >
            <span>عرض الجدول الكامل</span>
            <ArrowLeft className="w-4 h-4" />
          </button>

        </div>

      </div>

      {/* 3. MIDDLE SHORTCUT GRID (6 FEATURE CARDS) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        
        {/* CARD 1: المكتبة */}
        <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-black border border-amber-700/50 hover:border-amber-500 rounded-3xl p-4 text-center flex flex-col justify-between shadow-xl transition group">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-amber-600/20 border border-amber-500/40 text-amber-400 mx-auto mb-3 flex items-center justify-center group-hover:scale-110 transition">
              <Folder className="w-6 h-6" />
            </div>
            <h3 className="font-reem text-base font-extrabold text-amber-300 mb-1">المكتبة</h3>
            <p className="text-[11px] text-amber-200/70 font-ibm leading-tight mb-4">
              ملفات تعليمية، كتب، فيديوهات والمزيد
            </p>
          </div>
          <button
            onClick={() => onNavigate('questionBank')}
            className="w-full py-2 bg-slate-900 hover:bg-amber-500 hover:text-slate-950 text-amber-300 border border-amber-700/60 font-ibm font-bold text-xs rounded-xl transition"
          >
            فتح المكتبة
          </button>
        </div>

        {/* CARD 2: الألعاب التعليمية */}
        <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-black border border-amber-700/50 hover:border-amber-500 rounded-3xl p-4 text-center flex flex-col justify-between shadow-xl transition group">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-amber-600/20 border border-amber-500/40 text-amber-400 mx-auto mb-3 flex items-center justify-center group-hover:scale-110 transition">
              <Gamepad2 className="w-6 h-6" />
            </div>
            <h3 className="font-reem text-base font-extrabold text-amber-300 mb-1">الألعاب التعليمية</h3>
            <p className="text-[11px] text-amber-200/70 font-ibm leading-tight mb-4">
              ألعاب تفاعلية لتعزيز الفهم والمراجعة
            </p>
          </div>
          <button
            onClick={() => onNavigate('games')}
            className="w-full py-2 bg-slate-900 hover:bg-amber-500 hover:text-slate-950 text-amber-300 border border-amber-700/60 font-ibm font-bold text-xs rounded-xl transition"
          >
            فتح الألعاب
          </button>
        </div>

        {/* CARD 3: الدروس والمحتوى */}
        <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-black border border-amber-700/50 hover:border-amber-500 rounded-3xl p-4 text-center flex flex-col justify-between shadow-xl transition group">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-rose-600/20 border border-rose-500/40 text-rose-400 mx-auto mb-3 flex items-center justify-center group-hover:scale-110 transition">
              <BookOpen className="w-6 h-6" />
            </div>
            <h3 className="font-reem text-base font-extrabold text-rose-300 mb-1">الدروس والمحتوى</h3>
            <p className="text-[11px] text-amber-200/70 font-ibm leading-tight mb-4">
              إدارة الدروس والملفات والشرح والوسائط
            </p>
          </div>
          <button
            onClick={() => onNavigate('classMode')}
            className="w-full py-2 bg-slate-900 hover:bg-rose-600 hover:text-white text-rose-300 border border-rose-700/60 font-ibm font-bold text-xs rounded-xl transition"
          >
            إدارة الدروس
          </button>
        </div>

        {/* CARD 4: الدرجات والتقارير */}
        <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-black border border-amber-700/50 hover:border-amber-500 rounded-3xl p-4 text-center flex flex-col justify-between shadow-xl transition group">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-blue-600/20 border border-blue-500/40 text-blue-400 mx-auto mb-3 flex items-center justify-center group-hover:scale-110 transition">
              <Trophy className="w-6 h-6" />
            </div>
            <h3 className="font-reem text-base font-extrabold text-amber-300 mb-1">الدرجات والتقارير</h3>
            <p className="text-[11px] text-amber-200/70 font-ibm leading-tight mb-4">
              إدخال الدرجات واستعراض التقارير والنتائج
            </p>
          </div>
          <button
            onClick={() => onNavigate('grades')}
            className="w-full py-2 bg-slate-900 hover:bg-amber-500 hover:text-slate-950 text-amber-300 border border-amber-700/60 font-ibm font-bold text-xs rounded-xl transition"
          >
            عرض التقارير
          </button>
        </div>

        {/* CARD 5: الحضور والغياب */}
        <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-black border border-amber-700/50 hover:border-amber-500 rounded-3xl p-4 text-center flex flex-col justify-between shadow-xl transition group">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 mx-auto mb-3 flex items-center justify-center group-hover:scale-110 transition">
              <CheckSquare className="w-6 h-6" />
            </div>
            <h3 className="font-reem text-base font-extrabold text-emerald-300 mb-1">الحضور والغياب</h3>
            <p className="text-[11px] text-amber-200/70 font-ibm leading-tight mb-4">
              تسجيل الحضور باستخدام QR ومتابعة الغياب
            </p>
          </div>
          <button
            onClick={() => onNavigate('attendance')}
            className="w-full py-2 bg-slate-900 hover:bg-emerald-600 hover:text-white text-emerald-300 border border-emerald-700/60 font-ibm font-bold text-xs rounded-xl transition"
          >
            فتح الحضور
          </button>
        </div>

        {/* CARD 6: إدارة الطلاب */}
        <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-black border border-amber-700/50 hover:border-amber-500 rounded-3xl p-4 text-center flex flex-col justify-between shadow-xl transition group">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-purple-600/20 border border-purple-500/40 text-purple-400 mx-auto mb-3 flex items-center justify-center group-hover:scale-110 transition">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="font-reem text-base font-extrabold text-amber-300 mb-1">إدارة الطلاب</h3>
            <p className="text-[11px] text-amber-200/70 font-ibm leading-tight mb-4">
              إضافة وتعديل بيانات الطلاب ومتابعة ملفاتهم
            </p>
          </div>
          <button
            onClick={() => onNavigate('students')}
            className="w-full py-2 bg-slate-900 hover:bg-amber-500 hover:text-slate-950 text-amber-300 border border-amber-700/60 font-ibm font-bold text-xs rounded-xl transition"
          >
            عرض الطلاب
          </button>
        </div>

      </div>

      {/* 4. BOTTOM ROW (3 WIDGETS) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* WIDGET 1: الحصة الحالية */}
        <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-black border-2 border-amber-600/70 rounded-3xl p-5 shadow-2xl flex flex-col justify-between relative overflow-hidden">
          <div>
            <div className="flex items-center justify-between mb-3 border-b border-amber-800/40 pb-2">
              <h3 className="font-reem text-base font-extrabold text-amber-300">
                الحصة الحالية
              </h3>
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping"></span>
            </div>

            <div className="space-y-1 mb-4">
              <h4 className="font-ibm font-extrabold text-sm text-white">
                {currentSession?.title || "الدراسات الاجتماعية"}
              </h4>
              <p className="text-xs text-amber-300/80 font-ibm">
                {currentSession?.group || "الصف الأول الإعدادي"}
              </p>
            </div>

            {/* Countdown timer */}
            <div className="text-center my-3 bg-amber-950/60 border border-amber-700/50 p-3 rounded-2xl">
              <p className="text-[10px] text-amber-400 font-bold mb-1">الوقت المتبقي</p>
              <div className="font-mono text-xl font-black text-amber-300 tracking-wider">
                {formatTimer(timerSeconds)}
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('classMode')}
            className="w-full py-2.5 bg-rose-950/80 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-600/60 font-ibm font-extrabold text-xs rounded-2xl transition"
          >
            إنهاء / دخول الحصة
          </button>
        </div>

        {/* WIDGET 2: آخر الإعلانات */}
        <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-black border-2 border-amber-600/70 rounded-3xl p-5 shadow-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3 border-b border-amber-800/40 pb-2 text-amber-300 font-reem font-bold text-base">
              <AlertCircle className="w-4 h-4 text-amber-400" />
              <h3>آخر الإعلانات</h3>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex items-start justify-between gap-2 border-b border-amber-900/30 pb-2">
                <div>
                  <h4 className="font-bold text-amber-100">اختبار درس الحضارة المصرية القديمة غداً</h4>
                  <p className="text-[10px] text-amber-400/80">الاثنين 21 يوليو - جميع المراحل</p>
                </div>
                <span className="w-2 h-2 rounded-full bg-rose-500 mt-1 shrink-0"></span>
              </div>

              <div className="flex items-start justify-between gap-2">
                <div>
                  <h4 className="font-bold text-amber-100">مراجعة شهر يوليو</h4>
                  <p className="text-[10px] text-amber-400/80">الأربعاء 23 يوليو - الصف الأول الإعدادي</p>
                </div>
                <span className="w-2 h-2 rounded-full bg-amber-400 mt-1 shrink-0"></span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('messages')}
            className="w-full mt-4 py-2.5 bg-slate-900 hover:bg-slate-800 border border-amber-700/60 text-amber-300 font-ibm font-extrabold text-xs rounded-2xl transition"
          >
            عرض جميع الإعلانات
          </button>
        </div>

        {/* WIDGET 3: الاختبارات القادمة */}
        <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-black border-2 border-amber-600/70 rounded-3xl p-5 shadow-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3 border-b border-amber-800/40 pb-2 text-amber-300 font-reem font-bold text-base">
              <Calendar className="w-4 h-4 text-amber-400" />
              <h3>الاختبارات القادمة</h3>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex items-start justify-between gap-2 border-b border-amber-900/30 pb-2">
                <div>
                  <h4 className="font-bold text-amber-100">اختبار درس الحضارة المصرية القديمة غداً</h4>
                  <p className="text-[10px] text-amber-400/80">الاثنين 21 يوليو - جميع المراحل</p>
                </div>
                <span className="w-2 h-2 rounded-full bg-rose-500 mt-1 shrink-0"></span>
              </div>

              <div className="flex items-start justify-between gap-2">
                <div>
                  <h4 className="font-bold text-amber-100">مراجعة شهر يوليو</h4>
                  <p className="text-[10px] text-amber-400/80">الأربعاء 23 يوليو - الصف الأول الإعدادي</p>
                </div>
                <span className="w-2 h-2 rounded-full bg-amber-400 mt-1 shrink-0"></span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('scanner')}
            className="w-full mt-4 py-2.5 bg-slate-900 hover:bg-slate-800 border border-amber-700/60 text-amber-300 font-ibm font-extrabold text-xs rounded-2xl transition"
          >
            عرض جميع الاختبارات
          </button>
        </div>

      </div>

    </div>
  );
}
