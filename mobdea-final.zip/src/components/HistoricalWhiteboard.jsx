import React, { useState, useRef, useEffect } from 'react';
import { 
  MousePointer, Edit3, Eraser, Type, Square, Image as ImageIcon, 
  RotateCcw, RotateCw, ZoomIn, ZoomOut, Sparkles, Trash2, Maximize2
} from 'lucide-react';

export default function HistoricalWhiteboard({ currentLesson }) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);

  // Tools & Drawing States
  const [activeTool, setActiveTool] = useState('pen'); // 'pen', 'highlighter', 'eraser', 'shape', 'text', 'pointer'
  const [penColor, setPenColor] = useState('#1e3a8a'); // default blue ink like reference
  const [penSize, setPenSize] = useState(3);
  const [isDrawing, setIsDrawing] = useState(false);
  
  // History for Undo / Redo
  const [history, setHistory] = useState([]);
  const [historyStep, setHistoryStep] = useState(-1);

  // Zoom & Pan
  const [zoomLevel, setZoomLevel] = useState(1);

  // Custom user text overlay
  const [textInputs, setTextInputs] = useState([]);
  const [newText, setNewText] = useState('');

  // Setup initial canvas dimensions and history
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = canvas.parentElement.clientWidth || 1000;
    canvas.height = canvas.parentElement.clientHeight || 700;

    // Save blank base state
    saveCanvasState();

    const handleResize = () => {
      // Preserve canvas drawing on window resize
      const tempImage = new Image();
      tempImage.src = canvas.toDataURL();
      tempImage.onload = () => {
        canvas.width = canvas.parentElement.clientWidth || 1000;
        canvas.height = canvas.parentElement.clientHeight || 700;
        ctx.drawImage(tempImage, 0, 0);
      };
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const saveCanvasState = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const dataUrl = canvas.toDataURL();
    setHistory(prev => {
      const next = prev.slice(0, historyStep + 1);
      return [...next, dataUrl];
    });
    setHistoryStep(prev => prev + 1);
  };

  const handleUndo = () => {
    if (historyStep <= 0) return;
    const nextStep = historyStep - 1;
    setHistoryStep(nextStep);
    restoreCanvasState(history[nextStep]);
  };

  const handleRedo = () => {
    if (historyStep >= history.length - 1) return;
    const nextStep = historyStep + 1;
    setHistoryStep(nextStep);
    restoreCanvasState(history[nextStep]);
  };

  const restoreCanvasState = (dataUrl) => {
    const canvas = canvasRef.current;
    if (!canvas || !dataUrl) return;
    const ctx = canvas.getContext('2d');
    const img = new Image();
    img.src = dataUrl;
    img.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
    };
  };

  const clearCanvasDrawings = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    saveCanvasState();
    setTextInputs([]);
  };

  // Canvas Mouse / Touch Handlers
  const startDrawing = (e) => {
    if (activeTool === 'pointer') return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX || e.touches?.[0]?.clientX) - rect.left;
    const y = (e.clientY || e.touches?.[0]?.clientY) - rect.top;

    const ctx = canvas.getContext('2d');
    ctx.beginPath();
    ctx.moveTo(x / zoomLevel, y / zoomLevel);
    setIsDrawing(true);
  };

  const draw = (e) => {
    if (!isDrawing || activeTool === 'pointer') return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX || e.touches?.[0]?.clientX) - rect.left) / zoomLevel;
    const y = ((e.clientY || e.touches?.[0]?.clientY) - rect.top) / zoomLevel;

    const ctx = canvas.getContext('2d');

    if (activeTool === 'eraser') {
      ctx.clearRect(x - 15, y - 15, 30, 30);
    } else {
      ctx.strokeStyle = activeTool === 'highlighter' ? `${penColor}55` : penColor;
      ctx.lineWidth = activeTool === 'highlighter' ? penSize * 4 : penSize;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };

  const stopDrawing = () => {
    if (isDrawing) {
      setIsDrawing(false);
      saveCanvasState();
    }
  };

  const addTextToBoard = () => {
    if (!newText.trim()) return;
    setTextInputs(prev => [...prev, { id: Date.now(), text: newText, x: 200, y: 200, color: penColor }]);
    setNewText('');
  };

  // Grade, Subject, Lesson Name from current lesson
  const gradeName = currentLesson?.grade || "الصف الأول الإعدادي";
  const subjectName = currentLesson?.subject || "الدراسات الاجتماعية والتاريخ";
  const lessonTitle = currentLesson?.lessonName || "الدرس: مفهوم الدولة وعناصرها";

  return (
    <div 
      ref={containerRef}
      className="relative flex-1 bg-slate-950 p-2 md:p-4 rounded-3xl border-2 border-amber-600/70 shadow-2xl flex flex-col justify-between overflow-hidden min-h-[640px]"
    >
      
      {/* LUXURY HISTORICAL FRAME WRAPPER */}
      <div className="relative flex-1 bg-[#f5efe0] rounded-2xl border-4 border-[#3b2313] shadow-2xl overflow-hidden flex flex-col">
        
        {/* PARCHMENT BACKGROUND TEXTURE PATTERN */}
        <div 
          className="absolute inset-0 pointer-events-none opacity-40 bg-repeat"
          style={{
            backgroundImage: `radial-gradient(#b89b68 0.75px, transparent 0.75px), radial-gradient(#b89b68 0.75px, #f5efe0 0.75px)`,
            backgroundSize: '30px 30px',
            backgroundPosition: '0 0, 15px 15px'
          }}
        ></div>

        {/* TOP DYNAMIC BOARD HEADER (Grade | Subject | Lesson) */}
        <div className="relative z-10 bg-gradient-to-r from-[#2c180b] via-[#432612] to-[#2c180b] border-b-2 border-amber-500/80 px-6 py-2.5 text-center shadow-lg flex flex-wrap items-center justify-between gap-2">
          
          <div className="flex items-center gap-2 text-amber-200 font-ibm font-extrabold text-xs sm:text-sm">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
            <span>{gradeName}</span>
          </div>

          <div className="font-reem text-amber-300 font-bold text-sm sm:text-base tracking-wide flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{subjectName}</span>
          </div>

          <div className="bg-amber-950/80 border border-amber-500/60 px-4 py-1 rounded-xl font-reem text-xs sm:text-sm font-extrabold text-amber-200 shadow-inner">
            {lessonTitle}
          </div>
        </div>

        {/* MAIN BOARD CANVAS AREA (ZOOMABLE) */}
        <div 
          className="relative flex-1 overflow-auto custom-scrollbar p-6 flex flex-col justify-between select-none"
          style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'top right', transition: 'transform 0.2s ease-out' }}
        >

          {/* PRE-POPULATED LESSON CONTENT (Exact visual reference matching attached image) */}
          <div className="relative z-0 pointer-events-none max-w-5xl mx-auto w-full space-y-6 text-[#1c120c] font-ibm">
            
            {/* Main Red Handwritten Lesson Title */}
            <div className="flex items-center justify-center gap-3 text-center my-2">
              <span className="text-rose-700 text-2xl font-bold font-reem">⭐</span>
              <h2 className="font-reem text-2xl sm:text-3xl font-extrabold text-rose-800 tracking-wide underline decoration-rose-600/40 decoration-wavy">
                درس : مفهوم الدولة وعناصرها
              </h2>
            </div>

            {/* TWO COLUMNS LESSON BODY */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
              
              {/* RIGHT COLUMN: Definitions & Elements */}
              <div className="space-y-6 text-right">
                
                {/* 1. Definition */}
                <div>
                  <h3 className="font-reem text-lg font-extrabold text-blue-900 mb-1">
                    تعريف الدولة :
                  </h3>
                  <p className="text-base sm:text-lg font-bold leading-relaxed text-[#2a1d15] pr-2">
                    هي <span className="border-b-2 border-rose-600 font-extrabold text-[#111]">تنظيم سياسي</span> يقوم على مجموعة من الناس يعيشون على <span className="border-b-2 border-rose-600 font-extrabold text-[#111]">إقليم محدد</span> ويخضعون <span className="border-b-2 border-rose-600 font-extrabold text-[#111]">لسلطة واحدة</span> .
                  </p>
                </div>

                {/* 2. State Elements List */}
                <div>
                  <h3 className="font-reem text-lg font-extrabold text-blue-900 mb-2">
                    عناصر الدولة :
                  </h3>
                  <ul className="space-y-1.5 pr-4 text-base sm:text-lg font-extrabold">
                    <li className="flex items-center gap-2">
                      <span className="text-rose-700 font-mono">١ -</span>
                      <span>الشعب ( السكان )</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-rose-700 font-mono">٢ -</span>
                      <span>الإقليم ( الأرض )</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-rose-700 font-mono">٣ -</span>
                      <span>السلطة ( الحكومة )</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="text-rose-700 font-mono">٤ -</span>
                      <span>السيادة</span>
                    </li>
                  </ul>
                </div>

                {/* 3. Activity Section */}
                <div className="pt-2">
                  <h3 className="font-reem text-base font-extrabold text-rose-800 flex items-center gap-2">
                    <span>نشاط :</span>
                    <span className="text-emerald-600 text-xl">💡</span>
                  </h3>
                  <p className="text-sm sm:text-base font-bold text-slate-800 leading-relaxed pr-2">
                    اذكر أمثلة لدول في العالم ثم حدد عناصر الدولة في كل مثال .
                  </p>
                </div>

              </div>

              {/* LEFT COLUMN: Pyramid Diagram & Importance & Cloud Callout */}
              <div className="space-y-6 text-right flex flex-col items-center md:items-end">
                
                {/* 1. Importance of State */}
                <div className="w-full">
                  <h3 className="font-reem text-lg font-extrabold text-blue-900 mb-2">
                    أهمية الدولة :
                  </h3>
                  <ul className="space-y-1 pr-4 text-sm sm:text-base font-bold text-slate-900">
                    <li>- حفظ الأمن والنظام .</li>
                    <li>- تحقيق العدالة بين الأفراد .</li>
                    <li>- توفير الخدمات الأساسية .</li>
                    <li>- حماية الوطن من الأخطار .</li>
                  </ul>
                </div>

                {/* 2. Green Pyramid Diagram (الهرم) */}
                <div className="my-2 flex flex-col items-center">
                  <div className="relative w-56 h-48 border-b-4 border-emerald-800 flex flex-col justify-end items-center">
                    
                    {/* Tier 1: السيادة */}
                    <div className="w-16 h-10 bg-emerald-100/80 border-2 border-emerald-700 clip-triangle flex items-center justify-center font-bold text-xs text-rose-800 shadow-sm">
                      السيادة
                    </div>

                    {/* Tier 2: السلطة */}
                    <div className="w-28 h-9 bg-emerald-100/80 border-2 border-emerald-700 flex items-center justify-center font-bold text-xs text-rose-800 my-0.5">
                      السلطة
                    </div>

                    {/* Tier 3: الإقليم */}
                    <div className="w-40 h-9 bg-emerald-100/80 border-2 border-emerald-700 flex items-center justify-center font-bold text-xs text-rose-800 my-0.5">
                      الإقليم
                    </div>

                    {/* Tier 4: الشعب */}
                    <div className="w-52 h-9 bg-emerald-100/80 border-2 border-emerald-700 flex items-center justify-center font-bold text-xs text-rose-800">
                      الشعب
                    </div>

                  </div>
                </div>

                {/* 3. Question Callout Cloud */}
                <div className="relative bg-amber-100/90 border-2 border-amber-800/80 p-4 rounded-3xl shadow-md text-center max-w-xs mt-2">
                  <span className="font-reem text-base font-extrabold text-amber-900 block mb-1">
                    فكر :
                  </span>
                  <p className="font-bold text-xs sm:text-sm text-amber-950">
                    لماذا تحتاج المجتمعات إلى وجود دولة ؟ ❓
                  </p>
                </div>

              </div>

            </div>

            {/* Castle Illustration Sketch at Bottom Left */}
            <div className="flex items-end justify-between pt-4 border-t border-amber-900/20">
              <div className="flex items-center gap-2 text-blue-900/70 font-ibm text-xs">
                <span className="text-2xl">🏰</span>
                <span className="font-bold">حصون ودول العصور القديمة والوسطى</span>
              </div>
            </div>

          </div>

          {/* Interactive User Text Inputs Overlay */}
          {textInputs.map(t => (
            <div 
              key={t.id} 
              className="absolute z-20 font-ibm font-bold text-lg bg-amber-100/80 p-2 rounded-lg border border-amber-500 shadow-md"
              style={{ left: t.x, top: t.y, color: t.color }}
            >
              {t.text}
            </div>
          ))}

          {/* FREEHAND CANVAS DRAWING OVERLAY */}
          <canvas
            ref={canvasRef}
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            onTouchStart={startDrawing}
            onTouchMove={draw}
            onTouchEnd={stopDrawing}
            className={`absolute inset-0 z-10 w-full h-full ${
              activeTool === 'pointer' ? 'cursor-default' : activeTool === 'eraser' ? 'cursor-crosshair' : 'cursor-crosshair'
            }`}
          />

        </div>

        {/* FLOATING DARK CONTROL TOOLBAR AT BOTTOM CENTER */}
        <div className="relative z-30 bg-gradient-to-r from-black via-slate-950 to-black border-2 border-amber-500/80 rounded-2xl px-4 py-2 mx-auto mb-3 shadow-2xl flex items-center gap-2 sm:gap-3 flex-wrap">
          
          {/* Pointer Tool */}
          <button
            onClick={() => setActiveTool('pointer')}
            title="مؤشر القراءة"
            className={`p-2 rounded-xl transition ${
              activeTool === 'pointer' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-amber-200 hover:bg-slate-800'
            }`}
          >
            <MousePointer className="w-4 h-4" />
          </button>

          {/* Blue Pen */}
          <button
            onClick={() => { setActiveTool('pen'); setPenColor('#1e3a8a'); }}
            title="قلم أزرق"
            className={`w-6 h-6 rounded-full bg-blue-700 border-2 ${
              activeTool === 'pen' && penColor === '#1e3a8a' ? 'ring-2 ring-amber-400 scale-110' : 'border-white/40'
            }`}
          />

          {/* Red Pen */}
          <button
            onClick={() => { setActiveTool('pen'); setPenColor('#be123c'); }}
            title="قلم أحمر"
            className={`w-6 h-6 rounded-full bg-rose-700 border-2 ${
              activeTool === 'pen' && penColor === '#be123c' ? 'ring-2 ring-amber-400 scale-110' : 'border-white/40'
            }`}
          />

          {/* Green Pen */}
          <button
            onClick={() => { setActiveTool('pen'); setPenColor('#047857'); }}
            title="قلم أخضر"
            className={`w-6 h-6 rounded-full bg-emerald-700 border-2 ${
              activeTool === 'pen' && penColor === '#047857' ? 'ring-2 ring-amber-400 scale-110' : 'border-white/40'
            }`}
          />

          {/* Eraser */}
          <button
            onClick={() => setActiveTool('eraser')}
            title="ممحاة الرسم"
            className={`p-2 rounded-xl transition ${
              activeTool === 'eraser' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-amber-200 hover:bg-slate-800'
            }`}
          >
            <Eraser className="w-4 h-4" />
          </button>

          {/* Divider */}
          <div className="w-px h-6 bg-amber-800/60" />

          {/* Text Tool */}
          <div className="flex items-center gap-1">
            <input
              type="text"
              value={newText}
              onChange={(e) => setNewText(e.target.value)}
              placeholder="اكتب ملاحظة..."
              className="w-24 sm:w-32 px-2 py-1 bg-slate-900 border border-amber-800 rounded-lg text-xs text-amber-100 focus:outline-none focus:border-amber-400"
            />
            <button
              onClick={addTextToBoard}
              title="إضافة نص"
              className="p-1.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded-lg text-xs"
            >
              <Type className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Divider */}
          <div className="w-px h-6 bg-amber-800/60" />

          {/* Undo / Redo */}
          <button
            onClick={handleUndo}
            disabled={historyStep <= 0}
            title="تراجع ↺"
            className="p-2 text-amber-200 hover:bg-slate-800 rounded-xl disabled:opacity-40"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={handleRedo}
            disabled={historyStep >= history.length - 1}
            title="إعادة ↻"
            className="p-2 text-amber-200 hover:bg-slate-800 rounded-xl disabled:opacity-40"
          >
            <RotateCw className="w-4 h-4" />
          </button>

          {/* Page Indicator */}
          <span className="font-ibm font-bold text-xs text-amber-300 px-2 py-1 bg-slate-900 border border-amber-800 rounded-lg">
            1/1
          </span>

          {/* Zoom Buttons */}
          <button
            onClick={() => setZoomLevel(prev => Math.min(prev + 0.15, 2.0))}
            title="تكبير"
            className="p-2 text-amber-200 hover:bg-slate-800 rounded-xl"
          >
            <ZoomIn className="w-4 h-4" />
          </button>

          <button
            onClick={() => setZoomLevel(prev => Math.max(prev - 0.15, 0.6))}
            title="تصغير"
            className="p-2 text-amber-200 hover:bg-slate-800 rounded-xl"
          >
            <ZoomOut className="w-4 h-4" />
          </button>

          {/* Clear Canvas */}
          <button
            onClick={clearCanvasDrawings}
            title="مسح كتابات السبورة"
            className="p-2 text-rose-400 hover:bg-rose-950/60 rounded-xl transition"
          >
            <Trash2 className="w-4 h-4" />
          </button>

        </div>

      </div>

    </div>
  );
}
