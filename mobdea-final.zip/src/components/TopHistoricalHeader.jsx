import React from 'react';
import { BookOpen, Sparkles, Flame, ChevronDown } from 'lucide-react';

export default function TopHistoricalHeader({ 
  currentLesson, 
  onLessonChange, 
  lessonsList = [] 
}) {
  return (
    <header className="relative z-20 bg-slate-950 border-b-2 border-amber-600/60 text-amber-100 px-4 py-2.5 shadow-2xl flex flex-wrap items-center justify-between gap-4">
      
      {/* LEFT: Banner "المُبدع" */}
      <div className="flex items-center gap-3">
        {/* Banner Badge */}
        <div className="relative bg-gradient-to-b from-amber-950 via-amber-900 to-black border-2 border-amber-500/80 px-4 py-1.5 rounded-b-xl shadow-lg shadow-amber-950/80 flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300 font-reem font-bold text-lg">
            م
          </div>
          <div>
            <h1 className="font-reem text-amber-300 font-extrabold text-base leading-tight tracking-wide drop-shadow-md">
              المُبدع
            </h1>
            <p className="text-[10px] text-amber-200/80 font-ibm">للتعليم ممتع</p>
          </div>
          <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
        </div>

        {/* Decorative Hanging Lantern */}
        <div className="hidden sm:flex items-center gap-1.5 text-amber-400/80 text-xs font-ibm bg-amber-950/40 border border-amber-800/40 px-3 py-1 rounded-lg">
          <Flame className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
          <span>منصة التاريخ والجغرافيا</span>
        </div>
      </div>

      {/* CENTER: "شرح الدرس" Historical Badge */}
      <div className="flex items-center gap-2">
        <div className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-amber-600 to-amber-800 rounded-2xl blur-xs opacity-75 group-hover:opacity-100 transition duration-300"></div>
          <div className="relative bg-gradient-to-r from-black via-slate-950 to-black border-2 border-amber-500/90 px-6 py-1.5 rounded-xl flex items-center gap-3 shadow-2xl">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
            <span className="font-reem text-xl font-extrabold text-amber-300 tracking-wider">
              شرح الدرس المباشر
            </span>
            <BookOpen className="w-5 h-5 text-amber-400" />
          </div>
        </div>
      </div>

      {/* RIGHT: Teacher Profile Badge & Lesson Selector */}
      <div className="flex items-center gap-4">
        
        {/* Dynamic Lesson Selection */}
        {lessonsList.length > 0 && (
          <div className="relative hidden lg:block">
            <select
              value={currentLesson.id}
              onChange={(e) => {
                const found = lessonsList.find(l => l.id === Number(e.target.value));
                if (found && onLessonChange) onLessonChange(found);
              }}
              className="appearance-none bg-slate-900 border border-amber-600/60 text-amber-200 text-xs font-ibm font-bold py-1.5 px-4 pr-8 rounded-xl focus:outline-none focus:border-amber-400 cursor-pointer"
            >
              {lessonsList.map(l => (
                <option key={l.id} value={l.id} className="bg-slate-950 text-amber-100">
                  {l.grade} - {l.lessonName}
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-amber-400 absolute left-2 top-2.5 pointer-events-none" />
          </div>
        )}

        {/* Teacher Profile Badge */}
        <div className="flex items-center gap-3 bg-gradient-to-l from-amber-950/80 via-slate-950 to-black border border-amber-600/70 p-1.5 pr-3 rounded-2xl shadow-xl">
          <div className="text-right">
            <h2 className="font-reem text-sm font-extrabold text-amber-300 leading-tight">
              مصطفى بركات
            </h2>
            <p className="text-[10px] text-amber-200/70 font-ibm">
              معلم دراسات اجتماعية وتاريخ
            </p>
          </div>

          {/* Teacher Circular Frame */}
          <div className="relative w-11 h-11 rounded-full p-0.5 bg-gradient-to-tr from-amber-300 via-amber-600 to-amber-200 shadow-md ring-2 ring-amber-500/40">
            <div className="w-full h-full rounded-full overflow-hidden bg-amber-950 flex items-center justify-center border border-amber-900">
              <svg className="w-full h-full" viewBox="0 0 100 100" fill="none">
                {/* Background gradient fill */}
                <defs>
                  <linearGradient id="teacherBg" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#2e1005" />
                    <stop offset="100%" stopColor="#0f0502" />
                  </linearGradient>
                </defs>
                <rect width="100" height="100" fill="url(#teacherBg)" />
                
                {/* Stylized realistic avatar representation matching prompt */}
                {/* Head / Skin */}
                <ellipse cx="50" cy="42" rx="18" ry="22" fill="#e0ac69" />
                {/* Hair */}
                <path d="M 31 38 C 31 22, 69 22, 69 38 C 65 24, 35 24, 31 38 Z" fill="#1f150d" />
                {/* Eyes */}
                <circle cx="43" cy="40" r="2.5" fill="#2d1b0e" />
                <circle cx="57" cy="40" r="2.5" fill="#2d1b0e" />
                {/* Beard */}
                <path d="M 34 46 C 34 62, 66 62, 66 46 C 60 58, 40 58, 34 46 Z" fill="#261a10" />
                {/* Smile */}
                <path d="M 44 49 Q 50 54 56 49" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" fill="none" />
                {/* Historic Coat Hood Outfit */}
                <path d="M 22 88 Q 50 62 78 88 L 85 100 L 15 100 Z" fill="#4a2e1b" stroke="#d4af37" strokeWidth="2" />
                <path d="M 38 68 Q 50 78 62 68 Q 50 85 38 68 Z" fill="#7a1c1c" />
              </svg>
            </div>
          </div>
        </div>

      </div>
    </header>
  );
}
