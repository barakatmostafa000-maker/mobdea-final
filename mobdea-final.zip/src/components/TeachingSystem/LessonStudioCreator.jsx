import React, { useState } from 'react';
import { 
  Plus, Layers, FileText, Video, Image as ImageIcon, Map, 
  HelpCircle, Gamepad2, Check, ArrowRight, ArrowLeft, Trash2, 
  Move, Save, Sparkles, BookOpen, Edit3, ShieldAlert
} from 'lucide-react';

export default function LessonStudioCreator({ onSaveLesson, onCancel }) {
  // Lesson General Details State
  const [lessonTitle, setLessonTitle] = useState('درس جديد: جغرافيا الوطن العربي والحدود');
  const [grade, setGrade] = useState('الصف الأول الإعدادي');
  const [subject, setSubject] = useState('الدراسات الاجتماعية والتاريخ');
  const [unit, setUnit] = useState('الوحدة الأولى: البيئة والجغرافيا');

  // Selected Resources Attached to this Lesson
  const [selectedPDFPages, setSelectedPDFPages] = useState([
    { pageNum: 1, title: 'كتاب الدراسات - ص ١ (تعريف الدولة)' },
    { pageNum: 2, title: 'كتاب الدراسات - ص ٢ (عناصر الدولة)' }
  ]);
  const [videoUrl, setVideoUrl] = useState('https://www.youtube.com/embed/sample_video');
  const [includeWhiteboard, setIncludeWhiteboard] = useState(true);
  const [includeMapChallenge, setIncludeMapChallenge] = useState(true);
  const [attachedQuizId, setAttachedQuizId] = useState('quiz_state_elements');
  const [teacherNotes, setTeacherNotes] = useState('يرجى التركيز على المخطط الهرمي لعناصر الدولة ومناقشة النشاط التفاعلي مع الطلاب.');

  // Handle Save
  const handleSaveLessonStudio = (e) => {
    e.preventDefault();
    if (!lessonTitle.trim()) return;

    const newLessonObj = {
      id: `lesson_${Date.now()}`,
      lessonName: lessonTitle,
      grade,
      subject,
      unit,
      pdfPagesCount: selectedPDFPages.length,
      hasVideo: !!videoUrl,
      hasWhiteboard: includeWhiteboard,
      hasMapChallenge: includeMapChallenge,
      hasQuiz: !!attachedQuizId,
      notes: teacherNotes,
      createdAt: new Date().toISOString()
    };

    if (onSaveLesson) onSaveLesson(newLessonObj);
    alert('تم إنشاء وتجميع المادة التعليمية للدرس بنجاح! ⭐');
  };

  return (
    <div className="w-full bg-slate-950 border-2 border-amber-600/70 p-4 sm:p-6 rounded-3xl shadow-2xl space-y-6 font-ibm text-amber-100">
      
      {/* HEADER */}
      <div className="flex items-center justify-between border-b border-amber-900/60 pb-4">
        <div>
          <h2 className="font-reem text-xl sm:text-2xl font-bold text-amber-300 flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-amber-400" />
            <span>استوديو تجميع وإنشاء الدروس من الهاتف</span>
          </h2>
          <p className="text-xs text-amber-200/80 mt-1">
            اختر صفحات PDF، أرفق الفيديو والسبورة وتحدي الخرائط والاختبارات في درس واحد متكامل.
          </p>
        </div>

        {onCancel && (
          <button
            onClick={onCancel}
            className="px-3 py-1.5 bg-slate-800 text-amber-300 rounded-xl text-xs font-bold"
          >
            إلغاء
          </button>
        )}
      </div>

      <form onSubmit={handleSaveLessonStudio} className="space-y-6 text-xs font-bold">
        
        {/* SECTION 1: LESSON METADATA */}
        <div className="bg-slate-900/90 border border-amber-900/80 p-4 rounded-2xl space-y-4">
          <h3 className="font-reem text-sm font-bold text-amber-400 flex items-center gap-2">
            <BookOpen className="w-4 h-4" />
            <span>١. البيانات الأساسية للدرس</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-amber-300 mb-1">عنوان الدرس *</label>
              <input
                type="text"
                required
                value={lessonTitle}
                onChange={(e) => setLessonTitle(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-amber-800 rounded-xl text-amber-100 outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-amber-300 mb-1">الصف الدراسي</label>
              <select
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-amber-800 rounded-xl text-amber-100 outline-none"
              >
                <option value="الصف الأول الإعدادي">الصف الأول الإعدادي</option>
                <option value="الصف الثاني الإعدادي">الصف الثاني الإعدادي</option>
                <option value="الصف الثالث الإعدادي">الصف الثالث الإعدادي</option>
              </select>
            </div>
          </div>
        </div>

        {/* SECTION 2: SELECT PDF PAGES */}
        <div className="bg-slate-900/90 border border-amber-900/80 p-4 rounded-2xl space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-reem text-sm font-bold text-amber-400 flex items-center gap-2">
              <FileText className="w-4 h-4 text-rose-400" />
              <span>٢. تحديد وتسلسل صفحات PDF لشرح المذكرة</span>
            </h3>
            <button
              type="button"
              onClick={() => setSelectedPDFPages(prev => [...prev, { pageNum: prev.length + 1, title: `كتاب الدراسات - ص ${prev.length + 1}` }])}
              className="px-2.5 py-1 bg-amber-500 text-slate-950 font-extrabold rounded-lg text-[11px]"
            >
              + إضافة صفحة
            </button>
          </div>

          <div className="space-y-2">
            {selectedPDFPages.map((page, idx) => (
              <div key={idx} className="flex items-center justify-between bg-slate-950 p-2.5 rounded-xl border border-amber-900/60">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-rose-950 text-rose-400 border border-rose-800 flex items-center justify-center font-mono">
                    {page.pageNum}
                  </span>
                  <span>{page.title}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedPDFPages(prev => prev.filter((_, i) => i !== idx))}
                  className="p-1 text-rose-400 hover:bg-rose-950 rounded-lg"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* SECTION 3: ATTACH MULTIMEDIA & MAPS */}
        <div className="bg-slate-900/90 border border-amber-900/80 p-4 rounded-2xl space-y-4">
          <h3 className="font-reem text-sm font-bold text-amber-400 flex items-center gap-2">
            <Layers className="w-4 h-4 text-blue-400" />
            <span>٣. إدراج الموارد الملحقة بالحصة (السبورة، الفيديو، الخرائط، الاختبار)</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Whiteboard Toggle */}
            <label className="flex items-center justify-between p-3 bg-slate-950 border border-amber-900/80 rounded-xl cursor-pointer">
              <div className="flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-emerald-400" />
                <span>السبورة الرقمية التفاعلية</span>
              </div>
              <input
                type="checkbox"
                checked={includeWhiteboard}
                onChange={(e) => setIncludeWhiteboard(e.target.checked)}
                className="w-4 h-4 accent-amber-500"
              />
            </label>

            {/* Map Challenge Toggle */}
            <label className="flex items-center justify-between p-3 bg-slate-950 border border-amber-900/80 rounded-xl cursor-pointer">
              <div className="flex items-center gap-2">
                <Map className="w-4 h-4 text-purple-400" />
                <span>تحدي الخرائط التفاعلي</span>
              </div>
              <input
                type="checkbox"
                checked={includeMapChallenge}
                onChange={(e) => setIncludeMapChallenge(e.target.checked)}
                className="w-4 h-4 accent-amber-500"
              />
            </label>

          </div>

          <div>
            <label className="block text-amber-300 mb-1">ملاحظات وإرشادات المعلم للدرس</label>
            <textarea
              rows="2"
              value={teacherNotes}
              onChange={(e) => setTeacherNotes(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-amber-800 rounded-xl text-amber-100 outline-none"
            />
          </div>
        </div>

        {/* SUBMIT BUTTON */}
        <div className="pt-2 flex justify-end">
          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-3 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black rounded-2xl text-sm shadow-xl transition"
          >
            حفظ وتجميع الدرس الجديد ⭐
          </button>
        </div>

      </form>

    </div>
  );
}
