import React, { useState } from 'react';
import { 
  FileText, Video, Image as ImageIcon, Monitor, HelpCircle, 
  Gamepad2, Plus, Map, BookOpen, Layers, Sparkles, UserCheck, 
  Settings, FolderPlus, HelpCircle as QuizIcon
} from 'lucide-react';

import PDFViewerEngine from './PDFViewerEngine';
import InteractiveWhiteboard from './InteractiveWhiteboard';
import MobileLibraryManager from './MobileLibraryManager';
import LessonStudioCreator from './LessonStudioCreator';
import MapChallengeMain from '../MapChallenge/MapChallengeMain';
import StudentsPanel from '../StudentsPanel';
import TopHistoricalHeader from '../TopHistoricalHeader';

export default function ClassroomTeachingHub({ 
  currentLesson, 
  setCurrentLesson, 
  lessonsList, 
  students, 
  setStudents, 
  attendance, 
  setAttendance, 
  currentSession 
}) {
  // Active Teaching Resource
  const [activeResource, setActiveResource] = useState('pdf'); // 'pdf', 'board', 'map', 'library', 'studio', 'video', 'quiz', 'game'

  // Current Loaded Resource Document info
  const [activeDoc, setActiveDoc] = useState({
    title: 'مذكرة الشرح - درس مفهوم الدولة وعناصرها.pdf',
    docId: 'doc_lesson_state_1'
  });

  return (
    <div className="space-y-4 font-ibm">
      
      {/* DYNAMIC TOP HISTORICAL HEADER (Grade | Subject | Lesson) */}
      <TopHistoricalHeader
        currentLesson={currentLesson}
        onLessonChange={(lesson) => setCurrentLesson(lesson)}
        lessonsList={lessonsList}
      />

      {/* TOP RESOURCE MODE NAVIGATOR (FAST CLASSROOM SWITCHER) */}
      <div className="w-full bg-gradient-to-r from-black via-slate-950 to-black border-2 border-amber-600/70 rounded-2xl px-3 py-2 shadow-2xl flex items-center justify-between gap-2 overflow-x-auto custom-scrollbar">
        <div className="flex items-center gap-1.5 sm:gap-2">
          
          {/* PDF Viewer */}
          <button
            onClick={() => setActiveResource('pdf')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shrink-0 ${
              activeResource === 'pdf'
                ? 'bg-amber-500 text-slate-950 border-amber-300 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 text-amber-100 border-amber-900/50 hover:bg-rose-950/40'
            }`}
          >
            <FileText className={`w-4 h-4 ${activeResource === 'pdf' ? 'text-slate-950' : 'text-rose-400'}`} />
            <span>عرض الـ PDF</span>
          </button>

          {/* Interactive Whiteboard */}
          <button
            onClick={() => setActiveResource('board')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shrink-0 ${
              activeResource === 'board'
                ? 'bg-amber-500 text-slate-950 border-amber-300 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 text-amber-100 border-amber-900/50 hover:bg-emerald-950/40'
            }`}
          >
            <Monitor className={`w-4 h-4 ${activeResource === 'board' ? 'text-slate-950' : 'text-emerald-400'}`} />
            <span>السبورة الرقمية</span>
          </button>

          {/* Map Challenge */}
          <button
            onClick={() => setActiveResource('map')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shrink-0 ${
              activeResource === 'map'
                ? 'bg-amber-500 text-slate-950 border-amber-300 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 text-amber-100 border-amber-900/50 hover:bg-purple-950/40'
            }`}
          >
            <Map className={`w-4 h-4 ${activeResource === 'map' ? 'text-slate-950' : 'text-purple-400'}`} />
            <span>تحدي الخرائط</span>
          </button>

          {/* Mobile Library */}
          <button
            onClick={() => setActiveResource('library')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shrink-0 ${
              activeResource === 'library'
                ? 'bg-amber-500 text-slate-950 border-amber-300 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 text-amber-100 border-amber-900/50 hover:bg-blue-950/40'
            }`}
          >
            <BookOpen className={`w-4 h-4 ${activeResource === 'library' ? 'text-slate-950' : 'text-blue-400'}`} />
            <span>المكتبة التعليمية</span>
          </button>

          {/* Video Player */}
          <button
            onClick={() => setActiveResource('video')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shrink-0 ${
              activeResource === 'video'
                ? 'bg-amber-500 text-slate-950 border-amber-300 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 text-amber-100 border-amber-900/50 hover:bg-cyan-950/40'
            }`}
          >
            <Video className={`w-4 h-4 ${activeResource === 'video' ? 'text-slate-950' : 'text-cyan-400'}`} />
            <span>فيديو الشرح</span>
          </button>

          {/* Quiz & Exam */}
          <button
            onClick={() => setActiveResource('quiz')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shrink-0 ${
              activeResource === 'quiz'
                ? 'bg-amber-500 text-slate-950 border-amber-300 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 text-amber-100 border-amber-900/50 hover:bg-amber-950/40'
            }`}
          >
            <QuizIcon className={`w-4 h-4 ${activeResource === 'quiz' ? 'text-slate-950' : 'text-amber-300'}`} />
            <span>اختبار الحصة</span>
          </button>

        </div>

        {/* LESSON STUDIO BUTTON */}
        <button
          onClick={() => setActiveResource('studio')}
          className="px-3.5 py-1.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 shrink-0 transition"
        >
          <Sparkles className="w-3.5 h-3.5 text-slate-950" />
          <span>تجميع درس جديد</span>
        </button>
      </div>

      {/* MAIN CLASSROOM DISPLAY AREA (Resource View + Right Students Panel) */}
      <div className="flex flex-col lg:flex-row items-stretch gap-4">
        
        {/* MAIN RESOURCE WORKSPACE (~80% WIDTH) */}
        <div className="flex-1 min-w-0 flex flex-col space-y-3">
          
          {activeResource === 'pdf' && (
            <PDFViewerEngine
              documentTitle={activeDoc.title}
              documentId={activeDoc.docId}
            />
          )}

          {activeResource === 'board' && (
            <InteractiveWhiteboard currentLesson={currentLesson} />
          )}

          {activeResource === 'map' && (
            <MapChallengeMain currentLesson={currentLesson} />
          )}

          {activeResource === 'library' && (
            <MobileLibraryManager
              onOpenResourceInClass={(file) => {
                setActiveDoc({ title: file.name, docId: file.id });
                if (file.type === 'map') setActiveResource('map');
                else if (file.type === 'video') setActiveResource('video');
                else if (file.type === 'quiz') setActiveResource('quiz');
                else setActiveResource('pdf');
              }}
            />
          )}

          {activeResource === 'studio' && (
            <LessonStudioCreator
              onSaveLesson={(newLesson) => {
                setCurrentLesson(newLesson);
                setActiveResource('pdf');
              }}
              onCancel={() => setActiveResource('pdf')}
            />
          )}

          {activeResource === 'video' && (
            <div className="bg-slate-950 border-2 border-amber-600/70 p-6 rounded-3xl text-amber-100 shadow-2xl space-y-4">
              <h3 className="text-lg font-bold font-reem text-amber-300 flex items-center gap-2">
                <Video className="w-5 h-5 text-cyan-400" />
                <span>عرض فيديو الشرح الملحق بالدرس</span>
              </h3>
              <div className="relative aspect-video w-full rounded-2xl overflow-hidden border-2 border-amber-900/80 bg-black flex items-center justify-center">
                <iframe
                  src="https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ"
                  title="فيديو الدرس"
                  className="w-full h-full border-0"
                  allowFullScreen
                />
              </div>
            </div>
          )}

          {activeResource === 'quiz' && (
            <div className="bg-slate-950 border-2 border-amber-600/70 p-6 rounded-3xl text-amber-100 shadow-2xl space-y-4">
              <h3 className="text-xl font-bold font-reem text-amber-300 flex items-center gap-2">
                <QuizIcon className="w-6 h-6 text-amber-400" />
                <span>اختبار سريع للحصة التفاعلية 📝</span>
              </h3>
              <p className="text-sm font-ibm text-amber-100/90 leading-relaxed">
                السؤال الرئيسي: اذكر عناصر الدولة الأربعة بالتفصيل واشرح الفرق بين الإقليم والسيادة.
              </p>
              <button 
                onClick={() => alert('الإجابة النموذجية:\n١- الشعب (السكان)\n٢- الإقليم (الأرض الطبيعية والبحرية والجوية)\n٣- السلطة (الحكومة الهيئة الحاكمة)\n٤- السيادة (الاستقلالية وعدم التبعية) ⭐')} 
                className="px-5 py-2.5 bg-amber-500 text-slate-950 font-ibm font-black rounded-xl text-xs shadow-md hover:bg-amber-400 transition"
              >
                عرض الإجابة النموذجية وتوزيع النقاط ⭐
              </button>
            </div>
          )}

        </div>

        {/* STUDENTS PANEL (~20% REDUCED WIDTH) */}
        <StudentsPanel
          students={students}
          setStudents={setStudents}
          attendance={attendance}
          setAttendance={setAttendance}
          currentSessionId={currentSession?.id || 1}
        />

      </div>

    </div>
  );
}
