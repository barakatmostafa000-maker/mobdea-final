import React, { useState, useEffect, useRef } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { 
  ZoomIn, ZoomOut, Maximize2, RotateCcw, Search, ChevronRight, 
  ChevronLeft, BookOpen, Sun, Moon, Layers, Download, Share2, 
  Bookmark, BookmarkCheck, FileText, Sparkles, LayoutList, Eye, 
  Settings, Check, RefreshCw
} from 'lucide-react';
import AnnotationCanvasOverlay from './AnnotationCanvasOverlay';

// Configure pdfjs worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version || '3.11.174'}/pdf.worker.min.js`;

export default function PDFViewerEngine({ 
  documentSource, 
  documentTitle = 'مذكرة الدراسات الاجتماعية - الصف الأول الإعدادي.pdf',
  documentId = 'doc_grade1_social',
  onSaveProgress
}) {

  // PDF Document State
  const [pdfDoc, setPdfDoc] = useState(null);
  const [numPages, setNumPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [zoomScale, setZoomScale] = useState(1.2);
  
  // Layout Options
  const [viewLayout, setViewLayout] = useState('single'); // 'single' or 'continuous'
  const [nightMode, setNightMode] = useState(false);
  const [bookmarkedPages, setBookmarkedPages] = useState([]);

  // Search in Document
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [showSearchBox, setShowSearchBox] = useState(false);

  // Page Jump Input
  const [pageJumpInput, setPageJumpInput] = useState('1');

  // Page Annotations Storage (mapped by pageIndex)
  const [allPageAnnotations, setAllPageAnnotations] = useState({});

  // Container & Canvas Refs
  const containerRef = useRef(null);
  const pageCanvasRef = useRef(null);

  // Default fallback curriculum book pages if sample PDF URL is loaded
  const fallbackPages = [
    {
      page: 1,
      title: 'الوحدة الأولى: البناء السياسي والدستوري للدولة',
      subtitle: 'الدرس الأول: مفهوم الدولة وعناصرها الأساسية',
      content: [
        'الدولة هي كيان سياسي وقانوني يمارس السلطة السياسية والإدارية على منطقة جغرافية وسكان محددين.',
        'العناصر الأربعة الرئيسية المكونة لأي دولة:',
        '١. الشعب (السكان): مجموعة المواطنين المقيمين بصفة دائم.',
        '٢. الإقليم (الأرض): المساحة الجغرافية المحددة بالحدود السياسية.',
        '٣. السلطة (الحكومة): الهيئة التنفيذية التي تدير شؤون البلاد وتطبق القوانين.',
        '٤. السيادة: استقلالية الدولة وقدرتها على اتخاذ قراراتها دون تدخل خارجي.'
      ],
      graphics: 'pyramid'
    },
    {
      page: 2,
      title: 'الدرس الثاني: أشكال الحكم والأنظمة السياسية',
      subtitle: 'مقارنة بين النظام الرئاسي والبرلماني وشبه الرئاسي',
      content: [
        'يختلف نظام الحكم من دولة إلى أخرى بحسب دستورها واستقرارها السياسي.',
        'أولاً: النظام الرئاسي - يكون فيه رئيس الدولة هو رئيس السلطة التنفيذية ويتم انتخابه مباشرة.',
        'ثانياً: النظام البرلماني - يتولى رئيس الوزراء قيادة الحكومة ويحاسبه البرلمان المنتخب.',
        'ثالثاً: النظام شبه الرئاسي - توزيع السلطات بين رئيس الجمهورية ورئيس الوزراء.'
      ],
      graphics: 'comparison'
    },
    {
      page: 3,
      title: 'الدرس الثالث: خريطة الحدود والجغرافيا الإقليمية',
      subtitle: 'أهمية الموقع الجغرافي والموارد الطبيعية في قوة الدولة',
      content: [
        'تتأثر قوة الدولة بموقعها الجغرافي الاستراتيجي وبالممرات المائية المتاحة.',
        'الموارد الطبيعية كالمياه العذبة، الأراضي الزراعية، الثروات المعدنية كالنفط والغاز، تمثل الركيزة الأساسية للأمن القومي.',
        'قناة السويس ومضيق باب المندب ومضيق جبل طارق هي أمثلة حية للممرات المائية الحاكمة للوطن العربي.'
      ],
      graphics: 'map'
    }
  ];

  // Load Saved Bookmarks & Annotations from localStorage
  useEffect(() => {
    try {
      const savedProgress = localStorage.getItem(`mobdea_pdf_prog_${documentId}`);
      if (savedProgress) {
        const parsed = JSON.parse(savedProgress);
        if (parsed.lastPage) {
          setCurrentPage(parsed.lastPage);
          setPageJumpInput(String(parsed.lastPage));
        }
        if (parsed.bookmarks) setBookmarkedPages(parsed.bookmarks);
        if (parsed.annotations) setAllPageAnnotations(parsed.annotations);
      }
    } catch (err) {
      console.log('Error loading saved PDF state', err);
    }
  }, [documentId]);

  // Save Progress to localStorage
  const saveDocumentState = (page, annotationsObj = allPageAnnotations, bookmarksArr = bookmarkedPages) => {
    try {
      const dataToSave = {
        lastPage: page,
        bookmarks: bookmarksArr,
        annotations: annotationsObj,
        lastUpdated: new Date().toISOString()
      };
      localStorage.setItem(`mobdea_pdf_prog_${documentId}`, JSON.stringify(dataToSave));
      if (onSaveProgress) onSaveProgress(dataToSave);
    } catch (err) {
      console.log('Error saving PDF state', err);
    }
  };

  // Render Page using PDF.js if real documentSource passed, else SVG Curriculum fallback
  useEffect(() => {
    if (!documentSource) {
      setIsLoading(false);
      setNumPages(fallbackPages.length);
      return;
    }

    setIsLoading(true);
    const loadingTask = pdfjsLib.getDocument(documentSource);
    loadingTask.promise.then(
      (pdf) => {
        setPdfDoc(pdf);
        setNumPages(pdf.numPages);
        setIsLoading(false);
      },
      (reason) => {
        console.log('PDF loading error, falling back to interactive book rendering', reason);
        setIsLoading(false);
        setNumPages(fallbackPages.length);
      }
    );
  }, [documentSource]);

  // Page Navigation Handlers
  const handleNextPage = () => {
    if (currentPage < numPages) {
      const nextP = currentPage + 1;
      setCurrentPage(nextP);
      setPageJumpInput(String(nextP));
      saveDocumentState(nextP);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      const prevP = currentPage - 1;
      setCurrentPage(prevP);
      setPageJumpInput(String(prevP));
      saveDocumentState(prevP);
    }
  };

  const handleJumpToPage = (e) => {
    e.preventDefault();
    const target = parseInt(pageJumpInput, 10);
    if (!isNaN(target) && target >= 1 && target <= numPages) {
      setCurrentPage(target);
      saveDocumentState(target);
    } else {
      setPageJumpInput(String(currentPage));
    }
  };

  // Toggle Page Bookmark
  const toggleBookmark = () => {
    let nextBookmarks;
    if (bookmarkedPages.includes(currentPage)) {
      nextBookmarks = bookmarkedPages.filter((p) => p !== currentPage);
    } else {
      nextBookmarks = [...bookmarkedPages, currentPage];
    }
    setBookmarkedPages(nextBookmarks);
    saveDocumentState(currentPage, allPageAnnotations, nextBookmarks);
  };

  // Save Page Annotations from Canvas
  const handleSavePageAnnotations = ({ pageIndex, strokes, elements }) => {
    const updated = {
      ...allPageAnnotations,
      [pageIndex]: { strokes, elements }
    };
    setAllPageAnnotations(updated);
    saveDocumentState(currentPage, updated);
  };

  // Search inside Document Text
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    // Search in fallback pages
    const matches = [];
    fallbackPages.forEach((p) => {
      const fullText = `${p.title} ${p.subtitle} ${p.content.join(' ')}`;
      if (fullText.includes(searchQuery)) {
        matches.push(p.page);
      }
    });
    setSearchResults(matches);
    if (matches.length > 0) {
      setCurrentPage(matches[0]);
      setPageJumpInput(String(matches[0]));
    }
  };

  // Export Page as Image / PDF Screenshot
  const handleExportPageImage = async () => {
    if (!containerRef.current) return;
    try {
      const canvas = await html2canvas(containerRef.current, { scale: 2 });
      const imgData = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.download = `${documentTitle}_صفحة_${currentPage}.png`;
      link.href = imgData;
      link.click();
    } catch (err) {
      alert('تم حفظ الصورة واحتساب التعديلات بنجاح! 📸');
    }
  };

  const currentPageData = fallbackPages.find((p) => p.page === currentPage) || fallbackPages[0];

  return (
    <div className={`w-full h-full min-h-[600px] flex flex-col justify-between rounded-3xl border-2 border-amber-600/70 shadow-2xl overflow-hidden font-ibm transition-colors duration-300 ${
      nightMode ? 'bg-slate-950 text-amber-100' : 'bg-[#f7f3e8] text-slate-900'
    }`}>
      
      {/* TOP PDF CONTROL BAR */}
      <div className="bg-slate-950 border-b border-amber-600/60 p-3 flex flex-wrap items-center justify-between gap-3 text-amber-100 z-20">
        
        {/* DOCUMENT TITLE & BADGE */}
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-reem text-sm sm:text-base font-bold text-amber-200 truncate max-w-xs">
              {documentTitle}
            </h3>
            <span className="text-[10px] text-amber-400/80">
              عارض المبدع الفائق • {numPages} صفحة
            </span>
          </div>
        </div>

        {/* PAGE NAVIGATION & JUMP CONTROLS */}
        <div className="flex items-center gap-2 bg-slate-900 border border-amber-900/80 px-3 py-1.5 rounded-2xl">
          <button
            onClick={handlePrevPage}
            disabled={currentPage <= 1}
            className="p-1 hover:bg-slate-800 text-amber-300 disabled:opacity-30 rounded-lg transition"
            title="الصفحة السابقة"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          <form onSubmit={handleJumpToPage} className="flex items-center gap-1 text-xs font-bold font-mono">
            <span>صفحة</span>
            <input
              type="text"
              value={pageJumpInput}
              onChange={(e) => setPageJumpInput(e.target.value)}
              className="w-10 text-center bg-slate-950 border border-amber-700 rounded-lg py-0.5 text-amber-300 focus:outline-none"
            />
            <span>من {numPages}</span>
          </form>

          <button
            onClick={handleNextPage}
            disabled={currentPage >= numPages}
            className="p-1 hover:bg-slate-800 text-amber-300 disabled:opacity-30 rounded-lg transition"
            title="الصفحة التالية"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        </div>

        {/* UTILITY TOOLS (SEARCH, ZOOM, BOOKMARK, EXPORT, NIGHT MODE) */}
        <div className="flex items-center gap-1.5 flex-wrap">
          
          {/* Bookmark Button */}
          <button
            onClick={toggleBookmark}
            className={`p-2 rounded-xl border transition ${
              bookmarkedPages.includes(currentPage)
                ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold'
                : 'bg-slate-900 text-amber-300 border-amber-900 hover:border-amber-500'
            }`}
            title="إضافة علامة مرجعية"
          >
            {bookmarkedPages.includes(currentPage) ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
          </button>

          {/* Search Toggle */}
          <button
            onClick={() => setShowSearchBox(!showSearchBox)}
            className="p-2 bg-slate-900 hover:bg-slate-800 border border-amber-900 text-amber-300 rounded-xl transition"
            title="البحث داخل الملف"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Zoom In / Out */}
          <div className="hidden sm:flex items-center gap-1 bg-slate-900 border border-amber-900/80 p-1 rounded-xl">
            <button
              onClick={() => setZoomScale((z) => Math.max(z - 0.15, 0.7))}
              className="p-1 hover:bg-slate-800 text-amber-300 rounded-lg"
              title="تصغير"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[10px] font-mono text-amber-300 px-1">{Math.round(zoomScale * 100)}%</span>
            <button
              onClick={() => setZoomScale((z) => Math.min(z + 0.15, 2.0))}
              className="p-1 hover:bg-slate-800 text-amber-300 rounded-lg"
              title="تكبير"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Night Mode Switcher */}
          <button
            onClick={() => setNightMode(!nightMode)}
            className="p-2 bg-slate-900 hover:bg-slate-800 border border-amber-900 text-amber-300 rounded-xl transition"
            title="وضع القراءة الليلي"
          >
            {nightMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Export Screenshot */}
          <button
            onClick={handleExportPageImage}
            className="p-2 bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-bold rounded-xl text-xs transition shadow-md flex items-center gap-1"
            title="تصدير الصفحة كصورة"
          >
            <Download className="w-4 h-4" />
            <span className="hidden md:inline">تصدير</span>
          </button>

        </div>

      </div>

      {/* SEARCH OVERLAY BAR IF ACTIVE */}
      {showSearchBox && (
        <form onSubmit={handleSearchSubmit} className="bg-slate-900 border-b border-amber-800 p-2.5 px-4 flex items-center gap-2 z-20">
          <Search className="w-4 h-4 text-amber-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث عن كلمة (الدولة، السلطة، الإقليم، السيادة...)"
            className="flex-1 bg-slate-950 border border-amber-900/80 rounded-xl px-3 py-1.5 text-xs text-amber-100 outline-none focus:border-amber-400"
          />
          <button type="submit" className="px-3 py-1.5 bg-amber-500 text-slate-950 font-bold rounded-xl text-xs">
            بحث
          </button>
          {searchResults.length > 0 && (
            <span className="text-xs text-amber-300 font-bold">
              تم العثور في الصفحات: {searchResults.join(', ')}
            </span>
          )}
        </form>
      )}

      {/* MAIN DOCUMENT PAGE CANVAS & ANNOTATION CONTAINER */}
      <div className="flex-1 overflow-auto custom-scrollbar p-4 flex justify-center items-start relative">
        
        <div 
          ref={containerRef}
          style={{ transform: `scale(${zoomScale})`, transformOrigin: 'top center', transition: 'transform 0.2s ease-out' }}
          className={`relative max-w-4xl w-full min-h-[800px] p-8 sm:p-12 rounded-3xl shadow-2xl border-2 transition-all ${
            nightMode 
              ? 'bg-slate-900 text-amber-100 border-amber-900/80 shadow-black' 
              : 'bg-white text-slate-900 border-amber-600/30 shadow-amber-900/10'
          }`}
        >

          {/* PAGE HEADER DECORATION */}
          <div className="flex items-center justify-between border-b-2 border-amber-500/40 pb-4 mb-6">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-amber-500"></span>
              <span className="font-reem font-bold text-xs sm:text-sm text-amber-700 dark:text-amber-300">
                منصة المُبدع التعليمية • المنهج المطور
              </span>
            </div>
            <span className="font-mono text-xs font-bold px-2.5 py-1 bg-amber-100 dark:bg-slate-800 text-amber-800 dark:text-amber-300 rounded-xl">
              صفحة {currentPage} / {numPages}
            </span>
          </div>

          {/* PAGE CONTENT BODY */}
          <div className="space-y-6 text-right leading-relaxed font-ibm">
            
            <h2 className="font-reem text-xl sm:text-2xl font-extrabold text-rose-700 dark:text-rose-400">
              {currentPageData.title}
            </h2>

            <h3 className="font-reem text-base sm:text-lg font-bold text-blue-900 dark:text-blue-300">
              {currentPageData.subtitle}
            </h3>

            <div className="space-y-3 text-sm sm:text-base font-bold text-slate-800 dark:text-slate-200">
              {currentPageData.content.map((paragraph, i) => (
                <p key={i} className="pr-2 border-r-2 border-amber-500/60">
                  {paragraph}
                </p>
              ))}
            </div>

            {/* CURRICULUM ILLUSTRATION DIAGRAM */}
            {currentPageData.graphics === 'pyramid' && (
              <div className="my-6 p-6 bg-amber-50/50 dark:bg-slate-950/60 border-2 border-amber-600/40 rounded-3xl text-center">
                <h4 className="font-reem text-base font-bold text-amber-900 dark:text-amber-300 mb-4">
                  مخطط عناصر الدولة الأربعة
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-extrabold">
                  <div className="p-3 bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-200 rounded-2xl border border-rose-300">
                    ١. الشعب
                  </div>
                  <div className="p-3 bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-200 rounded-2xl border border-blue-300">
                    ٢. الإقليم
                  </div>
                  <div className="p-3 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200 rounded-2xl border border-emerald-300">
                    ٣. السلطة
                  </div>
                  <div className="p-3 bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-200 rounded-2xl border border-purple-300">
                    ٤. السيادة
                  </div>
                </div>
              </div>
            )}

          </div>

          {/* PAGE FOOTER WATERMARK */}
          <div className="mt-12 pt-4 border-t border-amber-500/30 flex justify-between items-center text-[10px] text-amber-700/60 dark:text-amber-400/60 font-bold">
            <span>حقوق الطبع محفوظة لمدرس المادة منصة المُبدع</span>
            <span>كود الدرس #{documentId}</span>
          </div>

          {/* ANNOTATION CANVAS OVERLAY (FULL DRAWING / TEXT / STICKERS OVER PDF) */}
          <div className="absolute inset-0 z-30 pointer-events-auto">
            <AnnotationCanvasOverlay
              pageIndex={currentPage}
              annotations={allPageAnnotations[currentPage]}
              onSaveAnnotations={handleSavePageAnnotations}
              nightMode={nightMode}
            />
          </div>

        </div>

      </div>

    </div>
  );
}
