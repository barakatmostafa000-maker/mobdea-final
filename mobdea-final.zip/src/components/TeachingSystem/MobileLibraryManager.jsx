import React, { useState, useEffect } from 'react';
import { 
  FileText, Video, Image as ImageIcon, Map, FileSpreadsheet, 
  BookOpen, HelpCircle, FileCode, Plus, Search, Filter, Trash2, 
  Eye, Download, Share2, Tag, Check, X, Sparkles, FolderPlus,
  ArrowUpRight, Edit3
} from 'lucide-react';

export default function MobileLibraryManager({ onOpenResourceInClass, onAttachToLesson }) {
  // Library Storage State
  const [libraryFiles, setLibraryFiles] = useState([
    {
      id: 'lib_1',
      name: 'كتاب الدراسات الاجتماعية - الفصل الدراسي الأول',
      type: 'pdf',
      grade: 'الصف الأول الإعدادي',
      subject: 'الدراسات الاجتماعية والتاريخ',
      unit: 'الوحدة الأولى: الدولة والمجتمع',
      lesson: 'الدرس الأول: مفهوم الدولة',
      description: 'الكتاب المدرسي المعتمد للفيصل الأول شاملاً جميع الشروحات والخرائط.',
      keywords: 'دولة، جغرافيا، تاريخ، سنة أولى',
      size: '14.2 MB',
      createdAt: '2026-07-20'
    },
    {
      id: 'lib_2',
      name: 'خريطة الوطن العربي السياسية والحدود الطبيعية',
      type: 'map',
      grade: 'الصف الأول الإعدادي',
      subject: 'الدراسات الاجتماعية والتاريخ',
      unit: 'الوحدة الثانية: جغرافيا الوطن العربي',
      lesson: 'درس موقع الوطن العربي',
      description: 'خريطة عالية الجودة توضح الحدود والمنافذ البحرية والمضايق.',
      keywords: 'خريطة، حدود، باب المندب، قناة السويس',
      size: '5.8 MB',
      createdAt: '2026-07-21'
    },
    {
      id: 'lib_3',
      name: 'فيديو شرح مفصل لعناصر الدولة الأربعة',
      type: 'video',
      grade: 'الصف الأول الإعدادي',
      subject: 'الدراسات الاجتماعية والتاريخ',
      unit: 'الوحدة الأولى: الدولة والمجتمع',
      lesson: 'الدرس الأول: مفهوم الدولة',
      description: 'شرح مبسط وتفاعلي بالصوت والصورة.',
      keywords: 'فيديو، شعب، سلطة، إقليم، سيادة',
      size: '42.0 MB',
      createdAt: '2026-07-22'
    },
    {
      id: 'lib_4',
      name: 'اختبار الكتروني سريع على درس مفهوم الدولة',
      type: 'quiz',
      grade: 'الصف الأول الإعدادي',
      subject: 'الدراسات الاجتماعية والتاريخ',
      unit: 'الوحدة الأولى: الدولة والمجتمع',
      lesson: 'الدرس الأول: مفهوم الدولة',
      description: 'أسئلة متعددة الخيارات واختبارات صح وخطأ مع التصحيح التلقائي.',
      keywords: 'امتحان، أسئلة، مراجعة، أونلاين',
      size: '1.1 MB',
      createdAt: '2026-07-23'
    }
  ]);

  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGradeFilter, setSelectedGradeFilter] = useState('الكل');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState('الكل');

  // Modal State for Upload / Add Metadata
  const [showAddModal, setShowAddModal] = useState(false);
  const [newFileForm, setNewFileForm] = useState({
    name: '',
    type: 'pdf',
    grade: 'الصف الأول الإعدادي',
    subject: 'الدراسات الاجتماعية والتاريخ',
    unit: 'الوحدة الأولى',
    lesson: 'الدرس الأول',
    description: '',
    keywords: ''
  });

  // Load Saved Library from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('mobdea_mobile_library');
      if (saved) setLibraryFiles(JSON.parse(saved));
    } catch (err) {
      console.log('Error loading library files', err);
    }
  }, []);

  const saveLibrary = (updated) => {
    setLibraryFiles(updated);
    try {
      localStorage.setItem('mobdea_mobile_library', JSON.stringify(updated));
    } catch (err) {
      console.log('Error saving library', err);
    }
  };

  // Submit New File Modal
  const handleAddNewFile = (e) => {
    e.preventDefault();
    if (!newFileForm.name.trim()) return;

    const newObj = {
      id: `lib_${Date.now()}`,
      ...newFileForm,
      size: '4.5 MB',
      createdAt: new Date().toISOString().split('T')[0]
    };

    const updated = [newObj, ...libraryFiles];
    saveLibrary(updated);
    setShowAddModal(false);
    setNewFileForm({
      name: '',
      type: 'pdf',
      grade: 'الصف الأول الإعدادي',
      subject: 'الدراسات الاجتماعية والتاريخ',
      unit: 'الوحدة الأولى',
      lesson: 'الدرس الأول',
      description: '',
      keywords: ''
    });
  };

  // Delete File
  const handleDeleteFile = (id) => {
    const updated = libraryFiles.filter(f => f.id !== id);
    saveLibrary(updated);
  };

  // Filtered List
  const filteredFiles = libraryFiles.filter((file) => {
    const matchesSearch = `${file.name} ${file.description} ${file.keywords} ${file.lesson}`
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesGrade = selectedGradeFilter === 'الكل' || file.grade === selectedGradeFilter;
    const matchesType = selectedTypeFilter === 'الكل' || file.type === selectedTypeFilter;
    return matchesSearch && matchesGrade && matchesType;
  });

  const fileTypeIcons = {
    pdf: { icon: FileText, color: 'text-rose-400', bg: 'bg-rose-950/40 border-rose-800' },
    word: { icon: FileText, color: 'text-blue-400', bg: 'bg-blue-950/40 border-blue-800' },
    ppt: { icon: FileSpreadsheet, color: 'text-amber-400', bg: 'bg-amber-950/40 border-amber-800' },
    video: { icon: Video, color: 'text-cyan-400', bg: 'bg-cyan-950/40 border-cyan-800' },
    image: { icon: ImageIcon, color: 'text-emerald-400', bg: 'bg-emerald-950/40 border-emerald-800' },
    map: { icon: Map, color: 'text-purple-400', bg: 'bg-purple-950/40 border-purple-800' },
    quiz: { icon: HelpCircle, color: 'text-amber-300', bg: 'bg-amber-950/40 border-amber-800' }
  };

  return (
    <div className="w-full bg-slate-950 border-2 border-amber-600/70 p-4 sm:p-6 rounded-3xl shadow-2xl space-y-6 font-ibm text-amber-100">
      
      {/* HEADER & ADD BUTTON */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-amber-900/60 pb-4">
        <div>
          <h2 className="font-reem text-xl sm:text-2xl font-bold text-amber-300 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-amber-400" />
            <span>مكتبة المحتوى التعليمي والدروس</span>
          </h2>
          <p className="text-xs text-amber-200/80 mt-1">
            إدارة ورفع المذكرات، الكتب، الخرائط، الفيديو والأدلة التعليمية مباشرة من الهاتف.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-extrabold rounded-2xl text-xs sm:text-sm shadow-xl hover:from-amber-400 hover:to-amber-300 transition flex items-center justify-center gap-2"
        >
          <FolderPlus className="w-5 h-5" />
          <span>رفع ملف جديد للمكتبة</span>
        </button>
      </div>

      {/* SEARCH & FILTERS BAR */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 absolute right-3 top-3 text-amber-400/70" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث بالاسم، الكلمات المفتاحية..."
            className="w-full pr-9 pl-4 py-2 bg-slate-900 border border-amber-900/80 rounded-2xl text-xs text-amber-100 outline-none focus:border-amber-400"
          />
        </div>

        {/* Grade Filter */}
        <select
          value={selectedGradeFilter}
          onChange={(e) => setSelectedGradeFilter(e.target.value)}
          className="bg-slate-900 border border-amber-900/80 rounded-2xl px-3 py-2 text-xs text-amber-100 outline-none focus:border-amber-400"
        >
          <option value="الكل">كل الصفوف الدراسية</option>
          <option value="الصف الأول الإعدادي">الصف الأول الإعدادي</option>
          <option value="الصف الثاني الإعدادي">الصف الثاني الإعدادي</option>
          <option value="الصف الثالث الإعدادي">الصف الثالث الإعدادي</option>
        </select>

        {/* Type Filter */}
        <select
          value={selectedTypeFilter}
          onChange={(e) => setSelectedTypeFilter(e.target.value)}
          className="bg-slate-900 border border-amber-900/80 rounded-2xl px-3 py-2 text-xs text-amber-100 outline-none focus:border-amber-400"
        >
          <option value="الكل">جميع أنواع الملفات</option>
          <option value="pdf">مستندات PDF</option>
          <option value="map">خرائط تفاعلية</option>
          <option value="video">فيديوهات شرح</option>
          <option value="quiz">اختبارات وأسئلة</option>
        </select>
      </div>

      {/* FILES GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredFiles.map((file) => {
          const typeConf = fileTypeIcons[file.type] || fileTypeIcons.pdf;
          const Icon = typeConf.icon;

          return (
            <div
              key={file.id}
              className="bg-slate-900/90 border border-amber-900/80 p-5 rounded-3xl flex flex-col justify-between hover:border-amber-500/80 transition shadow-xl group"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className={`p-2 rounded-2xl border ${typeConf.bg} ${typeConf.color} flex items-center gap-2`}>
                    <Icon className="w-4 h-4" />
                    <span className="font-extrabold text-[11px] uppercase">{file.type}</span>
                  </div>

                  <span className="text-[10px] text-amber-400/80 font-mono font-bold bg-slate-950 px-2.5 py-1 rounded-xl border border-amber-900/40">
                    {file.size}
                  </span>
                </div>

                <h3 className="font-bold text-amber-100 text-base mb-1 group-hover:text-amber-300 transition">
                  {file.name}
                </h3>

                <p className="text-xs text-amber-200/70 mb-3 line-clamp-2">
                  {file.description}
                </p>

                {/* Metadata Tags */}
                <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-amber-300 font-bold mb-4">
                  <span className="bg-amber-950 border border-amber-800 px-2 py-0.5 rounded-lg">
                    {file.grade}
                  </span>
                  <span className="bg-amber-950 border border-amber-800 px-2 py-0.5 rounded-lg">
                    {file.unit}
                  </span>
                  <span className="bg-amber-950 border border-amber-800 px-2 py-0.5 rounded-lg">
                    {file.lesson}
                  </span>
                </div>
              </div>

              {/* ACTION BUTTONS */}
              <div className="pt-3 border-t border-amber-900/50 flex items-center justify-between gap-2">
                <button
                  onClick={() => onOpenResourceInClass && onOpenResourceInClass(file)}
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold rounded-xl text-xs flex items-center gap-1 shadow-md transition"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>فتح للشرح</span>
                </button>

                <div className="flex items-center gap-1">
                  {onAttachToLesson && (
                    <button
                      onClick={() => onAttachToLesson(file)}
                      className="p-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-xl text-xs font-bold border border-amber-800/80"
                      title="إرفاق بالدرس"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  )}

                  <button
                    onClick={() => handleDeleteFile(file.id)}
                    className="p-1.5 bg-slate-800 hover:bg-rose-950 text-rose-400 rounded-xl text-xs font-bold border border-rose-900/50 transition"
                    title="حذف من المكتبة"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

            </div>
          );
        })}
      </div>

      {/* METADATA UPLOAD MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-950 border-2 border-amber-500 rounded-3xl p-6 max-w-lg w-full text-amber-100 shadow-2xl space-y-4 max-h-[90vh] overflow-auto custom-scrollbar">
            
            <div className="flex items-center justify-between border-b border-amber-800 pb-3">
              <h3 className="font-reem text-lg font-bold text-amber-300 flex items-center gap-2">
                <Tag className="w-5 h-5 text-amber-400" />
                <span>إدخال بيانات وتصنيف الملف الجديد</span>
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 hover:bg-slate-800 rounded-xl text-amber-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddNewFile} className="space-y-4 text-xs font-bold">
              
              <div>
                <label className="block text-amber-300 mb-1">اسم الملف أو العنوان *</label>
                <input
                  type="text"
                  required
                  value={newFileForm.name}
                  onChange={(e) => setNewFileForm({ ...newFileForm, name: e.target.value })}
                  placeholder="مثال: مذكرة شرح درس مفهوم الدولة"
                  className="w-full px-3 py-2 bg-slate-900 border border-amber-800 rounded-xl text-amber-100 outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-amber-300 mb-1">نوع الملف</label>
                  <select
                    value={newFileForm.type}
                    onChange={(e) => setNewFileForm({ ...newFileForm, type: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-amber-800 rounded-xl text-amber-100 outline-none"
                  >
                    <option value="pdf">مستند PDF</option>
                    <option value="word">مستند Word</option>
                    <option value="ppt">عرض تقديمي PowerPoint</option>
                    <option value="video">فيديو تعليمي</option>
                    <option value="image">صورة توضيحية</option>
                    <option value="map">خريطة تفاعلية</option>
                    <option value="quiz">اختبار / تمارين</option>
                  </select>
                </div>

                <div>
                  <label className="block text-amber-300 mb-1">الصف الدراسي</label>
                  <select
                    value={newFileForm.grade}
                    onChange={(e) => setNewFileForm({ ...newFileForm, grade: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-amber-800 rounded-xl text-amber-100 outline-none"
                  >
                    <option value="الصف الأول الإعدادي">الصف الأول الإعدادي</option>
                    <option value="الصف الثاني الإعدادي">الصف الثاني الإعدادي</option>
                    <option value="الصف الثالث الإعدادي">الصف الثالث الإعدادي</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-amber-300 mb-1">الوحدة التعليمية</label>
                  <input
                    type="text"
                    value={newFileForm.unit}
                    onChange={(e) => setNewFileForm({ ...newFileForm, unit: e.target.value })}
                    placeholder="مثال: الوحدة الأولى"
                    className="w-full px-3 py-2 bg-slate-900 border border-amber-800 rounded-xl text-amber-100 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-amber-300 mb-1">اسم الدرس</label>
                  <input
                    type="text"
                    value={newFileForm.lesson}
                    onChange={(e) => setNewFileForm({ ...newFileForm, lesson: e.target.value })}
                    placeholder="مثال: مفهوم الدولة وعناصرها"
                    className="w-full px-3 py-2 bg-slate-900 border border-amber-800 rounded-xl text-amber-100 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-amber-300 mb-1">الوصف المبتصر</label>
                <textarea
                  rows="2"
                  value={newFileForm.description}
                  onChange={(e) => setNewFileForm({ ...newFileForm, description: e.target.value })}
                  placeholder="وصف محتوى الملف وملاحظات الشرح..."
                  className="w-full px-3 py-2 bg-slate-900 border border-amber-800 rounded-xl text-amber-100 outline-none"
                />
              </div>

              <div>
                <label className="block text-amber-300 mb-1">الكلمات المفتاحية (مفصولة بفاصلة)</label>
                <input
                  type="text"
                  value={newFileForm.keywords}
                  onChange={(e) => setNewFileForm({ ...newFileForm, keywords: e.target.value })}
                  placeholder="دولة، سيادة، جغرافيا، امتحان..."
                  className="w-full px-3 py-2 bg-slate-900 border border-amber-800 rounded-xl text-amber-100 outline-none"
                />
              </div>

              <div className="pt-3 border-t border-amber-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-800 text-amber-300 rounded-xl"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold rounded-xl shadow-lg"
                >
                  حفظ وتصنيف
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
