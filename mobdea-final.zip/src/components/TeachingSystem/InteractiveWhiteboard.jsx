import React, { useState, useRef, useEffect } from 'react';
import { 
  PenTool, Edit3, Eraser, Highlighter, Type, Square, Circle, 
  ArrowLeft, Image as ImageIcon, Map, Layers, RotateCcw, RotateCw, 
  Trash2, ZoomIn, ZoomOut, Maximize2, Move, Save, Download, 
  Plus, Sparkles, FileText, Check, X, MousePointer, HelpCircle
} from 'lucide-react';
import AnnotationCanvasOverlay from './AnnotationCanvasOverlay';

export default function InteractiveWhiteboard({ currentLesson, onSaveBoard }) {
  const [boardZoom, setBoardZoom] = useState(1);
  const [activeBoardTool, setActiveBoardTool] = useState('pen');
  
  // Whiteboard Embedded Items (PDF pages, maps, images, text, cards)
  const [boardObjects, setBoardObjects] = useState([
    {
      id: 'pdf_embed_1',
      type: 'pdf_page',
      x: 50,
      y: 40,
      width: 480,
      title: 'كتاب الدراسات - صفحة ١ (مفهوم الدولة)',
      content: 'الدولة تنظيم سياسي يقوم على أربعة اركان: الشعب والإقليم والسلطة والسيادة.'
    },
    {
      id: 'map_embed_1',
      type: 'map',
      x: 560,
      y: 40,
      width: 400,
      title: 'خريطة الوطن العربي السياسية',
      mapUrl: 'https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?w=800&auto=format&fit=crop&q=80'
    }
  ]);

  const [selectedObjId, setSelectedObjId] = useState(null);

  // Whiteboard Annotations (strokes and stickers)
  const [whiteboardAnnotations, setWhiteboardAnnotations] = useState({});

  // Add new embedded image or card
  const handleAddBoardCard = (type) => {
    const newObj = {
      id: `embed_${Date.now()}`,
      type: type,
      x: 100 + Math.random() * 80,
      y: 100 + Math.random() * 80,
      width: 380,
      title: type === 'note' ? 'ملاحظة شرح جديدة' : type === 'image' ? 'شكل تعليمي توضيحي' : 'سؤال الحصة التفاعلي',
      content: type === 'note' ? 'اكتب نقاط الشرح الرئيسية الموجهة للطلاب...' : 'صورة أو مخطط توضيحي مأخوذ من المذكرة.'
    };
    setBoardObjects(prev => [...prev, newObj]);
    setSelectedObjId(newObj.id);
  };

  // Delete Object
  const handleDeleteSelected = () => {
    if (!selectedObjId) return;
    setBoardObjects(prev => prev.filter(o => o.id !== selectedObjId));
    setSelectedObjId(null);
  };

  // Bring to front
  const handleBringToFront = () => {
    if (!selectedObjId) return;
    const target = boardObjects.find(o => o.id === selectedObjId);
    if (!target) return;
    const filtered = boardObjects.filter(o => o.id !== selectedObjId);
    setBoardObjects([...filtered, target]);
  };

  // Save Whiteboard State
  const handleSaveBoardState = () => {
    const savedData = {
      lessonId: currentLesson?.id || 'lesson_1',
      objects: boardObjects,
      annotations: whiteboardAnnotations,
      savedAt: new Date().toISOString()
    };
    localStorage.setItem(`mobdea_whiteboard_${currentLesson?.id || 'lesson_1'}`, JSON.stringify(savedData));
    if (onSaveBoard) onSaveBoard(savedData);
    alert('تم حفظ السبورة التفاعلية بنجاح! ⭐');
  };

  return (
    <div className="relative w-full flex-1 bg-slate-950 p-2 sm:p-4 rounded-3xl border-2 border-amber-600/70 shadow-2xl flex flex-col justify-between overflow-hidden min-h-[640px] font-ibm">
      
      {/* HISTORICAL ELEGANT PARCHMENT BOARD CONTAINER */}
      <div className="relative flex-1 bg-[#f5efe0] rounded-2xl border-4 border-[#3b2313] shadow-2xl overflow-hidden flex flex-col">
        
        {/* PARCHMENT PATTERN BACKGROUND */}
        <div 
          className="absolute inset-0 pointer-events-none opacity-40 bg-repeat"
          style={{
            backgroundImage: `radial-gradient(#b89b68 0.75px, transparent 0.75px), radial-gradient(#b89b68 0.75px, #f5efe0 0.75px)`,
            backgroundSize: '30px 30px',
            backgroundPosition: '0 0, 15px 15px'
          }}
        />

        {/* TOP BOARD HEADER */}
        <div className="relative z-20 bg-gradient-to-r from-[#2c180b] via-[#432612] to-[#2c180b] border-b-2 border-amber-500/80 px-4 py-2.5 shadow-lg flex flex-wrap items-center justify-between gap-2 text-amber-100">
          
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
            <h3 className="font-reem text-sm sm:text-base font-bold text-amber-200">
              السبورة الرقمية التفاعلية • {currentLesson?.lessonName || 'الدرس المباشر'}
            </h3>
          </div>

          {/* TOP QUICK EMBED & SAVE CONTROLS */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleAddBoardCard('note')}
              className="px-2.5 py-1 bg-amber-950/90 border border-amber-500/60 hover:bg-amber-800 text-amber-200 rounded-xl text-xs font-bold flex items-center gap-1 transition"
            >
              <Plus className="w-3.5 h-3.5 text-amber-400" />
              <span>إدراج ملاحظة</span>
            </button>

            <button
              onClick={() => handleAddBoardCard('image')}
              className="px-2.5 py-1 bg-amber-950/90 border border-amber-500/60 hover:bg-amber-800 text-amber-200 rounded-xl text-xs font-bold flex items-center gap-1 transition"
            >
              <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
              <span>إدراج صورة</span>
            </button>

            <button
              onClick={handleSaveBoardState}
              className="px-3 py-1 bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-extrabold rounded-xl text-xs shadow-md hover:from-amber-400 hover:to-amber-300 transition flex items-center gap-1"
            >
              <Save className="w-3.5 h-3.5" />
              <span>حفظ السبورة</span>
            </button>
          </div>

        </div>

        {/* CANVAS WHITEBOARD WORKSPACE (ZOOMABLE) */}
        <div 
          className="relative flex-1 overflow-auto custom-scrollbar p-6 select-none"
          style={{ transform: `scale(${boardZoom})`, transformOrigin: 'top right', transition: 'transform 0.2s ease-out' }}
        >

          {/* EMBEDDED OBJECTS (PDF PAGES, MAPS, NOTES) */}
          {boardObjects.map((obj) => {
            const isSelected = selectedObjId === obj.id;

            return (
              <div
                key={obj.id}
                onClick={(e) => { e.stopPropagation(); setSelectedObjId(obj.id); }}
                style={{
                  left: obj.x,
                  top: obj.y,
                  width: obj.width
                }}
                className={`absolute z-10 bg-white/95 dark:bg-slate-900/95 border-2 p-4 rounded-3xl shadow-xl transition-all font-ibm ${
                  isSelected ? 'border-amber-500 ring-4 ring-amber-400/40 shadow-2xl scale-[1.01]' : 'border-amber-900/40 hover:border-amber-600'
                }`}
              >
                {/* Object Header Bar */}
                <div className="flex items-center justify-between border-b border-amber-500/30 pb-2 mb-3">
                  <div className="flex items-center gap-2">
                    {obj.type === 'pdf_page' ? (
                      <FileText className="w-4 h-4 text-rose-600" />
                    ) : obj.type === 'map' ? (
                      <Map className="w-4 h-4 text-blue-600" />
                    ) : (
                      <Sparkles className="w-4 h-4 text-amber-500" />
                    )}
                    <span className="font-reem text-xs font-bold text-amber-900 dark:text-amber-200 truncate max-w-[200px]">
                      {obj.title}
                    </span>
                  </div>

                  {isSelected && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={handleBringToFront}
                        className="p-1 bg-amber-100 dark:bg-slate-800 text-amber-800 dark:text-amber-300 rounded-lg text-[10px] font-bold"
                        title="جلب للأمام"
                      >
                        <Layers className="w-3 h-3" />
                      </button>
                      <button
                        onClick={handleDeleteSelected}
                        className="p-1 bg-rose-100 dark:bg-rose-950 text-rose-600 rounded-lg text-[10px] font-bold"
                        title="حذف"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Object Content */}
                {obj.type === 'pdf_page' && (
                  <div className="bg-amber-50/80 dark:bg-slate-950 p-4 rounded-2xl border border-amber-200 dark:border-amber-900/60 text-xs leading-relaxed text-slate-800 dark:text-slate-200">
                    <p className="font-extrabold text-rose-800 dark:text-rose-400 mb-1">
                      مقتطف من كتاب الدراسات:
                    </p>
                    <p>{obj.content}</p>
                  </div>
                )}

                {obj.type === 'map' && (
                  <div className="relative rounded-2xl overflow-hidden border border-amber-300">
                    <img
                      src={obj.mapUrl}
                      alt="خريطة السبورة"
                      className="w-full h-48 object-cover rounded-2xl"
                    />
                    <div className="absolute bottom-2 right-2 bg-slate-950/80 text-amber-300 text-[10px] px-2 py-0.5 rounded-lg font-bold">
                      خريطة تفاعلية
                    </div>
                  </div>
                )}

                {obj.type === 'note' && (
                  <div className="p-3 bg-amber-100/90 text-amber-950 rounded-2xl text-xs font-bold leading-relaxed border border-amber-300">
                    {obj.content}
                  </div>
                )}

              </div>
            );
          })}

          {/* ANNOTATION DRAWING OVERLAY FOR WHITEBOARD */}
          <div className="absolute inset-0 z-20 pointer-events-auto">
            <AnnotationCanvasOverlay
              pageIndex={1}
              annotations={whiteboardAnnotations[1]}
              onSaveAnnotations={({ pageIndex, strokes, elements }) => {
                setWhiteboardAnnotations(prev => ({
                  ...prev,
                  [pageIndex]: { strokes, elements }
                }));
              }}
            />
          </div>

        </div>

      </div>

    </div>
  );
}
