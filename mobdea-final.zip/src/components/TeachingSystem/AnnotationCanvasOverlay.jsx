import React, { useState, useRef, useEffect } from 'react';
import { 
  PenTool, Edit2, Eraser, Highlighter, Type, Square, Circle, 
  ArrowLeft, ArrowRight, Minus, Move, RotateCcw, RotateCw, Trash2, 
  CheckCircle2, XCircle, Stamp, Sparkles, Image as ImageIcon,
  MousePointer, Palette, Layers, ZoomIn, ZoomOut, Check, X,
  HelpCircle, Star, Hash, Lock, Unlock, Eye, Copy
} from 'lucide-react';

export default function AnnotationCanvasOverlay({ 
  width, 
  height, 
  pageIndex, 
  annotations, 
  onSaveAnnotations,
  readOnly = false,
  nightMode = false
}) {

  // Canvas Reference
  const canvasRef = useRef(null);
  const overlayRef = useRef(null);

  // Active Tool & Style Configuration
  const [activeTool, setActiveTool] = useState('pen'); // pen, pencil, highlighter, laser, eraser, select, text, shape, element
  const [selectedShape, setSelectedShape] = useState('rectangle'); // line, arrow, circle, rectangle, triangle
  const [penColor, setPenColor] = useState('#ef4444'); // Red default
  const [strokeWidth, setStrokeWidth] = useState(4);
  const [opacity, setOpacity] = useState(0.5); // For highlighter

  // Laser Pointer Position
  const [laserPos, setLaserPos] = useState(null);

  // Drawing Freehand Strokes
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentStroke, setCurrentStroke] = useState([]);
  const [strokes, setStrokes] = useState(annotations?.strokes || []);

  // Placed Elements (Text, Shapes, Stickers, Images, Badges)
  const [elements, setElements] = useState(annotations?.elements || []);
  const [selectedElementId, setSelectedElementId] = useState(null);

  // Text Box Input Modal/Inline State
  const [editingTextId, setEditingTextId] = useState(null);
  const [textValue, setTextValue] = useState('');

  // History for Undo / Redo
  const [history, setHistory] = useState([ { strokes: annotations?.strokes || [], elements: annotations?.elements || [] } ]);
  const [historyIndex, setHistoryIndex] = useState(0);

  // Sync internal state if pageIndex or annotations change
  useEffect(() => {
    if (annotations) {
      setStrokes(annotations.strokes || []);
      setElements(annotations.elements || []);
      setHistory([ { strokes: annotations.strokes || [], elements: annotations.elements || [] } ]);
      setHistoryIndex(0);
    }
  }, [pageIndex, annotations]);

  // Save changes to parent whenever strokes or elements update
  const pushStateToParent = (newStrokes, newElements) => {
    setStrokes(newStrokes);
    setElements(newElements);
    
    // Add to history
    const nextHistory = history.slice(0, historyIndex + 1);
    nextHistory.push({ strokes: newStrokes, elements: newElements });
    setHistory(nextHistory);
    setHistoryIndex(nextHistory.length - 1);

    if (onSaveAnnotations) {
      onSaveAnnotations({ pageIndex, strokes: newStrokes, elements: newElements });
    }
  };

  // Undo Action
  const handleUndo = () => {
    if (historyIndex > 0) {
      const prev = history[historyIndex - 1];
      setHistoryIndex(historyIndex - 1);
      setStrokes(prev.strokes);
      setElements(prev.elements);
      if (onSaveAnnotations) {
        onSaveAnnotations({ pageIndex, strokes: prev.strokes, elements: prev.elements });
      }
    }
  };

  // Redo Action
  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const next = history[historyIndex + 1];
      setHistoryIndex(historyIndex + 1);
      setStrokes(next.strokes);
      setElements(next.elements);
      if (onSaveAnnotations) {
        onSaveAnnotations({ pageIndex, strokes: next.strokes, elements: next.elements });
      }
    }
  };

  // Clear Page Annotations
  const handleClearAll = () => {
    pushStateToParent([], []);
  };

  // Render Canvas Freehand Strokes
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw saved strokes
    strokes.forEach((s) => {
      if (!s.points || s.points.length < 2) return;
      ctx.beginPath();
      ctx.moveTo(s.points[0].x, s.points[0].y);

      for (let i = 1; i < s.points.length; i++) {
        ctx.lineTo(s.points[i].x, s.points[i].y);
      }

      ctx.strokeStyle = s.tool === 'highlighter' ? `${s.color}${Math.round(s.opacity * 255).toString(16).padStart(2, '0')}` : s.color;
      ctx.lineWidth = s.tool === 'highlighter' ? s.width * 3 : s.tool === 'pencil' ? Math.max(1, s.width - 1) : s.width;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      if (s.tool === 'pencil') {
        ctx.setLineDash([3, 2]);
      } else {
        ctx.setLineDash([]);
      }
      ctx.stroke();
    });

    // Draw active stroke
    if (currentStroke && currentStroke.length > 1) {
      ctx.beginPath();
      ctx.moveTo(currentStroke[0].x, currentStroke[0].y);
      for (let i = 1; i < currentStroke.length; i++) {
        ctx.lineTo(currentStroke[i].x, currentStroke[i].y);
      }
      ctx.strokeStyle = activeTool === 'highlighter' ? `${penColor}${Math.round(opacity * 255).toString(16).padStart(2, '0')}` : penColor;
      ctx.lineWidth = activeTool === 'highlighter' ? strokeWidth * 3 : activeTool === 'pencil' ? Math.max(1, strokeWidth - 1) : strokeWidth;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      if (activeTool === 'pencil') ctx.setLineDash([3, 2]);
      else ctx.setLineDash([]);
      ctx.stroke();
    }
  }, [strokes, currentStroke, activeTool, penColor, strokeWidth, opacity]);

  // Mouse / Touch Handlers for Drawing
  const handlePointerDown = (e) => {
    if (readOnly) return;

    const rect = overlayRef.current.getBoundingClientRect();
    const clientX = e.clientX || e.touches?.[0]?.clientX;
    const clientY = e.clientY || e.touches?.[0]?.clientY;
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    if (activeTool === 'laser') {
      setLaserPos({ x, y });
      return;
    }

    if (activeTool === 'pen' || activeTool === 'pencil' || activeTool === 'highlighter') {
      setIsDrawing(true);
      setCurrentStroke([{ x, y }]);
      return;
    }

    if (activeTool === 'eraser') {
      // Erase stroke nearby
      const filteredStrokes = strokes.filter((s) => {
        return !s.points.some((p) => Math.hypot(p.x - x, p.y - y) < 20);
      });
      // Erase elements nearby
      const filteredElements = elements.filter((el) => {
        return Math.hypot(el.x - x, el.y - y) > 30;
      });
      pushStateToParent(filteredStrokes, filteredElements);
      return;
    }

    if (activeTool === 'text') {
      const newTextObj = {
        id: Date.now(),
        type: 'text',
        x,
        y,
        text: 'انقر للتعادل والكتابة هنا...',
        color: penColor,
        fontSize: Math.max(16, strokeWidth * 4),
        fontWeight: 'bold'
      };
      pushStateToParent(strokes, [...elements, newTextObj]);
      setSelectedElementId(newTextObj.id);
      setEditingTextId(newTextObj.id);
      setTextValue(newTextObj.text);
      setActiveTool('select');
      return;
    }

    if (activeTool === 'shape') {
      const newShape = {
        id: Date.now(),
        type: 'shape',
        shapeType: selectedShape,
        x,
        y,
        width: 120,
        height: 80,
        color: penColor,
        strokeWidth: strokeWidth,
        fillColor: `${penColor}22`
      };
      pushStateToParent(strokes, [...elements, newShape]);
      setSelectedElementId(newShape.id);
      setActiveTool('select');
      return;
    }
  };

  const handlePointerMove = (e) => {
    const rect = overlayRef.current?.getBoundingClientRect();
    if (!rect) return;
    const clientX = e.clientX || e.touches?.[0]?.clientX;
    const clientY = e.clientY || e.touches?.[0]?.clientY;
    if (!clientX || !clientY) return;

    const x = clientX - rect.left;
    const y = clientY - rect.top;

    if (activeTool === 'laser') {
      setLaserPos({ x, y });
      return;
    }

    if (isDrawing) {
      setCurrentStroke((prev) => [...prev, { x, y }]);
    }
  };

  const handlePointerUp = () => {
    if (isDrawing && currentStroke.length > 0) {
      const newStrokeObj = {
        id: Date.now(),
        tool: activeTool,
        color: penColor,
        width: strokeWidth,
        opacity: opacity,
        points: currentStroke
      };
      pushStateToParent([...strokes, newStrokeObj], elements);
      setCurrentStroke([]);
      setIsDrawing(false);
    }
  };

  // Add Preset Elements (Check ✅, Cross ❌, Star ⭐, Badge Numbers, Arrows)
  const addPresetElement = (type, content) => {
    const newEl = {
      id: Date.now(),
      type,
      content,
      x: 100 + Math.random() * 100,
      y: 100 + Math.random() * 100,
      size: 32,
      color: penColor
    };
    pushStateToParent(strokes, [...elements, newEl]);
    setSelectedElementId(newEl.id);
  };

  // Delete Selected Element
  const deleteSelectedElement = () => {
    if (!selectedElementId) return;
    const nextEls = elements.filter((el) => el.id !== selectedElementId);
    pushStateToParent(strokes, nextEls);
    setSelectedElementId(null);
  };

  const colors = [
    '#ef4444', // Red
    '#2563eb', // Blue
    '#10b981', // Green
    '#f59e0b', // Amber/Yellow
    '#8b5cf6', // Purple
    '#ec4899', // Pink
    '#000000', // Black
    '#ffffff'  // White
  ];

  return (
    <div 
      ref={overlayRef}
      onMouseDown={handlePointerDown}
      onMouseMove={handlePointerMove}
      onMouseUp={handlePointerUp}
      onTouchStart={handlePointerDown}
      onTouchMove={handlePointerMove}
      onTouchEnd={handlePointerUp}
      style={{ width: width || '100%', height: height || '100%' }}
      className="relative select-none touch-none overflow-hidden"
    >
      
      {/* CANVAS DRAWING LAYER */}
      <canvas
        ref={canvasRef}
        width={typeof width === 'number' ? width : 1000}
        height={typeof height === 'number' ? height : 1400}
        className="absolute inset-0 w-full h-full pointer-events-none z-10"
      />

      {/* PLACED SVG SHAPES & TEXT & ELEMENTS */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none z-20">
        {elements.map((el) => {
          const isSelected = selectedElementId === el.id;

          if (el.type === 'shape') {
            return (
              <g 
                key={el.id} 
                onClick={(e) => { e.stopPropagation(); setSelectedElementId(el.id); }}
                className="pointer-events-auto cursor-pointer"
              >
                {el.shapeType === 'rectangle' && (
                  <rect
                    x={el.x}
                    y={el.y}
                    width={el.width}
                    height={el.height}
                    fill={el.fillColor || 'transparent'}
                    stroke={el.color}
                    strokeWidth={el.strokeWidth || 3}
                    rx="8"
                    className={isSelected ? 'stroke-amber-400 stroke-[4] filter drop-shadow-md' : ''}
                  />
                )}
                {el.shapeType === 'circle' && (
                  <ellipse
                    cx={el.x + el.width / 2}
                    cy={el.y + el.height / 2}
                    rx={el.width / 2}
                    ry={el.height / 2}
                    fill={el.fillColor || 'transparent'}
                    stroke={el.color}
                    strokeWidth={el.strokeWidth || 3}
                    className={isSelected ? 'stroke-amber-400 stroke-[4] filter drop-shadow-md' : ''}
                  />
                )}
                {el.shapeType === 'arrow' && (
                  <g>
                    <line
                      x1={el.x}
                      y1={el.y + el.height / 2}
                      x2={el.x + el.width}
                      y2={el.y + el.height / 2}
                      stroke={el.color}
                      strokeWidth={el.strokeWidth || 4}
                      strokeLinecap="round"
                    />
                    <polygon
                      points={`${el.x + el.width - 12},${el.y + el.height / 2 - 8} ${el.x + el.width},${el.y + el.height / 2} ${el.x + el.width - 12},${el.y + el.height / 2 + 8}`}
                      fill={el.color}
                    />
                  </g>
                )}
                {el.shapeType === 'line' && (
                  <line
                    x1={el.x}
                    y1={el.y}
                    x2={el.x + el.width}
                    y2={el.y + el.height}
                    stroke={el.color}
                    strokeWidth={el.strokeWidth || 3}
                    strokeLinecap="round"
                  />
                )}
              </g>
            );
          }

          if (el.type === 'badge' || el.type === 'sticker') {
            return (
              <g 
                key={el.id}
                onClick={(e) => { e.stopPropagation(); setSelectedElementId(el.id); }}
                className="pointer-events-auto cursor-pointer"
                transform={`translate(${el.x}, ${el.y})`}
              >
                <text textAnchor="middle" dominantBaseline="central" fontSize={el.size || 28} className="select-none">
                  {el.content}
                </text>
                {isSelected && (
                  <circle r={el.size ? el.size / 1.5 : 20} fill="none" stroke="#f59e0b" strokeWidth="2" strokeDasharray="3,3" />
                )}
              </g>
            );
          }

          return null;
        })}
      </svg>

      {/* HTML TEXT ELEMENTS OVERLAY */}
      <div className="absolute inset-0 pointer-events-none z-30">
        {elements.filter(el => el.type === 'text').map((el) => {
          const isSelected = selectedElementId === el.id;
          const isEditing = editingTextId === el.id;

          return (
            <div
              key={el.id}
              onClick={(e) => { e.stopPropagation(); setSelectedElementId(el.id); }}
              onDoubleClick={() => { setEditingTextId(el.id); setTextValue(el.text); }}
              style={{
                left: el.x,
                top: el.y,
                color: el.color,
                fontSize: `${el.fontSize || 18}px`
              }}
              className={`absolute pointer-events-auto p-1.5 rounded-xl transition font-ibm font-extrabold max-w-sm ${
                isSelected ? 'ring-2 ring-amber-400 bg-amber-950/80 shadow-lg' : 'bg-transparent'
              }`}
            >
              {isEditing ? (
                <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-amber-500 shadow-xl">
                  <input
                    type="text"
                    value={textValue}
                    onChange={(e) => setTextValue(e.target.value)}
                    className="bg-transparent text-amber-100 text-sm px-2 py-1 outline-none font-ibm"
                    autoFocus
                  />
                  <button
                    onClick={() => {
                      const nextEls = elements.map(item => item.id === el.id ? { ...item, text: textValue } : item);
                      pushStateToParent(strokes, nextEls);
                      setEditingTextId(null);
                    }}
                    className="p-1 bg-emerald-600 text-white rounded-lg text-xs"
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <span>{el.text}</span>
              )}
            </div>
          );
        })}
      </div>

      {/* GLOWING LASER POINTER EFFECT */}
      {activeTool === 'laser' && laserPos && (
        <div 
          style={{ left: laserPos.x - 12, top: laserPos.y - 12 }}
          className="absolute w-6 h-6 rounded-full bg-rose-500/80 border-2 border-white shadow-[0_0_20px_#ef4444] animate-ping pointer-events-none z-50"
        />
      )}

      {/* FLOATING ANNOTATION TOOLBAR FOR TEACHER */}
      {!readOnly && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-40 bg-slate-950/95 border-2 border-amber-600/80 px-3 py-2 rounded-2xl shadow-2xl backdrop-blur-2xl flex items-center gap-2 flex-wrap font-ibm text-amber-100 max-w-[95%]">
          
          {/* Select Tool */}
          <button
            onClick={() => setActiveTool('select')}
            className={`p-2 rounded-xl transition ${
              activeTool === 'select' ? 'bg-amber-500 text-slate-950 font-black' : 'hover:bg-slate-800 text-amber-300'
            }`}
            title="أداة التحديد والتحريك"
          >
            <MousePointer className="w-4 h-4" />
          </button>

          {/* Normal Pen */}
          <button
            onClick={() => setActiveTool('pen')}
            className={`p-2 rounded-xl transition ${
              activeTool === 'pen' ? 'bg-amber-500 text-slate-950 font-black' : 'hover:bg-slate-800 text-amber-300'
            }`}
            title="قلم عادي"
          >
            <PenTool className="w-4 h-4" />
          </button>

          {/* Pencil */}
          <button
            onClick={() => setActiveTool('pencil')}
            className={`p-2 rounded-xl transition ${
              activeTool === 'pencil' ? 'bg-amber-500 text-slate-950 font-black' : 'hover:bg-slate-800 text-amber-300'
            }`}
            title="قلم رصاص"
          >
            <Edit2 className="w-4 h-4" />
          </button>

          {/* Highlighter */}
          <button
            onClick={() => setActiveTool('highlighter')}
            className={`p-2 rounded-xl transition ${
              activeTool === 'highlighter' ? 'bg-amber-500 text-slate-950 font-black' : 'hover:bg-slate-800 text-amber-300'
            }`}
            title="هايلايتر للتظليل"
          >
            <Highlighter className="w-4 h-4" />
          </button>

          {/* Laser Pointer */}
          <button
            onClick={() => setActiveTool('laser')}
            className={`p-2 rounded-xl transition ${
              activeTool === 'laser' ? 'bg-rose-600 text-white font-black animate-pulse shadow-[0_0_10px_#ef4444]' : 'hover:bg-slate-800 text-rose-400'
            }`}
            title="قلم ليزر تفاعلي"
          >
            <Sparkles className="w-4 h-4" />
          </button>

          {/* Eraser */}
          <button
            onClick={() => setActiveTool('eraser')}
            className={`p-2 rounded-xl transition ${
              activeTool === 'eraser' ? 'bg-amber-500 text-slate-950 font-black' : 'hover:bg-slate-800 text-amber-300'
            }`}
            title="ممحاة"
          >
            <Eraser className="w-4 h-4" />
          </button>

          {/* Text Tool */}
          <button
            onClick={() => setActiveTool('text')}
            className={`p-2 rounded-xl transition ${
              activeTool === 'text' ? 'bg-amber-500 text-slate-950 font-black' : 'hover:bg-slate-800 text-amber-300'
            }`}
            title="إدراج مربع نص"
          >
            <Type className="w-4 h-4" />
          </button>

          {/* Shape Tool Drawer */}
          <div className="flex items-center gap-1 border-r border-amber-900/60 pr-1 mr-1">
            <button
              onClick={() => { setActiveTool('shape'); setSelectedShape('rectangle'); }}
              className={`p-1.5 rounded-lg text-xs ${activeTool === 'shape' && selectedShape === 'rectangle' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-amber-300 hover:bg-slate-800'}`}
              title="مستطيل"
            >
              <Square className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => { setActiveTool('shape'); setSelectedShape('circle'); }}
              className={`p-1.5 rounded-lg text-xs ${activeTool === 'shape' && selectedShape === 'circle' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-amber-300 hover:bg-slate-800'}`}
              title="دائرة"
            >
              <Circle className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => { setActiveTool('shape'); setSelectedShape('arrow'); }}
              className={`p-1.5 rounded-lg text-xs ${activeTool === 'shape' && selectedShape === 'arrow' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-amber-300 hover:bg-slate-800'}`}
              title="سهم"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Preset Stamps / Educational Badges */}
          <div className="hidden sm:flex items-center gap-1 border-r border-amber-900/60 pr-1 mr-1">
            <button
              onClick={() => addPresetElement('badge', '✅')}
              className="p-1 rounded hover:bg-slate-800 text-xs"
              title="علامة صح"
            >
              ✅
            </button>
            <button
              onClick={() => addPresetElement('badge', '❌')}
              className="p-1 rounded hover:bg-slate-800 text-xs"
              title="علامة خطأ"
            >
              ❌
            </button>
            <button
              onClick={() => addPresetElement('badge', '⭐')}
              className="p-1 rounded hover:bg-slate-800 text-xs"
              title="نجمة ممتاز"
            >
              ⭐
            </button>
            <button
              onClick={() => addPresetElement('badge', '①')}
              className="p-1 rounded hover:bg-slate-800 text-xs text-amber-400 font-bold"
              title="رقم 1"
            >
              ①
            </button>
            <button
              onClick={() => addPresetElement('badge', '②')}
              className="p-1 rounded hover:bg-slate-800 text-xs text-amber-400 font-bold"
              title="رقم 2"
            >
              ②
            </button>
          </div>

          {/* Color Palette Selector */}
          <div className="flex items-center gap-1 border-r border-amber-900/60 pr-1 mr-1">
            {colors.slice(0, 5).map((c) => (
              <button
                key={c}
                onClick={() => setPenColor(c)}
                className={`w-4 h-4 rounded-full border border-slate-950 transition ${
                  penColor === c ? 'scale-125 ring-2 ring-amber-400' : 'opacity-80 hover:opacity-100'
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>

          {/* Stroke Width Slider */}
          <div className="hidden lg:flex items-center gap-1 text-[10px] text-amber-300 font-mono">
            <span>السمك:</span>
            <input
              type="range"
              min="2"
              max="16"
              value={strokeWidth}
              onChange={(e) => setStrokeWidth(Number(e.target.value))}
              className="w-14 accent-amber-500 cursor-pointer"
            />
          </div>

          {/* Undo / Redo */}
          <div className="flex items-center gap-1 border-r border-amber-900/60 pr-1 mr-1">
            <button
              onClick={handleUndo}
              disabled={historyIndex <= 0}
              className="p-1.5 text-amber-300 hover:bg-slate-800 rounded-lg disabled:opacity-30"
              title="تراجع"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleRedo}
              disabled={historyIndex >= history.length - 1}
              className="p-1.5 text-amber-300 hover:bg-slate-800 rounded-lg disabled:opacity-30"
              title="إعادة"
            >
              <RotateCw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Delete Selected or Clear All */}
          {selectedElementId ? (
            <button
              onClick={deleteSelectedElement}
              className="p-1.5 bg-rose-950 border border-rose-600 text-rose-300 hover:bg-rose-800 rounded-xl text-xs font-bold transition flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>حذف</span>
            </button>
          ) : (
            <button
              onClick={handleClearAll}
              className="p-1.5 bg-slate-900 border border-rose-900/60 text-rose-400 hover:bg-rose-950 rounded-xl text-xs font-bold transition"
              title="مسح الكل"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}

        </div>
      )}

    </div>
  );
}
