import { realtimeSync } from '../realtime/realtimeSync';

/**
 * Screen Sharing Service
 * Handles WebRTC peer connection signaling, screen/window/tab stream capture options, and broadcasting.
 */

export const STREAM_TYPES = {
  SCREEN: 'screen',
  WINDOW: 'window',
  TAB: 'tab'
};

export const screenShareService = {
  activeStream: null,
  peerConnections: new Map(),

  /**
   * Request display media stream from browser (entire screen, window, or browser tab)
   */
  async startScreenCapture(streamType = STREAM_TYPES.SCREEN) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
      throw new Error('مشاركة الشاشة غير مدعومة في هذا المتصفح');
    }

    try {
      const displayMediaOptions = {
        video: {
          cursor: 'always',
          displaySurface: streamType === STREAM_TYPES.TAB ? 'browser' : streamType === STREAM_TYPES.WINDOW ? 'window' : 'monitor'
        },
        audio: true
      };

      const stream = await navigator.mediaDevices.getDisplayMedia(displayMediaOptions);
      this.activeStream = stream;

      // Handle user stopping stream via browser UI
      stream.getVideoTracks()[0].onended = () => {
        this.stopScreenShare();
      };

      return {
        success: true,
        stream,
        streamType,
        trackId: stream.getVideoTracks()[0]?.id
      };
    } catch (err) {
      console.error('[screenShareService.startScreenCapture error]:', err);
      throw new Error('تم إلغاء أو رفض إذن مشاركة الشاشة');
    }
  },

  /**
   * Broadcast WebRTC offer signal to live session channel
   */
  async broadcastScreenOffer(sessionId, presenterId, offerSignal) {
    const payload = {
      sessionId,
      presenterId,
      offerSignal,
      timestamp: new Date().toISOString()
    };

    await realtimeSync.sendBroadcast(`session_${sessionId}`, 'SCREEN_SHARE_OFFER', payload);
    return payload;
  },

  /**
   * Broadcast WebRTC answer signal back to presenter
   */
  async sendAnswerSignal(sessionId, presenterId, answerSignal) {
    await realtimeSync.sendBroadcast(`session_${sessionId}`, 'SCREEN_SHARE_ANSWER', {
      presenterId,
      answerSignal
    });
  },

  /**
   * Send WebRTC ICE candidate
   */
  async sendIceCandidate(sessionId, candidate) {
    await realtimeSync.sendBroadcast(`session_${sessionId}`, 'SCREEN_SHARE_ICE', { candidate });
  },

  /**
   * Stop active screen share session
   */
  stopScreenShare(sessionId) {
    if (this.activeStream) {
      this.activeStream.getTracks().forEach(track => track.stop());
      this.activeStream = null;
    }

    if (sessionId) {
      realtimeSync.sendBroadcast(`session_${sessionId}`, 'SCREEN_SHARE_STOPPED', {
        timestamp: new Date().toISOString()
      });
    }

    return { success: true };
  }
};
