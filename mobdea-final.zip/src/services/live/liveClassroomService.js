import { supabase } from '../../lib/supabaseClient';
import { realtimeSync } from '../realtime/realtimeSync';

/**
 * Live Classroom Service
 * Handles creation, management, participant interactions, hand raising, and student controls for live sessions.
 */

export const generateJoinCode = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

export const liveClassroomService = {
  /**
   * Teacher creates a new live classroom session
   */
  async createLiveSession({ title, groupName, teacherId, settings = {} }) {
    if (!title || !teacherId) throw new Error('عنوان الحصة ومعرّف المعلم مطلوبان');

    const joinCode = generateJoinCode();
    const sessionData = {
      teacher_id: teacherId,
      title: title.trim(),
      group_name: groupName || 'مجموعة افتراضية',
      join_code: joinCode,
      status: 'scheduled',
      settings: {
        allow_mic: true,
        allow_chat: true,
        allow_whiteboard: false,
        ...settings
      },
      created_at: new Date().toISOString()
    };

    try {
      const { data, error } = await supabase
        .from('live_sessions')
        .insert([sessionData])
        .select()
        .single();

      if (error) throw new Error(error.message || 'فشل إنشاء الحصة المباشرة');

      return {
        session: data,
        joinCode: data.join_code,
        joinUrl: `${window.location.origin}/live/${data.join_code}`
      };
    } catch (err) {
      console.warn('[liveClassroomService.createLiveSession fallback mode]:', err);
      // Fallback in-memory session if offline
      return {
        session: { id: `session_${Date.now()}`, ...sessionData, status: 'live' },
        joinCode,
        joinUrl: `${window.location.origin}/live/${joinCode}`
      };
    }
  },

  /**
   * Start or End a live classroom session
   */
  async updateSessionStatus(sessionId, status) {
    if (!['live', 'paused', 'ended'].includes(status)) {
      throw new Error('حالة الحصة غير صالحة');
    }

    const updates = {
      status,
      ...(status === 'live' ? { started_at: new Date().toISOString() } : {}),
      ...(status === 'ended' ? { ended_at: new Date().toISOString() } : {})
    };

    try {
      const { data, error } = await supabase
        .from('live_sessions')
        .update(updates)
        .eq('id', sessionId)
        .select()
        .single();

      if (error) console.warn('Supabase session update notice:', error.message);

      // Broadcast session state change to channel
      await realtimeSync.sendBroadcast(`session_${sessionId}`, 'SESSION_STATUS_CHANGED', { status, updates });

      return data || { id: sessionId, ...updates };
    } catch (err) {
      console.error('[liveClassroomService.updateSessionStatus error]:', err);
      await realtimeSync.sendBroadcast(`session_${sessionId}`, 'SESSION_STATUS_CHANGED', { status, updates });
      return { id: sessionId, ...updates };
    }
  },

  /**
   * Student joins a live session by Join Code or Link
   */
  async joinSessionByCode(joinCode, user) {
    if (!joinCode || !user) throw new Error('رمز الدخول ومعلومات الطالب مطلوبة');

    try {
      const { data: session, error } = await supabase
        .from('live_sessions')
        .select('*')
        .eq('join_code', joinCode.trim())
        .single();

      if (error || !session) {
        throw new Error('رمز الحصة غير صحيح أو الحصة غير موجودة');
      }

      if (session.status === 'ended') {
        throw new Error('هذه الحصة المباشرة قد انتهت بالفعل');
      }

      // Add participant entry
      const participant = {
        session_id: session.id,
        user_id: user.id,
        user_name: user.fullName || 'طالب',
        user_role: user.role || 'student',
        joined_at: new Date().toISOString()
      };

      await supabase.from('session_participants').upsert(participant).catch(e => console.warn(e));

      // Subscribe to session channel
      realtimeSync.subscribeChannel(`session_${session.id}`);
      await realtimeSync.trackPresence(`session_${session.id}`, participant);
      await realtimeSync.sendBroadcast(`session_${session.id}`, 'PARTICIPANT_JOINED', participant);

      return { session, participant };
    } catch (err) {
      console.error('[liveClassroomService.joinSessionByCode error]:', err);
      throw err;
    }
  },

  /**
   * Toggle student hand raise state
   */
  async toggleRaiseHand(sessionId, userId, isRaised) {
    try {
      await supabase
        .from('session_participants')
        .update({ hand_raised: isRaised })
        .match({ session_id: sessionId, user_id: userId })
        .catch(e => console.warn(e));

      await realtimeSync.sendBroadcast(`session_${sessionId}`, 'HAND_RAISE_TOGGLED', {
        userId,
        isRaised
      });

      return { userId, isRaised };
    } catch (err) {
      console.error('[liveClassroomService.toggleRaiseHand error]:', err);
      return { userId, isRaised };
    }
  },

  /**
   * Teacher grants or revokes student permissions (Microphone, Whiteboard, Screen Share)
   */
  async grantPermission(sessionId, studentId, permissionType, granted) {
    const validPermissions = ['mic_granted', 'whiteboard_granted', 'screen_share_granted'];
    if (!validPermissions.includes(permissionType)) {
      throw new Error('نوع الصلاحية غير معروف');
    }

    try {
      await supabase
        .from('session_participants')
        .update({ [permissionType]: granted })
        .match({ session_id: sessionId, user_id: studentId })
        .catch(e => console.warn(e));

      await realtimeSync.sendBroadcast(`session_${sessionId}`, 'PERMISSION_UPDATED', {
        studentId,
        permissionType,
        granted
      });

      return { studentId, permissionType, granted };
    } catch (err) {
      console.error('[liveClassroomService.grantPermission error]:', err);
      return { studentId, permissionType, granted };
    }
  },

  /**
   * Send chat message in live classroom
   */
  async sendChatMessage(sessionId, user, text) {
    if (!text || !text.trim()) return null;

    const message = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      sessionId,
      senderId: user.id,
      senderName: user.fullName || 'مشارك',
      senderRole: user.role,
      text: text.trim(),
      timestamp: new Date().toISOString()
    };

    await realtimeSync.sendBroadcast(`session_${sessionId}`, 'CHAT_MESSAGE_RECEIVED', message);
    return message;
  },

  /**
   * Teacher initiates a live challenge between two students during lesson
   */
  async startLiveChallenge(sessionId, student1, student2, challengeQuestion) {
    const challenge = {
      id: `ch_${Date.now()}`,
      sessionId,
      student1,
      student2,
      question: challengeQuestion || 'سؤال التحدي المباشر',
      status: 'active',
      startedAt: new Date().toISOString()
    };

    await realtimeSync.sendBroadcast(`session_${sessionId}`, 'LIVE_CHALLENGE_STARTED', challenge);
    return challenge;
  }
};
