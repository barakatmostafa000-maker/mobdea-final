import { supabase } from '../../lib/supabaseClient';
import { realtimeSync } from '../realtime/realtimeSync';

/**
 * Interactive Synchronized Whiteboard Service
 * Manages vector strokes, shapes, eraser, zoom levels, and real-time canvas state broadcast across all participants.
 */

export const DRAW_TOOLS = {
  PEN: 'pen',
  ERASER: 'eraser',
  LINE: 'line',
  RECTANGLE: 'rectangle',
  CIRCLE: 'circle',
  TEXT: 'text'
};

export const whiteboardService = {
  strokesHistory: [],

  /**
   * Add a new vector stroke or shape to the whiteboard
   */
  async addStroke(sessionId, strokeData, userId) {
    if (!sessionId || !strokeData) return;

    const stroke = {
      id: `stroke_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      tool: strokeData.tool || DRAW_TOOLS.PEN,
      color: strokeData.color || '#3b82f6',
      lineWidth: strokeData.lineWidth || 3,
      points: strokeData.points || [],
      shapeConfig: strokeData.shapeConfig || null,
      text: strokeData.text || '',
      createdBy: userId,
      timestamp: Date.now()
    };

    this.strokesHistory.push(stroke);

    // Broadcast stroke to room in real-time
    await realtimeSync.sendBroadcast(`session_${sessionId}`, 'WHITEBOARD_STROKE_ADDED', stroke);

    // Persist full state to Supabase background
    this.saveWhiteboardState(sessionId, userId).catch(e => console.warn(e));

    return stroke;
  },

  /**
   * Clear full whiteboard canvas for all participants
   */
  async clearCanvas(sessionId, userId) {
    this.strokesHistory = [];

    await realtimeSync.sendBroadcast(`session_${sessionId}`, 'WHITEBOARD_CANVAS_CLEARED', {
      clearedBy: userId,
      timestamp: Date.now()
    });

    await this.saveWhiteboardState(sessionId, userId);
  },

  /**
   * Save current whiteboard canvas state to database
   */
  async saveWhiteboardState(sessionId, userId) {
    try {
      await supabase.from('whiteboard_states').upsert({
        session_id: sessionId,
        strokes: this.strokesHistory,
        updated_by: userId,
        updated_at: new Date().toISOString()
      }, { onConflict: 'session_id' });
    } catch (err) {
      console.warn('[whiteboardService.saveWhiteboardState warning]:', err);
    }
  },

  /**
   * Load existing whiteboard canvas state from database
   */
  async loadWhiteboardState(sessionId) {
    try {
      const { data, error } = await supabase
        .from('whiteboard_states')
        .select('*')
        .eq('session_id', sessionId)
        .single();

      if (error || !data) return [];
      this.strokesHistory = data.strokes || [];
      return this.strokesHistory;
    } catch (err) {
      console.warn('[whiteboardService.loadWhiteboardState warning]:', err);
      return [];
    }
  },

  /**
   * Update viewport zoom or pan scale
   */
  updateZoomAndPan(scale, offsetX, offsetY) {
    return {
      scale: Math.max(0.5, Math.min(scale, 3.0)), // limit zoom between 50% and 300%
      offsetX,
      offsetY
    };
  }
};
