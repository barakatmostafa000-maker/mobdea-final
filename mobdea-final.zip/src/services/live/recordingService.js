import { supabase } from '../../lib/supabaseClient';
import { realtimeSync } from '../realtime/realtimeSync';

/**
 * Session Recording Service
 * Manages Start/Pause/Resume/Stop recording controls, media chunk handlers, metadata, and student recording library.
 */

export const RECORDING_STATES = {
  IDLE: 'idle',
  RECORDING: 'recording',
  PAUSED: 'paused',
  STOPPED: 'stopped'
};

export const recordingService = {
  mediaRecorder: null,
  recordedChunks: [],
  recordingState: RECORDING_STATES.IDLE,
  recordingStartTime: null,

  /**
   * Start recording live session audio/video stream
   */
  async startRecording(sessionId, stream, teacherId) {
    if (!stream) throw new Error('لا يوجد بث مرئي/صوتي متاح للتسجيل');

    this.recordedChunks = [];
    this.recordingStartTime = Date.now();

    try {
      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm';

      this.mediaRecorder = new MediaRecorder(stream, { mimeType });

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          this.recordedChunks.push(event.data);
        }
      };

      this.mediaRecorder.start(1000); // Save chunk every second
      this.recordingState = RECORDING_STATES.RECORDING;

      // Broadcast recording status
      await realtimeSync.sendBroadcast(`session_${sessionId}`, 'RECORDING_STATE_CHANGED', {
        state: RECORDING_STATES.RECORDING,
        startedAt: this.recordingStartTime
      });

      return { success: true, state: RECORDING_STATES.RECORDING };
    } catch (err) {
      console.error('[recordingService.startRecording error]:', err);
      throw new Error('فشل بدء تسجيل الحصة');
    }
  },

  /**
   * Pause current recording
   */
  async pauseRecording(sessionId) {
    if (this.mediaRecorder && this.recordingState === RECORDING_STATES.RECORDING) {
      this.mediaRecorder.pause();
      this.recordingState = RECORDING_STATES.PAUSED;

      await realtimeSync.sendBroadcast(`session_${sessionId}`, 'RECORDING_STATE_CHANGED', {
        state: RECORDING_STATES.PAUSED
      });
    }
    return { state: this.recordingState };
  },

  /**
   * Resume paused recording
   */
  async resumeRecording(sessionId) {
    if (this.mediaRecorder && this.recordingState === RECORDING_STATES.PAUSED) {
      this.mediaRecorder.resume();
      this.recordingState = RECORDING_STATES.RECORDING;

      await realtimeSync.sendBroadcast(`session_${sessionId}`, 'RECORDING_STATE_CHANGED', {
        state: RECORDING_STATES.RECORDING
      });
    }
    return { state: this.recordingState };
  },

  /**
   * Stop recording, process blob video file, and save recording metadata
   */
  async stopRecording(sessionId, sessionTitle, teacherId) {
    if (!this.mediaRecorder) return null;

    return new Promise((resolve) => {
      this.mediaRecorder.onstop = async () => {
        const blob = new Blob(this.recordedChunks, { type: 'video/webm' });
        const durationSeconds = Math.round((Date.now() - (this.recordingStartTime || Date.now())) / 1000);
        const sizeBytes = blob.size;

        this.recordingState = RECORDING_STATES.STOPPED;

        // Generate demo recording file URL / Blob URL for client playback
        const fileUrl = URL.createObjectURL(blob);

        const recordingMetadata = {
          id: `rec_${Date.now()}`,
          sessionId,
          title: sessionTitle || 'تسجيل الحصة المباشرة',
          teacherId,
          fileUrl,
          durationSeconds,
          sizeBytes,
          formattedSize: `${(sizeBytes / (1024 * 1024)).toFixed(1)} ميجابايت`,
          isShared: true,
          createdAt: new Date().toISOString()
        };

        // Save entry to database
        await supabase.from('recordings').insert([{
          session_id: sessionId,
          title: recordingMetadata.title,
          teacher_id: teacherId,
          file_url: fileUrl,
          duration_seconds: durationSeconds,
          size_bytes: sizeBytes,
          is_shared: true
        }]).catch(e => console.warn(e));

        await realtimeSync.sendBroadcast(`session_${sessionId}`, 'RECORDING_STATE_CHANGED', {
          state: RECORDING_STATES.STOPPED,
          recording: recordingMetadata
        });

        resolve(recordingMetadata);
      };

      this.mediaRecorder.stop();
    });
  },

  /**
   * Fetch all saved recordings for students/teachers
   */
  async getRecordingsList(teacherId = null) {
    try {
      let query = supabase.from('recordings').select('*');
      if (teacherId) {
        query = query.eq('teacher_id', teacherId);
      } else {
        query = query.eq('is_shared', true);
      }

      const { data, error } = await query.order('created_at', { ascending: false });
      if (error || !data) return [];
      return data;
    } catch {
      return [];
    }
  },

  /**
   * Delete recording file
   */
  async deleteRecording(recordingId) {
    try {
      await supabase.from('recordings').delete().eq('id', recordingId);
      return { success: true };
    } catch (err) {
      console.error('[recordingService.deleteRecording error]:', err);
      return { success: false };
    }
  },

  /**
   * Toggle recording share visibility with students
   */
  async toggleShareRecording(recordingId, isShared) {
    try {
      await supabase.from('recordings').update({ is_shared: isShared }).eq('id', recordingId);
      return { success: true, isShared };
    } catch (err) {
      console.error('[recordingService.toggleShareRecording error]:', err);
      return { success: false };
    }
  }
};
