/**
 * Centralized Services Export Hub
 * Unifies Auth, Live Classroom, Multiplayer, Realtime, and Game services.
 */

// Auth Services
export { supabase } from '../lib/supabaseClient';
export { authService, validateEmail, validatePassword, validateSignUpInput } from './auth/authService';
export { sessionManager } from './auth/sessionManager';
export { roleManager, ROLES, ROLE_LABELS, ROLE_PERMISSIONS, normalizeRole } from './auth/roleManager';
export { routeGuard, useRouteGuard, DEFAULT_ROLE_HOME } from './auth/routeGuard';

// Live Classroom Services
export { liveClassroomService, generateJoinCode } from './live/liveClassroomService';
export { screenShareService, STREAM_TYPES } from './live/screenShareService';
export { whiteboardService, DRAW_TOOLS } from './live/whiteboardService';
export { recordingService, RECORDING_STATES } from './live/recordingService';

// Multiplayer & Gaming Services
export { gameService, GAME_MODES } from './multiplayer/gameService';
export { inviteService } from './multiplayer/inviteService';
export { teamService } from './multiplayer/teamService';
export { tournamentService, TOURNAMENT_TYPES } from './multiplayer/tournamentService';

// Real-Time Sync Engine
export { realtimeSync } from './realtime/realtimeSync';
