import { supabase } from '../../lib/supabaseClient';

/**
 * Friend Invitation System Service
 * Generates unique shareable codes and links for instant match/game access between students.
 */

export const inviteService = {
  /**
   * Student creates a friend invite code or link for a game room
   */
  async createFriendInvite(roomId, inviterUser) {
    if (!roomId || !inviterUser) throw new Error('معرف الغرفة ومعلومات الداعي مطلوبة');

    const inviteCode = `INV-${Math.floor(1000 + Math.random() * 9000)}`;
    const inviteUrl = `${window.location.origin}/game/join?code=${inviteCode}`;

    const inviteData = {
      room_id: roomId,
      inviter_id: inviterUser.id,
      invite_code: inviteCode,
      is_used: false,
      created_at: new Date().toISOString()
    };

    try {
      await supabase.from('game_invites').insert([inviteData]).catch(e => console.warn(e));

      return {
        inviteCode,
        inviteUrl,
        shareText: `نداء إلى بطل المُبدع! أتحداك في مسابقة دراسية مباشرة 🏆. اضغط الرابط للانضمام فوراً:\n${inviteUrl}`
      };
    } catch (err) {
      console.error('[inviteService.createFriendInvite error]:', err);
      return { inviteCode, inviteUrl, shareText: inviteUrl };
    }
  },

  /**
   * Validate invitation code and return corresponding game room
   */
  async validateInviteCode(inviteCode) {
    if (!inviteCode) throw new Error('كود الدعوة غير محدد');

    try {
      const { data, error } = await supabase
        .from('game_invites')
        .select('*, game_rooms(*)')
        .eq('invite_code', inviteCode.trim())
        .single();

      if (error || !data) {
        throw new Error('كود الدعوة انتهت صلاحيته أو غير صحيح');
      }

      return {
        isValid: true,
        roomId: data.room_id,
        inviterId: data.inviter_id,
        room: data.game_rooms
      };
    } catch (err) {
      console.error('[inviteService.validateInviteCode error]:', err);
      throw err;
    }
  }
};
