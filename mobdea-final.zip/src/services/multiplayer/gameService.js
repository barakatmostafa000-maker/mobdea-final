import { supabase } from '../../lib/supabaseClient';
import { realtimeSync } from '../realtime/realtimeSync';

/**
 * Multiplayer Learning Games Engine
 * Supports Player vs Player (PvP), Player vs AI (PvAI), Team vs Team, and Class vs Class game modes.
 */

export const GAME_MODES = {
  PVP: 'pvp',
  PVAI: 'pvai',
  TEAM_VS_TEAM: 'team_vs_team',
  CLASS_VS_CLASS: 'class_vs_class'
};

export const gameService = {
  /**
   * Create a new multiplayer game room
   */
  async createGameRoom({ mode = GAME_MODES.PVP, hostUser, subjectKey = 'general' }) {
    if (!hostUser) throw new Error('معلومات المنشئ مطلوبة');

    const roomCode = Math.floor(10000 + Math.random() * 90000).toString();
    const roomData = {
      code: roomCode,
      mode,
      status: 'waiting',
      created_by: hostUser.id,
      game_state: {
        host: { id: hostUser.id, name: hostUser.fullName, score: 0 },
        opponent: mode === GAME_MODES.PVAI ? { id: 'ai_bot', name: 'المُبدع الذكي 🤖', score: 0 } : null,
        currentTurn: hostUser.id,
        currentQuestionIndex: 0,
        scores: {},
        subjectKey
      },
      created_at: new Date().toISOString()
    };

    try {
      const { data, error } = await supabase
        .from('game_rooms')
        .insert([roomData])
        .select()
        .single();

      if (error) console.warn('Supabase game_room insert notice:', error.message);

      const createdRoom = data || { id: `room_${Date.now()}`, ...roomData };

      // Subscribe host to real-time game room channel
      realtimeSync.subscribeChannel(`game_${createdRoom.code}`);
      await realtimeSync.trackPresence(`game_${createdRoom.code}`, {
        userId: hostUser.id,
        userName: hostUser.fullName,
        role: 'host'
      });

      return createdRoom;
    } catch (err) {
      console.error('[gameService.createGameRoom error]:', err);
      return { id: `room_${Date.now()}`, ...roomData };
    }
  },

  /**
   * Join an existing multiplayer game room using Room Code
   */
  async joinGameRoom(roomCode, participantUser) {
    if (!roomCode || !participantUser) throw new Error('كود الغرفة ومعلومات اللاعب مطلوبة');

    try {
      const { data: room, error } = await supabase
        .from('game_rooms')
        .select('*')
        .eq('code', roomCode.trim())
        .single();

      if (error || !room) {
        throw new Error('غرفة اللعبة غير موجودة أو الكود غير صحيح');
      }

      const updatedGameState = {
        ...room.game_state,
        opponent: { id: participantUser.id, name: participantUser.fullName, score: 0 }
      };

      await supabase
        .from('game_rooms')
        .update({ status: 'active', game_state: updatedGameState })
        .eq('id', room.id)
        .catch(e => console.warn(e));

      // Subscribe to real-time room channel
      realtimeSync.subscribeChannel(`game_${roomCode}`);
      await realtimeSync.trackPresence(`game_${roomCode}`, {
        userId: participantUser.id,
        userName: participantUser.fullName,
        role: 'opponent'
      });

      await realtimeSync.sendBroadcast(`game_${roomCode}`, 'PLAYER_JOINED_GAME', {
        player: participantUser,
        updatedGameState
      });

      return { room, gameState: updatedGameState };
    } catch (err) {
      console.error('[gameService.joinGameRoom error]:', err);
      throw err;
    }
  },

  /**
   * Submit an answer in game room and update score
   */
  async submitAnswer(roomCode, userId, questionId, selectedOption, isCorrect) {
    const pointsToAdd = isCorrect ? 10 : 0;

    const payload = {
      userId,
      questionId,
      selectedOption,
      isCorrect,
      pointsToAdd,
      timestamp: Date.now()
    };

    await realtimeSync.sendBroadcast(`game_${roomCode}`, 'GAME_ANSWER_SUBMITTED', payload);

    return payload;
  },

  /**
   * Simulate AI Turn response for Player vs AI mode
   */
  async triggerAiTurn(roomCode, question) {
    const isAiCorrect = Math.random() > 0.3; // 70% AI accuracy
    const aiAnswer = {
      userId: 'ai_bot',
      userName: 'المُبدع الذكي 🤖',
      isCorrect: isAiCorrect,
      pointsToAdd: isAiCorrect ? 10 : 0,
      timestamp: Date.now()
    };

    // Simulate thinking delay
    setTimeout(async () => {
      await realtimeSync.sendBroadcast(`game_${roomCode}`, 'GAME_ANSWER_SUBMITTED', aiAnswer);
    }, 1500);

    return aiAnswer;
  }
};
