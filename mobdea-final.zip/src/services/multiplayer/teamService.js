import { supabase } from '../../lib/supabaseClient';

/**
 * Team System Service
 * Handles team creation, member management, team points, and team vs team match organization.
 */

export const teamService = {
  /**
   * Teacher creates a new student team
   */
  async createTeam(teamName, creatorId, logoUrl = null) {
    if (!teamName || !creatorId) throw new Error('اسم الفريق ومعرف المنشئ مطلوبان');

    const teamData = {
      name: teamName.trim(),
      created_by: creatorId,
      logo_url: logoUrl,
      points: 0,
      created_at: new Date().toISOString()
    };

    try {
      const { data, error } = await supabase
        .from('teams')
        .insert([teamData])
        .select()
        .single();

      if (error) throw new Error(error.message || 'فشل إنشاء الفريق');
      return data;
    } catch (err) {
      console.warn('[teamService.createTeam fallback]:', err);
      return { id: `team_${Date.now()}`, ...teamData };
    }
  },

  /**
   * Add a student to a team
   */
  async addStudentToTeam(teamId, studentId, role = 'member') {
    try {
      const { data, error } = await supabase
        .from('team_members')
        .insert([{ team_id: teamId, student_id: studentId, role }])
        .select()
        .single();

      if (error) console.warn('Supabase add student to team notice:', error.message);
      return data || { teamId, studentId, role };
    } catch (err) {
      console.error('[teamService.addStudentToTeam error]:', err);
      return { teamId, studentId, role };
    }
  },

  /**
   * Remove student from team
   */
  async removeStudentFromTeam(teamId, studentId) {
    try {
      await supabase
        .from('team_members')
        .delete()
        .match({ team_id: teamId, student_id: studentId });

      return { success: true };
    } catch (err) {
      console.error('[teamService.removeStudentFromTeam error]:', err);
      return { success: false };
    }
  },

  /**
   * Get team details with members
   */
  async getTeamWithMembers(teamId) {
    try {
      const { data: team, error } = await supabase
        .from('teams')
        .select('*, team_members(*)')
        .eq('id', teamId)
        .single();

      if (error || !team) return null;
      return team;
    } catch {
      return null;
    }
  },

  /**
   * Fetch all teams ordered by points (Team Leaderboard)
   */
  async getTeamsLeaderboard() {
    try {
      const { data, error } = await supabase
        .from('teams')
        .select('*')
        .order('points', { ascending: false });

      if (error || !data) return [];
      return data;
    } catch {
      return [];
    }
  },

  /**
   * Award points to a team
   */
  async addPointsToTeam(teamId, points) {
    try {
      const { data: team } = await supabase.from('teams').select('points').eq('id', teamId).single();
      const currentPoints = team ? team.points || 0 : 0;
      const newPoints = currentPoints + points;

      await supabase.from('teams').update({ points: newPoints }).eq('id', teamId);
      return { teamId, newPoints };
    } catch (err) {
      console.error('[teamService.addPointsToTeam error]:', err);
      return { teamId, points };
    }
  }
};
