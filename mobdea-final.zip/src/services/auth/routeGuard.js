import { useMemo } from 'react';
import { roleManager, ROLES, normalizeRole } from './roleManager';

/**
 * Route Protection & Role Guard Service
 * Enforces route and tab level access control depending on user roles.
 */

export const DEFAULT_ROLE_HOME = {
  [ROLES.ADMIN]: 'dashboard',
  [ROLES.TEACHER]: 'dashboard',
  [ROLES.STUDENT]: 'dashboard',
  [ROLES.PARENT]: 'dashboard'
};

export const routeGuard = {
  /**
   * Evaluates if a given role is allowed to view a specific target route/tab
   */
  canAccessRoute(role, targetRoute) {
    if (!targetRoute) return true;
    return roleManager.hasPermission(role, targetRoute);
  },

  /**
   * Returns default home destination route for a given user role
   */
  getDefaultRouteForRole(role) {
    const validRole = normalizeRole(role);
    return DEFAULT_ROLE_HOME[validRole] || 'dashboard';
  },

  /**
   * Filters an array of sidebar or menu navigation items according to user role permissions
   */
  filterMenuItems(menuItems = [], userRole) {
    if (!Array.isArray(menuItems)) return [];
    return menuItems.filter(item => {
      if (!item || !item.id) return true;
      return this.canAccessRoute(userRole, item.id);
    });
  },

  /**
   * Validates target navigation route and returns redirect route if unauthorized
   */
  verifyNavigation(userRole, targetRoute) {
    const isAllowed = this.canAccessRoute(userRole, targetRoute);
    if (isAllowed) {
      return { allowed: true, targetRoute };
    }
    const fallbackRoute = this.getDefaultRouteForRole(userRole);
    return {
      allowed: false,
      redirectRoute: fallbackRoute,
      reason: `عذراً، حسالك كـ (${roleManager.getRoleLabel(userRole)}) لا يملك صلاحية الوصول إلى هذه الصفحة`
    };
  }
};

/**
 * Custom React Hook for Route Guarding
 * Usage: const { isAllowed, redirectRoute, allowedRoutes } = useRouteGuard(currentUser, activeTab);
 */
export const useRouteGuard = (user, currentRoute) => {
  return useMemo(() => {
    const userRole = user ? normalizeRole(user.role) : ROLES.STUDENT;
    const allowed = routeGuard.canAccessRoute(userRole, currentRoute);
    const redirectRoute = allowed ? null : routeGuard.getDefaultRouteForRole(userRole);
    const allowedRoutes = roleManager.getAllowedRoutes(userRole);

    return {
      isAllowed: allowed,
      redirectRoute,
      allowedRoutes,
      userRole,
      roleLabel: roleManager.getRoleLabel(userRole)
    };
  }, [user, currentRoute]);
};
