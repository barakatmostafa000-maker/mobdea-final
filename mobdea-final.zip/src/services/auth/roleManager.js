/**
 * Role Manager
 * Handles user roles definition, normalization, and permission mapping across the application.
 */

export const ROLES = {
  ADMIN: 'admin',
  TEACHER: 'teacher',
  STUDENT: 'student',
  PARENT: 'parent'
};

export const ROLE_LABELS = {
  [ROLES.ADMIN]: 'مدير النظام (Admin)',
  [ROLES.TEACHER]: 'معلم / أستاذ (Teacher)',
  [ROLES.STUDENT]: 'طالب (Student)',
  [ROLES.PARENT]: 'ولي أمر (Parent)'
};

/**
 * Normalizes role input strings to valid role constants
 */
export const normalizeRole = (roleInput) => {
  if (!roleInput || typeof roleInput !== 'string') return ROLES.STUDENT;
  const cleaned = roleInput.trim().toLowerCase();
  if (Object.values(ROLES).includes(cleaned)) {
    return cleaned;
  }
  return ROLES.STUDENT;
};

/**
 * Permissions matrix defining route/tab access per role
 */
export const ROLE_PERMISSIONS = {
  [ROLES.ADMIN]: [
    'dashboard',
    'classMode',
    'students',
    'studentCards',
    'sessions',
    'attendance',
    'grades',
    'scanner',
    'questionBank',
    'games',
    'mapChallenge',
    'payments',
    'messages',
    'smartAssistant',
    'settings'
  ],
  [ROLES.TEACHER]: [
    'dashboard',
    'classMode',
    'students',
    'studentCards',
    'sessions',
    'attendance',
    'grades',
    'scanner',
    'questionBank',
    'games',
    'mapChallenge',
    'messages',
    'smartAssistant'
  ],
  [ROLES.STUDENT]: [
    'dashboard',
    'studentCards',
    'questionBank',
    'games',
    'mapChallenge',
    'grades'
  ],
  [ROLES.PARENT]: [
    'dashboard',
    'attendance',
    'grades',
    'payments',
    'messages'
  ]
};

/**
 * Role Manager Utilities
 */
export const roleManager = {
  ROLES,
  ROLE_LABELS,

  /**
   * Get all allowed routes/tabs for a user role
   */
  getAllowedRoutes(role) {
    const validRole = normalizeRole(role);
    return ROLE_PERMISSIONS[validRole] || ROLE_PERMISSIONS[ROLES.STUDENT];
  },

  /**
   * Check if a role has access to a specific route/tab
   */
  hasPermission(role, route) {
    if (!route) return true;
    const allowed = this.getAllowedRoutes(role);
    return allowed.includes(route);
  },

  /**
   * Check if role is admin
   */
  isAdmin(role) {
    return normalizeRole(role) === ROLES.ADMIN;
  },

  /**
   * Check if role is teacher
   */
  isTeacher(role) {
    return normalizeRole(role) === ROLES.TEACHER;
  },

  /**
   * Check if role is student
   */
  isStudent(role) {
    return normalizeRole(role) === ROLES.STUDENT;
  },

  /**
   * Check if role is parent
   */
  isParent(role) {
    return normalizeRole(role) === ROLES.PARENT;
  },

  /**
   * Returns localized role title
   */
  getRoleLabel(role) {
    const validRole = normalizeRole(role);
    return ROLE_LABELS[validRole] || 'طالب';
  }
};
