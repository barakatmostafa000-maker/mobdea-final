import { supabase } from '../../lib/supabaseClient';
import { normalizeRole, ROLES } from './roleManager';

const STORAGE_KEYS = {
  USER_DATA: 'mobdea_user_profile',
  SESSION_DATA: 'mobdea_session_data',
  LAST_LOGIN: 'mobdea_last_login'
};

let inMemorySession = null;
let inMemoryUser = null;

export const sessionManager = {
  /**
   * Save session and user profile data securely to persistent storage and memory
   */
  saveSession(user, session) {
    try {
      inMemoryUser = user;
      inMemorySession = session;

      if (user) {
        localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(user));
      }
      if (session) {
        localStorage.setItem(STORAGE_KEYS.SESSION_DATA, JSON.stringify({
          access_token: session.access_token,
          refresh_token: session.refresh_token,
          expires_at: session.expires_at || Date.now() + 3600 * 1000
        }));
      }
      localStorage.setItem(STORAGE_KEYS.LAST_LOGIN, new Date().toISOString());
    } catch (err) {
      console.warn('[SessionManager.saveSession warning]:', err);
    }
  },

  /**
   * Retrieve stored user profile and session data
   */
  getStoredSession() {
    try {
      if (inMemoryUser && inMemorySession) {
        return { user: inMemoryUser, session: inMemorySession };
      }

      const rawUser = localStorage.getItem(STORAGE_KEYS.USER_DATA);
      const rawSession = localStorage.getItem(STORAGE_KEYS.SESSION_DATA);

      if (!rawUser) return null;

      const user = JSON.parse(rawUser);
      const session = rawSession ? JSON.parse(rawSession) : null;

      // Ensure normalized user structure
      user.role = normalizeRole(user.role);

      inMemoryUser = user;
      inMemorySession = session;

      return { user, session };
    } catch (err) {
      console.error('[SessionManager.getStoredSession error]:', err);
      return null;
    }
  },

  /**
   * Clear all stored session information
   */
  clearSession() {
    inMemoryUser = null;
    inMemorySession = null;
    try {
      localStorage.removeItem(STORAGE_KEYS.USER_DATA);
      localStorage.removeItem(STORAGE_KEYS.SESSION_DATA);
      localStorage.removeItem(STORAGE_KEYS.LAST_LOGIN);
      localStorage.removeItem('mobdea_auth_token');
    } catch (err) {
      console.warn('[SessionManager.clearSession warning]:', err);
    }
  },

  /**
   * Auto-login initialization hook
   * Checks Supabase active auth session or local storage and triggers auto-login callback
   */
  async initAutoLogin(onSuccess, onError) {
    try {
      // First check active Supabase session
      const { data: { session }, error } = await supabase.auth.getSession();

      if (error) {
        console.warn('[SessionManager.initAutoLogin Supabase session notice]:', error.message);
      }

      if (session && session.user) {
        const userRole = normalizeRole(
          session.user.user_metadata?.role || session.user.app_metadata?.role || ROLES.STUDENT
        );

        const authenticatedUser = {
          id: session.user.id,
          email: session.user.email,
          fullName: session.user.user_metadata?.full_name || 'مستخدم المنصة',
          role: userRole,
          phone: session.user.user_metadata?.phone || ''
        };

        this.saveSession(authenticatedUser, session);
        if (onSuccess) onSuccess(authenticatedUser, session);
        return { isAuthenticated: true, user: authenticatedUser, session };
      }

      // Fallback check stored local session
      const stored = this.getStoredSession();
      if (stored && stored.user) {
        if (onSuccess) onSuccess(stored.user, stored.session);
        return { isAuthenticated: true, user: stored.user, session: stored.session };
      }

      if (onError) onError(new Error('لا توجد جلسة نشطة متوفرة'));
      return { isAuthenticated: false, user: null, session: null };
    } catch (err) {
      console.error('[SessionManager.initAutoLogin error]:', err);
      if (onError) onError(err);
      return { isAuthenticated: false, user: null, session: null };
    }
  },

  /**
   * Subscribe to Supabase auth state changes for real-time auto sync
   */
  subscribeToAuthChanges(onAuthChange) {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        const userRole = normalizeRole(
          session.user.user_metadata?.role || session.user.app_metadata?.role || ROLES.STUDENT
        );
        const user = {
          id: session.user.id,
          email: session.user.email,
          fullName: session.user.user_metadata?.full_name || 'مستخدم المنصة',
          role: userRole,
          phone: session.user.user_metadata?.phone || ''
        };
        this.saveSession(user, session);
        if (onAuthChange) onAuthChange('SIGNED_IN', user, session);
      } else if (event === 'SIGNED_OUT') {
        this.clearSession();
        if (onAuthChange) onAuthChange('SIGNED_OUT', null, null);
      } else if (event === 'TOKEN_REFRESHED' && session) {
        const stored = this.getStoredSession();
        if (stored?.user) {
          this.saveSession(stored.user, session);
          if (onAuthChange) onAuthChange('TOKEN_REFRESHED', stored.user, session);
        }
      }
    });

    return () => {
      subscription?.unsubscribe();
    };
  }
};
