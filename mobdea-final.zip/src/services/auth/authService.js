import { supabase } from '../../lib/supabaseClient';
import { ROLES, normalizeRole } from './roleManager';

/**
 * Input validation helpers
 */
export const validateEmail = (email) => {
  if (!email || typeof email !== 'string') return { isValid: false, message: 'البريد الإلكتروني مطلوب' };
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email.trim())) {
    return { isValid: false, message: 'يرجى إدخال بريد إلكتروني صحيح' };
  }
  return { isValid: true, message: '' };
};

export const validatePassword = (password) => {
  if (!password || typeof password !== 'string') return { isValid: false, message: 'كلمة المرور مطلوبة' };
  if (password.length < 6) {
    return { isValid: false, message: 'كلمة المرور يجب أن لا تقل عن 6 أحرف' };
  }
  return { isValid: true, message: '' };
};

export const validateSignUpInput = ({ email, password, fullName, role }) => {
  const emailVal = validateEmail(email);
  if (!emailVal.isValid) return emailVal;

  const passVal = validatePassword(password);
  if (!passVal.isValid) return passVal;

  if (!fullName || fullName.trim().length < 2) {
    return { isValid: false, message: 'الاسم الكامل مطلوب ويجب أن يتكون من حرفين على الأقل' };
  }

  if (role && !Object.values(ROLES).includes(role.toLowerCase())) {
    return { isValid: false, message: 'نوع الحساب المحدد غير صالح' };
  }

  return { isValid: true, message: '' };
};

/**
 * Authentication Service
 * Clean Architecture service layer for handling login, registration, password resets, and user profile management.
 */
export const authService = {
  /**
   * Log in user with email and password
   */
  async login({ email, password }) {
    const emailVal = validateEmail(email);
    if (!emailVal.isValid) throw new Error(emailVal.message);

    const passVal = validatePassword(password);
    if (!passVal.isValid) throw new Error(passVal.message);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password
      });

      if (error) {
        // Handle standard Supabase error messages in Arabic
        if (error.message.includes('Invalid login credentials')) {
          throw new Error('البريد الإلكتروني أو كلمة المرور غير صحيحة');
        }
        if (error.message.includes('Email not confirmed')) {
          throw new Error('يرجى تأكيد البريد الإلكتروني أولاً');
        }
        throw new Error(error.message || 'حدث خطأ أثناء تسجيل الدخول');
      }

      const user = data?.user;
      if (!user) throw new Error('تعذر جلب بيانات المستخدم');

      // Resolve user role from user_metadata or profiles table
      const userRole = normalizeRole(
        user.user_metadata?.role || user.app_metadata?.role || ROLES.STUDENT
      );

      const profile = await this.fetchUserProfile(user.id, userRole);

      return {
        user: {
          id: user.id,
          email: user.email,
          fullName: user.user_metadata?.full_name || profile?.full_name || 'مستخدم المنصة',
          role: userRole,
          phone: user.user_metadata?.phone || profile?.phone || '',
          avatarUrl: user.user_metadata?.avatar_url || null
        },
        session: data.session
      };
    } catch (err) {
      console.error('[AuthService.login error]:', err);
      throw err;
    }
  },

  /**
   * Register a new user with role
   */
  async signUp({ email, password, fullName, role = ROLES.STUDENT, phone = '' }) {
    const validation = validateSignUpInput({ email, password, fullName, role });
    if (!validation.isValid) throw new Error(validation.message);

    const targetRole = normalizeRole(role);

    try {
      const { data, error } = await supabase.auth.signUp({
        email: email.trim().toLowerCase(),
        password,
        options: {
          data: {
            full_name: fullName.trim(),
            role: targetRole,
            phone: phone.trim()
          }
        }
      });

      if (error) {
        if (error.message.includes('User already registered')) {
          throw new Error('هذا البريد الإلكتروني مُسجل بالفعل');
        }
        throw new Error(error.message || 'فشل إنشاء الحساب الجديد');
      }

      const user = data?.user;
      if (user) {
        // Create matching entry in public 'profiles' table
        await supabase.from('profiles').upsert({
          id: user.id,
          email: user.email,
          full_name: fullName.trim(),
          role: targetRole,
          phone: phone.trim(),
          updated_at: new Date().toISOString()
        }).catch(e => console.warn('Profile table insert notice:', e));
      }

      return {
        user: user ? {
          id: user.id,
          email: user.email,
          fullName: fullName.trim(),
          role: targetRole,
          phone: phone.trim()
        } : null,
        session: data?.session,
        needsEmailConfirmation: !data?.session
      };
    } catch (err) {
      console.error('[AuthService.signUp error]:', err);
      throw err;
    }
  },

  /**
   * Send password reset email
   */
  async resetPassword(email) {
    const emailVal = validateEmail(email);
    if (!emailVal.isValid) throw new Error(emailVal.message);

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email.trim().toLowerCase(), {
        redirectTo: `${window.location.origin}/reset-password`
      });

      if (error) {
        throw new Error(error.message || 'فشل إرسال رابط إعادة ضبط كلمة المرور');
      }

      return { success: true, message: 'تم إرسال رابط إعادة ضبط كلمة المرور إلى بريدك الإلكتروني' };
    } catch (err) {
      console.error('[AuthService.resetPassword error]:', err);
      throw err;
    }
  },

  /**
   * Update current authenticated user password
   */
  async updatePassword(newPassword) {
    const passVal = validatePassword(newPassword);
    if (!passVal.isValid) throw new Error(passVal.message);

    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw new Error(error.message || 'فشل تحديث كلمة المرور');
      return { success: true, message: 'تم تحديث كلمة المرور بنجاح' };
    } catch (err) {
      console.error('[AuthService.updatePassword error]:', err);
      throw err;
    }
  },

  /**
   * Log out active user
   */
  async logout() {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) console.warn('Supabase signOut warning:', error.message);
      return { success: true };
    } catch (err) {
      console.error('[AuthService.logout error]:', err);
      return { success: true }; // Force clean exit on client
    }
  },

  /**
   * Fetch user details from 'profiles' table if available
   */
  async fetchUserProfile(userId, fallbackRole = ROLES.STUDENT) {
    if (!userId) return null;
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error || !data) return { role: fallbackRole };
      return data;
    } catch {
      return { role: fallbackRole };
    }
  },

  /**
   * Get current active session user
   */
  async getCurrentUser() {
    try {
      const { data: { user }, error } = await supabase.auth.getUser();
      if (error || !user) return null;

      const userRole = normalizeRole(
        user.user_metadata?.role || user.app_metadata?.role || ROLES.STUDENT
      );

      return {
        id: user.id,
        email: user.email,
        fullName: user.user_metadata?.full_name || 'مستخدم المنصة',
        role: userRole,
        phone: user.user_metadata?.phone || ''
      };
    } catch {
      return null;
    }
  }
};
