/**
 * Unified Authentication Module Export
 * Exposes authService, sessionManager, roleManager, and routeGuard services.
 */

export { supabase } from '../../lib/supabaseClient';
export { authService, validateEmail, validatePassword, validateSignUpInput } from './authService';
export { sessionManager } from './sessionManager';
export { roleManager, ROLES, ROLE_LABELS, ROLE_PERMISSIONS, normalizeRole } from './roleManager';
export { routeGuard, useRouteGuard, DEFAULT_ROLE_HOME } from './routeGuard';
