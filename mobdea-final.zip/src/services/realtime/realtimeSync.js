import { supabase } from '../../lib/supabaseClient';

/**
 * Realtime Synchronization Engine
 * Manages Supabase Realtime channels, presence tracking, WebRTC signaling, and custom event broadcasts.
 */

class RealtimeSyncManager {
  constructor() {
    this.channels = new Map();
  }

  /**
   * Join or subscribe to a real-time channel (e.g. live classroom or game room)
   */
  subscribeChannel(channelName, onBroadcastCallback, onPresenceCallback) {
    if (this.channels.has(channelName)) {
      return this.channels.get(channelName);
    }

    const channel = supabase.channel(channelName, {
      config: {
        broadcast: { self: false },
        presence: { key: '' }
      }
    });

    // Listen to custom broadcast events
    channel.on('broadcast', { event: '*' }, (payload) => {
      if (onBroadcastCallback) {
        onBroadcastCallback(payload.event, payload.payload);
      }
    });

    // Listen to presence state changes
    channel.on('presence', { event: 'sync' }, () => {
      const presenceState = channel.presenceState();
      if (onPresenceCallback) {
        onPresenceCallback('sync', presenceState);
      }
    });

    channel.on('presence', { event: 'join' }, ({ key, newPresences }) => {
      if (onPresenceCallback) {
        onPresenceCallback('join', { key, newPresences });
      }
    });

    channel.on('presence', { event: 'leave' }, ({ key, leftPresences }) => {
      if (onPresenceCallback) {
        onPresenceCallback('leave', { key, leftPresences });
      }
    });

    channel.subscribe((status) => {
      console.log(`[RealtimeSync] Channel '${channelName}' status:`, status);
    });

    this.channels.set(channelName, channel);
    return channel;
  }

  /**
   * Track user presence in a live session
   */
  async trackPresence(channelName, userInfo) {
    const channel = this.channels.get(channelName);
    if (!channel) throw new Error(`Channel '${channelName}' is not subscribed.`);
    return await channel.track(userInfo);
  }

  /**
   * Broadcast a custom event to all participants in a channel
   */
  async sendBroadcast(channelName, event, payload) {
    const channel = this.channels.get(channelName);
    if (!channel) throw new Error(`Channel '${channelName}' is not active.`);
    return await channel.send({
      type: 'broadcast',
      event,
      payload
    });
  }

  /**
   * Leave and unsubscribe from a channel
   */
  async unsubscribeChannel(channelName) {
    const channel = this.channels.get(channelName);
    if (channel) {
      await supabase.removeChannel(channel);
      this.channels.delete(channelName);
      console.log(`[RealtimeSync] Unsubscribed from channel: ${channelName}`);
    }
  }

  /**
   * Clean up all active real-time channels
   */
  async unsubscribeAll() {
    for (const [name, channel] of this.channels.entries()) {
      await supabase.removeChannel(channel);
    }
    this.channels.clear();
  }
}

export const realtimeSync = new RealtimeSyncManager();
