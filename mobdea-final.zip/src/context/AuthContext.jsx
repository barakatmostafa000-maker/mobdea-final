import React, { createContext, useContext, useState, useEffect } from 'react';
import { authService } from '../services/auth/authService';
import { sessionManager } from '../services/auth/sessionManager';
import { roleManager, ROLES } from '../services/auth/roleManager';
import { routeGuard } from '../services/auth/routeGuard';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState(null);

  // Initialize session and auto-login
  useEffect(() => {
    let unsubscribeAuthListener;

    const initializeAuth = async () => {
      setLoading(true);
      try {
        await sessionManager.initAutoLogin(
          (authenticatedUser, activeSession) => {
            setUser(authenticatedUser);
            setSession(activeSession);
            setAuthError(null);
          },
          () => {
            setUser(null);
            setSession(null);
          }
        );

        unsubscribeAuthListener = sessionManager.subscribeToAuthChanges((event, updatedUser, updatedSession) => {
          if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
            setUser(updatedUser);
            setSession(updatedSession);
            setAuthError(null);
          } else if (event === 'SIGNED_OUT') {
            setUser(null);
            setSession(null);
          }
        });
      } catch (err) {
        console.error('[AuthProvider initAuth error]:', err);
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();

    return () => {
      if (unsubscribeAuthListener) unsubscribeAuthListener();
    };
  }, []);

  const login = async ({ email, password }) => {
    setLoading(true);
    setAuthError(null);
    try {
      const result = await authService.login({ email, password });
      setUser(result.user);
      setSession(result.session);
      sessionManager.saveSession(result.user, result.session);
      return result;
    } catch (err) {
      setAuthError(err.message || 'فشل تسجيل الدخول');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const signUp = async ({ email, password, fullName, role, phone }) => {
    setLoading(true);
    setAuthError(null);
    try {
      const result = await authService.signUp({ email, password, fullName, role, phone });
      if (result.user && result.session) {
        setUser(result.user);
        setSession(result.session);
        sessionManager.saveSession(result.user, result.session);
      }
      return result;
    } catch (err) {
      setAuthError(err.message || 'فشل إنشاء الحساب');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    setLoading(true);
    try {
      await authService.logout();
      sessionManager.clearSession();
      setUser(null);
      setSession(null);
      setAuthError(null);
    } catch (err) {
      console.error('[AuthProvider logout error]:', err);
    } finally {
      setLoading(false);
    }
  };

  const resetPassword = async (email) => {
    return await authService.resetPassword(email);
  };

  const value = {
    user,
    session,
    loading,
    authError,
    isAuthenticated: !!user,
    userRole: user ? user.role : ROLES.STUDENT,
    login,
    signUp,
    logout,
    resetPassword,
    canAccessRoute: (route) => routeGuard.canAccessRoute(user ? user.role : ROLES.STUDENT, route),
    getRoleLabel: () => roleManager.getRoleLabel(user ? user.role : ROLES.STUDENT)
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
