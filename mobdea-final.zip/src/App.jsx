import React, { useState, useEffect } from 'react';
import {
  Users, UserPlus, QrCode, BookOpen, CheckSquare, Award, Camera, 
  HelpCircle, Trophy, MapPin, CreditCard, BarChart2, MessageSquare, 
  Sparkles, Folder, Settings, Lock, Play, Search, Plus, Trash2, Edit, 
  Phone, Send, RefreshCw, CheckCircle2, XCircle, AlertCircle, Eye, 
  Volume2, ChevronRight, Menu, X, Shield, DollarSign, Calendar, LogOut
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

import TopHistoricalHeader from './components/TopHistoricalHeader';
import HistoricalWhiteboard from './components/HistoricalWhiteboard';
import StudentsPanel from './components/StudentsPanel';
import LessonResourcesBar from './components/LessonResourcesBar';
import DashboardHomepage from './components/DashboardHomepage';
import LoginPage from './components/LoginPage';
import MapChallengeMain from './components/MapChallenge/MapChallengeMain';
import ClassroomTeachingHub from './components/TeachingSystem/ClassroomTeachingHub';
import { useAuth } from './context/AuthContext';

// Initial Mock Data
const INITIAL_LESSONS = [
  {
    id: 1,
    grade: "الصف الأول الإعدادي",
    subject: "الدراسات الاجتماعية والتاريخ",
    lessonName: "الدرس: مفهوم الدولة وعناصرها"
  },
  {
    id: 2,
    grade: "الصف السادس الابتدائي",
    subject: "الدراسات الاجتماعية",
    lessonName: "الدرس: موقع الوطن العربي وأهميته"
  },
  {
    id: 3,
    grade: "الصف الخامس الابتدائي",
    subject: "الدراسات الاجتماعية",
    lessonName: "الدرس: موقع مصر الجغرافي والفلكي"
  }
];

const INITIAL_STUDENTS = [
  { id: 1, code: 101, name: "عمر أحمد محمود", grade: "الصف السادس الابتدائي", group: "مجموعة 5 مساءً", guardianPhone: "01012345678", sessionPrice: 50, points: 120 },
  { id: 2, code: 102, name: "فاطمة محمد علي", grade: "الصف السادس الابتدائي", group: "مجموعة 5 مساءً", guardianPhone: "01123456789", sessionPrice: 50, points: 150 },
  { id: 3, code: 103, name: "يوسف إبراهيم حسن", grade: "الصف الخامس الابتدائي", group: "مجموعة 4 عصراً", guardianPhone: "01234567890", sessionPrice: 45, points: 90 },
  { id: 4, code: 104, name: "مريم خالد عبد الرحمن", grade: "الصف الرابع الابتدائي", group: "مجموعة 3 عصراً", guardianPhone: "01543210987", sessionPrice: 40, points: 180 },
  { id: 5, code: 105, name: "عبد الله طارق السيد", grade: "الصف الأول الإعدادي", group: "مجموعة 6 مساءً", guardianPhone: "01098765432", sessionPrice: 60, points: 110 }
];

const INITIAL_SESSIONS = [
  { id: 1, title: "الصف السادس الابتدائي", group: "مجموعة 5 مساءً", day: "الأربعاء", time: "17:00", price: 50, current: true },
  { id: 2, title: "الصف الخامس الابتدائي", group: "مجموعة 4 عصراً", day: "الأحد", time: "16:00", price: 45, current: false },
  { id: 3, title: "الصف الأول الإعدادي", group: "مجموعة 6 مساءً", day: "السبت", time: "18:00", price: 60, current: false }
];

const INITIAL_QUESTIONS = [
  { id: "q1", gradeKey: "6", grade: "الصف السادس الابتدائي", unit: "الوحدة الأولى", lesson: "موقع الوطن العربي", type: "mcq", text: "تقع دولة جزر القمر في المحيط ... جنوب دائرة الاستواء؟", options: ["الأطلسي", "الهندي", "الهادي", "القطبي"], answerIndex: 1, answer: "الهندي", clues: ["محيط يقع شرق إفريقيا"] },
  { id: "q2", gradeKey: "6", grade: "الصف السادس الابتدائي", unit: "الوحدة الأولى", lesson: "موقع الوطن العربي", type: "mcq", text: "يحد الوطن العربي شمالاً البحر المتوسط وجبال ...؟", options: ["زاجروس", "توروس", "أطلس", "الهيمالايا"], answerIndex: 1, answer: "توروس", clues: ["جبال في شمال الشام وتركيا"] },
  { id: "q3", gradeKey: "5", grade: "الصف الخامس الابتدائي", unit: "الوحدة الأولى", lesson: "موقع مصر", type: "mcq", text: "يمر مدار السرطان في ... مصر؟", options: ["شمال", "جنوب", "شرق", "غرب"], answerIndex: 1, answer: "جنوب", clues: ["بالقرب من أسوان"] }
];

const INITIAL_GRADES = [
  { id: 1, studentId: 1, exam: "اختبار الوحدة الأولى", score: 18, total: 20, date: "2026-07-20", strength: "المفاهيم والتضاريس", weakness: "التواريخ" },
  { id: 2, studentId: 2, exam: "اختبار الوحدة الأولى", score: 20, total: 20, date: "2026-07-20", strength: "ممتازة في كل الأسئلة", weakness: "لا يوجد" },
  { id: 3, studentId: 4, exam: "اختبار مراجعة بدايه الترم", score: 19, total: 20, date: "2026-07-22", strength: "قراءة الخرائط", weakness: "التركيز الدقيق" }
];

const INITIAL_PAYMENTS = [
  { id: 1, studentId: 1, amount: 50, period: "حصة أربعاء", date: "2026-07-24" },
  { id: 2, studentId: 2, amount: 200, period: "اشتراك شهر يوليو", date: "2026-07-01" },
  { id: 3, studentId: 3, amount: 45, period: "حصة أحد", date: "2026-07-22" }
];

export default function App() {
  const { isAuthenticated, logout } = useAuth();
  const [isExplicitlyLoggedOut, setIsExplicitlyLoggedOut] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [pinInput, setPinInput] = useState('');
  
  // App States
  const [lessonsList, setLessonsList] = useState(INITIAL_LESSONS);
  const [currentLesson, setCurrentLesson] = useState(INITIAL_LESSONS[0]);
  const [activeResource, setActiveResource] = useState('board');
  const [students, setStudents] = useState(INITIAL_STUDENTS);
  const [sessions, setSessions] = useState(INITIAL_SESSIONS);
  const [questions, setQuestions] = useState(INITIAL_QUESTIONS);
  const [grades, setGrades] = useState(INITIAL_GRADES);
  const [attendance, setAttendance] = useState([
    { id: 1, studentId: 1, sessionId: 1, date: "2026-07-24", status: "حاضر" },
    { id: 2, studentId: 2, sessionId: 1, date: "2026-07-24", status: "حاضر" }
  ]);
  const [payments, setPayments] = useState(INITIAL_PAYMENTS);

  // Settings
  const [settings, setSettings] = useState({ adminPin: '1234', lockEnabled: false, voiceEnabled: true });

  // Dialogs
  const [showAddStudent, setShowAddStudent] = useState(false);
  const [editingStudent, setEditingStudent] = useState(null);
  const [showAddGrade, setShowAddGrade] = useState(false);
  const [showAddPayment, setShowAddPayment] = useState(false);

  // Scanner Simulation State
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState(null);
  const [selectedScanStudent, setSelectedScanStudent] = useState(students[0]?.id || 1);

  // AI Assistant Messages
  const [aiMessages, setAiMessages] = useState([
    { sender: 'ai', text: 'أهلاً بك أستاذنا العزيز! أنا المساعد التعليمي الذكي لمنصة المُبدع. كيف أستطيع مساعدتك اليوم في تحضير الدروس صياغة الامتحانات؟' }
  ]);
  const [aiPrompt, setAiPrompt] = useState('');

  // Lock Handler
  const handleUnlock = () => {
    if (pinInput === settings.adminPin) {
      setIsLocked(false);
      setPinInput('');
    } else {
      alert('رمز PIN غير صحيح!');
    }
  };

  const currentSession = sessions.find(s => s.current) || sessions[0];

  // Render Login Page if not authenticated or explicitly logged out
  if (!isAuthenticated || isExplicitlyLoggedOut) {
    return (
      <LoginPage
        onLoginSuccess={() => {
          setIsExplicitlyLoggedOut(false);
          setActiveTab('dashboard');
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-['Cairo'] flex flex-col md:flex-row">
      
      {/* PIN LOCK SCREEN OVERLAY */}
      {isLocked && (
        <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 p-8 rounded-3xl max-w-sm w-full text-center shadow-2xl">
            <div className="w-16 h-16 bg-indigo-600/20 text-indigo-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold mb-1">شاشة الأمان - منصة المُبدع</h2>
            <p className="text-slate-400 text-sm mb-6">أدخل رمز PIN للدخول إلى البيانات</p>
            <input
              type="password"
              maxLength={4}
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value)}
              placeholder="••••"
              className="w-full text-center text-3xl tracking-widest py-3 bg-slate-800 border border-slate-700 rounded-xl mb-4 focus:outline-none focus:border-indigo-500"
            />
            <button
              onClick={handleUnlock}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 font-bold rounded-xl transition"
            >
              فتح التطبيق
            </button>
          </div>
        </div>
      )}

      {/* SIDEBAR NAVIGATION */}
      <aside className={`fixed inset-y-0 right-0 z-40 w-72 bg-slate-950 border-l border-slate-800 transform ${mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'} md:translate-x-0 transition-transform duration-300 ease-in-out flex flex-col`}>
        {/* Sidebar Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 to-indigo-400 flex items-center justify-center text-white font-extrabold text-xl shadow-lg shadow-indigo-500/20">
              م
            </div>
            <div>
              <h1 className="font-extrabold text-lg text-white leading-tight">منصة المُبدع</h1>
              <p className="text-xs text-indigo-400">إدارة الحصة المباشرة والسنتر</p>
            </div>
          </div>
          <button onClick={() => setMobileMenuOpen(false)} className="md:hidden text-slate-400 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 overflow-y-auto p-4 space-y-1.5 custom-scrollbar">
          {[
            { id: 'dashboard', label: 'الرئيسية', icon: BarChart2 },
            { id: 'classMode', label: 'وضع الحصة المباشرة 🔴', icon: Play, highlight: true },
            { id: 'students', label: 'إدارة الطلاب', icon: Users },
            { id: 'studentCards', label: 'كروت الحضور الكودية', icon: QrCode },
            { id: 'sessions', label: 'المجموعات والحصص', icon: BookOpen },
            { id: 'attendance', label: 'الحضور والغياب', icon: CheckSquare },
            { id: 'grades', label: 'سجل الدرجات والامتحانات', icon: Award },
            { id: 'scanner', label: 'الماسح الضوئي لتصحيح الورق', icon: Camera },
            { id: 'questionBank', label: 'بنك الأسئلة والشامل', icon: HelpCircle },
            { id: 'games', label: 'المسابقات والألعاب', icon: Trophy },
            { id: 'mapChallenge', label: 'تحدي الخرائط', icon: MapPin },
            { id: 'payments', label: 'المدفوعات والاشتراكات', icon: CreditCard },
            { id: 'messages', label: 'رسائل وتنبيهات الأمهات', icon: MessageSquare },
            { id: 'smartAssistant', label: 'المساعد التعليمي الذكي', icon: Sparkles },
            { id: 'settings', label: 'الإعدادات والأمان', icon: Settings }
          ].map(item => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => { setActiveTab(item.id); setMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-semibold transition-all ${
                  active
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : item.highlight
                    ? 'bg-rose-500/10 text-rose-400 hover:bg-rose-500/20'
                    : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                }`}
              >
                <Icon className={`w-5 h-5 ${active ? 'text-white' : item.highlight ? 'text-rose-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-slate-800 space-y-2">
          <button
            onClick={() => setIsLocked(true)}
            className="w-full flex items-center justify-center gap-2 py-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs font-bold text-amber-300 transition"
          >
            <Lock className="w-4 h-4 text-amber-400" />
            <span>قفل الشاشة برمز PIN</span>
          </button>

          <button
            onClick={async () => {
              await logout();
              setIsExplicitlyLoggedOut(true);
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 bg-rose-950/80 hover:bg-rose-900 border border-rose-800/80 rounded-xl text-xs font-bold text-rose-300 transition"
          >
            <LogOut className="w-4 h-4 text-rose-400" />
            <span>تسجيل الخروج</span>
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 md:mr-72 flex flex-col min-h-screen">
        
        {/* Top Header Bar */}
        <header className="bg-slate-950/80 backdrop-blur border-b border-slate-800 p-4 sticky top-0 z-30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="md:hidden p-2 text-slate-400 hover:text-white rounded-xl bg-slate-900 border border-slate-800"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div>
              <h2 className="text-xl font-extrabold text-white">
                {activeTab === 'dashboard' && 'لوحة التحكم الرئيسية'}
                {activeTab === 'classMode' && 'وضع الحصة المباشرة'}
                {activeTab === 'students' && 'قائمة الطلاب وسجل البيانات'}
                {activeTab === 'studentCards' && 'بطاقات الحضور الكودية (كروت الطالب)'}
                {activeTab === 'sessions' && 'جدول الحصص والمجموعات'}
                {activeTab === 'attendance' && 'تسجيل الحضور والغياب'}
                {activeTab === 'grades' && 'نتائج الامتحانات والدرجات'}
                {activeTab === 'scanner' && 'الماسح الضوئي لتصحيح ورقة الإجابة'}
                {activeTab === 'questionBank' && 'بنك الأسئلة المطور'}
                {activeTab === 'games' && 'المسابقات والأسئلة التفاعلية'}
                {activeTab === 'mapChallenge' && 'تحدي الخرائط التفاعلي'}
                {activeTab === 'payments' && 'المدفوعات والإيرادات'}
                {activeTab === 'messages' && 'إرسال التقرير عبر واتساب'}
                {activeTab === 'smartAssistant' && 'المساعد الذكي للمعلم'}
                {activeTab === 'settings' && 'إعدادات المنصة'}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 bg-indigo-950/60 border border-indigo-800/50 px-3 py-1.5 rounded-xl">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-xs font-bold text-indigo-200">
                الحصة الحالية: {currentSession.title} ({currentSession.group})
              </span>
            </div>
          </div>
        </header>

        {/* MAIN BODY PAGES */}
        <main className="flex-1 p-4 md:p-8 max-w-7xl mx-auto w-full">

          {/* DASHBOARD TAB */}
          {activeTab === 'dashboard' && (
            <DashboardHomepage
              onNavigate={(tab) => setActiveTab(tab)}
              currentSession={currentSession}
              students={students}
              sessions={sessions}
            />
          )}

          {/* CLASS MODE TAB (THE INTEGRATED TEACHING & EXPLANATION SYSTEM) */}
          {activeTab === 'classMode' && (
            <ClassroomTeachingHub
              currentLesson={currentLesson}
              setCurrentLesson={setCurrentLesson}
              lessonsList={lessonsList}
              students={students}
              setStudents={setStudents}
              attendance={attendance}
              setAttendance={setAttendance}
              currentSession={currentSession}
            />
          )}

          {/* STUDENTS ROSTER TAB */}
          {activeTab === 'students' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="relative w-full sm:w-80">
                  <Search className="w-5 h-5 absolute right-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    placeholder="بحث بالكود أو الاسم..."
                    className="w-full pr-10 pl-4 py-2.5 bg-slate-900 border border-slate-800 rounded-2xl text-sm text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <button
                  onClick={() => setShowAddStudent(true)}
                  className="w-full sm:w-auto px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30"
                >
                  <UserPlus className="w-5 h-5" />
                  إضافة طالب جديد
                </button>
              </div>

              {/* Students Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {students.map(student => (
                  <div key={student.id} className="bg-slate-900 border border-slate-800 p-5 rounded-3xl flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <span className="bg-indigo-950 text-indigo-400 font-extrabold text-xs px-3 py-1 rounded-xl border border-indigo-800">
                          كود #{student.code}
                        </span>
                        <span className="text-xs font-bold text-amber-400">{student.sessionPrice} ج.م / حصة</span>
                      </div>
                      <h3 className="font-extrabold text-white text-lg">{student.name}</h3>
                      <p className="text-xs text-slate-400 mt-1">{student.grade} • {student.group}</p>
                      <p className="text-xs text-indigo-400 mt-2 flex items-center gap-1">
                        <Phone className="w-3.5 h-3.5" />
                        ولي الأمر: {student.guardianPhone}
                      </p>
                    </div>

                    <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between">
                      <a
                        href={`https://api.whatsapp.com/send?phone=${student.guardianPhone}&text=${encodeURIComponent(`سلام عليكم ولي أمر الطالب ${student.name}، نود إعلامكم بتحديثات حصة مادة المبدع.`)}`}
                        target="_blank"
                        rel="noreferrer"
                        className="px-3 py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 rounded-xl text-xs font-bold flex items-center gap-1"
                      >
                        <Send className="w-3.5 h-3.5" />
                        واتساب
                      </a>
                      <button
                        onClick={() => {
                          setStudents(prev => prev.filter(s => s.id !== student.id));
                        }}
                        className="p-1.5 text-rose-400 hover:bg-rose-500/10 rounded-xl transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STUDENT CARDS / QR TAB */}
          {activeTab === 'studentCards' && (
            <div className="space-y-6">
              <p className="text-slate-400 text-sm">كروت المتابعة الكودية للطلاب للطباعة أو المسح الضوئي للحضور:</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {students.map(student => (
                  <div key={student.id} className="bg-slate-900 border border-slate-800 p-6 rounded-3xl flex flex-col items-center text-center shadow-xl">
                    <div className="w-full flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
                      <span className="font-extrabold text-indigo-400 text-sm">منصة المُبدع</span>
                      <span className="text-xs font-bold text-slate-400">كود #{student.code}</span>
                    </div>
                    
                    <h3 className="font-extrabold text-white text-lg mb-1">{student.name}</h3>
                    <p className="text-xs text-slate-400 mb-4">{student.grade}</p>

                    <div className="p-3 bg-white rounded-2xl mb-4">
                      <QRCodeSVG value={`STUDENT_CODE_${student.code}`} size={120} />
                    </div>

                    <span className="text-xs font-mono font-bold text-slate-400 bg-slate-800 px-3 py-1 rounded-lg">
                      CODE-{student.code.toString().padStart(4, '0')}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SCANNER TAB */}
          {activeTab === 'scanner' && (
            <div className="space-y-6 max-w-2xl mx-auto">
              <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl text-center">
                <h3 className="text-xl font-extrabold text-white mb-2">الماسح الضوئي لتصحيح ورقة الإجابة (OMR)</h3>
                <p className="text-slate-400 text-sm mb-6">وجه الكاميرا لورقة التظليل ليتم تقييم الإجابات تلقائياً وحفظ الدرجة في السجل.</p>

                {/* Viewfinder Frame */}
                <div className="w-full h-64 bg-slate-950 border-2 border-dashed border-indigo-500/50 rounded-2xl flex flex-col items-center justify-center relative overflow-hidden mb-6">
                  {isScanning ? (
                    <div className="flex flex-col items-center gap-3">
                      <RefreshCw className="w-10 h-10 text-indigo-400 animate-spin" />
                      <span className="text-sm font-bold text-indigo-200">جاري مسح الفقرات وتحليل الإجابات...</span>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-2">
                      <Camera className="w-12 h-12 text-indigo-400" />
                      <span className="text-xs text-slate-500">منطقة التقاط نموذج الإجابة</span>
                    </div>
                  )}
                </div>

                <div className="mb-6 text-right">
                  <label className="block text-xs font-bold text-slate-400 mb-2">اختر الطالب لاختبار تصحيح ورقه:</label>
                  <select
                    value={selectedScanStudent}
                    onChange={(e) => setSelectedScanStudent(Number(e.target.value))}
                    className="w-full p-3 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white"
                  >
                    {students.map(s => (
                      <option key={s.id} value={s.id}>{s.name} ({s.grade})</option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={() => {
                    setIsScanning(true);
                    setScanResult(null);
                    setTimeout(() => {
                      setIsScanning(false);
                      const generatedScore = Math.floor(Math.random() * 5) + 16;
                      setScanResult(generatedScore);
                    }, 1500);
                  }}
                  disabled={isScanning}
                  className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-500 font-bold rounded-2xl text-white shadow-lg shadow-indigo-600/30 transition flex items-center justify-center gap-2"
                >
                  <Camera className="w-5 h-5" />
                  <span>التقاط ومسح الورقة الآن</span>
                </button>

                {scanResult !== null && (
                  <div className="mt-6 p-4 bg-emerald-950/60 border border-emerald-800 rounded-2xl text-right animate-fade-in">
                    <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-lg mb-2">
                      <CheckCircle2 className="w-6 h-6" />
                      <span>تم التصحيح واستخراج الدرجة!</span>
                    </div>
                    <p className="text-sm text-slate-200">النتيجة المحصلة: <strong className="text-emerald-400 text-lg">{scanResult} / 20</strong></p>
                    <button
                      onClick={() => {
                        setGrades(prev => [
                          ...prev,
                          { id: Date.now(), studentId: selectedScanStudent, exam: 'تصحيح كاميرا تلقائي', score: scanResult, total: 20, date: '2026-07-24', strength: 'إجابات نموذجية', weakness: 'لا يوجد' }
                        ]);
                        alert('تمت إضافة الدرجة لسجل الطالب بنجاح!');
                        setScanResult(null);
                      }}
                      className="mt-3 w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs"
                    >
                      حفظ الدرجة في السجل
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* QUESTION BANK TAB */}
          {activeTab === 'questionBank' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <p className="text-slate-400 text-sm">أسئلة متعددة الخيارات والصح والخطأ للمناهج الدراسية:</p>
              </div>

              <div className="space-y-4">
                {questions.map(q => (
                  <div key={q.id} className="bg-slate-900 border border-slate-800 p-6 rounded-3xl">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-indigo-400 bg-indigo-950 px-3 py-1 rounded-xl border border-indigo-800">
                        {q.grade} • {q.unit}
                      </span>
                      <span className="text-xs font-bold text-emerald-400">الإجابة: {q.answer}</span>
                    </div>
                    <h3 className="font-extrabold text-white text-base mb-4">{q.text}</h3>
                    {q.options && (
                      <div className="grid grid-cols-2 gap-2">
                        {q.options.map((opt, idx) => (
                          <div
                            key={idx}
                            className={`p-3 rounded-xl border text-xs font-bold text-center ${
                              idx === q.answerIndex ? 'bg-emerald-950/60 border-emerald-600 text-emerald-300' : 'bg-slate-800/60 border-slate-700 text-slate-300'
                            }`}
                          >
                            {opt}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* GAMES & QUIZZES TAB */}
          {activeTab === 'games' && (
            <div className="space-y-6 max-w-2xl mx-auto">
              <div className="bg-gradient-to-tr from-indigo-900 to-purple-900 border border-indigo-700 p-8 rounded-3xl text-center shadow-2xl">
                <Trophy className="w-16 h-16 text-amber-400 mx-auto mb-3 animate-bounce" />
                <h3 className="text-2xl font-black text-white">مسابقة المبدع السريعة 🏆</h3>
                <p className="text-indigo-200 text-sm mb-6">تحدي الأسئلة بين طلاب المجموعة لرفع معنويات الحصة</p>

                <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl text-right mb-6">
                  <span className="text-xs font-bold text-amber-400">سؤال التحدي الحالي:</span>
                  <h4 className="text-lg font-bold text-white mt-1">تقع دولة جزر القمر في المحيط ... جنوب دائرة الاستواء؟</h4>
                  <div className="grid grid-cols-2 gap-2 mt-4">
                    {["الأطلسي", "الهندي", "الهادي", "القطبي"].map((opt, i) => (
                      <button
                        key={i}
                        onClick={() => alert(i === 1 ? 'إجابة صحيحة! 🎉 +10 نقاط' : 'إجابة خاطئة، حاول ثانية!')}
                        className="p-3 bg-slate-800 hover:bg-indigo-600 text-white font-bold rounded-xl text-sm border border-slate-700 transition"
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* MAP CHALLENGE TAB */}
          {activeTab === 'mapChallenge' && (
            <div className="-m-6">
              <MapChallengeMain />
            </div>
          )}

          {/* PAYMENTS TAB */}
          {activeTab === 'payments' && (
            <div className="space-y-6">
              <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-xs">إجمالي مدفوعات الحصص المسجلة</p>
                  <h3 className="text-3xl font-black text-emerald-400 mt-1">
                    {payments.reduce((acc, curr) => acc + curr.amount, 0)} ج.م
                  </h3>
                </div>
                <button
                  onClick={() => {
                    const amount = prompt('المبلغ بالجنيه:');
                    if (amount) {
                      setPayments(prev => [...prev, { id: Date.now(), studentId: 1, amount: Number(amount), period: 'دفع حادي', date: '2026-07-24' }]);
                    }
                  }}
                  className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 font-bold text-white rounded-xl text-sm flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  تسجيل دفع
                </button>
              </div>

              <div className="space-y-3">
                {payments.map(p => {
                  const st = students.find(s => s.id === p.studentId);
                  return (
                    <div key={p.id} className="p-4 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-between">
                      <div>
                        <h4 className="font-bold text-white text-base">{st?.name || 'طالب'}</h4>
                        <p className="text-xs text-slate-400">{p.period} • {p.date}</p>
                      </div>
                      <span className="text-emerald-400 font-extrabold text-lg">+{p.amount} ج.م</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* MESSAGES TAB */}
          {activeTab === 'messages' && (
            <div className="space-y-6">
              <p className="text-slate-400 text-sm">إرسال تقارير الحضور المباشرة للأمهات عبر واتساب:</p>
              <div className="space-y-3">
                {students.map(s => (
                  <div key={s.id} className="p-5 bg-slate-900 border border-slate-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h4 className="font-bold text-white text-base">{s.name}</h4>
                      <p className="text-xs text-slate-400">ولي الأمر: {s.guardianPhone}</p>
                      <p className="text-xs text-indigo-300 mt-2 bg-slate-800 p-2 rounded-xl">
                        "ولي أمر الطالب/ة {s.name}، نود إحاطتكم بحضور ومتابعة الطالب لمواعيد حوافز الدرس بنجاح عبر منصة المُبدع."
                      </p>
                    </div>
                    <a
                      href={`https://api.whatsapp.com/send?phone=${s.guardianPhone}&text=${encodeURIComponent(`سلام عليكم ولي أمر الطالب/ة ${s.name}، نود إحاطتكم بحضور ومتابعة الطالب لمواعيد حوافز الدرس بنجاح عبر منصة المُبدع.`)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 font-bold text-white rounded-2xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20"
                    >
                      <Send className="w-4 h-4" />
                      إرسال التقرير عبر واتساب
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SMART ASSISTANT TAB */}
          {activeTab === 'smartAssistant' && (
            <div className="space-y-4 max-w-3xl mx-auto flex flex-col h-[600px]">
              <div className="flex-1 bg-slate-900 border border-slate-800 p-6 rounded-3xl overflow-y-auto space-y-4 custom-scrollbar">
                {aiMessages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.sender === 'user' ? 'justify-start' : 'justify-end'}`}>
                    <div className={`p-4 rounded-2xl max-w-md text-sm ${
                      msg.sender === 'user' ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-200 border border-slate-700'
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder="اطلب صياغة سؤال، تحضير درس، أو مراجعة..."
                  className="flex-1 p-3.5 bg-slate-900 border border-slate-800 rounded-2xl text-sm text-white focus:outline-none focus:border-indigo-500"
                />
                <button
                  onClick={() => {
                    if (aiPrompt) {
                      setAiMessages(prev => [
                        ...prev,
                        { sender: 'user', text: aiPrompt },
                        { sender: 'ai', text: `تمت المعالجة للطلب: "${aiPrompt}". جاري تطبيق التوصيات التعليمية بنجاح.` }
                      ]);
                      setAiPrompt('');
                    }
                  }}
                  className="p-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}

          {/* SETTINGS TAB */}
          {activeTab === 'settings' && (
            <div className="space-y-6 max-w-2xl mx-auto">
              <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4">
                <h3 className="text-lg font-bold text-white mb-2">إعدادات الأمان وقفل PIN</h3>
                
                <div className="flex items-center justify-between py-2 border-b border-slate-800">
                  <span className="text-sm font-semibold text-slate-300">رمز القفل الحقيقي (PIN)</span>
                  <input
                    type="text"
                    value={settings.adminPin}
                    onChange={(e) => setSettings({ ...settings, adminPin: e.target.value })}
                    className="w-24 text-center py-1.5 bg-slate-800 border border-slate-700 rounded-xl font-mono text-sm text-indigo-400"
                  />
                </div>

                <div className="pt-4">
                  <h4 className="font-bold text-white text-sm mb-1">عن منصة المُبدع v9.0.0</h4>
                  <p className="text-xs text-slate-400">تطبيق متكامل لإدارة الحصة، متابعة الطلاب، وبنك الأسئلة المطور.</p>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>
    </div>
  );
}
