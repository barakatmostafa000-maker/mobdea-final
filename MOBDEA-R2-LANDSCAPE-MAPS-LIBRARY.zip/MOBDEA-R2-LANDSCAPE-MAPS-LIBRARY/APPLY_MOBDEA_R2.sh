#!/usr/bin/env bash
set -euo pipefail

PROJECT="${1:-/workspaces/mobdea-final}"
cd "$PROJECT"

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP=".mobdea-r2-backup-$STAMP"
mkdir -p "$BACKUP/src/pages" "$BACKUP/src/styles"

cp src/pages/ContentLibrary.jsx "$BACKUP/src/pages/ContentLibrary.jsx"
cp src/styles/app.css "$BACKUP/src/styles/app.css"

python3 - <<'PY'
from pathlib import Path
import re

library = Path("src/pages/ContentLibrary.jsx")
text = library.read_text(encoding="utf-8")

react_import = re.compile(
    r"import\s*\{\s*(?P<names>[^}]*)\}\s*from\s*(['\"])react\2\s*;",
    re.S,
)
match = react_import.search(text)
if not match:
    raise SystemExit("❌ لم يتم العثور على import الخاص بـ React داخل ContentLibrary.jsx")

names = [item.strip() for item in match.group("names").split(",") if item.strip()]
if "useEffect" not in names:
    names.insert(0, "useEffect")
    replacement = "import { " + ", ".join(names) + " } from 'react';"
    text = text[:match.start()] + replacement + text[match.end():]

library.write_text(text, encoding="utf-8")

css_path = Path("src/styles/app.css")
css = css_path.read_text(encoding="utf-8")

css = re.sub(
    r"\.map-pro-transform\s*\{\s*position\s*:\s*relative\s*;\s*transform-origin\s*:\s*center center\s*;?\s*\}",
    ".map-pro-transform{position:absolute;inset:0;width:100%;height:100%;transform-origin:center center}",
    css,
)

start = "/* ===== MOBDEA R2 START: landscape + maps + library ===== */"
end = "/* ===== MOBDEA R2 END ===== */"
if start in css and end in css:
    before = css.split(start, 1)[0]
    after = css.split(end, 1)[1]
    css = before.rstrip() + "\n\n" + after.lstrip()

override = r'''
/* ===== MOBDEA R2 START: landscape + maps + library ===== */

.map-pro-stage {
  position: relative !important;
  isolation: isolate !important;
  min-width: 0 !important;
  overflow: hidden !important;
  background:
    radial-gradient(circle at 50% 38%, rgba(24, 99, 137, .95), #071c2b 58%, #031019 100%) !important;
}

.map-pro-stage > .map-pro-transform {
  position: absolute !important;
  inset: 0 !important;
  width: 100% !important;
  height: 100% !important;
  min-width: 0 !important;
  min-height: 0 !important;
  display: block !important;
  transform-origin: center center !important;
}

.map-pro-stage .map-pro-svg,
.map-pro-stage .map-pro-draw-canvas,
.map-pro-stage .map-pro-placement-layer {
  position: absolute !important;
  inset: 0 !important;
  width: 100% !important;
  height: 100% !important;
}

.map-pro-stage .map-pro-svg {
  display: block !important;
  visibility: visible !important;
  opacity: 1 !important;
}

.map-game-main,
.map-game-canvas-shell,
.lesson-map-main,
.lesson-map-canvas-shell,
.classmode-map-embed {
  min-width: 0 !important;
  min-height: 0 !important;
}

.map-game-canvas-shell,
.lesson-map-canvas-shell {
  position: relative !important;
  overflow: hidden !important;
}

.classmode-map-embed .lesson-map-studio {
  height: 100% !important;
  min-height: 0 !important;
}

.classmode-map-embed .lesson-map-main {
  height: 100% !important;
  min-height: 0 !important;
  grid-template-rows: auto auto auto minmax(0, 1fr) auto !important;
}

.classmode-map-embed .lesson-map-canvas-shell,
.classmode-map-embed .map-pro-stage {
  height: 100% !important;
  min-height: 0 !important;
}

@media (orientation: landscape) and (max-height: 680px) {
  .app-shell-v103:not(.lesson-mode-shell) {
    width: 100vw !important;
    height: 100dvh !important;
    grid-template-rows: 42px minmax(0, 1fr) !important;
    overflow: hidden !important;
  }

  .app-shell-v103:not(.lesson-mode-shell) > .mobile-header {
    height: 42px !important;
    min-height: 42px !important;
    max-height: 42px !important;
  }

  .app-shell-v103:not(.lesson-mode-shell) > .app-content {
    width: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    padding: 4px !important;
    overflow-x: hidden !important;
    overflow-y: auto !important;
  }

  .dashboard-reference-layout,
  .dashboard-v103 {
    width: 100% !important;
    min-width: 0 !important;
    gap: 4px !important;
  }

  .dashboard-reference-hero,
  .dashboard-v103 .dashboard-reference-hero {
    width: 100% !important;
    min-width: 0 !important;
    height: 132px !important;
    min-height: 132px !important;
    max-height: 132px !important;
    grid-template-columns: minmax(0, 1.25fr) minmax(145px, .55fr) !important;
    overflow: hidden !important;
  }

  .dashboard-reference-copy {
    min-width: 0 !important;
    padding: 7px 11px !important;
    align-content: center !important;
  }

  .dashboard-reference-copy h2 {
    margin: 0 !important;
    font-size: clamp(1.45rem, 4.2vw, 2.2rem) !important;
    line-height: 1 !important;
  }

  .dashboard-reference-copy h3 {
    margin: 3px 0 5px !important;
    font-size: .78rem !important;
    line-height: 1.2 !important;
  }

  .dashboard-reference-copy p {
    display: none !important;
  }

  .dashboard-reference-actions {
    gap: 5px !important;
    margin-top: 5px !important;
  }

  .dashboard-reference-actions button {
    min-height: 28px !important;
    padding: 4px 9px !important;
    font-size: .66rem !important;
  }

  .dashboard-reference-portrait {
    width: 100% !important;
    height: 132px !important;
    min-height: 132px !important;
    max-height: 132px !important;
    overflow: hidden !important;
  }

  .dashboard-reference-portrait img {
    width: 100% !important;
    height: 100% !important;
    object-fit: cover !important;
    object-position: center 25% !important;
  }

  .dashboard-today-panel,
  .dashboard-reference-bottom {
    display: none !important;
  }

  .dashboard-feature-grid,
  .dashboard-v103 .dashboard-feature-grid {
    width: 100% !important;
    min-width: 0 !important;
    display: grid !important;
    grid-template-columns: repeat(6, minmax(0, 1fr)) !important;
    gap: 4px !important;
    overflow: hidden !important;
  }

  .dashboard-feature-card,
  .dashboard-v103 .dashboard-feature-card {
    min-width: 0 !important;
    min-height: 78px !important;
    height: 78px !important;
    padding: 5px !important;
    overflow: hidden !important;
  }

  .dashboard-feature-card h3,
  .dashboard-feature-card strong {
    font-size: .67rem !important;
    line-height: 1.15 !important;
  }

  .dashboard-feature-card p,
  .dashboard-feature-card small,
  .dashboard-feature-card .secondary-btn {
    display: none !important;
  }

  .dashboard-feature-card svg {
    width: 25px !important;
    height: 25px !important;
  }
}

@media (orientation: landscape) and (max-height: 680px) {
  .map-game-page {
    width: 100% !important;
    height: 100% !important;
    min-height: 0 !important;
    padding: 3px !important;
    overflow: hidden !important;
  }

  .map-challenge-pro {
    width: 100% !important;
    height: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    grid-template-rows: 42px minmax(0, 1fr) !important;
  }

  .map-game-layout {
    width: 100% !important;
    height: 100% !important;
    min-height: 0 !important;
    grid-template-columns: 132px minmax(0, 1fr) 195px !important;
    grid-template-rows: minmax(0, 1fr) !important;
  }

  .map-game-main {
    height: 100% !important;
    grid-template-rows: auto minmax(0, 1fr) auto !important;
  }

  .map-game-canvas-shell,
  .map-game-canvas-shell .map-pro-stage {
    width: 100% !important;
    height: 100% !important;
    min-height: 0 !important;
  }
}

@media (orientation: portrait) {
  .map-game-page {
    width: 100% !important;
    min-width: 0 !important;
    min-height: calc(100dvh - 54px) !important;
    padding: 4px !important;
    overflow-y: auto !important;
  }

  .map-challenge-pro {
    width: 100% !important;
    height: auto !important;
    min-height: calc(100dvh - 62px) !important;
    overflow: visible !important;
  }

  .map-game-layout {
    width: 100% !important;
    height: auto !important;
    min-height: 0 !important;
    display: grid !important;
    grid-template-columns: minmax(0, 1fr) !important;
    grid-template-rows: auto minmax(520px, 62dvh) auto !important;
    overflow: visible !important;
  }

  .map-game-nav,
  .map-game-main,
  .map-game-question-panel {
    width: 100% !important;
    min-width: 0 !important;
    height: auto !important;
  }

  .map-game-main {
    min-height: 520px !important;
    grid-template-rows: auto minmax(440px, 1fr) auto !important;
  }

  .map-game-canvas-shell,
  .map-game-canvas-shell .map-pro-stage {
    width: 100% !important;
    min-height: 440px !important;
    height: 100% !important;
  }

  .map-game-question-panel {
    max-height: none !important;
    overflow: visible !important;
  }
}

/* ===== MOBDEA R2 END ===== */
'''

css = css.rstrip() + "\n\n" + override.strip() + "\n"
css_path.write_text(css, encoding="utf-8")

print("✅ تم إصلاح استيراد useEffect في مكتبة المحتوى")
print("✅ تم إصلاح انهيار مساحة الخريطة داخل الحصة والتحدي")
print("✅ تم إضافة تنسيق Landscape مضغوط للشاشة الرئيسية")
PY

echo "===== فحص البناء ====="
npm run build

echo
echo "✅ تم تطبيق MOBDEA R2 بنجاح"
echo "✅ النسخة الاحتياطية: $BACKUP"
echo "شغّل npm run dev -- --host 0.0.0.0 واختبر قبل بناء APK."
