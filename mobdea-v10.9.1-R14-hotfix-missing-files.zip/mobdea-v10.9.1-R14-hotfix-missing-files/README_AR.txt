R14 hotfix: missing source files accidentally omitted from cumulative ZIP.
Copy this folder contents over the project root.
Files:
- src/services/gameRooms.js
- src/styles/v104.css
- src/styles/v105.css
- src/styles/v106.css
No version change. Run npm run verify then npm run build.
