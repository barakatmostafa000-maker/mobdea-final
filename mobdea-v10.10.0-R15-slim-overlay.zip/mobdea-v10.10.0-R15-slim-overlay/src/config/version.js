export const APP_VERSION = '10.10.0';
export const APP_VERSION_CODE = 113;
export const DATA_SCHEMA_VERSION = 13;
export const RELEASE_CHANNEL = 'stable';
export const RELEASE_TAG = 'R14';
