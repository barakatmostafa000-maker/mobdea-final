import { registerPlugin } from '@capacitor/core';

const NativePdfRenderer = registerPlugin('MobdeaPdfRenderer');
const cache = new Map();

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = '';
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }
  return btoa(binary);
}

async function renderBuffer(buffer, page = 1, maxWidth = 1600, cacheKey = '') {
  if (!buffer?.byteLength || !globalThis.Capacitor?.isNativePlatform?.()) return null;
  if (buffer.byteLength > 160 * 1024 * 1024) {
    throw new Error('حجم ملف PDF أكبر من الحد المدعوم للعرض داخل السبورة.');
  }
  const normalizedPage = Math.max(1, Number(page) || 1);
  const key = `${cacheKey || `bytes:${buffer.byteLength}`}:${normalizedPage}:${maxWidth}`;
  if (cache.has(key)) return cache.get(key);
  const task = NativePdfRenderer.renderPage({
    base64: arrayBufferToBase64(buffer),
    page: normalizedPage,
    maxWidth,
  });
  cache.set(key, task);
  try {
    return await task;
  } catch (error) {
    cache.delete(key);
    throw error;
  }
}

export async function renderNativePdfBlob(blob, page = 1, maxWidth = 1600, cacheKey = '') {
  if (!(blob instanceof Blob)) throw new Error('ملف PDF غير متاح داخل ذاكرة المنصة.');
  return renderBuffer(await blob.arrayBuffer(), page, maxWidth, cacheKey || `${blob.type}:${blob.size}`);
}

export async function renderNativePdfPage(url, page = 1, maxWidth = 1600) {
  if (!url || !globalThis.Capacitor?.isNativePlatform?.()) return null;
  const response = await fetch(url);
  if (!response.ok) throw new Error('تعذر قراءة ملف PDF.');
  return renderBuffer(await response.arrayBuffer(), page, maxWidth, url);
}

export function clearPdfRenderCache() {
  cache.clear();
}
