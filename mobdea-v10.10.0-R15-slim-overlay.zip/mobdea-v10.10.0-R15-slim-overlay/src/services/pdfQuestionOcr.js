import { registerPlugin } from '@capacitor/core';
import { getAssetBlob } from './assetStore';
import { normalizeOcrText, structureOcrQuestions } from './ocrQuestionParser';
import { selectQuestionPageWindow } from './ocrQuestionDiscovery';

const NativePdfOcr = registerPlugin('MobdeaPdfOcr');
export const OCR_MAX_PAGES = 20;
export const OCR_AUTO_SCAN_PAGES = 30;

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = '';
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }
  return btoa(binary);
}

export { normalizeOcrText, structureOcrQuestions } from './ocrQuestionParser';

function ensureNativeOcr() {
  if (!globalThis.Capacitor?.isNativePlatform?.()) {
    throw new Error('استخراج OCR يعمل داخل تطبيق Android على الموبايل أو التابلت.');
  }
}

async function loadPdfAsset(assetId) {
  if (!assetId) throw new Error('ارفع كتاب الشرح الأساسي أو ملف الامتحانات لهذا الصف أولًا.');
  ensureNativeOcr();
  const blob = await getAssetBlob(assetId);
  if (!(blob instanceof Blob)) throw new Error('تعذر قراءة ملف PDF من ذاكرة المنصة.');
  if (blob.size > 160 * 1024 * 1024) throw new Error('حجم ملف PDF أكبر من الحد المدعوم لاستخراج الأسئلة.');
  return blob;
}

async function recognizePdfRange({ blob, startPage, endPage, onProgress }) {
  const firstPage = Math.max(1, Number(startPage || 1));
  const lastPage = Math.max(firstPage, Number(endPage || firstPage));
  if (lastPage - firstPage + 1 > OCR_MAX_PAGES) {
    throw new Error(`يمكن استخراج ${OCR_MAX_PAGES} صفحة كحد أقصى في العملية الواحدة.`);
  }

  let listener;
  try {
    listener = await NativePdfOcr.addListener('progress', (event) => {
      onProgress?.({
        page: Number(event?.page || firstPage),
        totalPages: Number(event?.totalPages || lastPage - firstPage + 1),
        stage: String(event?.stage || 'recognizing'),
      });
    });
    return await NativePdfOcr.recognizePdfPages({
      base64: arrayBufferToBase64(await blob.arrayBuffer()),
      startPage: firstPage,
      endPage: lastPage,
      language: 'ara+eng',
      maxWidth: 1800,
    });
  } finally {
    await listener?.remove?.().catch?.(() => {});
  }
}

export async function extractQuestionsFromPdfAsset({
  assetId,
  startPage = 1,
  endPage = startPage,
  onProgress,
} = {}) {
  const blob = await loadPdfAsset(assetId);
  const firstPage = Math.max(1, Number(startPage || 1));
  const lastPage = Math.max(firstPage, Number(endPage || firstPage));
  const result = await recognizePdfRange({ blob, startPage: firstPage, endPage: lastPage, onProgress });
  const structured = structureOcrQuestions(result?.text || '');
  return {
    ...structured,
    pages: Array.isArray(result?.pages) ? result.pages : [],
    pageCount: Number(result?.pageCount || 0),
    processedPages: Number(result?.processedPages || 0),
    startPage: firstPage,
    endPage: lastPage,
    modelDownloaded: Boolean(result?.modelDownloaded),
  };
}

/**
 * Finds the exercise/question pages automatically near the end of a lesson.
 * The scan is intentionally bounded because Arabic OCR is CPU intensive.
 */
export async function autoDetectQuestionsFromPdfAsset({
  assetId,
  lessonStartPage = 1,
  lessonEndPage = lessonStartPage,
  onProgress,
} = {}) {
  const blob = await loadPdfAsset(assetId);
  const declaredStart = Math.max(1, Number(lessonStartPage || 1));
  const declaredEnd = Math.max(declaredStart, Number(lessonEndPage || declaredStart));
  const scanStart = Math.max(declaredStart, declaredEnd - OCR_AUTO_SCAN_PAGES + 1);
  const collectedPages = [];
  let pageCount = 0;
  let modelDownloaded = false;

  for (let chunkStart = scanStart; chunkStart <= declaredEnd; chunkStart += OCR_MAX_PAGES) {
    const chunkEnd = Math.min(declaredEnd, chunkStart + OCR_MAX_PAGES - 1);
    const result = await recognizePdfRange({
      blob,
      startPage: chunkStart,
      endPage: chunkEnd,
      onProgress: (progress) => onProgress?.({ ...progress, stage: progress.stage === 'recognizing' ? 'detecting-questions' : progress.stage }),
    });
    pageCount = Math.max(pageCount, Number(result?.pageCount || 0));
    modelDownloaded ||= Boolean(result?.modelDownloaded);
    for (const page of Array.isArray(result?.pages) ? result.pages : []) collectedPages.push(page);
  }

  const { pages: selectedPages, scored } = selectQuestionPageWindow(collectedPages);
  if (!selectedPages.length) {
    return {
      ...structureOcrQuestions(''),
      pageCount,
      processedPages: collectedPages.length,
      startPage: 0,
      endPage: 0,
      detected: false,
      modelDownloaded,
      scannedStartPage: scanStart,
      scannedEndPage: declaredEnd,
      pageScores: scored.map(({ page, score, parsed }) => ({ page, score: Number(score.toFixed(2)), parsed })),
    };
  }

  const combined = selectedPages
    .map((page) => `--- صفحة ${page.page} ---\n${page.text || ''}`)
    .join('\n\n');
  const structured = structureOcrQuestions(combined);
  return {
    ...structured,
    pageCount,
    processedPages: collectedPages.length,
    startPage: Number(selectedPages[0]?.page || 0),
    endPage: Number(selectedPages[selectedPages.length - 1]?.page || 0),
    detected: true,
    modelDownloaded,
    scannedStartPage: scanStart,
    scannedEndPage: declaredEnd,
    detectedPages: selectedPages.map((page) => Number(page.page)),
    pageScores: scored.map(({ page, score, parsed }) => ({ page, score: Number(score.toFixed(2)), parsed })),
  };
}
