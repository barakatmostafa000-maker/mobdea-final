import { buildCloudUrl, timeoutFetch } from './cloudSync';
import { importAssetBlob } from './assetStore';
import { createCredentialSecret } from '../utils/security';
import { safeTrim } from '../utils/safety';

const STUDENT_TOKEN_HEADER = 'X-Mobdea-Student-Token';
const STUDENT_WORKSPACE_HEADER = 'X-Mobdea-Workspace';

function publicConfig(settings = {}) {
  const cloud = settings?.cloudSync || settings || {};
  const endpoint = String(cloud.endpoint || '').trim().replace(/\/$/, '');
  const workspaceId = safeTrim(cloud.workspaceId || '', 80).replace(/[^a-zA-Z0-9_-]/g, '');
  if (!/^https:\/\//i.test(endpoint)) throw new Error('رابط خادم الطلاب غير مضبوط على هذا الجهاز.');
  if (!/^[a-zA-Z0-9_-]{3,80}$/.test(workspaceId)) throw new Error('مساحة العمل غير مضبوطة على هذا الجهاز.');
  return { endpoint, workspaceId };
}

async function readError(response, fallback) {
  try {
    const body = await response.json();
    if (body?.error === 'student_not_found' || body?.error === 'invalid_credentials') return 'كود الطالب أو PIN غير صحيح.';
    if (body?.error === 'student_not_active') return 'حساب الطالب غير مفعّل. تواصل مع المعلم.';
    if (body?.error === 'rate_limited') return 'محاولات كثيرة؛ انتظر قليلًا ثم أعد المحاولة.';
    if (body?.error === 'workspace_not_ready') return 'بيانات الطلاب لم تُرفع إلى المنصة السحابية بعد.';
    return body?.message || body?.error || fallback;
  } catch {
    return fallback;
  }
}

function authHeaders(config, token = '', extra = {}) {
  return {
    'Content-Type': 'application/json',
    [STUDENT_WORKSPACE_HEADER]: config.workspaceId,
    ...(token ? { [STUDENT_TOKEN_HEADER]: token } : {}),
    ...extra,
  };
}

function recordKey(record = {}) {
  const id = record.id ?? record.studentId ?? record.sessionId ?? record.roomId ?? record.token;
  return id == null ? JSON.stringify(record) : String(id);
}

function mergeRecords(local = [], remote = []) {
  const map = new Map();
  for (const item of Array.isArray(local) ? local : []) map.set(recordKey(item), item);
  for (const item of Array.isArray(remote) ? remote : []) map.set(recordKey(item), { ...(map.get(recordKey(item)) || {}), ...item });
  return [...map.values()];
}

export async function loginStudentFromCloud(settings, code, pin) {
  const config = publicConfig(settings);
  const response = await timeoutFetch(buildCloudUrl(config.endpoint, '/student/login'), {
    method: 'POST',
    headers: authHeaders(config),
    body: JSON.stringify({ code: safeTrim(code, 24), pin: safeTrim(pin, 16) }),
  }, 25000);
  if (!response.ok) throw new Error(await readError(response, `تعذر دخول الطالب (${response.status}).`));
  const payload = await response.json();
  if (!payload?.student || !payload?.studentToken || !payload?.data) throw new Error('استجابة دخول الطالب غير مكتملة.');
  return { ...payload, endpoint: config.endpoint, workspaceId: config.workspaceId };
}

export async function refreshStudentPortalSnapshot(session = {}) {
  const config = publicConfig(session);
  const token = safeTrim(session.studentToken || session.token || '', 260);
  if (!token) throw new Error('جلسة الطالب غير موجودة. أعد تسجيل الدخول.');
  const response = await timeoutFetch(buildCloudUrl(config.endpoint, '/student/snapshot'), {
    method: 'GET',
    headers: authHeaders(config, token),
  }, 25000);
  if (!response.ok) throw new Error(await readError(response, `تعذر تحديث حساب الطالب (${response.status}).`));
  return response.json();
}

export async function fetchStudentAssetBlob(session = {}, assetId = '') {
  const config = publicConfig(session);
  const token = safeTrim(session.studentToken || session.token || '', 260);
  const id = safeTrim(assetId, 100);
  if (!token || !id) throw new Error('بيانات تنزيل الملف غير مكتملة.');
  const response = await timeoutFetch(buildCloudUrl(config.endpoint, `/student/assets/${encodeURIComponent(id)}`), {
    method: 'GET',
    headers: authHeaders(config, token, { Accept: '*/*' }),
  }, 300000);
  if (!response.ok) throw new Error(await readError(response, `تعذر تنزيل الملف (${response.status}).`));
  return response.blob();
}

export async function ensureStudentAssetLocal(session, asset = {}) {
  const id = safeTrim(asset?.id || asset?.assetId || '', 100);
  if (!id) return null;
  const blob = await fetchStudentAssetBlob(session, id);
  return importAssetBlob(blob, {
    id,
    name: asset.name || asset.fileName || 'student-file',
    type: asset.type || asset.mimeType || blob.type || 'application/octet-stream',
    kind: asset.kind || 'student-resource',
    sha256: asset.sha256,
    size: asset.size || blob.size,
  });
}

export function mergeStudentPortalSnapshot(localData = {}, payload = {}, sessionOverride = null) {
  const snapshot = payload.data || payload || {};
  const cloudStudent = payload.student || snapshot.students?.[0];
  if (!cloudStudent) throw new Error('لم تُرجع المنصة بيانات الطالب.');
  const localStudents = Array.isArray(localData.students) ? localData.students : [];
  const existing = localStudents.find((item) => String(item.id) === String(cloudStudent.id) || String(item.code) === String(cloudStudent.code)) || {};
  const student = { ...existing, ...cloudStudent };
  const studentIndex = localStudents.findIndex((item) => String(item.id) === String(student.id) || String(item.code) === String(student.code));
  const students = studentIndex >= 0
    ? localStudents.map((item, index) => index === studentIndex ? student : item)
    : [...localStudents, student];
  const currentSession = sessionOverride || localData.settings?.studentPortalSession || {};
  const studentPortalSession = {
    ...currentSession,
    endpoint: payload.endpoint || currentSession.endpoint || localData.settings?.cloudSync?.endpoint || '',
    workspaceId: payload.workspaceId || currentSession.workspaceId || localData.settings?.cloudSync?.workspaceId || '',
    studentToken: payload.studentToken || currentSession.studentToken || '',
    expiresAt: payload.expiresAt || currentSession.expiresAt || '',
    studentId: student.id,
    studentCode: student.code,
    lastPullAt: new Date().toISOString(),
    lastError: '',
  };
  return {
    ...localData,
    students,
    attendance: mergeRecords(localData.attendance, snapshot.attendance),
    grades: mergeRecords(localData.grades, snapshot.grades),
    payments: mergeRecords(localData.payments, snapshot.payments),
    achievements: mergeRecords(localData.achievements, snapshot.achievements),
    gameResults: mergeRecords(localData.gameResults, snapshot.gameResults),
    mapResults: mergeRecords(localData.mapResults, snapshot.mapResults),
    contentLibrary: mergeRecords(localData.contentLibrary, snapshot.contentLibrary),
    lessonRecordings: mergeRecords(localData.lessonRecordings, snapshot.lessonRecordings),
    customQuestionBank: mergeRecords(localData.customQuestionBank, snapshot.customQuestionBank),
    settings: {
      ...localData.settings,
      ...(snapshot.settings || {}),
      cloudSync: {
        ...(localData.settings?.cloudSync || {}),
        endpoint: studentPortalSession.endpoint,
        workspaceId: studentPortalSession.workspaceId,
        publicAppUrl: snapshot.settings?.cloudSync?.publicAppUrl || localData.settings?.cloudSync?.publicAppUrl || '',
        token: localData.settings?.cloudSync?.token || '',
      },
      studentPortalSession,
    },
  };
}

export async function mergeStudentLoginSnapshot(localData = {}, payload = {}, pin = '') {
  const snapshot = payload.data || {};
  const cloudStudent = payload.student || snapshot.students?.[0];
  if (!cloudStudent) throw new Error('لم تُرجع المنصة بيانات الطالب.');
  const localSecret = await createCredentialSecret(pin, 'student');
  const preparedPayload = {
    ...payload,
    student: { ...cloudStudent, ...localSecret, studentPin: '' },
  };
  return mergeStudentPortalSnapshot(localData, preparedPayload, {
    endpoint: payload.endpoint,
    workspaceId: payload.workspaceId,
    studentToken: payload.studentToken,
    expiresAt: payload.expiresAt || '',
  });
}
