#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FILES_DIR="$SCRIPT_DIR/FILES"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$ROOT/.mobdea-r7-backup-$STAMP"

fail() { echo "❌ $1" >&2; exit 1; }
[[ -f "$ROOT/package.json" ]] || fail "شغّل السكربت من جذر مشروع mobdea-final"
[[ -d "$ROOT/src" ]] || fail "مجلد src غير موجود"

mapfile -t PATCH_FILES < "$SCRIPT_DIR/PATCH_FILES.txt"
mkdir -p "$BACKUP_DIR"

restore_backup() {
  echo "↩️ تتم استعادة الملفات السابقة..."
  local rel
  for rel in "${PATCH_FILES[@]}"; do
    if [[ -f "$BACKUP_DIR/$rel" ]]; then
      mkdir -p "$ROOT/$(dirname "$rel")"
      cp -a "$BACKUP_DIR/$rel" "$ROOT/$rel"
    fi
  done
}
trap 'code=$?; if [[ $code -ne 0 ]]; then restore_backup; echo "❌ لم يكتمل R7؛ تمت استعادة الملفات القديمة."; fi; exit $code' EXIT

for rel in "${PATCH_FILES[@]}"; do
  [[ -f "$ROOT/$rel" ]] || fail "الملف غير موجود في المشروع: $rel"
  [[ -f "$FILES_DIR/$rel" ]] || fail "ملف التحديث مفقود: $rel"
  mkdir -p "$BACKUP_DIR/$(dirname "$rel")"
  cp -a "$ROOT/$rel" "$BACKUP_DIR/$rel"
  cp -a "$FILES_DIR/$rel" "$ROOT/$rel"
done

echo "🔐 تم تطبيق نظام كلمة المرور الموحدة للمعلم والإدارة"

npm run build
if [[ -d "$ROOT/android" ]]; then
  npx cap sync android
fi

trap - EXIT
echo "✅ تم تطبيق MOBDEA R7 بنجاح"
echo "📦 النسخة الاحتياطية: $BACKUP_DIR"
