MOBDEA R7 — Unified Staff Password

- Prevents teacher/admin password creation from the login screen.
- Adds one initial unified password for teacher and admin, stored in source only as a PBKDF2 hash.
- Lets an authorized staff user change the unified password from Settings after entering the current password.
- Changing the password disables the initial factory password on that device.
- Recovery changes teacher and admin passwords together.
- Existing numeric staff PINs remain temporarily compatible for migration.

Important:
Password changes are local to the device data. To propagate them to other devices, use the platform cloud push/pull flow after the cloud service is working.
