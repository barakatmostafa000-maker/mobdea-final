# تطبيق تحديث المُبدع 10.4.0 في Codespaces

## 1. حفظ الحالة الحالية

من داخل المشروع:

```bash
cd /workspaces/mobdea-final

git status --short
git switch -c backup-before-mobdea-10.4.0

git add -A
git commit -m "Backup before Mobdea 10.4.0" || true
```

لا تستخدم `git reset --hard` ولا تفك الضغط مباشرة فوق المشروع قبل إنشاء النسخة الاحتياطية.

## 2. تطبيق ملف الـPatch

ارفع `mobdea-v10.4.0-patch.zip` إلى جذر المشروع، ثم نفّذ:

```bash
cd /workspaces/mobdea-final
rm -rf /tmp/mobdea-v10.4.0-patch
mkdir -p /tmp/mobdea-v10.4.0-patch
unzip -q mobdea-v10.4.0-patch.zip -d /tmp/mobdea-v10.4.0-patch

rsync -a \
  --exclude 'APPLY_PATCH_10_4_AR.md' \
  --exclude 'MOBDEA_10_4_0_IMPLEMENTATION_AR.md' \
  --exclude 'CHANGED_FILES_10_4_0.txt' \
  --exclude 'MOBDEA_10_4_0_VALIDATION.log' \
  --exclude 'MOBDEA_10_4_0_JSX_SYNTAX.log' \
  --exclude 'MOBDEA_10_4_0_CSS_CHECK.log' \
  --exclude 'MOBDEA_10_4_0_BUILD_ATTEMPT.log' \
  /tmp/mobdea-v10.4.0-patch/mobdea-v10.4.0-patch/ \
  /workspaces/mobdea-final/
```

يمكن نسخ ملفات التقارير إلى الجذر أيضًا عند الحاجة؛ استبعادها أعلاه لا يؤثر في التطبيق.

## 3. تثبيت الحزم والتحقق

```bash
cd /workspaces/mobdea-final
npm ci
npm test
npm run lint
npm run format:check
npm run verify:static
npm run build
npx cap sync android
```

المطلوب أن تظهر الاختبارات بدون فشل، ثم ينجح بناء Vite ومزامنة Capacitor.

## 4. بناء APK

```bash
cd /workspaces/mobdea-final

JAVA21_HOME="$(find /usr/lib/jvm -maxdepth 1 -type d -name 'java-21-openjdk-*' | head -n 1)"
export JAVA_HOME="$JAVA21_HOME"
export ANDROID_HOME="$HOME/Android/Sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"

printf 'sdk.dir=%s\n' "$ANDROID_HOME" > android/local.properties

cd android
./gradlew --stop || true
./gradlew -version
rm -rf app/build
./gradlew clean assembleDebug --no-build-cache
```

تأكد أن Gradle يعرض Java 21. ستجد الملف هنا:

```text
/workspaces/mobdea-final/android/app/build/outputs/apk/debug/app-debug.apk
```

## 5. تثبيت واختبار نظيف

لمنع بقاء Cache من إصدار أقدم:

- احذف النسخة التجريبية السابقة أو امسح بياناتها بعد حفظ أي بيانات مهمة.
- ثبّت APK الجديد.
- اختبر الموبايل والتابلت قبل دمج الفرع في `main`.

## 6. حفظ الإصدار في GitHub بعد الاختبار

```bash
cd /workspaces/mobdea-final
git add -A
git commit -m "Release Mobdea 10.4.0 responsive class mode and sync fixes"
git push -u origin HEAD
```
