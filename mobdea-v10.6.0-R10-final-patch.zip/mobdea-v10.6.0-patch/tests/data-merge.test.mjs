import test from 'node:test';
import assert from 'node:assert/strict';
import {
  hasDuplicateStudentCodes,
  mergeAppData,
  mergeStudents,
} from '../src/services/dataMerge.js';

test('student merge keeps both devices and repairs duplicate codes', () => {
  const merged = mergeStudents(
    [{ id: 1, code: 1, name: 'أحمد', grade: 'الأول' }, { id: 3, code: 2, name: 'محمود', grade: 'الأول' }],
    [{ id: 2, code: 2, name: 'سارة', grade: 'الأول' }],
  );
  assert.equal(merged.length, 3);
  assert.equal(hasDuplicateStudentCodes(merged), false);
  assert.deepEqual(new Set(merged.map((item) => item.code)).size, 3);
});

test('cloud merge preserves local cloud secret and remote records', () => {
  const merged = mergeAppData(
    { students: [{ id: 1, code: 1, name: 'أحمد' }], settings: { cloudSync: { endpoint: 'https://sync.example', workspaceId: 'main', token: 'local-secret-token-1234567890' } } },
    { students: [{ id: 2, code: 2, name: 'سارة' }], settings: { cloudSync: { token: '', revision: 'r2' } } },
  );
  assert.equal(merged.students.length, 2);
  assert.equal(merged.settings.cloudSync.token, 'local-secret-token-1234567890');
  assert.equal(merged.settings.cloudSync.revision, 'r2');
});

test('local record wins when both devices have no usable timestamp', () => {
  const merged = mergeStudents(
    [{ id: 7, code: 7, name: 'الاسم المحلي الجديد', grade: 'الثاني' }],
    [{ id: 7, code: 7, name: 'الاسم السحابي القديم', grade: 'الأول' }],
  );
  assert.equal(merged.length, 1);
  assert.equal(merged[0].name, 'الاسم المحلي الجديد');
  assert.equal(merged[0].grade, 'الثاني');
});
