import { useRef, useState } from 'react';
import { Play, Plus, Trash2 } from 'lucide-react';
import { speakWelcome, playVoiceClip } from '../services/voice';
import {
  createRecoverySecret, createStaffPasswordSecret, hasStaffPasswordSecret,
  verifyFactoryStaffPassword, verifyStaffPasswordSecret,
} from '../utils/security';
import { downloadBackup, readBackupFile, restoreBackupAssets } from '../services/backup';
import { pullCloudData, pushCloudData, testCloudConnection } from '../services/cloudSync';
import { checkForUpdate } from '../services/updater';
import { release } from '../config/release';
import { deleteAsset, storeAsset } from '../services/assetStore';
import { normalizeAppData } from '../services/storage';
import { mergeAppData, normalizeStudentCodes } from '../services/dataMerge';
import { copyToClipboard } from '../services/share';
import { decodeSharePayload, encodeSharePayload } from '../utils/shareCodec';
import { secureVaultLevel } from '../services/secureVault';

const clipTypes = [
  ['welcome', 'الترحيب'],
  ['excellent', 'ممتاز'],
  ['close', 'قريبة'],
  ['retry', 'حاول تاني'],
  ['calm', 'هدوء'],
  ['comic', 'كوميدي'],
  ['correct', 'صوت الإجابة الصحيحة'],
  ['wrong', 'صوت الخطأ'],
  ['win', 'صوت الفوز']
];

export default function Settings({ data, updateData, resetAppData }) {
  const [currentStaffPassword, setCurrentStaffPassword] = useState('');
  const [newStaffPassword, setNewStaffPassword] = useState('');
  const [confirmStaffPassword, setConfirmStaffPassword] = useState('');
  const [recoveryQuestion, setRecoveryQuestion] = useState(data.settings.staffRecoveryQuestion || '');
  const [recoveryAnswer, setRecoveryAnswer] = useState('');
  const [notice, setNotice] = useState('');
  const [updateCheckResult, setUpdateCheckResult] = useState(null);
  const [updateChecking, setUpdateChecking] = useState(false);
  const [backupPassword, setBackupPassword] = useState('');
  const [backupIncludeAssets, setBackupIncludeAssets] = useState(true);
  const [backupBusy, setBackupBusy] = useState(false);

  const runManualUpdateCheck = async () => {
    setUpdateChecking(true);
    setUpdateCheckResult(null);
    try {
      const result = await checkForUpdate(data.settings, release.appVersion);
      setUpdateCheckResult(result.available
        ? `يتوفر إصدار جديد: ${result.version} (الحالي: ${release.displayVersion})`
        : `التطبيق محدّث بالفعل (${release.displayVersion}).`);
    } catch (error) {
      setUpdateCheckResult(error.message || 'تعذر التحقق من التحديث.');
    } finally {
      setUpdateChecking(false);
    }
  };
  const [syncing, setSyncing] = useState(false);
  const [clipTitle, setClipTitle] = useState('');
  const [clipType, setClipType] = useState('excellent');
  const [clipText, setClipText] = useState('');
  const [clipInfo, setClipInfo] = useState('');
  const fileRef = useRef(null);
  const clipFileRef = useRef(null);

  const patchSettings = (patch) => updateData((current) => ({ ...current, settings: { ...current.settings, ...patch } }));
  const patchVisible = (key, value) => updateData((current) => ({
    ...current,
    settings: { ...current.settings, visibleModules: { ...current.settings.visibleModules, [key]: value } },
  }));
  const patchCloud = (patch, options = {}) => updateData((current) => ({
    ...current,
    settings: { ...current.settings, cloudSync: { ...current.settings.cloudSync, ...patch } },
  }), options);

  const saveStaffPassword = async () => {
    const current = currentStaffPassword.normalize('NFKC').trim();
    const next = newStaffPassword.normalize('NFKC').trim();
    const confirm = confirmStaffPassword.normalize('NFKC').trim();
    if (!current) { setNotice('اكتب كلمة المرور الحالية أولًا.'); return; }
    if (next.length < 8) { setNotice('كلمة المرور الجديدة يجب ألا تقل عن 8 خانات.'); return; }
    if (next !== confirm) { setNotice('تأكيد كلمة المرور غير مطابق.'); return; }

    const teacherConfigured = hasStaffPasswordSecret(data.settings, 'teacher');
    const adminConfigured = hasStaffPasswordSecret(data.settings, 'admin');
    const checks = [];
    if (teacherConfigured) checks.push(verifyStaffPasswordSecret(current, data.settings, 'teacher'));
    if (adminConfigured) checks.push(verifyStaffPasswordSecret(current, data.settings, 'admin'));
    if (data.settings?.staffFactoryPasswordDisabled !== true) checks.push(verifyFactoryStaffPassword(current));
    const verified = (await Promise.all(checks)).some(Boolean);
    if (!verified) { setNotice('كلمة المرور الحالية غير صحيحة.'); return; }

    const teacherSecret = await createStaffPasswordSecret(next, 'teacher');
    const adminSecret = await createStaffPasswordSecret(next, 'admin');
    await patchSettings({ teacherPin: '', adminPin: '', staffFactoryPasswordDisabled: true, ...teacherSecret, ...adminSecret });
    setCurrentStaffPassword('');
    setNewStaffPassword('');
    setConfirmStaffPassword('');
    setNotice('تم تغيير كلمة المرور الموحدة للمعلم والإدارة وتعطيل كلمة المرور الأولية على هذا الجهاز.');
  };

  const saveRecovery = async () => {
    if (recoveryAnswer.trim().length < 10) { setNotice('عبارة الاسترجاع يجب ألا تقل عن 10 أحرف ويُفضّل أن تكون جملة لا يعرفها غيرك.'); return; }
    const secret = await createRecoverySecret(recoveryAnswer);
    await patchSettings({ staffRecoveryQuestion: recoveryQuestion.trim(), ...secret });
    setRecoveryAnswer('');
    setNotice('تم حفظ عبارة الاسترجاع، ويمكن استخدامها من شاشة الدخول عند نسيان الرقم السري');
  };

  const restore = async (file) => {
    try {
      const restored = await readBackupFile(file, backupPassword);
      await restoreBackupAssets(restored.assets);
      await updateData(normalizeAppData(restored.data));
      setNotice('تمت استعادة النسخة الاحتياطية بنجاح');
    } catch (error) {
      setNotice(error.message || 'تعذر استعادة النسخة');
    }
  };

  const testCloud = async () => {
    setSyncing(true);
    try { await testCloudConnection(data.settings); setNotice('تم الاتصال بخادم المزامنة بنجاح'); }
    catch (error) { setNotice(error.message); }
    finally { setSyncing(false); }
  };

  const pushCloud = async () => {
    setSyncing(true);
    try {
      const result = await pushCloudData(data);
      await patchCloud({ revision: result.revision, lastPushAt: result.updatedAt || new Date().toISOString(), lastAutoSyncAt: new Date().toISOString(), localChangedAt: '', autoSyncError: '' }, { skipCloudDirty: true });
      setNotice('تم رفع نسخة المنصة إلى السحابة');
    } catch (error) { setNotice(error.message); }
    finally { setSyncing(false); }
  };

  const pullCloud = async () => {
    if (!window.confirm('سيتم دمج بيانات هذا الجهاز مع النسخة السحابية مع منع تكرار أكواد الطلاب. هل تريد المتابعة؟')) return;
    setSyncing(true);
    try {
      const payload = await pullCloudData(data.settings);
      const merged = mergeAppData(data, payload.data);
      const restored = {
        ...merged,
        students: normalizeStudentCodes(merged.students || []),
        settings: {
          ...merged.settings,
          cloudSync: { ...merged.settings.cloudSync, ...data.settings.cloudSync, revision: payload.revision, lastPullAt: new Date().toISOString(), lastAutoSyncAt: new Date().toISOString(), localChangedAt: '', autoSyncError: '' }
        }
      };
      await updateData(restored, { skipCloudDirty: true });
      setNotice('تم دمج بيانات الجهاز مع النسخة السحابية ومنع تكرار أكواد الطلاب.');
    } catch (error) { setNotice(error.message); }
    finally { setSyncing(false); }
  };

  const copySyncSetup = async () => {
    const endpoint = String(cloud.endpoint || '').trim();
    const workspaceId = String(cloud.workspaceId || '').trim();
    const token = String(cloud.token || '').trim();
    if (!endpoint.startsWith('https://') || workspaceId.length < 3 || token.length < 24) {
      setNotice('أكمل رابط الخادم ومساحة العمل والرمز السري قبل نسخ إعداد الجهاز.');
      return;
    }
    const code = `MOBDEA-SYNC-1.${encodeSharePayload({
      endpoint,
      workspaceId,
      token,
      publicAppUrl: String(cloud.publicAppUrl || '').trim(),
      autoSync: cloud.autoSync !== false,
      autoSyncIntervalMinutes: Number(cloud.autoSyncIntervalMinutes || 2),
    })}`;
    const copied = await copyToClipboard(code);
    setNotice(copied
      ? 'تم نسخ إعداد الجهاز. الصقه مرة واحدة في التابلت، ولا ترسله لأي شخص لأنه يحتوي الرمز السري.'
      : 'تعذر النسخ التلقائي. اسمح للتطبيق باستخدام الحافظة ثم أعد المحاولة.');
  };

  const importSyncSetup = async () => {
    const raw = globalThis.prompt?.('الصق رمز إعداد المزامنة المنسوخ من الجهاز الأساسي:') || '';
    if (!raw.trim()) return;
    const prefix = 'MOBDEA-SYNC-1.';
    const payload = raw.trim().startsWith(prefix)
      ? decodeSharePayload(raw.trim().slice(prefix.length))
      : null;
    if (!payload || !String(payload.endpoint || '').startsWith('https://') || String(payload.workspaceId || '').length < 3 || String(payload.token || '').length < 24) {
      setNotice('رمز إعداد الجهاز غير صالح أو ناقص.');
      return;
    }
    await patchCloud({
      endpoint: String(payload.endpoint).trim(),
      workspaceId: String(payload.workspaceId).trim(),
      token: String(payload.token),
      publicAppUrl: String(payload.publicAppUrl || '').trim(),
      autoSync: payload.autoSync !== false,
      autoSyncIntervalMinutes: Math.max(1, Math.min(60, Number(payload.autoSyncIntervalMinutes || 2))),
      revision: '',
      autoSyncError: '',
      localChangedAt: new Date().toISOString(),
    });
    setNotice('تم استيراد إعداد الجهاز. اضغط اختبار الاتصال ثم تنزيل الآن لدمج بيانات الجهازين.');
  };

  const addVoiceClip = async (file) => {
    if (!file) return;
    try {
      const asset = await storeAsset(file, { name: file.name, type: file.type, kind: 'voice' });
      const nextClip = {
        id: Date.now(),
        title: clipTitle.trim() || file.name.replace(/\.[^.]+$/, ''),
        phraseType: clipType,
        text: clipText.trim(),
        url: '',
        assetId: asset.id,
        mimeType: asset.type,
        fileName: asset.name,
        fileSize: asset.size,
        createdAt: new Date().toISOString(),
      };
      const voiceClips = [...(data.settings.voiceClips || []), nextClip];
      await patchSettings({ voiceClips });
      setClipInfo(`تم تشفير الصوت وإضافته: ${nextClip.title}`);
      setClipTitle('');
      setClipText('');
    } catch (error) {
      setClipInfo(error?.message || 'تعذر إضافة الملف الصوتي.');
    } finally {
      if (clipFileRef.current) clipFileRef.current.value = '';
    }
  };

  const removeVoiceClip = async (id) => {
    const clip = (data.settings.voiceClips || []).find((item) => item.id === id);
    const voiceClips = (data.settings.voiceClips || []).filter((item) => item.id !== id);
    await patchSettings({ voiceClips });
    if (clip?.assetId) await deleteAsset(clip.assetId).catch(() => {});
  };

  const previewClip = (clip) => {
    const played = playVoiceClip({ voiceClips: [clip] }, clip.phraseType);
    if (!played) setNotice('تعذر تشغيل الصوت.');
  };

  const exportBackup = async () => {
    setBackupBusy(true);
    try {
      await downloadBackup(data, backupPassword, { includeAssets: backupIncludeAssets });
      setNotice('تم إنشاء نسخة احتياطية مشفرة. احتفظ بكلمة المرور؛ لا يمكن فتح النسخة بدونها.');
    } catch (error) {
      setNotice(error?.message || 'تعذر إنشاء النسخة الاحتياطية.');
    } finally {
      setBackupBusy(false);
    }
  };

  const cloud = data.settings.cloudSync || {};
  const voiceClips = Array.isArray(data.settings.voiceClips) ? data.settings.voiceClips : [];

  return <section className="page">
    <div className="page-heading"><div><span className="eyebrow">الحماية والتحكم</span><h2>إعدادات المنصة</h2><p>حدد ما يظهر، فعّل القفل، وتحكم في الصوت والنسخ والمزامنة.</p></div></div>
    {notice && <div className="settings-notice">{notice}</div>}
    <div className="settings-grid">
      <article className="panel"><h3>الحماية</h3>
        <label className="setting-row"><span>تفعيل قفل الإدارة</span><input type="checkbox" checked={data.settings.lockEnabled} onChange={(e) => patchSettings({ lockEnabled: e.target.checked })}/></label>
        <p className="settings-help">كلمة مرور واحدة للمعلم والإدارة. لتغييرها يجب كتابة كلمة المرور الحالية أولًا.</p>
        <label className="setting-row"><span>كلمة المرور الحالية</span><input type="password" maxLength="128" value={currentStaffPassword} placeholder="كلمة المرور الحالية" autoComplete="current-password" onChange={(e) => setCurrentStaffPassword(e.target.value.slice(0, 128))}/></label>
        <label className="setting-row"><span>كلمة المرور الجديدة</span><input type="password" maxLength="128" value={newStaffPassword} placeholder="8 خانات على الأقل" autoComplete="new-password" onChange={(e) => setNewStaffPassword(e.target.value.slice(0, 128))}/></label>
        <label className="setting-row"><span>تأكيد كلمة المرور</span><input type="password" maxLength="128" value={confirmStaffPassword} placeholder="أعد كتابة كلمة المرور" autoComplete="new-password" onChange={(e) => setConfirmStaffPassword(e.target.value.slice(0, 128))}/></label>
        <label className="setting-row"><span>القفل بعد عدم الاستخدام</span><select value={data.settings.lockAfterMinutes || 10} onChange={(e)=>patchSettings({lockAfterMinutes:Number(e.target.value)})}><option value="5">5 دقائق</option><option value="10">10 دقائق</option><option value="20">20 دقيقة</option><option value="30">30 دقيقة</option></select></label>
        <button className="primary-btn" onClick={saveStaffPassword}>تغيير كلمة مرور المعلم والإدارة</button>

        <div className="settings-divider" />
        <p className="settings-help">استخدم عبارة استرجاع طويلة لا يعرفها غيرك. التلميح اختياري ولا تُكتب فيه العبارة نفسها.</p>
        <label className="setting-row"><span>تلميح اختياري</span><input value={recoveryQuestion} placeholder="تلميح يساعدك على تذكر العبارة" onChange={(e)=>setRecoveryQuestion(e.target.value)}/></label>
        <label className="setting-row"><span>عبارة الاسترجاع</span><input type="password" value={recoveryAnswer} placeholder={data.settings.staffRecoveryAnswerHash ? 'إجابة محفوظة — اكتب إجابة جديدة لتغييرها' : 'اكتب الإجابة'} onChange={(e)=>setRecoveryAnswer(e.target.value)}/></label>
        <button className="secondary-btn" onClick={saveRecovery}>حفظ عبارة الاسترجاع</button>
      </article>

      <article className="panel"><h3>التحكم فيما يظهر</h3>
        {Object.entries({ games:'الألعاب', grades:'الدرجات', payments:'الحسابات', reports:'التقارير', messages:'رسائل أولياء الأمور' }).map(([key,label]) =>
          <label className="setting-row" key={key}><span>{label}</span><input type="checkbox" checked={data.settings.visibleModules[key] !== false} onChange={(e) => patchVisible(key,e.target.checked)}/></label>
        )}
      </article>

      <article className="panel"><h3>الصوت والتشجيع</h3>
        <label className="setting-row"><span>تشغيل الأصوات</span><input type="checkbox" checked={data.settings.voiceEnabled} onChange={(e)=>patchSettings({voiceEnabled:e.target.checked})}/></label>
        <label className="setting-row"><span>الترحيب عند الفتح</span><input type="checkbox" checked={data.settings.welcomeVoice} onChange={(e)=>patchSettings({welcomeVoice:e.target.checked})}/></label>
        <label className="setting-row"><span>مستوى الصوت</span><input type="range" min="0" max="1" step="0.1" value={data.settings.voiceVolume} onChange={(e)=>patchSettings({voiceVolume:Number(e.target.value)})}/></label>
        <button className="secondary-btn" onClick={()=>speakWelcome(data.settings)}>تجربة صوت الترحيب</button>

        <div className="voice-clips-box">
          <div className="voice-clips-header">
            <strong>أصوات مخصصة من الموبايل</strong>
            <small>اربط كل صوت بفئة تشجيعية</small>
          </div>
          <div className="voice-clip-form">
            <input placeholder="اسم الصوت" value={clipTitle} onChange={(e) => setClipTitle(e.target.value)} />
            <select value={clipType} onChange={(e) => setClipType(e.target.value)}>
              {clipTypes.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
            </select>
            <input placeholder="الجملة المكتوبة أو الوصف" value={clipText} onChange={(e) => setClipText(e.target.value)} />
            <button type="button" className="secondary-btn" onClick={() => clipFileRef.current?.click()}><Plus size={16}/> رفع ملف صوت</button>
          </div>
          <input ref={clipFileRef} type="file" accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg" hidden onChange={(e) => addVoiceClip(e.target.files?.[0])} />
          <div className="voice-clips-list">
            {voiceClips.length ? voiceClips.map((clip) => (
              <div className="voice-clip-item" key={clip.id}>
                <div>
                  <strong>{clip.title}</strong>
                  <small>{clipTypes.find(([value]) => value === clip.phraseType)?.[1] || clip.phraseType} • {clip.fileName || clip.text || 'صوت مخصص'}</small>
                </div>
                <div className="voice-clip-actions">
                  <button className="secondary-btn" onClick={() => previewClip(clip)}><Play size={16}/> تشغيل</button>
                  <button className="secondary-btn danger-text" onClick={() => removeVoiceClip(clip.id)}><Trash2 size={16}/> حذف</button>
                </div>
              </div>
            )) : <small className="settings-help">لا توجد أصوات مخصصة بعد.</small>}
          </div>
          {clipInfo && <div className="settings-notice">{clipInfo}</div>}
        </div>
      </article>

      <article className="panel cloud-settings"><h3>المزامنة السحابية</h3><p className="settings-help">تعمل المنصة Offline بدون إعداد. بعد نشر خادم المزامنة يمكنك الرفع والتنزيل من أي جهاز.</p>
        <label><span>رابط الخادم</span><input placeholder="https://mobdea-sync...workers.dev" value={cloud.endpoint || ''} onChange={(e)=>patchCloud({endpoint:e.target.value.trim()})}/></label>
        <label><span>مساحة العمل</span><input placeholder="mostafa-center-main" value={cloud.workspaceId || ''} onChange={(e)=>patchCloud({workspaceId:e.target.value.trim()})}/></label>
        <label><span>الرمز السري</span><input type="password" value={cloud.token || ''} onChange={(e)=>patchCloud({token:e.target.value})}/></label>
        <label><span>رابط صفحة الطلاب العامة</span><input type="url" placeholder="https://your-project.pages.dev/" value={cloud.publicAppUrl || ''} onChange={(e)=>patchCloud({publicAppUrl:e.target.value.trim()})}/><small className="settings-help">يجب أن يكون رابط نسخة الويب المنشورة، وليس رابط Codespaces أو رابط الخادم.</small></label>
        <label className="setting-row"><span>مزامنة تلقائية بين الأجهزة</span><input type="checkbox" checked={cloud.autoSync !== false} onChange={(e)=>patchCloud({autoSync:e.target.checked,autoSyncError:''})}/></label>
        <label className="setting-row"><span>تكرار المزامنة</span><select value={cloud.autoSyncIntervalMinutes || 2} onChange={(e)=>patchCloud({autoSyncIntervalMinutes:Number(e.target.value)})}><option value="1">كل دقيقة</option><option value="2">كل دقيقتين</option><option value="5">كل 5 دقائق</option><option value="10">كل 10 دقائق</option></select></label>
        <label className="setting-row"><span>نسخ سحابي تلقائي</span><input type="checkbox" checked={cloud.autoBackup === true} onChange={(e)=>patchCloud({autoBackup:e.target.checked,autoBackupError:''})}/></label>
        <label className="setting-row"><span>تكرار النسخ التلقائي</span><select value={cloud.autoBackupIntervalHours || 24} onChange={(e)=>patchCloud({autoBackupIntervalHours:Number(e.target.value)})}><option value="6">كل 6 ساعات</option><option value="12">كل 12 ساعة</option><option value="24">يوميًا</option><option value="72">كل 3 أيام</option><option value="168">أسبوعيًا</option></select></label>
        <div className="backup-actions"><button className="secondary-btn" disabled={syncing} onClick={testCloud}>اختبار الاتصال</button><button className="primary-btn" disabled={syncing} onClick={pushCloud}>رفع الآن</button><button className="secondary-btn" disabled={syncing} onClick={pullCloud}>تنزيل الآن</button></div>
        <div className="backup-actions sync-device-actions"><button className="secondary-btn" type="button" onClick={copySyncSetup}>نسخ إعداد الجهاز</button><button className="secondary-btn" type="button" onClick={importSyncSetup}>استيراد إعداد جهاز</button></div>
        <small className="settings-help">لن تتزامن الأجهزة إلا عند استخدام نفس رابط الخادم ومساحة العمل والرمز السري. رمز إعداد الجهاز حساس ولا يُشارك خارج أجهزتك.</small>
        {(cloud.lastPushAt || cloud.lastPullAt || cloud.lastAutoSyncAt || cloud.lastAutoBackupAt) && <small className="sync-times">آخر رفع: {cloud.lastPushAt || '—'}<br/>آخر تنزيل: {cloud.lastPullAt || '—'}<br/>آخر مزامنة تلقائية: {cloud.lastAutoSyncAt || '—'}<br/>آخر نسخة تلقائية: {cloud.lastAutoBackupAt || '—'}</small>}
        {cloud.autoSyncError && <small className="settings-help danger-text">آخر خطأ في المزامنة: {cloud.autoSyncError}</small>}
        {cloud.autoBackupError && <small className="settings-help danger-text">آخر خطأ في النسخ التلقائي: {cloud.autoBackupError}</small>}
      </article>

      <article className="panel"><h3>النسخ الاحتياطي المشفّر</h3><p className="settings-help">تُشفّر النسخة بـ AES-256 ولا يمكن استعادتها دون كلمة المرور. مستوى حماية المفاتيح الحالي: {secureVaultLevel() === 'android-keystore' ? 'Android Keystore' : 'تخزين المتصفح (أضعف من تطبيق Android)'}.</p>
        <label className="setting-row"><span>كلمة مرور النسخة</span><input type="password" minLength="10" value={backupPassword} placeholder="10 أحرف على الأقل" onChange={(e)=>setBackupPassword(e.target.value)}/></label>
        <label className="setting-row"><span>تضمين الملفات والصوت</span><input type="checkbox" checked={backupIncludeAssets} onChange={(e)=>setBackupIncludeAssets(e.target.checked)}/></label>
        <div className="backup-actions"><button className="primary-btn" disabled={backupBusy} onClick={exportBackup}>{backupBusy ? 'جارٍ التشفير...' : 'تصدير نسخة مشفرة'}</button><button className="secondary-btn" disabled={backupBusy} onClick={()=>fileRef.current?.click()}>استعادة نسخة</button></div>
        <input ref={fileRef} type="file" accept="application/json,.json,.mobdea" hidden onChange={(e)=>e.target.files?.[0]&&restore(e.target.files[0])}/>
      </article>

      <article className="panel"><h3>تحديث التطبيق</h3><p className="settings-help">يجب أن يكون ملف التحديث عبر HTTPS ويحتوي على version وapkUrl وsha256 وsizeBytes وpackageName. يتحقق تطبيق Android من البصمة والتوقيع قبل التثبيت.</p>
        <label className="setting-row"><span>رابط Manifest</span><input value={data.settings.update?.manifestUrl || ''} placeholder="https://.../update.json" onChange={(e)=>patchSettings({update:{...(data.settings.update||{}),manifestUrl:e.target.value.trim()}})}/></label>
        <label className="setting-row"><span>الفحص عند فتح التطبيق</span><input type="checkbox" checked={data.settings.update?.autoCheck !== false} onChange={(e)=>patchSettings({update:{...(data.settings.update||{}),autoCheck:e.target.checked}})}/></label>
        <button className="secondary-btn" onClick={runManualUpdateCheck} disabled={updateChecking}>{updateChecking ? 'جارٍ التحقق...' : 'التحقق من وجود تحديثات الآن'}</button>
        {updateCheckResult && <p className="settings-help">{updateCheckResult}</p>}
      </article>

      <article className="panel"><h3>البيانات التجريبية</h3><button className="danger-btn" onClick={async()=>updateData(await resetAppData())}>إعادة البيانات التجريبية</button></article>
    </div>
  </section>;
}
