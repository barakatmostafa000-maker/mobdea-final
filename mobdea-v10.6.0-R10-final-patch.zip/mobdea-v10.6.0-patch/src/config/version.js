export const APP_VERSION = '10.6.0';
export const APP_VERSION_CODE = 108;
export const DATA_SCHEMA_VERSION = 12;
export const RELEASE_CHANNEL = 'stable';
export const RELEASE_TAG = 'R10';
