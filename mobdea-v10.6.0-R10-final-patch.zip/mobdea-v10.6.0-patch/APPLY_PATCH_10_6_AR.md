# تطبيق باتش منصة المُبدع 10.6.0 — R10

هذا الباتش يُطبَّق فوق نسخة **10.4.0** التي تم اختبارها، ويشمل كل تعديلات 10.5.0 السابقة بالإضافة إلى إصلاحات التابلت والمزامنة وتحديات الأونلاين.

## 1) سحب الباتش من المستودع

بعد رفع `mobdea-v10.6.0-R10-final-patch.zip` إلى جذر GitHub:

```bash
cd /workspaces/mobdea-final
git fetch origin main
git restore --source=origin/main -- mobdea-v10.6.0-R10-final-patch.zip
ls -lh mobdea-v10.6.0-R10-final-patch.zip
```

## 2) نسخة احتياطية وفرع مستقل

```bash
cd /workspaces/mobdea-final
cp mobdea-v10.6.0-R10-final-patch.zip /workspaces/
git stash push -u -m "Backup before Mobdea 10.6.0 R10"
git switch -c "mobdea-10.6.0-r10-$(date +%Y%m%d-%H%M)"
cp /workspaces/mobdea-v10.6.0-R10-final-patch.zip .
```

## 3) فحص وتطبيق الباتش بأمان

```bash
cd /workspaces/mobdea-final
rm -rf /tmp/mobdea-10.6-patch
mkdir -p /tmp/mobdea-10.6-patch

python3 - <<'PY'
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import json

archive_path = Path('mobdea-v10.6.0-R10-final-patch.zip')
target = Path('/tmp/mobdea-10.6-patch')

with ZipFile(archive_path) as archive:
    unsafe = []
    for name in archive.namelist():
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts:
            unsafe.append(name)
    if unsafe:
        raise SystemExit('❌ مسارات غير آمنة:\n' + '\n'.join(unsafe))
    archive.extractall(target)

roots = [target] + [item for item in target.iterdir() if item.is_dir()]
patch_root = None
for candidate in roots:
    package_file = candidate / 'package.json'
    if not package_file.exists():
        continue
    try:
        package = json.loads(package_file.read_text(encoding='utf-8'))
    except Exception:
        continue
    if package.get('version') == '10.6.0':
        patch_root = candidate
        break

if patch_root is None:
    raise SystemExit('❌ لم يتم العثور على package.json بإصدار 10.6.0')

Path('/tmp/mobdea-10.6-root.txt').write_text(str(patch_root), encoding='utf-8')
print('✅ الباتش آمن')
print('✅ الإصدار: 10.6.0')
print('✅ المسار:', patch_root)
PY

PATCH_ROOT="$(cat /tmp/mobdea-10.6-root.txt)"
rsync -a \
  --exclude='.git/' \
  --exclude='.env' \
  --exclude='.env.*' \
  --exclude='node_modules/' \
  --exclude='dist/' \
  --exclude='android/.gradle/' \
  --exclude='android/app/build/' \
  --exclude='android/local.properties' \
  --exclude='*.jks' \
  --exclude='*.keystore' \
  "$PATCH_ROOT"/ ./

node -p "require('./package.json').version"
grep -nE 'versionCode|versionName' android/app/build.gradle
git status --short
```

المطلوب: `10.6.0` و`versionCode 108` و`versionName "10.6.0"`.

## 4) الاختبارات والبناء

```bash
cd /workspaces/mobdea-final
npm ci
npm run verify
npx cap sync android
```

يجب أن تنتهي الاختبارات بـ `fail 0` ويجب أن ينجح Vite build.

## 5) بناء APK

```bash
cd /workspaces/mobdea-final
JAVA21_HOME="$(find /usr/lib/jvm -maxdepth 1 -type d -name 'java-21-openjdk-*' | head -n 1)"
export JAVA_HOME="$JAVA21_HOME"
export ANDROID_HOME="$HOME/Android/Sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"
printf 'sdk.dir=%s\n' "$ANDROID_HOME" > android/local.properties
sed -i '/^org\.gradle\.java\.home=/d' android/gradle.properties
echo "org.gradle.java.home=$JAVA21_HOME" >> android/gradle.properties
cd android
./gradlew --stop || true
rm -rf app/build
./gradlew clean assembleDebug --no-build-cache
```

ثم:

```bash
cd /workspaces/mobdea-final
cp android/app/build/outputs/apk/debug/app-debug.apk Mobdea-v10.6.0-R10-debug.apk
ls -lh Mobdea-v10.6.0-R10-debug.apk
```

## 6) خطوة إلزامية للأونلاين وتحدي الطالبين

بناء APK وحده لا يكفي. يجب نشر **Cloud Worker المعدل** ثم نشر نسخة الويب الجديدة التي تحتوي `join.html`.

```bash
cd /workspaces/mobdea-final
npx wrangler deploy --config cloud-worker/wrangler.jsonc
```

ثم انشر محتويات `dist` على رابط صفحة الطلاب الموجود في الإعدادات. عند استخدام GitHub Pages، فعّل Pages على المستودع ثم ارفع التغييرات إلى `main` ليعمل Workflow الموجود في `.github/workflows/deploy-web.yml`.

في التطبيق على الموبايل والتابلت استخدم نفس:

- رابط Cloud Worker.
- معرّف مساحة العمل.
- الرمز السري.
- رابط صفحة الطلاب العامة.

يمكن نسخ الإعداد كاملًا من جهاز واستيراده في الجهاز الآخر من صفحة الإعدادات.

## 7) اختبار القبول قبل الدمج في main

- التابلت يستخدم الشاشة كاملة ولا توجد مساحة سوداء سفلية.
- الصفحات العادية تسحب حتى آخر زر ومعلومة.
- طالب مضاف على الموبايل يظهر على التابلت والعكس.
- لا يمكن حفظ كود طالب مكرر.
- وضع الحصة يفتح الصف والدرس وكتاب الشرح ووسائط الدرس.
- الصور والفيديو وPDF وPowerPoint تملأ شاشة العرض مع السابق/التالي.
- الخريطة تظهر داخل وضع الحصة وتحدي الخرائط.
- رابط تحدي الطالبين يفتح `join.html` ويسمح بالدخول للغرفة.
- الصوت والتسجيل والحصة الأونلاين يجربان فعليًا على الجهازين.

لا تدمج الفرع في `main` إلا بعد هذه التجربة.
