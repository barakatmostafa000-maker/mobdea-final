import { BrowserRouter, Routes, Route, useNavigate, Navigate } from 'react-router-dom';
import { DashboardPage, SessionPage, WhiteboardPage } from './modules/almubdi3/pages';

function App() {
  const navigate = useNavigate();

  return (
    <Routes>
      <Route
        path="/dashboard"
        element={
          <DashboardPage
            onNavigate={(route) => navigate(route)}
            onStartSession={() => navigate('/session')}
          />
        }
      />
      <Route path="/session" element={<SessionPage onExit={() => navigate('/dashboard')} />} />
      <Route path="/whiteboard" element={<WhiteboardPage />} />
      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}

export default function AppWrapper() {
  return (
    <BrowserRouter>
      <App />
    </BrowserRouter>
  );
}
