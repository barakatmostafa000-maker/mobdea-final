import type {
  ShortcutCard,
  Announcement,
  ExamItem,
  ScheduleItem,
  StudentItem,
  EncouragementPhrase,
  NotificationItem,
} from '../types';

export const mockShortcuts: ShortcutCard[] = [
  {
    id: 'students',
    title: 'إدارة الطلاب',
    description: 'إضافة الطلاب، تنظيم المجموعات، وربط أولياء الأمور.',
    actionLabel: 'فتح الطلاب',
    route: '/dashboard?section=students',
    icon: 'users',
    color: '#C9A84C',
  },
  {
    id: 'attendance',
    title: 'الحضور والغياب',
    description: 'تسجيل الحضور، التأخير، والغياب بسرعة أثناء الحصة.',
    actionLabel: 'سجل الحضور',
    route: '/session?tab=attendance',
    icon: 'calendarCheck',
    color: '#60A5FA',
  },
  {
    id: 'grades',
    title: 'الدرجات والتقارير',
    description: 'متابعة الأداء وإخراج تقارير منظمة للطلاب.',
    actionLabel: 'عرض الدرجات',
    route: '/dashboard?section=grades',
    icon: 'award',
    color: '#34D399',
  },
  {
    id: 'lessons',
    title: 'الدروس والمحتوى',
    description: 'إدارة المواد، الصفحات، والمرفقات التعليمية.',
    actionLabel: 'إدارة الدروس',
    route: '/session?tab=pdf',
    icon: 'bookOpen',
    color: '#A78BFA',
  },
  {
    id: 'games',
    title: 'الألعاب التعليمية',
    description: 'أنشطة تفاعلية وأسئلة سريعة لرفع التفاعل.',
    actionLabel: 'تشغيل الألعاب',
    route: '/dashboard?section=games',
    icon: 'gamepad2',
    color: '#F97316',
  },
  {
    id: 'library',
    title: 'المكتبة',
    description: 'ملفات PDF، صور، ووسائط تعليمية جاهزة للشرح.',
    actionLabel: 'افتح المكتبة',
    route: '/dashboard?section=library',
    icon: 'library',
    color: '#38BDF8',
  },
];

export const mockAnnouncements: Announcement[] = [
  { id: 'a1', title: 'تم تحديث محتوى الوحدة الثالثة وإضافة أسئلة جديدة.', date: 'اليوم - 8:00 ص', type: 'info' },
  { id: 'a2', title: 'تنبيه: اختبار قصير غدًا للصف الأول الإعدادي.', date: 'أمس - 9:30 م', type: 'exam' },
  { id: 'a3', title: 'تم رفع ملف الخرائط الجديد في المكتبة.', date: 'أمس - 4:15 م', type: 'warning' },
];

export const mockExams: ExamItem[] = [
  { id: 'e1', subject: 'مراجعة الوحدة الثالثة', date: 'الخميس - 1:00 م', group: 'أولى إعدادي' },
  { id: 'e2', subject: 'اختبار خريطة مصر', date: 'السبت - 12:30 م', group: 'ثانية إعدادي' },
  { id: 'e3', subject: 'أسئلة تكميلية على الدرس الأول', date: 'الاثنين - 2:00 م', group: 'ثالثة إعدادي' },
];

export const mockSchedule: ScheduleItem[] = [
  { id: 's1', time: '2:00', title: 'الصف الرابع الابتدائي', group: 'ابتدائي', status: 'upcoming' },
  { id: 's2', time: '3:00', title: 'الصف السادس الابتدائي', group: 'ابتدائي', status: 'upcoming' },
  { id: 's3', time: '4:00', title: 'الصف الأول الإعدادي', group: 'إعدادي', status: 'current' },
  { id: 's4', time: '5:00', title: 'الصف الأول الثانوي', group: 'ثانوي', status: 'upcoming' },
];

export const mockStudents: StudentItem[] = [
  { id: 'st1', name: 'أحمد محمد', points: 24, status: 'present' },
  { id: 'st2', name: 'مريم خالد', points: 31, status: 'present' },
  { id: 'st3', name: 'يوسف علي', points: 18, status: 'late' },
  { id: 'st4', name: 'سلمى حسن', points: 27, status: 'present' },
  { id: 'st5', name: 'نور أحمد', points: 14, status: 'present' },
  { id: 'st6', name: 'حبيبة محمد', points: 21, status: 'present' },
  { id: 'st7', name: 'عبدالرحمن محمود', points: 11, status: 'absent' },
  { id: 'st8', name: 'أسماء رضا', points: 16, status: 'present' },
  { id: 'st9', name: 'عمر سامح', points: 20, status: 'late' },
  { id: 'st10', name: 'جنى كريم', points: 29, status: 'present' },
];

export const mockEncouragementPhrases: EncouragementPhrase[] = [
  { id: 'p1', text: 'أحسنت! إجابة ممتازة.', isFavorite: true },
  { id: 'p2', text: 'خطوة رائعة نحو التفوق.', isFavorite: false },
  { id: 'p3', text: 'استمر بهذا المستوى المميز.', isFavorite: false },
  { id: 'p4', text: 'إجابة قوية جدًا.', isFavorite: true },
];

export const mockNotifications: NotificationItem[] = [
  { id: 'n1', title: '3 طلاب جدد سجلوا اليوم', time: 'قبل 10 دقائق', unread: true },
  { id: 'n2', title: 'تم حفظ آخر حصة بنجاح', time: 'قبل ساعة', unread: true },
  { id: 'n3', title: 'تقرير الدرجات جاهز للعرض', time: 'أمس', unread: false },
];
