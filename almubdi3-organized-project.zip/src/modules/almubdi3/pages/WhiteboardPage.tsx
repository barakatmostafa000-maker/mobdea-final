import React, { useState } from 'react';
import { WhiteboardCanvas, WhiteboardToolbar } from '../components/whiteboard';
import { mockStudents } from '../mocks/dashboard';
import { Star, Crown, BookOpen } from 'lucide-react';

export const WhiteboardPage: React.FC = () => {
  const [tool, setTool] = useState('pen');
  const [color, setColor] = useState('#000000');
  const [strokeWidth, setStrokeWidth] = useState(3);
  const [opacity, setOpacity] = useState(1);

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-[#0D0D0D]" dir="rtl">
      <div className="relative flex h-16 items-center justify-between border-b border-[#2A2A2A] bg-gradient-to-b from-[#1A1A1A] to-[#0D0D0D] px-6">
        <div className="absolute left-0 top-0 h-1 w-full bg-gradient-to-r from-transparent via-[#C9A84C] to-transparent opacity-50" />
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-full border-2 border-[#C9A84C] bg-[#1A1A1A] text-[#C9A84C]">
            <Crown size={18} />
          </div>
          <div>
            <h1 className="text-lg font-bold text-[#C9A84C]">المُبدع</h1>
            <p className="text-xs text-[#A0A0A0]">مصطفى بركات - معلم دراسات</p>
          </div>
        </div>

        <div className="absolute left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full border border-[#C9A84C]/30 bg-[#1A1A1A] px-8 py-2">
          <BookOpen size={16} className="text-[#C9A84C]" />
          <h2 className="text-sm font-bold text-[#C9A84C]">شرح الدرس: مفهوم الدولة وعناصرها</h2>
        </div>

        <div className="w-32" />
      </div>

      <div className="flex flex-1 overflow-hidden">
        <div className="relative flex-1">
          <WhiteboardCanvas tool={tool} color={color} strokeWidth={strokeWidth} opacity={opacity} />
          <WhiteboardToolbar
            activeTool={tool}
            onToolChange={setTool}
            color={color}
            onColorChange={setColor}
            strokeWidth={strokeWidth}
            onStrokeWidthChange={setStrokeWidth}
            opacity={opacity}
            onOpacityChange={setOpacity}
          />
        </div>

        <aside className="w-72 overflow-y-auto border-r border-[#2A2A2A] bg-[#0D0D0D] p-4" dir="rtl">
          <h3 className="mb-4 flex items-center gap-2 text-sm font-bold text-[#C9A84C]">
            <Crown size={16} />
            الطلاب والنقاط
          </h3>
          <div className="space-y-2">
            {mockStudents.slice(0, 10).map((student, idx) => (
              <div key={student.id} className="flex items-center gap-3 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] p-3 transition hover:border-[#C9A84C]/30">
                <span className="w-4 font-mono text-xs text-[#666]">{idx + 1}</span>
                <span className="flex-1 text-xs text-white">{student.name}</span>
                <div className="flex items-center gap-1">
                  <Star size={12} className="text-[#C9A84C]" fill="currentColor" />
                  <span className="text-xs font-bold text-[#C9A84C]">{student.points}</span>
                </div>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
};
