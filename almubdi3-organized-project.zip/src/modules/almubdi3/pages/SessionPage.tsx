import React, { useState } from 'react';
import { SessionHeader, SessionToolbar, SessionCanvas, StudentsPanel, SessionFooter } from '../components/session';

interface SessionPageProps {
  onExit?: () => void;
}

export const SessionPage: React.FC<SessionPageProps> = ({ onExit }) => {
  const [activeMode, setActiveMode] = useState('whiteboard');
  const [activeTool, setActiveTool] = useState('pen');
  const [zoom, setZoom] = useState(1);

  const handleToolAction = (action: string) => {
    const actions = (window as Window & { __canvas_actions?: Record<string, (...args: any[]) => void> }).__canvas_actions;
    if (action === 'undo') actions?.undo?.();
    if (action === 'redo') actions?.redo?.();
    if (action === 'save') actions?.save?.();
    if (action === 'page') actions?.nextPage?.();
    if (action === 'new-page') actions?.prevPage?.();
    if (action === 'zoom-in') actions?.zoomIn?.();
    if (action === 'zoom-out') actions?.zoomOut?.();
  };

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-[#0D0D0D]" dir="rtl">
      <SessionHeader activeMode={activeMode} onModeChange={setActiveMode} />
      <div className="flex flex-1 overflow-hidden">
        <SessionToolbar activeTool={activeTool} onToolChange={setActiveTool} onAction={handleToolAction} />
        <SessionCanvas activeTool={activeTool} mode={activeMode} zoom={zoom} onZoomChange={setZoom} />
        <StudentsPanel />
      </div>
      <SessionFooter onExit={onExit} onEndSession={onExit} />
    </div>
  );
};
