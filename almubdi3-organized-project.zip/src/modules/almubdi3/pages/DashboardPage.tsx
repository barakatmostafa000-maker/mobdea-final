import React from 'react';
import { Sidebar, Header, HeroSection, SchedulePanel, ShortcutsGrid, BottomCards } from '../components/dashboard';

interface DashboardPageProps {
  onNavigate?: (route: string) => void;
  onStartSession?: () => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate, onStartSession }) => {
  return (
    <div className="min-h-screen bg-[#0D0D0D]" dir="rtl">
      <Sidebar onNavigate={onNavigate} />
      <div className="mr-0 transition-all duration-300 xl:mr-64">
        <Header />
        <main className="space-y-6 p-4 md:p-6">
          <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
            <div className="space-y-6">
              <HeroSection onStartSession={onStartSession} />
              <ShortcutsGrid onAction={onNavigate} />
              <BottomCards />
            </div>
            <SchedulePanel />
          </div>
        </main>
      </div>
    </div>
  );
};
