# Almubdi3 module

This module contains:
- Dashboard
- Session Mode
- Whiteboard

All files are organized so they can be copied into an existing React + TypeScript project.
