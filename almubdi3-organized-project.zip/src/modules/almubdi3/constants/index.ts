import type { NavItem, SessionModeItem } from '../types';

export const BRAND = {
  name: 'المُبدع',
  subtitle: 'لتعليم ممتع',
  teacher: 'مصطفى بركات',
};

export const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'الرئيسية', icon: 'home', route: '/dashboard' },
  { id: 'students', label: 'الطلاب', icon: 'users', route: '/dashboard?section=students' },
  { id: 'attendance', label: 'الحضور', icon: 'calendarCheck', route: '/dashboard?section=attendance' },
  { id: 'finance', label: 'المصروفات', icon: 'wallet', route: '/dashboard?section=finance' },
  { id: 'grades', label: 'الدرجات', icon: 'award', route: '/dashboard?section=grades' },
  { id: 'lessons', label: 'الدروس', icon: 'bookOpen', route: '/dashboard?section=lessons' },
  { id: 'exams', label: 'الاختبارات', icon: 'fileText', route: '/dashboard?section=exams' },
  { id: 'library', label: 'المكتبة', icon: 'library', route: '/dashboard?section=library' },
  { id: 'maps', label: 'الخرائط', icon: 'map', route: '/dashboard?section=maps' },
  { id: 'games', label: 'الألعاب التعليمية', icon: 'gamepad2', route: '/dashboard?section=games' },
  { id: 'reports', label: 'التقارير', icon: 'barChart3', route: '/dashboard?section=reports' },
  { id: 'settings', label: 'الإعدادات', icon: 'settings', route: '/dashboard?section=settings' },
];

export const SESSION_MODES: SessionModeItem[] = [
  { id: 'pdf', label: 'PDF', icon: 'fileText' },
  { id: 'whiteboard', label: 'السبورة', icon: 'penTool' },
  { id: 'images', label: 'الصور', icon: 'image' },
  { id: 'videos', label: 'الفيديوهات', icon: 'video' },
  { id: 'maps', label: 'الخرائط', icon: 'map' },
];

export const STROKE_COLORS = [
  '#000000',
  '#C9A84C',
  '#8B4513',
  '#D7263D',
  '#1D4ED8',
  '#15803D',
  '#7C3AED',
  '#EA580C',
  '#FFFFFF',
];

export const STROKE_WIDTHS = [1, 2, 3, 4, 5, 8, 10, 15, 20];

export const SEARCH_SUGGESTIONS = [
  'إدارة الطلاب',
  'الحضور والغياب',
  'الدرجات والتقارير',
  'السبورة التفاعلية',
  'الخرائط التعليمية',
  'الاختبارات القادمة',
  'المكتبة',
  'الألعاب التعليمية',
];
