import React from 'react';
import {
  MousePointer2,
  PenTool,
  Highlighter,
  Type,
  ArrowUpRight,
  Square,
  Circle,
  Triangle,
  Eraser,
  Move,
  ZoomIn,
  ZoomOut,
  Undo,
  Redo,
  Save,
  Trash2,
  Copy,
  Download,
  Image as ImageIcon,
  RotateCcw,
} from 'lucide-react';

const tools = [
  { id: 'select', icon: MousePointer2, label: 'تحديد' },
  { id: 'pen', icon: PenTool, label: 'قلم' },
  { id: 'pencil', icon: PenTool, label: 'رصاص' },
  { id: 'highlighter', icon: Highlighter, label: 'هايلايتر' },
  { id: 'text', icon: Type, label: 'نص' },
  { id: 'arrow', icon: ArrowUpRight, label: 'سهم' },
  { id: 'rect', icon: Square, label: 'مستطيل' },
  { id: 'circle', icon: Circle, label: 'دائرة' },
  { id: 'triangle', icon: Triangle, label: 'مثلث' },
  { id: 'eraser', icon: Eraser, label: 'ممحاة' },
  { id: 'move', icon: Move, label: 'تحريك' },
];

interface WhiteboardToolbarProps {
  activeTool: string;
  onToolChange: (tool: string) => void;
  color: string;
  onColorChange: (c: string) => void;
  strokeWidth: number;
  onStrokeWidthChange: (w: number) => void;
  opacity: number;
  onOpacityChange: (o: number) => void;
}

export const WhiteboardToolbar: React.FC<WhiteboardToolbarProps> = ({
  activeTool,
  onToolChange,
  color,
  onColorChange,
  strokeWidth,
  onStrokeWidthChange,
  opacity,
  onOpacityChange,
}) => {
  const [showColorPicker, setShowColorPicker] = React.useState(false);

  return (
    <div className="absolute bottom-6 left-1/2 z-40 flex max-w-[94vw] -translate-x-1/2 flex-wrap items-center gap-1 rounded-2xl border border-[#2A2A2A] bg-[#1A1A1A] px-4 py-2 shadow-2xl" dir="rtl">
      {tools.map((tool) => {
        const Icon = tool.icon;
        return (
          <button
            key={tool.id}
            onClick={() => onToolChange(tool.id)}
            title={tool.label}
            className={`flex h-9 w-9 items-center justify-center rounded-xl transition ${
              activeTool === tool.id ? 'bg-[#C9A84C] text-black' : 'text-[#A0A0A0] hover:bg-[#2A2A2A] hover:text-white'
            }`}
          >
            <Icon size={16} />
          </button>
        );
      })}

      <div className="mx-1 h-6 w-px bg-[#2A2A2A]" />

      <button
        onClick={() => (window as Window & { __wb_actions?: Record<string, (...args: any[]) => void> }).__wb_actions?.triggerImageUpload?.()}
        title="إدراج صورة"
        className="flex h-9 w-9 items-center justify-center rounded-xl text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white"
      >
        <ImageIcon size={16} />
      </button>

      <div className="relative">
        <button
          onClick={() => setShowColorPicker((value) => !value)}
          className="h-8 w-8 rounded-full border-2 border-[#666] transition-transform hover:scale-110"
          style={{ backgroundColor: color }}
        />
        {showColorPicker ? (
          <div className="absolute bottom-11 right-0 z-50 grid grid-cols-5 gap-1 rounded-2xl border border-[#2A2A2A] bg-[#1A1A1A] p-2 shadow-xl">
            {[
              '#000000',
              '#FFFFFF',
              '#FF0000',
              '#00FF00',
              '#0000FF',
              '#FFFF00',
              '#FF00FF',
              '#00FFFF',
              '#C9A84C',
              '#8B4513',
              '#FF6600',
              '#800080',
              '#008000',
              '#000080',
              '#808080',
            ].map((swatch) => (
              <button
                key={swatch}
                onClick={() => {
                  onColorChange(swatch);
                  setShowColorPicker(false);
                }}
                className="h-6 w-6 rounded-full border border-[#2A2A2A] transition-transform hover:scale-110"
                style={{ backgroundColor: swatch }}
              />
            ))}
          </div>
        ) : null}
      </div>

      <select
        value={strokeWidth}
        onChange={(event) => onStrokeWidthChange(Number(event.target.value))}
        className="h-9 w-14 rounded-lg border border-[#3A3A3A] bg-[#2A2A2A] px-1 py-1 text-xs text-white"
      >
        {[1, 2, 3, 4, 5, 8, 10, 15, 20].map((size) => (
          <option key={size} value={size}>
            {size}px
          </option>
        ))}
      </select>

      <div className="flex items-center gap-1">
        <span className="text-[10px] text-[#666]">شفافية</span>
        <input
          type="range"
          min="0.1"
          max="1"
          step="0.1"
          value={opacity}
          onChange={(event) => onOpacityChange(Number(event.target.value))}
          className="w-16 accent-[#C9A84C]"
        />
      </div>

      <div className="mx-1 h-6 w-px bg-[#2A2A2A]" />

      <button onClick={() => (window as Window & { __wb_actions?: Record<string, (...args: any[]) => void> }).__wb_actions?.zoomIn?.()} title="تكبير" className="flex h-9 w-9 items-center justify-center rounded-xl text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white">
        <ZoomIn size={16} />
      </button>
      <button onClick={() => (window as Window & { __wb_actions?: Record<string, (...args: any[]) => void> }).__wb_actions?.zoomOut?.()} title="تصغير" className="flex h-9 w-9 items-center justify-center rounded-xl text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white">
        <ZoomOut size={16} />
      </button>
      <button onClick={() => (window as Window & { __wb_actions?: Record<string, (...args: any[]) => void> }).__wb_actions?.undo?.()} title="تراجع" className="flex h-9 w-9 items-center justify-center rounded-xl text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white">
        <Undo size={16} />
      </button>
      <button onClick={() => (window as Window & { __wb_actions?: Record<string, (...args: any[]) => void> }).__wb_actions?.redo?.()} title="إعادة" className="flex h-9 w-9 items-center justify-center rounded-xl text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white">
        <Redo size={16} />
      </button>
      <button onClick={() => (window as Window & { __wb_actions?: Record<string, (...args: any[]) => void> }).__wb_actions?.deleteSelected?.()} title="حذف" className="flex h-9 w-9 items-center justify-center rounded-xl text-red-400 transition hover:bg-red-500/10">
        <Trash2 size={16} />
      </button>
      <button onClick={() => (window as Window & { __wb_actions?: Record<string, (...args: any[]) => void> }).__wb_actions?.duplicateSelected?.()} title="تكرار" className="flex h-9 w-9 items-center justify-center rounded-xl text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white">
        <Copy size={16} />
      </button>
      <button onClick={() => (window as Window & { __wb_actions?: Record<string, (...args: any[]) => void> }).__wb_actions?.save?.()} title="حفظ" className="flex h-9 w-9 items-center justify-center rounded-xl text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white">
        <Save size={16} />
      </button>
      <button onClick={() => (window as Window & { __wb_actions?: Record<string, (...args: any[]) => void> }).__wb_actions?.exportCanvas?.('png')} title="PNG" className="flex h-9 w-9 items-center justify-center rounded-xl text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white">
        <Download size={16} />
      </button>
      <button onClick={() => (window as Window & { __wb_actions?: Record<string, (...args: any[]) => void> }).__wb_actions?.exportCanvas?.('jpg')} title="JPG" className="flex h-9 w-9 items-center justify-center rounded-xl text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white">
        <Download size={16} />
      </button>
      <button onClick={() => (window as Window & { __wb_actions?: Record<string, (...args: any[]) => void> }).__wb_actions?.exportCanvas?.('pdf')} title="PDF" className="flex h-9 w-9 items-center justify-center rounded-xl text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white">
        <Download size={16} />
      </button>
      <button onClick={() => (window as Window & { __wb_actions?: Record<string, (...args: any[]) => void> }).__wb_actions?.clearCanvas?.()} title="مسح الكل" className="flex h-9 w-9 items-center justify-center rounded-xl text-red-400 transition hover:bg-red-500/10">
        <RotateCcw size={16} />
      </button>
    </div>
  );
};
