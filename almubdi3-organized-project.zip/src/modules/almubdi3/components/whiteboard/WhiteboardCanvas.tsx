import React, { useCallback, useEffect, useRef, useState } from 'react';
import { STROKE_COLORS, STROKE_WIDTHS } from '../../constants';
import { jsPDF } from 'jspdf';

interface Point {
  x: number;
  y: number;
}

interface WBElement {
  id: string;
  type: 'path' | 'text' | 'rect' | 'circle' | 'triangle' | 'arrow' | 'image';
  x: number;
  y: number;
  width?: number;
  height?: number;
  points?: Point[];
  text?: string;
  color: string;
  strokeWidth: number;
  opacity: number;
  rotation?: number;
  src?: string;
}

interface WhiteboardCanvasProps {
  tool: string;
  color: string;
  strokeWidth: number;
  opacity: number;
}

const STORAGE_KEY = 'whiteboard_data_v2';

export const WhiteboardCanvas: React.FC<WhiteboardCanvasProps> = ({ tool, color, strokeWidth, opacity }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [elements, setElements] = useState<WBElement[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? (JSON.parse(saved) as WBElement[]) : [];
    } catch {
      return [];
    }
  });

  const [history, setHistory] = useState<WBElement[][]>([[]]);
  const [historyStep, setHistoryStep] = useState(0);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPath, setCurrentPath] = useState<Point[]>([]);
  const [startPoint, setStartPoint] = useState<Point | null>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [textInput, setTextInput] = useState('');
  const [textPos, setTextPos] = useState<Point | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  const syncLocal = useCallback((next: WBElement[]) => {
    setElements(next);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  }, []);

  const pushHistory = useCallback(
    (newElements: WBElement[]) => {
      const nextHistory = history.slice(0, historyStep + 1);
      nextHistory.push([...newElements]);
      setHistory(nextHistory);
      setHistoryStep(nextHistory.length - 1);
    },
    [history, historyStep],
  );

  const undo = useCallback(() => {
    if (historyStep > 0) {
      const nextStep = historyStep - 1;
      setHistoryStep(nextStep);
      syncLocal(history[nextStep] ?? []);
      setSelectedId(null);
    }
  }, [history, historyStep, syncLocal]);

  const redo = useCallback(() => {
    if (historyStep < history.length - 1) {
      const nextStep = historyStep + 1;
      setHistoryStep(nextStep);
      syncLocal(history[nextStep] ?? []);
      setSelectedId(null);
    }
  }, [history, historyStep, syncLocal]);

  const save = useCallback(() => {
    localStorage.setItem('whiteboard_backup', JSON.stringify(elements));
  }, [elements]);

  const exportCanvas = useCallback((format: 'png' | 'jpg' | 'pdf') => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    if (format === 'pdf') {
      const pdf = new jsPDF('landscape', 'px', [canvas.width, canvas.height]);
      pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, 0, canvas.width, canvas.height);
      pdf.save('whiteboard.pdf');
      return;
    }

    const link = document.createElement('a');
    link.download = `whiteboard.${format}`;
    link.href = canvas.toDataURL(format === 'jpg' ? 'image/jpeg' : 'image/png');
    link.click();
  }, []);

  const deleteSelected = useCallback(() => {
    if (!selectedId) return;
    const next = elements.filter((element) => element.id !== selectedId);
    syncLocal(next);
    pushHistory(next);
    setSelectedId(null);
  }, [elements, pushHistory, selectedId, syncLocal]);

  const duplicateSelected = useCallback(() => {
    if (!selectedId) return;
    const element = elements.find((item) => item.id === selectedId);
    if (!element) return;
    const copy = { ...element, id: Date.now().toString(), x: element.x + 30, y: element.y + 30 };
    const next = [...elements, copy];
    syncLocal(next);
    pushHistory(next);
    setSelectedId(copy.id);
  }, [elements, pushHistory, selectedId, syncLocal]);

  const clearCanvas = useCallback(() => {
    if (!window.confirm('هل تريد مسح السبورة بالكامل؟')) return;
    syncLocal([]);
    pushHistory([]);
    setSelectedId(null);
  }, [pushHistory, syncLocal]);

  const triggerImageUpload = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const zoomIn = useCallback(() => setZoom((current) => Math.min(3, +(current + 0.1).toFixed(2))), []);
  const zoomOut = useCallback(() => setZoom((current) => Math.max(0.5, +(current - 0.1).toFixed(2))), []);

  useEffect(() => {
    (window as Window & { __wb_actions?: Record<string, (...args: any[]) => void> }).__wb_actions = {
      undo,
      redo,
      save,
      exportCanvas,
      deleteSelected,
      duplicateSelected,
      clearCanvas,
      triggerImageUpload,
      zoomIn,
      zoomOut,
    };
  }, [clearCanvas, deleteSelected, duplicateSelected, redo, save, undo, exportCanvas, triggerImageUpload, zoomIn, zoomOut]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.ctrlKey && event.key.toLowerCase() === 'z') {
        event.preventDefault();
        undo();
      }
      if (event.ctrlKey && event.key.toLowerCase() === 'y') {
        event.preventDefault();
        redo();
      }
      if (event.ctrlKey && event.key.toLowerCase() === 's') {
        event.preventDefault();
        save();
      }
      if (event.key === 'Delete' || event.key === 'Backspace') {
        deleteSelected();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [deleteSelected, redo, save, undo]);

  const getPoint = (event: React.MouseEvent): Point => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left - pan.x) / zoom,
      y: (event.clientY - rect.top - pan.y) / zoom,
    };
  };

  const handleMouseDown = (event: React.MouseEvent) => {
    if (event.button === 1 || tool === 'move') {
      setIsPanning(true);
      return;
    }

    if (tool === 'select') {
      const point = getPoint(event);
      const clicked = [...elements].reverse().find((element) => {
        if (element.type === 'path' && element.points) {
          return element.points.some((p) => Math.abs(p.x - point.x) < 10 && Math.abs(p.y - point.y) < 10);
        }
        return (
          point.x >= element.x &&
          point.x <= element.x + (element.width ?? 0) &&
          point.y >= element.y &&
          point.y <= element.y + (element.height ?? 0)
        );
      });

      if (clicked) {
        setSelectedId(clicked.id);
        setIsDragging(true);
        setDragOffset({ x: point.x - clicked.x, y: point.y - clicked.y });
      } else {
        setSelectedId(null);
      }
      return;
    }

    if (tool === 'text') {
      setTextPos(getPoint(event));
      return;
    }

    setIsDrawing(true);
    setStartPoint(getPoint(event));
    setCurrentPath([getPoint(event)]);
  };

  const handleMouseMove = (event: React.MouseEvent) => {
    if (isPanning) {
      setPan((current) => ({ x: current.x + event.movementX, y: current.y + event.movementY }));
      return;
    }

    if (isDragging && selectedId) {
      const point = getPoint(event);
      setElements((current) =>
        current.map((element) =>
          element.id === selectedId ? { ...element, x: point.x - dragOffset.x, y: point.y - dragOffset.y } : element,
        ),
      );
      return;
    }

    if (!isDrawing) return;
    if (['pen', 'pencil', 'highlighter', 'eraser'].includes(tool)) {
      setCurrentPath((current) => [...current, getPoint(event)]);
    }
  };

  const handleMouseUp = () => {
    if (isPanning) {
      setIsPanning(false);
      return;
    }

    if (isDragging) {
      if (selectedId) pushHistory(elements);
      setIsDragging(false);
      return;
    }

    if (!isDrawing || !startPoint) {
      setIsDrawing(false);
      return;
    }

    setIsDrawing(false);
    const endPoint = currentPath.length > 0 ? currentPath[currentPath.length - 1] : startPoint;

    if (['pen', 'pencil', 'highlighter', 'eraser'].includes(tool) && currentPath.length > 1) {
      const nextElement: WBElement = {
        id: Date.now().toString(),
        type: 'path',
        points: currentPath,
        x: 0,
        y: 0,
        color: tool === 'eraser' ? '#F5E6C8' : color,
        strokeWidth: tool === 'eraser' ? strokeWidth * 5 : strokeWidth,
        opacity: tool === 'highlighter' ? 0.25 : opacity,
      };
      const next = [...elements, nextElement];
      syncLocal(next);
      pushHistory(next);
    } else if (['rect', 'circle', 'triangle', 'arrow'].includes(tool)) {
      const nextElement: WBElement = {
        id: Date.now().toString(),
        type: tool as WBElement['type'],
        x: Math.min(startPoint.x, endPoint.x),
        y: Math.min(startPoint.y, endPoint.y),
        width: Math.abs(endPoint.x - startPoint.x),
        height: Math.abs(endPoint.y - startPoint.y),
        color,
        strokeWidth,
        opacity,
      };
      const next = [...elements, nextElement];
      syncLocal(next);
      pushHistory(next);
    }

    setCurrentPath([]);
    setStartPoint(null);
  };

  const handleTextSubmit = () => {
    if (!textInput.trim() || !textPos) return;
    const nextElement: WBElement = {
      id: Date.now().toString(),
      type: 'text',
      x: textPos.x,
      y: textPos.y,
      text: textInput.trim(),
      color,
      strokeWidth,
      opacity,
    };
    const next = [...elements, nextElement];
    syncLocal(next);
    pushHistory(next);
    setTextInput('');
    setTextPos(null);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (loadEvent) => {
      const src = String(loadEvent.target?.result ?? '');
      const nextElement: WBElement = {
        id: Date.now().toString(),
        type: 'image',
        x: 100,
        y: 100,
        width: 240,
        height: 180,
        src,
        color: '#000000',
        strokeWidth: 1,
        opacity: 1,
      };
      const next = [...elements, nextElement];
      syncLocal(next);
      pushHistory(next);
      setSelectedId(nextElement.id);
    };
    reader.readAsDataURL(file);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext('2d');
    if (!context) return;

    const draw = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      canvas.width = parent.clientWidth;
      canvas.height = parent.clientHeight;

      context.setTransform(1, 0, 0, 1, 0, 0);
      context.clearRect(0, 0, canvas.width, canvas.height);

      context.fillStyle = '#E8E8E8';
      context.fillRect(0, 0, canvas.width, canvas.height);

      context.fillStyle = 'rgba(0,0,0,0.05)';
      for (let x = 0; x < canvas.width; x += 20) {
        for (let y = 0; y < canvas.height; y += 20) {
          context.beginPath();
          context.arc(x, y, 1, 0, Math.PI * 2);
          context.fill();
        }
      }

      context.save();
      context.translate(pan.x, pan.y);
      context.scale(zoom, zoom);

      elements.forEach((element) => {
        context.save();
        context.globalAlpha = element.opacity;
        context.strokeStyle = element.color;
        context.fillStyle = element.color;
        context.lineWidth = element.strokeWidth;
        context.lineCap = 'round';
        context.lineJoin = 'round';

        if (element.rotation) {
          context.translate(element.x + (element.width ?? 0) / 2, element.y + (element.height ?? 0) / 2);
          context.rotate((element.rotation * Math.PI) / 180);
          context.translate(-(element.x + (element.width ?? 0) / 2), -(element.y + (element.height ?? 0) / 2));
        }

        if (element.type === 'path' && element.points?.length) {
          context.beginPath();
          element.points.forEach((point, index) => {
            if (index === 0) context.moveTo(point.x, point.y);
            else context.lineTo(point.x, point.y);
          });
          context.stroke();
        } else if (element.type === 'text' && element.text) {
          context.font = `${element.strokeWidth * 4 + 14}px Arial`;
          context.fillText(element.text, element.x, element.y);
        } else if (element.type === 'rect') {
          context.strokeRect(element.x, element.y, element.width ?? 100, element.height ?? 100);
        } else if (element.type === 'circle') {
          context.beginPath();
          context.ellipse(
            element.x + (element.width ?? 100) / 2,
            element.y + (element.height ?? 100) / 2,
            (element.width ?? 100) / 2,
            (element.height ?? 100) / 2,
            0,
            0,
            Math.PI * 2,
          );
          context.stroke();
        } else if (element.type === 'triangle') {
          context.beginPath();
          context.moveTo(element.x + (element.width ?? 100) / 2, element.y);
          context.lineTo(element.x + (element.width ?? 100), element.y + (element.height ?? 100));
          context.lineTo(element.x, element.y + (element.height ?? 100));
          context.closePath();
          context.stroke();
        } else if (element.type === 'arrow') {
          const endX = element.x + (element.width ?? 100);
          const endY = element.y + (element.height ?? 0);
          context.beginPath();
          context.moveTo(element.x, element.y);
          context.lineTo(endX, endY);
          context.stroke();
          const angle = Math.atan2(endY - element.y, endX - element.x);
          const headLen = 15;
          context.beginPath();
          context.moveTo(endX, endY);
          context.lineTo(
            endX - headLen * Math.cos(angle - Math.PI / 6),
            endY - headLen * Math.sin(angle - Math.PI / 6),
          );
          context.moveTo(endX, endY);
          context.lineTo(
            endX - headLen * Math.cos(angle + Math.PI / 6),
            endY - headLen * Math.sin(angle + Math.PI / 6),
          );
          context.stroke();
        } else if (element.type === 'image' && element.src) {
          const image = new Image();
          image.onload = () => {
            context.drawImage(image, element.x, element.y, element.width ?? 200, element.height ?? 200);
          };
          image.src = element.src;
        }

        context.restore();
      });

      if (isDrawing && currentPath.length > 1) {
        context.globalAlpha = opacity;
        context.strokeStyle = color;
        context.lineWidth = strokeWidth;
        context.beginPath();
        currentPath.forEach((point, index) => {
          if (index === 0) context.moveTo(point.x, point.y);
          else context.lineTo(point.x, point.y);
        });
        context.stroke();
      }

      if (selectedId) {
        const selected = elements.find((element) => element.id === selectedId);
        if (selected) {
          context.strokeStyle = '#C9A84C';
          context.lineWidth = 2;
          context.setLineDash([5, 5]);
          const padding = 8;
          context.strokeRect(
            selected.x - padding,
            selected.y - padding,
            (selected.width ?? 100) + padding * 2,
            (selected.height ?? 100) + padding * 2,
          );
          context.setLineDash([]);
        }
      }

      context.restore();
    };

    draw();
    const observer = new ResizeObserver(draw);
    if (canvas.parentElement) observer.observe(canvas.parentElement);
    return () => observer.disconnect();
  }, [color, currentPath, elements, isDrawing, opacity, pan.x, pan.y, selectedId, strokeWidth, zoom]);

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#2A2A2A]">
      <canvas
        ref={canvasRef}
        className={`absolute inset-0 ${isPanning ? 'cursor-grabbing' : tool === 'move' ? 'cursor-grab' : tool === 'select' ? 'cursor-pointer' : 'cursor-crosshair'}`}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      />

      <input
        type="file"
        ref={fileInputRef}
        accept="image/*"
        onChange={handleImageUpload}
        className="hidden"
      />

      {textPos ? (
        <div
          className="absolute z-50 flex gap-2 rounded-2xl border border-[#2A2A2A] bg-white p-3 shadow-2xl"
          style={{ left: textPos.x * zoom + pan.x, top: textPos.y * zoom + pan.y }}
        >
          <input
            autoFocus
            value={textInput}
            onChange={(event) => setTextInput(event.target.value)}
            onKeyDown={(event) => event.key === 'Enter' && handleTextSubmit()}
            placeholder="اكتب النص هنا..."
            className="w-56 rounded-xl border border-[#2A2A2A] px-3 py-2 text-sm text-black outline-none focus:border-[#C9A84C]"
          />
          <button
            onClick={handleTextSubmit}
            className="rounded-xl bg-[#C9A84C] px-4 text-sm font-bold text-black transition hover:bg-[#E8D5A3]"
          >
            OK
          </button>
        </div>
      ) : null}
    </div>
  );
};
