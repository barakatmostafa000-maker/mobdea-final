import React from 'react';
import { SESSION_MODES, BRAND } from '../../constants';
import { Icon } from '../common/Icon';
import { Clock, MapPin } from 'lucide-react';

interface SessionHeaderProps {
  activeMode: string;
  onModeChange: (mode: string) => void;
}

export const SessionHeader: React.FC<SessionHeaderProps> = ({ activeMode, onModeChange }) => {
  const now = new Date();
  const timeStr = now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
  const dateStr = now.toLocaleDateString('ar-EG', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <header className="border-b border-[#2A2A2A] bg-[#0D0D0D] px-4 py-4" dir="rtl">
      <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-[#C9A84C] to-[#8B6914] text-white">
              <Icon name="graduationCap" size={20} />
            </div>
            <div>
              <h1 className="text-sm font-bold text-[#C9A84C]">{BRAND.name}</h1>
              <p className="text-xs text-[#A0A0A0]">{BRAND.subtitle}</p>
            </div>
          </div>

          <div className="hidden h-8 w-px bg-[#2A2A2A] xl:block" />

          <div className="flex flex-wrap gap-2">
            {SESSION_MODES.map((mode) => (
              <button
                key={mode.id}
                onClick={() => onModeChange(mode.id)}
                className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-medium transition ${
                  activeMode === mode.id
                    ? 'bg-[#C9A84C] text-black'
                    : 'text-[#A0A0A0] hover:bg-[#2A2A2A] hover:text-white'
                }`}
              >
                <Icon name={mode.icon} size={16} />
                <span>{mode.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-4 text-xs text-[#A0A0A0]">
          <div className="flex items-center gap-1">
            <Clock size={14} className="text-[#C9A84C]" />
            <span>{timeStr}</span>
          </div>
          <div className="flex items-center gap-1">
            <MapPin size={14} className="text-[#C9A84C]" />
            <span>{dateStr}</span>
          </div>
          <div className="rounded-full border border-[#2A2A2A] px-3 py-1 text-[#C9A84C]">
            الوحدة الثالثة
          </div>
        </div>
      </div>
    </header>
  );
};
