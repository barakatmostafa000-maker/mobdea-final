import React, { useCallback, useEffect, useRef, useState } from 'react';
import { STROKE_COLORS, STROKE_WIDTHS } from '../../constants';

interface Point {
  x: number;
  y: number;
}

interface DrawElement {
  id: string;
  type: 'path' | 'text' | 'shape';
  points?: Point[];
  text?: string;
  color: string;
  width: number;
  opacity: number;
}

interface SessionCanvasProps {
  activeTool: string;
  mode: string;
  zoom: number;
  onZoomChange: (zoom: number) => void;
}

const STORAGE_KEY = 'session_canvas_v1';

export const SessionCanvas: React.FC<SessionCanvasProps> = ({
  activeTool,
  mode,
  zoom,
  onZoomChange,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [elements, setElements] = useState<DrawElement[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? (JSON.parse(saved) as DrawElement[]) : [];
    } catch {
      return [];
    }
  });
  const [history, setHistory] = useState<DrawElement[][]>([[]]);
  const [historyStep, setHistoryStep] = useState(0);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPath, setCurrentPath] = useState<Point[]>([]);
  const [startPoint, setStartPoint] = useState<Point | null>(null);
  const [page, setPage] = useState(1);
  const [color, setColor] = useState(STROKE_COLORS[0]);
  const [width, setWidth] = useState(3);
  const [opacity, setOpacity] = useState(1);
  const totalPages = 28;

  const pushHistory = useCallback(
    (newElements: DrawElement[]) => {
      const nextHistory = history.slice(0, historyStep + 1);
      nextHistory.push([...newElements]);
      setHistory(nextHistory);
      setHistoryStep(nextHistory.length - 1);
    },
    [history, historyStep],
  );

  const syncLocal = useCallback((next: DrawElement[]) => {
    setElements(next);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  }, []);

  const undo = useCallback(() => {
    if (historyStep > 0) {
      const nextStep = historyStep - 1;
      setHistoryStep(nextStep);
      syncLocal(history[nextStep] ?? []);
    }
  }, [history, historyStep, syncLocal]);

  const redo = useCallback(() => {
    if (historyStep < history.length - 1) {
      const nextStep = historyStep + 1;
      setHistoryStep(nextStep);
      syncLocal(history[nextStep] ?? []);
    }
  }, [history, historyStep, syncLocal]);

  const save = useCallback(() => {
    localStorage.setItem('session_canvas_backup', JSON.stringify(elements));
  }, [elements]);

  const zoomIn = useCallback(() => onZoomChange(Math.min(3, +(zoom + 0.1).toFixed(2))), [onZoomChange, zoom]);
  const zoomOut = useCallback(() => onZoomChange(Math.max(0.5, +(zoom - 0.1).toFixed(2))), [onZoomChange, zoom]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(elements));
  }, [elements]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.ctrlKey && event.key.toLowerCase() === 'z') {
        event.preventDefault();
        undo();
      }
      if (event.ctrlKey && event.key.toLowerCase() === 'y') {
        event.preventDefault();
        redo();
      }
      if (event.ctrlKey && event.key.toLowerCase() === 's') {
        event.preventDefault();
        save();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [redo, save, undo]);

  useEffect(() => {
    (window as Window & { __canvas_actions?: Record<string, (...args: any[]) => void> }).__canvas_actions = {
      undo,
      redo,
      save,
      zoomIn,
      zoomOut,
      prevPage: () => setPage((current) => Math.max(1, current - 1)),
      nextPage: () => setPage((current) => Math.min(totalPages, current + 1)),
    };
  }, [redo, save, totalPages, undo, zoomIn, zoomOut]);

  const getPoint = (event: React.MouseEvent): Point => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) / zoom,
      y: (event.clientY - rect.top) / zoom,
    };
  };

  const handleMouseDown = (event: React.MouseEvent) => {
    if (['zoom-in', 'zoom-out'].includes(activeTool)) return;
    const point = getPoint(event);
    setIsDrawing(true);
    setStartPoint(point);
    setCurrentPath([point]);
  };

  const handleMouseMove = (event: React.MouseEvent) => {
    if (!isDrawing) return;
    setCurrentPath((points) => [...points, getPoint(event)]);
  };

  const finishDraw = useCallback(() => {
    if (!isDrawing) return;
    setIsDrawing(false);

    if (currentPath.length < 2) {
      setCurrentPath([]);
      setStartPoint(null);
      return;
    }

    const element: DrawElement = {
      id: Date.now().toString(),
      type: 'path',
      points: currentPath,
      color: activeTool === 'highlighter' ? color : activeTool === 'eraser' ? '#F5E6C8' : color,
      width: activeTool === 'eraser' ? width * 3 : width,
      opacity: activeTool === 'highlighter' ? 0.25 : opacity,
    };

    const nextElements = [...elements, element];
    syncLocal(nextElements);
    pushHistory(nextElements);
    setCurrentPath([]);
    setStartPoint(null);
  }, [activeTool, color, currentPath, elements, isDrawing, opacity, pushHistory, syncLocal, width]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext('2d');
    if (!context) return;

    const draw = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      canvas.width = parent.clientWidth;
      canvas.height = parent.clientHeight;

      context.setTransform(1, 0, 0, 1, 0, 0);
      context.clearRect(0, 0, canvas.width, canvas.height);

      context.fillStyle = mode === 'pdf' ? '#F5E6C8' : '#F7F2E8';
      context.fillRect(0, 0, canvas.width, canvas.height);

      context.save();
      context.scale(zoom, zoom);

      elements.forEach((element) => {
        context.globalAlpha = element.opacity;
        context.strokeStyle = element.color;
        context.lineWidth = element.width;
        context.lineCap = 'round';
        context.lineJoin = 'round';

        if (element.type === 'path' && element.points?.length) {
          context.beginPath();
          element.points.forEach((point, index) => {
            if (index === 0) context.moveTo(point.x, point.y);
            else context.lineTo(point.x, point.y);
          });
          context.stroke();
        }
      });

      if (currentPath.length > 1) {
        context.globalAlpha = opacity;
        context.strokeStyle = color;
        context.lineWidth = width;
        context.beginPath();
        currentPath.forEach((point, index) => {
          if (index === 0) context.moveTo(point.x, point.y);
          else context.lineTo(point.x, point.y);
        });
        context.stroke();
      }

      context.restore();
    };

    draw();
    const observer = new ResizeObserver(draw);
    if (canvas.parentElement) observer.observe(canvas.parentElement);
    return () => observer.disconnect();
  }, [color, currentPath, elements, mode, opacity, width, zoom]);

  return (
    <div className="relative flex-1 overflow-hidden bg-[#0D0D0D]">
      <div className="absolute inset-0 m-4 overflow-hidden rounded-[1.75rem] border-4 border-[#8B6914] bg-[#F5E6C8]">
        <div
          className="pointer-events-none absolute inset-0 opacity-15"
          style={{
            backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(0,0,0,.18) 1px, transparent 0)',
            backgroundSize: '22px 22px',
          }}
        />
        <canvas
          ref={canvasRef}
          className="absolute inset-0 h-full w-full cursor-crosshair touch-none"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={finishDraw}
          onMouseLeave={finishDraw}
        />
      </div>

      <div className="absolute bottom-4 left-4 flex items-center gap-2 rounded-2xl border border-[#2A2A2A] bg-[#111111] px-3 py-2 text-xs text-white">
        <button onClick={() => setPage((current) => Math.max(1, current - 1))} className="rounded-lg bg-[#1A1A1A] px-3 py-2">
          السابق
        </button>
        <span className="rounded-lg border border-[#2A2A2A] px-3 py-2 text-[#C9A84C]">
          {page} / {totalPages}
        </span>
        <button onClick={() => setPage((current) => Math.min(totalPages, current + 1))} className="rounded-lg bg-[#1A1A1A] px-3 py-2">
          التالي
        </button>
      </div>

      <div className="absolute bottom-4 right-4 flex items-center gap-2 rounded-2xl border border-[#2A2A2A] bg-[#111111] px-3 py-2 text-xs text-white">
        <div className="flex items-center gap-1">
          {STROKE_COLORS.slice(0, 6).map((swatch) => (
            <button
              key={swatch}
              onClick={() => setColor(swatch)}
              className={`h-5 w-5 rounded-full border ${color === swatch ? 'border-white' : 'border-transparent'}`}
              style={{ backgroundColor: swatch }}
            />
          ))}
        </div>
        <select
          value={width}
          onChange={(event) => setWidth(Number(event.target.value))}
          className="h-8 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] px-2 text-xs text-white"
        >
          {STROKE_WIDTHS.map((size) => (
            <option key={size} value={size}>
              {size}px
            </option>
          ))}
        </select>
        <div className="flex items-center gap-1">
          <button onClick={zoomOut} className="h-8 rounded-lg bg-[#1A1A1A] px-2 text-white">
            -
          </button>
          <span className="w-12 text-center text-[#C9A84C]">{Math.round(zoom * 100)}%</span>
          <button onClick={zoomIn} className="h-8 rounded-lg bg-[#1A1A1A] px-2 text-white">
            +
          </button>
        </div>
      </div>
    </div>
  );
};
