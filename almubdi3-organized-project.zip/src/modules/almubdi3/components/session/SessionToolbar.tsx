import React from 'react';
import {
  Pen,
  MousePointer,
  Highlighter,
  Shapes,
  Type,
  ArrowUpRight,
  Eraser,
  Move,
  ZoomIn,
  ZoomOut,
  Undo,
  Redo,
  Save,
  FilePlus,
  PlusSquare,
} from 'lucide-react';

const tools = [
  { id: 'pen', icon: Pen, label: 'قلم' },
  { id: 'select', icon: MousePointer, label: 'تحديد' },
  { id: 'highlighter', icon: Highlighter, label: 'هايلايتر' },
  { id: 'shapes', icon: Shapes, label: 'أشكال' },
  { id: 'text', icon: Type, label: 'نص' },
  { id: 'arrow', icon: ArrowUpRight, label: 'سهم' },
  { id: 'eraser', icon: Eraser, label: 'ممحاة' },
  { id: 'move', icon: Move, label: 'تحريك' },
  { id: 'zoom-in', icon: ZoomIn, label: 'تكبير' },
  { id: 'zoom-out', icon: ZoomOut, label: 'تصغير' },
  { id: 'undo', icon: Undo, label: 'تراجع' },
  { id: 'redo', icon: Redo, label: 'إعادة' },
  { id: 'save', icon: Save, label: 'حفظ' },
  { id: 'page', icon: FilePlus, label: 'صفحة' },
  { id: 'new-page', icon: PlusSquare, label: 'صفحة جديدة' },
];

interface SessionToolbarProps {
  activeTool: string;
  onToolChange: (tool: string) => void;
  onAction?: (action: string) => void;
}

export const SessionToolbar: React.FC<SessionToolbarProps> = ({ activeTool, onToolChange, onAction }) => {
  return (
    <div className="flex w-16 flex-col items-center gap-1 overflow-y-auto border-l border-[#2A2A2A] bg-[#0D0D0D] py-4" dir="rtl">
      {tools.map((tool) => {
        const Icon = tool.icon;
        const isAction = ['undo', 'redo', 'save', 'page', 'new-page', 'zoom-in', 'zoom-out'].includes(tool.id);
        return (
          <button
            key={tool.id}
            onClick={() => (isAction ? onAction?.(tool.id) : onToolChange(tool.id))}
            title={tool.label}
            className={`mb-1 flex h-10 w-10 items-center justify-center rounded-xl transition ${
              activeTool === tool.id && !isAction
                ? 'bg-[#C9A84C] text-black'
                : 'text-[#A0A0A0] hover:bg-[#2A2A2A] hover:text-white'
            }`}
          >
            <Icon size={18} />
          </button>
        );
      })}
    </div>
  );
};
