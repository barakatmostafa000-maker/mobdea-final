import React from 'react';
import { LogOut, Radio, Camera, Users, BookOpen, Settings, Power } from 'lucide-react';

interface SessionFooterProps {
  onExit?: () => void;
  onEndSession?: () => void;
}

export const SessionFooter: React.FC<SessionFooterProps> = ({ onExit, onEndSession }) => {
  return (
    <footer className="flex items-center justify-between border-t border-[#2A2A2A] bg-[#0D0D0D] px-4 py-3" dir="rtl">
      <button
        onClick={onExit}
        className="inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white"
      >
        <LogOut size={16} />
        <span>خروج من وضع الحصة</span>
      </button>

      <div className="flex flex-wrap items-center gap-2">
        <button className="inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs text-red-400 transition hover:bg-red-500/10">
          <Radio size={16} />
          <span>تسجيل الحصة</span>
        </button>
        <button className="inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white">
          <Camera size={16} />
          <span>لقطة شاشة</span>
        </button>
        <button className="inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white">
          <Users size={16} />
          <span>عرض الطلاب</span>
        </button>
        <button className="inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white">
          <BookOpen size={16} />
          <span>المكتبة</span>
        </button>
        <button className="inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs text-[#A0A0A0] transition hover:bg-[#2A2A2A] hover:text-white">
          <Settings size={16} />
          <span>الإعدادات</span>
        </button>
      </div>

      <button
        onClick={onEndSession}
        className="inline-flex items-center gap-2 rounded-xl bg-red-600 px-5 py-2 text-xs font-bold text-white transition hover:bg-red-700"
      >
        <Power size={16} />
        <span>إنهاء الحصة</span>
      </button>
    </footer>
  );
};
