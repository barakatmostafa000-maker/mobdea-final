import React, { useState } from 'react';
import { mockStudents, mockEncouragementPhrases } from '../../mocks/dashboard';
import { Users, Plus, Star } from 'lucide-react';

export const StudentsPanel: React.FC = () => {
  const [students, setStudents] = useState(mockStudents);
  const [phrases, setPhrases] = useState(mockEncouragementPhrases);
  const [newPhrase, setNewPhrase] = useState('');

  const addPoints = (id: string) => {
    setStudents((prev) => prev.map((student) => (student.id === id ? { ...student, points: student.points + 5 } : student)));
  };

  const toggleFavorite = (id: string) => {
    setPhrases((prev) => prev.map((phrase) => (phrase.id === id ? { ...phrase, isFavorite: !phrase.isFavorite } : phrase)));
  };

  const addPhrase = () => {
    const text = newPhrase.trim();
    if (!text) return;
    setPhrases((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        text,
        isFavorite: false,
      },
    ]);
    setNewPhrase('');
  };

  return (
    <aside className="flex w-80 flex-col border-r border-[#2A2A2A] bg-[#0D0D0D]" dir="rtl">
      <div className="border-b border-[#2A2A2A] p-4">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users size={16} className="text-[#C9A84C]" />
            <h3 className="text-sm font-bold text-white">الطلاب في الحصة</h3>
          </div>
          <span className="text-xs font-bold text-[#C9A84C]">({students.length})</span>
        </div>

        <div className="space-y-1">
          {students.map((student) => (
            <div key={student.id} className="flex items-center gap-2 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] p-2">
              <div className={`h-2 w-2 rounded-full ${
                student.status === 'absent' ? 'bg-red-500' : student.status === 'late' ? 'bg-amber-500' : 'bg-green-500'
              }`} />
              <span className="flex-1 truncate text-xs text-white">{student.name}</span>
              <span className="text-xs font-mono text-[#C9A84C]">{student.points}</span>
              <button
                onClick={() => addPoints(student.id)}
                className="flex h-6 w-6 items-center justify-center rounded-lg bg-[#C9A84C]/20 text-[#C9A84C] transition hover:bg-[#C9A84C] hover:text-black"
              >
                <Plus size={12} />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 p-4">
        <h3 className="mb-3 text-sm font-bold text-white">الجمل التشجيعية</h3>
        <div className="mb-3 max-h-48 space-y-1 overflow-y-auto">
          {phrases.map((phrase) => (
            <div key={phrase.id} className="flex items-center justify-between rounded-xl bg-[#1A1A1A] p-2">
              <span className="text-xs text-[#A0A0A0]">{phrase.text}</span>
              <button onClick={() => toggleFavorite(phrase.id)} className="text-[#C9A84C] hover:text-[#E8D5A3]">
                <Star size={14} fill={phrase.isFavorite ? 'currentColor' : 'none'} />
              </button>
            </div>
          ))}
        </div>

        <div className="flex gap-2">
          <input
            value={newPhrase}
            onChange={(event) => setNewPhrase(event.target.value)}
            placeholder="جملة جديدة..."
            className="h-9 flex-1 rounded-xl border border-[#2A2A2A] bg-[#111111] px-3 text-xs text-white outline-none placeholder:text-[#666] focus:border-[#C9A84C]"
            onKeyDown={(event) => event.key === 'Enter' && addPhrase()}
          />
          <button
            onClick={addPhrase}
            className="inline-flex h-9 items-center justify-center rounded-xl bg-[#C9A84C] px-3 text-xs font-bold text-black transition hover:bg-[#E8D5A3]"
          >
            <Plus size={14} />
          </button>
        </div>
      </div>
    </aside>
  );
};
