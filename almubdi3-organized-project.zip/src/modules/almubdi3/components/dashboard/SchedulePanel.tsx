import React from 'react';
import { mockSchedule } from '../../mocks/dashboard';
import { Clock3, CalendarDays } from 'lucide-react';

export const SchedulePanel: React.FC = () => {
  return (
    <aside className="rounded-[2rem] border border-[#2A2A2A] bg-[#111111] p-5 shadow-glow" dir="rtl">
      <div className="flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#C9A84C]/10 text-[#C9A84C]">
          <CalendarDays size={20} />
        </div>
        <div>
          <h3 className="text-base font-bold text-white">جدول اليوم</h3>
          <p className="text-xs text-[#A0A0A0]">الخطة الزمنية للحصص</p>
        </div>
      </div>

      <div className="mt-5 space-y-3">
        {mockSchedule.map((item) => (
          <div
            key={item.id}
            className={`rounded-2xl border px-4 py-4 ${
              item.status === 'current'
                ? 'border-[#C9A84C]/40 bg-[#C9A84C]/10'
                : 'border-[#2A2A2A] bg-[#1A1A1A]'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-xs text-[#A0A0A0]">{item.group}</div>
                <div className="mt-1 text-sm font-bold text-white">{item.title}</div>
              </div>
              <div className="rounded-full border border-[#2A2A2A] px-3 py-1 text-xs text-[#C9A84C]">
                {item.time}
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2 text-xs text-[#A0A0A0]">
              <Clock3 size={14} className="text-[#C9A84C]" />
              <span>{item.status === 'current' ? 'الحصة الحالية' : 'قادم'}</span>
            </div>
          </div>
        ))}
      </div>

      <button className="mt-5 w-full rounded-2xl border border-[#2A2A2A] bg-[#0D0D0D] px-4 py-3 text-sm font-medium text-white transition hover:border-[#C9A84C]/40">
        عرض الجدول الكامل
      </button>
    </aside>
  );
};
