import React from 'react';
import { mockAnnouncements, mockExams } from '../../mocks/dashboard';
import { useTimer } from '../../hooks';
import { ChevronLeft, Clock, Megaphone, CalendarDays } from 'lucide-react';

interface BottomCardsProps {
  onViewAllAnnouncements?: () => void;
  onViewAllExams?: () => void;
}

export const BottomCards: React.FC<BottomCardsProps> = ({
  onViewAllAnnouncements,
  onViewAllExams,
}) => {
  const { formattedTime, start, pause, reset, isRunning } = useTimer();

  React.useEffect(() => {
    start();
    return () => pause();
  }, [start, pause]);

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-3" dir="rtl">
      <div className="rounded-[1.5rem] border border-[#2A2A2A] bg-[#111111] p-5">
        <div className="mb-4 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#C9A84C]/10">
            <Clock size={20} className="text-[#C9A84C]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">الحصة الحالية</h3>
            <p className="text-xs text-[#A0A0A0]">الدراسات الاجتماعية - الصف الأول الإعدادي</p>
          </div>
        </div>

        <div className="py-4 text-center">
          <div className="mb-2 font-mono text-4xl font-black text-[#C9A84C]">{formattedTime}</div>
          <p className="text-xs text-[#A0A0A0]">الوقت المنقضي</p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={isRunning ? pause : start}
            className="flex-1 rounded-xl bg-[#C9A84C] py-2 text-xs font-bold text-black transition hover:bg-[#E8D5A3]"
          >
            {isRunning ? 'إيقاف مؤقت' : 'استئناف'}
          </button>
          <button
            onClick={reset}
            className="flex-1 rounded-xl bg-[#1A1A1A] py-2 text-xs font-medium text-white transition hover:bg-[#2A2A2A]"
          >
            إنهاء الحصة
          </button>
        </div>
      </div>

      <div className="rounded-[1.5rem] border border-[#2A2A2A] bg-[#111111] p-5">
        <div className="mb-4 flex items-center gap-2">
          <Megaphone size={18} className="text-[#C9A84C]" />
          <h3 className="text-sm font-bold text-white">آخر الإعلانات</h3>
        </div>
        <div className="space-y-3">
          {mockAnnouncements.map((item) => (
            <div key={item.id} className="flex items-start gap-3 rounded-2xl border border-[#2A2A2A] bg-[#0D0D0D] p-3">
              <div className={`mt-1.5 h-2 w-2 rounded-full flex-shrink-0 ${item.type === 'exam' ? 'bg-red-500' : 'bg-[#C9A84C]'}`} />
              <div className="flex-1">
                <p className="text-xs font-medium leading-relaxed text-white">{item.title}</p>
                <p className="mt-1 text-xs text-[#666]">{item.date}</p>
              </div>
            </div>
          ))}
        </div>
        <button
          onClick={onViewAllAnnouncements}
          className="mt-3 flex w-full items-center justify-center gap-1 text-xs text-[#C9A84C] hover:underline"
        >
          عرض جميع الإعلانات <ChevronLeft size={14} />
        </button>
      </div>

      <div className="rounded-[1.5rem] border border-[#2A2A2A] bg-[#111111] p-5">
        <div className="mb-4 flex items-center gap-2">
          <CalendarDays size={18} className="text-[#C9A84C]" />
          <h3 className="text-sm font-bold text-white">الاختبارات القادمة</h3>
        </div>
        <div className="space-y-3">
          {mockExams.map((exam) => (
            <div key={exam.id} className="flex items-start gap-3 rounded-2xl border border-[#2A2A2A] bg-[#0D0D0D] p-3">
              <div className="mt-1.5 h-2 w-2 rounded-full bg-[#C9A84C] flex-shrink-0" />
              <div className="flex-1">
                <p className="text-xs font-medium leading-relaxed text-white">{exam.subject}</p>
                <p className="mt-1 text-xs text-[#666]">{exam.date}</p>
              </div>
            </div>
          ))}
        </div>
        <button
          onClick={onViewAllExams}
          className="mt-3 flex w-full items-center justify-center gap-1 text-xs text-[#C9A84C] hover:underline"
        >
          عرض جميع الاختبارات <ChevronLeft size={14} />
        </button>
      </div>
    </div>
  );
};
