import React from 'react';
import { BRAND } from '../../constants';
import { Icon } from '../common/Icon';
import { ArrowLeft, CalendarDays, Star } from 'lucide-react';

interface HeroSectionProps {
  onStartSession?: () => void;
  onViewSchedule?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onStartSession, onViewSchedule }) => {
  return (
    <section
      className="relative overflow-hidden rounded-[2rem] border border-[#2A2A2A] bg-gradient-to-br from-[#151515] via-[#111111] to-[#0A0A0A] p-6 shadow-glow md:p-8"
      dir="rtl"
    >
      <div className="absolute inset-0 opacity-20">
        <div className="absolute -left-12 top-8 h-48 w-48 rounded-full bg-[#C9A84C]/20 blur-3xl" />
        <div className="absolute bottom-0 right-0 h-64 w-64 rounded-full bg-[#8B6914]/20 blur-3xl" />
      </div>

      <div className="relative grid gap-8 xl:grid-cols-[1.2fr_0.8fr] xl:items-center">
        <div className="space-y-6">
          <div className="inline-flex items-center gap-2 rounded-full border border-[#C9A84C]/30 bg-[#C9A84C]/10 px-4 py-2 text-xs font-medium text-[#E8D5A3]">
            <Star size={14} />
            <span>جاهز لبدء حصة جديدة؟</span>
          </div>

          <div>
            <h1 className="text-3xl font-black leading-tight text-white md:text-5xl">
              {BRAND.name} <span className="text-[#C9A84C]">{BRAND.subtitle}</span>
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-7 text-[#CFCFCF] md:text-base">
              لوحة تعليمية متكاملة لإدارة الطلاب، متابعة الحضور، تشغيل الحصة، وفتح
              السبورة التفاعلية مع تصميم فاخر ومناسب للتابلت.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              onClick={onStartSession}
              className="inline-flex items-center gap-2 rounded-2xl bg-[#C9A84C] px-5 py-3 text-sm font-bold text-black transition hover:bg-[#E8D5A3]"
            >
              <span>ابدأ الحصة الآن</span>
              <ArrowLeft size={16} />
            </button>
            <button
              onClick={onViewSchedule}
              className="inline-flex items-center gap-2 rounded-2xl border border-[#2A2A2A] bg-[#111111] px-5 py-3 text-sm font-medium text-white transition hover:border-[#C9A84C]/40"
            >
              <CalendarDays size={16} className="text-[#C9A84C]" />
              <span>عرض الجدول</span>
            </button>
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            {[
              { label: 'حضور اليوم', value: '92%', icon: 'shieldCheck' },
              { label: 'الطلاب النشطون', value: '38', icon: 'users' },
              { label: 'حصة قادمة', value: '04:00', icon: 'clock' },
            ].map((item) => (
              <div key={item.label} className="rounded-2xl border border-[#2A2A2A] bg-[#111111]/80 p-4">
                <div className="flex items-center gap-2 text-xs text-[#A0A0A0]">
                  <Icon name={item.icon} size={16} className="text-[#C9A84C]" />
                  <span>{item.label}</span>
                </div>
                <div className="mt-3 text-2xl font-black text-white">{item.value}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative mx-auto flex w-full max-w-lg items-center justify-center">
          <div className="absolute inset-6 rounded-[2rem] border border-[#C9A84C]/20 bg-[#C9A84C]/5" />
          <div className="relative z-10 flex w-full items-center justify-center">
            <div className="grid w-full grid-cols-2 gap-4">
              <div className="rounded-[2rem] border border-[#2A2A2A] bg-[#111111]/90 p-5">
                <div className="flex h-20 w-20 items-center justify-center rounded-full border border-[#C9A84C]/30 bg-gradient-to-br from-[#C9A84C] to-[#8B6914] text-white">
                  <Icon name="graduationCap" size={34} />
                </div>
                <div className="mt-5 text-sm font-bold text-white">معلم متميز</div>
                <div className="mt-1 text-xs text-[#A0A0A0]">إدارة وشرح وتفاعل</div>
              </div>

              <div className="rounded-[2rem] border border-[#2A2A2A] bg-[#111111]/90 p-5">
                <div className="text-xs text-[#A0A0A0]">إحصاءات سريعة</div>
                <div className="mt-4 space-y-3">
                  {[
                    { label: 'دروس جاهزة', value: '24' },
                    { label: 'اختبارات', value: '11' },
                    { label: 'خرائط', value: '08' },
                  ].map((row) => (
                    <div key={row.label} className="flex items-center justify-between rounded-2xl bg-[#1A1A1A] px-3 py-2">
                      <span className="text-xs text-[#D7D7D7]">{row.label}</span>
                      <span className="text-sm font-bold text-[#C9A84C]">{row.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="col-span-2 rounded-[2rem] border border-[#2A2A2A] bg-[#111111]/90 p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs text-[#A0A0A0]">أحدث نشاط</div>
                    <div className="mt-1 text-base font-bold text-white">تحضير درس: مفهوم الدولة وعناصرها</div>
                  </div>
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#C9A84C]/10 text-[#C9A84C]">
                    <Icon name="bookOpen" size={20} />
                  </div>
                </div>
                <div className="mt-4 h-2 rounded-full bg-[#2A2A2A]">
                  <div className="h-2 w-2/3 rounded-full bg-gradient-to-r from-[#C9A84C] to-[#E8D5A3]" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
