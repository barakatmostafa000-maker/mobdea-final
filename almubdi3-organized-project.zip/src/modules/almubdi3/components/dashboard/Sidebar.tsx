import React from 'react';
import { NAV_ITEMS, BRAND } from '../../constants';
import { Icon } from '../common/Icon';
import { useSidebar } from '../../hooks';
import { PanelLeft, PanelRight } from 'lucide-react';

interface SidebarProps {
  onNavigate?: (route: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onNavigate }) => {
  const { isOpen, toggle } = useSidebar(true);

  return (
    <aside
      className={`fixed inset-y-0 right-0 z-40 w-64 border-l border-[#2A2A2A] bg-[#111111]/95 backdrop-blur-xl transition-transform duration-300 ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      }`}
      dir="rtl"
    >
      <div className="flex h-full flex-col">
        <div className="flex items-center justify-between border-b border-[#2A2A2A] px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full border border-[#C9A84C]/40 bg-[#1A1A1A] text-[#C9A84C] shadow-glow">
              <Icon name="sparkles" size={20} />
            </div>
            <div>
              <h1 className="text-sm font-bold text-[#C9A84C]">{BRAND.name}</h1>
              <p className="text-[11px] text-[#A0A0A0]">{BRAND.subtitle}</p>
            </div>
          </div>
          <button
            onClick={toggle}
            className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-[#2A2A2A] text-[#A0A0A0] transition hover:border-[#C9A84C]/40 hover:text-white"
            aria-label="toggle sidebar"
          >
            {isOpen ? <PanelRight size={18} /> : <PanelLeft size={18} />}
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4">
          <div className="mb-3 px-2 text-[11px] font-bold uppercase tracking-[0.28em] text-[#666]">
            القائمة
          </div>
          <div className="space-y-1">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate?.(item.route)}
                className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-right text-sm text-[#D7D7D7] transition hover:bg-[#1A1A1A] hover:text-white"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#1A1A1A] text-[#C9A84C]">
                  <Icon name={item.icon} size={18} />
                </span>
                <span className="flex-1">
                  <span className="block font-medium">{item.label}</span>
                  {item.description ? (
                    <span className="mt-0.5 block text-[11px] text-[#777]">{item.description}</span>
                  ) : null}
                </span>
              </button>
            ))}
          </div>
        </nav>

        <div className="border-t border-[#2A2A2A] p-4">
          <button className="flex w-full items-center justify-center gap-2 rounded-xl border border-[#402B2B] bg-[#1A1111] px-4 py-3 text-sm font-medium text-[#FCA5A5] transition hover:bg-[#2A1717]">
            <Icon name="logout" size={16} />
            <span>تسجيل الخروج</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
