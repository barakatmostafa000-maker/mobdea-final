import React, { useMemo } from 'react';
import { BRAND, SEARCH_SUGGESTIONS } from '../../constants';
import { useNotifications, useSearch } from '../../hooks';
import { Bell, Search, Menu } from 'lucide-react';
import { Icon } from '../common/Icon';

export const Header: React.FC = () => {
  const { notifications, unreadCount, markAllAsRead } = useNotifications();
  const { query, setQuery, filteredItems } = useSearch(SEARCH_SUGGESTIONS, (item) => item);

  const todayLabel = useMemo(
    () =>
      new Date().toLocaleDateString('ar-EG', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      }),
    [],
  );

  return (
    <header className="border-b border-[#2A2A2A] bg-[#0D0D0D]/90 px-4 py-4 backdrop-blur-xl md:px-6" dir="rtl">
      <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
        <div className="flex items-center gap-3">
          <button className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-[#2A2A2A] bg-[#1A1A1A] text-[#C9A84C] xl:hidden">
            <Menu size={18} />
          </button>
          <div>
            <h2 className="text-lg font-bold text-white">{BRAND.name}</h2>
            <p className="text-xs text-[#A0A0A0]">{todayLabel}</p>
          </div>
        </div>

        <div className="relative w-full max-w-2xl">
          <div className="flex items-center gap-3 rounded-2xl border border-[#2A2A2A] bg-[#111111] px-4 py-3 shadow-glow">
            <Search size={18} className="text-[#C9A84C]" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث داخل المنصة..."
              className="w-full bg-transparent text-sm text-white outline-none placeholder:text-[#666]"
            />
            {query ? (
              <button onClick={() => setQuery('')} className="text-xs text-[#A0A0A0] hover:text-white">
                مسح
              </button>
            ) : null}
          </div>

          {query ? (
            <div className="absolute z-20 mt-2 w-full overflow-hidden rounded-2xl border border-[#2A2A2A] bg-[#111111] shadow-2xl">
              {filteredItems.slice(0, 5).map((item) => (
                <button
                  key={item}
                  className="block w-full border-b border-[#2A2A2A] px-4 py-3 text-right text-sm text-[#D7D7D7] last:border-0 hover:bg-[#1A1A1A]"
                >
                  {item}
                </button>
              ))}
            </div>
          ) : null}
        </div>

        <div className="flex items-center justify-between gap-3 xl:justify-end">
          <button
            onClick={markAllAsRead}
            className="relative inline-flex h-12 items-center gap-2 rounded-2xl border border-[#2A2A2A] bg-[#111111] px-4 text-sm text-white transition hover:border-[#C9A84C]/40"
          >
            <Bell size={18} className="text-[#C9A84C]" />
            <span>الإشعارات</span>
            {unreadCount > 0 ? (
              <span className="inline-flex min-w-6 items-center justify-center rounded-full bg-[#C9A84C] px-1.5 text-[11px] font-bold text-black">
                {unreadCount}
              </span>
            ) : null}
          </button>

          <div className="flex items-center gap-3 rounded-2xl border border-[#2A2A2A] bg-[#111111] px-3 py-2">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-[#C9A84C] to-[#8B6914] text-white">
              <Icon name="graduationCap" size={20} />
            </div>
            <div className="text-right">
              <div className="text-sm font-semibold text-white">مصطفى بركات</div>
              <div className="text-[11px] text-[#A0A0A0]">معلم دراسات</div>
            </div>
          </div>

          <div className="hidden rounded-2xl border border-[#2A2A2A] bg-[#111111] px-4 py-3 text-right text-xs text-[#A0A0A0] xl:block">
            <span className="block text-[#C9A84C]">لوحة التحكم</span>
            <span className="mt-1 block">إدارة يومك الدراسي</span>
          </div>
        </div>
      </div>

      {notifications.length ? (
        <div className="mt-4 flex flex-wrap gap-2">
          {notifications.slice(0, 2).map((notification) => (
            <span
              key={notification.id}
              className={`rounded-full border px-3 py-1 text-[11px] ${
                notification.unread
                  ? 'border-[#C9A84C]/40 bg-[#C9A84C]/10 text-[#E8D5A3]'
                  : 'border-[#2A2A2A] bg-[#111111] text-[#8A8A8A]'
              }`}
            >
              {notification.title}
            </span>
          ))}
        </div>
      ) : null}
    </header>
  );
};
