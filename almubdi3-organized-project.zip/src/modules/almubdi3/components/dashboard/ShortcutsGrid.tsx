import React from 'react';
import { mockShortcuts } from '../../mocks/dashboard';
import { Icon } from '../common/Icon';
import { ArrowLeft } from 'lucide-react';

interface ShortcutsGridProps {
  onAction?: (route: string) => void;
}

export const ShortcutsGrid: React.FC<ShortcutsGridProps> = ({ onAction }) => {
  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6" dir="rtl">
      {mockShortcuts.map((card) => (
        <div
          key={card.id}
          className="group flex flex-col rounded-[1.5rem] border border-[#2A2A2A] bg-[#111111] p-5 transition hover:border-[#C9A84C]/40"
        >
          <div
            className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl transition-transform group-hover:scale-110"
            style={{ backgroundColor: `${card.color}20` }}
          >
            <Icon name={card.icon} size={24} color={card.color} />
          </div>
          <h4 className="mb-2 text-sm font-bold text-white">{card.title}</h4>
          <p className="mb-4 flex-1 text-xs leading-relaxed text-[#A0A0A0]">{card.description}</p>
          <button
            onClick={() => onAction?.(card.route)}
            className="flex items-center justify-center gap-1 rounded-xl border border-[#2A2A2A] py-2 text-xs font-medium text-[#A0A0A0] transition hover:border-[#C9A84C] hover:bg-[#C9A84C] hover:text-black"
          >
            <span>{card.actionLabel}</span>
            <ArrowLeft size={14} />
          </button>
        </div>
      ))}
    </div>
  );
};
