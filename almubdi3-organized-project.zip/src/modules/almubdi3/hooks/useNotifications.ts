import { useMemo, useState } from 'react';
import { mockNotifications } from '../mocks/dashboard';
import type { NotificationItem } from '../types';

export function useNotifications(initial: NotificationItem[] = mockNotifications) {
  const [notifications, setNotifications] = useState<NotificationItem[]>(initial);

  const unreadCount = useMemo(
    () => notifications.filter((notification) => notification.unread).length,
    [notifications],
  );

  const markAllAsRead = () => {
    setNotifications((current) => current.map((notification) => ({ ...notification, unread: false })));
  };

  const toggleUnread = (id: string) => {
    setNotifications((current) =>
      current.map((notification) =>
        notification.id === id ? { ...notification, unread: !notification.unread } : notification,
      ),
    );
  };

  return {
    notifications,
    unreadCount,
    markAllAsRead,
    toggleUnread,
    setNotifications,
  };
}
