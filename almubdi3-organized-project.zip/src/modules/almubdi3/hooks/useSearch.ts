import { useMemo, useState } from 'react';

export function useSearch<T>(items: T[], selector: (item: T) => string, initialQuery = '') {
  const [query, setQuery] = useState(initialQuery);

  const filteredItems = useMemo(() => {
    const value = query.trim().toLowerCase();
    if (!value) return items;
    return items.filter((item) => selector(item).toLowerCase().includes(value));
  }, [items, query, selector]);

  return {
    query,
    setQuery,
    filteredItems,
  };
}
