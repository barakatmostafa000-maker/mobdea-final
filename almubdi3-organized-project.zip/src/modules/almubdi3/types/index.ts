export interface NavItem {
  id: string;
  label: string;
  icon: string;
  route: string;
  description?: string;
}

export interface ShortcutCard {
  id: string;
  title: string;
  description: string;
  actionLabel: string;
  route: string;
  icon: string;
  color: string;
}

export interface Announcement {
  id: string;
  title: string;
  date: string;
  type: 'info' | 'exam' | 'warning';
}

export interface ExamItem {
  id: string;
  subject: string;
  date: string;
  group?: string;
}

export interface ScheduleItem {
  id: string;
  time: string;
  title: string;
  group: string;
  status: 'upcoming' | 'current' | 'done';
}

export interface StudentItem {
  id: string;
  name: string;
  points: number;
  status?: 'present' | 'late' | 'absent';
}

export interface EncouragementPhrase {
  id: string;
  text: string;
  isFavorite: boolean;
}

export interface NotificationItem {
  id: string;
  title: string;
  time: string;
  unread: boolean;
}

export interface SessionModeItem {
  id: string;
  label: string;
  icon: string;
}
