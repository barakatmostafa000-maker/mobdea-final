# المُبدع - organized export

This archive contains a complete React + TypeScript + Vite starter with:
- Dashboard
- Session Mode
- Whiteboard
- shared hooks, types, constants and mock data

## Run
```bash
npm install
npm run dev
```
