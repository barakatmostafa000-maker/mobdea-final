/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      boxShadow: {
        glow: "0 0 0 1px rgba(201,168,76,.25), 0 12px 40px rgba(0,0,0,.35)",
      },
    },
  },
  plugins: [],
};
