set -euo pipefail
npm run preview -- --host 127.0.0.1 --port 4173 > /tmp/r20-fix24-preview.log 2>&1 &
PID=$!
trap 'kill "$PID" 2>/dev/null || true' EXIT
for attempt in $(seq 1 60); do
  curl --fail --silent http://127.0.0.1:4173/ >/dev/null && break
  sleep 1
done
rm -rf r20-mobdea-online-smoke
R20_MOBDEA_ONLINE_URL=http://127.0.0.1:4173 node scripts/r20-fix24-mobdea-online-smoke.mjs
test -s r20-mobdea-online-smoke/tablet-1280x800-mobdea-online.png
