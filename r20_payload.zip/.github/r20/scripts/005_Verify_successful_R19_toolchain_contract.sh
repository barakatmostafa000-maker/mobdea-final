set -euo pipefail

node --version | tee /tmp/r20-node-version.txt
node -e 'const major=Number(process.versions.node.split(".")[0]); if (major !== 22) { throw new Error(`Expected Node 22, got ${process.version}`); }'

test -s package-lock.json

test -s android/gradle/wrapper/gradle-wrapper.properties
grep -Fq 'gradle-8.11.1-' android/gradle/wrapper/gradle-wrapper.properties

# AGP 8.7.2 is the proven successful environment. If the project stores
# the AGP version literally, reject a different literal version. If it is
# indirection-based, defer the authoritative check to Gradle itself later.
AGP_LINES="$(grep -R -n -E 'com\\.android\\.tools\\.build:gradle|com\\.android\\.application' android --include='*.gradle' --include='*.gradle.kts' --include='*.toml' 2>/dev/null || true)"
if [ -n "$AGP_LINES" ]; then
  printf '%s\n' "$AGP_LINES" > /tmp/r20-agp-lines.txt
  if printf '%s\n' "$AGP_LINES" | grep -Eq '[0-9]+\\.[0-9]+\\.[0-9]+'; then
    printf '%s\n' "$AGP_LINES" | grep -Fq '8.7.2'
  fi
fi

printf 'Node=22 Gradle=8.11.1 JDK=21 AndroidSDK=35 BuildTools=34/35 AGP=8.7.2\n' > /tmp/r20-toolchain-contract.txt
