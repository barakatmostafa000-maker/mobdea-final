set -euo pipefail

node --test \
  tests/r20-fix18-games.test.mjs

node --test \
  tests/online-game.test.mjs \
  tests/gamification.test.mjs \
  tests/student-ranking.test.mjs

node --test \
  tests/r20-fix05-role-dashboard.test.mjs

grep -Eq \
  'R20_GAMES_PATH = ".+"' \
  src/config/r20GamesConfig.js

grep -Fq \
  'R20_GAMES_HAS_QUESTION_FLOW = true' \
  src/config/r20GamesConfig.js

grep -Fq \
  'R20_FIX18_GAMES_V1' \
  src/services/r20GamesRuntime.js

grep -Fq \
  'data-r20-games-dashboard-entry' \
  src/services/r20GamesRuntime.js

grep -Fq \
  'data-r20-game-question-flow' \
  src/services/r20GamesRuntime.js

grep -Fq \
  'data-r20-game-question-transition' \
  src/services/r20GamesRuntime.js

if [ -s /tmp/r20-fix18-games-protected-sources.txt ]; then
  : > /tmp/r20-fix18-games-after.sha256

  while IFS= read -r file; do
    sha256sum "$file"
  done < \
    /tmp/r20-fix18-games-protected-sources.txt \
    > /tmp/r20-fix18-games-after.sha256

  cmp \
    /tmp/r20-fix18-games-before.sha256 \
    /tmp/r20-fix18-games-after.sha256
fi


git diff --check
