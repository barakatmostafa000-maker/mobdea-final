set -euo pipefail

echo "R19 surgical merge guards completed for FIX01-FIX25."
git diff --name-status | tee /tmp/r20-final-source-diff-files.txt

# No repair phase is allowed to delete a protected R19 source file.
if git diff --name-status | grep -Eq '^D[[:space:]]'; then
  echo "ERROR: protected R19 file deletion detected" >&2
  exit 1
fi

# Exact baseline identity remains pinned.
test "$R19_BASE_COMMIT" = "cd7e7cd597af23ca1169e1f19c3ac954727c3f2d"
test "$R19_PATCH_SHA256" = "cdde2432847080323e32430c86e5a717877a6f54a5c21a32820072c1761c7332"
test "$R19_FIX3_PAYLOAD_COMMIT" = "3477b1b9b7f2210823054634e4f840ff9744910c"

git diff --check
