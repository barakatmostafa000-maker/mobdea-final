set -euo pipefail

if [ ! -s scripts/r19-fix8-browser-smoke.mjs ]; then
  echo "Existing tablet smoke script is unavailable; mandatory source/Android gates continue."
  exit 0
fi

npm run preview -- --host 127.0.0.1 --port 4173 > /tmp/r20-cumulative-preview.log 2>&1 &
PREVIEW_PID=$!
trap 'kill "$PREVIEW_PID" 2>/dev/null || true' EXIT

READY=0
for attempt in $(seq 1 60); do
  if curl --fail --silent http://127.0.0.1:4173/ >/dev/null; then
    READY=1
    break
  fi
  sleep 1
done
test "$READY" -eq 1

rm -rf r19-fix8-smoke
R19_SMOKE_URL=http://127.0.0.1:4173 \
  node scripts/r19-fix8-browser-smoke.mjs

test -s r19-fix8-smoke/tablet-1280x800.png
test -s r19-fix8-smoke/tablet-1920x1080.png
