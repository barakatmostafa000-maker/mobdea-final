set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-audit01_08.json \
  --phase AUDIT01_08 \
  --allow "src/services/r20CriticalViewGuard.js" \
  --allow "src/services/r20PortalLoginBridge.js" \
  --allow "src/services/r20PortalScopeGuard.js" \
  --allow "src/styles/r20-audit-phase01-08.css" \
  --allow "tests/r20-audit-phase01-08.test.mjs" \
  --allow "scripts/r20-phase01-08-browser-audit.mjs" \
  --allow "src/main.jsx" \
  --allow "src/services/r20StudentManagement.js" \
  --allow "tests/r20-fix03-student-management.test.mjs" \
  --allow "src/services/r20PortalAuthClient.js" \
  --allow "cloud-worker/r20PortalAccounts.js" \
  --allow "src/services/r20PortalAccountRuntime.js" \
  --allow "src/services/r20PdfGestures.js"
git diff --check
