set -euo pipefail

test -s src/App.jsx
test -s cloud-worker/worker.js
test -s src/services/cloudSync.js
test -s tests/student-portal-sync.test.mjs

grep -Fq 'pullCloudDataIfExists' src/App.jsx
grep -Fq 'mergeAppData' src/App.jsx
grep -Fq 'pushCloudData' src/App.jsx

grep -Fq '/sync' src/services/cloudSync.js
grep -Fq 'student-session:' cloud-worker/worker.js
grep -Fq 'studentPinHash' cloud-worker/worker.js
grep -Fq 'studentPinSalt' cloud-worker/worker.js

# Never invent a second /api/sync architecture.
if grep -Fq '/api/sync' src/services/cloudSync.js; then
  echo "::error::Unexpected fake /api/sync path found."
  exit 1
fi
