set -euo pipefail

node --test tests/r20-fix06-teacher-tablet-dashboard.test.mjs
node --test tests/r20-fix05-role-dashboard.test.mjs

grep -Fq 'R20_FIX06_TEACHER_TABLET_DASHBOARD_V1' \
  src/services/r20TeacherTabletDashboard.js

grep -Fq 'data-r20-teacher-dashboard' \
  src/styles/r20-fix06-teacher-tablet-dashboard.css

grep -Fq 'overflow-x: clip' \
  src/styles/r20-fix06-teacher-tablet-dashboard.css

grep -Fq 'object-fit: contain' \
  src/styles/r20-fix06-teacher-tablet-dashboard.css

grep -Fq 'max-width: 1400px' \
  src/styles/r20-fix06-teacher-tablet-dashboard.css

grep -Fq 'max-width: 1024px' \
  src/styles/r20-fix06-teacher-tablet-dashboard.css

git diff --check
