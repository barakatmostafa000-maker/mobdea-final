set -euo pipefail

node --test tests/r20-fix08-ocr-page-questions.test.mjs
node --test tests/pdf-question-ocr.test.mjs
node --test tests/native-asset-bridge.test.mjs

OCR="android/app/src/main/java/com/mobdea/education/ocr/R20PageOcrPlugin.java"
MAIN="android/app/src/main/java/com/mobdea/education/MainActivity.java"

grep -Fq 'R20_FIX08_NATIVE_PAGE_OCR_V1' "$OCR"
grep -Fq 'Bitmap.Config.ARGB_8888' "$OCR"
grep -Fq 'getAssets().list("tess304")' "$OCR"
grep -Fq 'R20PageOcrPlugin.class' "$MAIN"
grep -Fq 'com.rmtheis:tess-two:9.1.0' android/app/build.gradle

test -s /tmp/r20-fix08-ocr-callers.txt
grep -Fq 'src/pages/ClassMode.jsx' /tmp/r20-fix08-ocr-callers.txt
grep -Fq 'relatedQuestions' src/pages/ClassMode.jsx
grep -Fq 'project12QuestionScope' src/pages/ClassMode.jsx
! grep -Eq 'tess304[/\\]|(ara|eng)\.traineddata' src/pages/ClassMode.jsx

git diff --check
