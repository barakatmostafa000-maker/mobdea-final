set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix17.json \
  --phase FIX17 \
  --allow "src/config/r20MediaCapabilities.js" \
  --allow "src/services/r20MediaControls.js" \
  --allow "src/services/r20PowerPointMode.js" \
  --allow "src/styles/r20-fix17-media.css" \
  --allow "tests/r20-fix17-media.test.mjs" \
  --allow "scripts/r20-fix17-detect-media.py" \
  --allow "scripts/r20-fix17-media-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
