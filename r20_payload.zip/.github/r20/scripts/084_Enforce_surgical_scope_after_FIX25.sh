set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix25.json \
  --phase FIX25 \
  --allow "src/config/r20MonthlyEvaluationConfig.js" \
  --allow "src/services/r20MonthlyEvaluation.js" \
  --allow "src/styles/r20-fix25-monthly-evaluation.css" \
  --allow "tests/r20-fix25-monthly-evaluation.test.mjs" \
  --allow "scripts/r20-fix25-detect-monthly-evaluation.py" \
  --allow "scripts/r20-fix25-monthly-evaluation-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
