set -euo pipefail

# Reuse the Playwright installation from the prior smoke step.
npm run preview \
  -- \
  --host 127.0.0.1 \
  --port 4174 \
  > /tmp/r20-fix16-image-preview.log 2>&1 &

PID=$!

trap \
  'kill "$PID" 2>/dev/null || true' \
  EXIT

READY=0

for attempt in $(seq 1 60); do
  if curl \
    --fail \
    --silent \
    http://127.0.0.1:4174/ \
    >/dev/null; then

    READY=1
    break
  fi

  sleep 1
done

test "$READY" -eq 1

rm -rf \
  r20-image-mode-smoke

R20_IMAGE_MODE_URL=http://127.0.0.1:4174 \
  node \
  scripts/r20-fix16-image-mode-smoke.mjs

test -s \
  r20-image-mode-smoke/tablet-1280x800-image-mode.png

test -s \
  r20-image-mode-smoke/tablet-1920x1080-image-mode.png

test -s \
  r20-image-mode-smoke/mobile-landscape-844x390-image-mode.png
