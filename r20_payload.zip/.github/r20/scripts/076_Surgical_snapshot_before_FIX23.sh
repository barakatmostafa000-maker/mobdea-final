set -euo pipefail
python3 /tmp/r20-surgical-guard.py snapshot /tmp/r20-surgical-fix23.json
