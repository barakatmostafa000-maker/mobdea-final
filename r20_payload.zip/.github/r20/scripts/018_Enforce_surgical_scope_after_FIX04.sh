set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix04.json \
  --phase FIX04 \
  --allow "src/services/r20AccountPolicy.js" \
  --allow "src/services/r20PortalAuthClient.js" \
  --allow "src/services/r20PortalAccountRuntime.js" \
  --allow "src/styles/r20-fix04-accounts.css" \
  --allow "cloud-worker/r20PortalAccounts.js" \
  --allow "tests/r20-fix04-student-parent-accounts.test.mjs" \
  --allow "src/main.jsx" \
  --allow "cloud-worker/worker.js"
git diff --check
