set -euo pipefail

npx cap sync android

test -s android/app/src/main/assets/public/index.html
test "$(find android/app/src/main/assets/public -type f -name '*.js' | wc -l)" -gt 0
test "$(find android/app/src/main/assets/public -type f -name '*.css' | wc -l)" -gt 0
