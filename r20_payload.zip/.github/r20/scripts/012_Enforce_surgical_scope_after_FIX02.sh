set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix02.json \
  --phase FIX02 \
  --allow "src/styles/r20-fix02-unified-classmode-layout.css" \
  --allow "src/services/r20UnifiedClassModeLayout.js" \
  --allow "tests/r20-fix02-unified-classmode-layout.test.mjs" \
  --allow "src/main.jsx"
git diff --check
