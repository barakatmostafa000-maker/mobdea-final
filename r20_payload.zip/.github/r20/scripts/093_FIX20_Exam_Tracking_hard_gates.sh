set -euo pipefail

node --test tests/r20-fix20-exam-tracking.test.mjs

node --test \
  tests/r20-fix19-question-bank-pipeline.test.mjs \
  tests/question-rotation.test.mjs \
  tests/r20-fix18-games.test.mjs

grep -Fq 'R20_FIX20_EXAM_TRACKING_CONFIG_V1' src/config/r20ExamTrackingConfig.js
grep -Fq 'R20_FIX20_EXAM_TRACKING_V1' src/services/r20ExamTracking.js
grep -Fq 'stableExamCodeFromFile' src/services/r20ExamTracking.js
grep -Fq 'getStudentWeakness' src/services/r20ExamTracking.js
grep -Fq 'mobdea:r20-exam-result-ready' src/services/r20ExamTracking.js
grep -Fq 'mobdea:r20-exam-tracking-snapshot' src/services/r20ExamTracking.js

if [ -s /tmp/r20-fix20-exam-protected-sources.txt ]; then
  : > /tmp/r20-fix20-exam-after.sha256

  while IFS= read -r file; do
    sha256sum "$file"
  done < /tmp/r20-fix20-exam-protected-sources.txt \
    > /tmp/r20-fix20-exam-after.sha256

  cmp /tmp/r20-fix20-exam-before.sha256 /tmp/r20-fix20-exam-after.sha256
fi


git diff --check
