set -euo pipefail

node --test tests/r20-fix11-country-cards.test.mjs
node --test tests/r20-fix10-educational-cards.test.mjs

grep -Fq 'R20_FIX11_COUNTRY_CARDS_V1' src/services/r20CountryCards.js
grep -Fq 'data-r20-country-card' src/services/r20CountryCards.js
grep -Fq 'countryCardFontScale' src/services/r20CountryCards.js
grep -Fq 'hasOverflow' src/services/r20CountryCards.js
grep -Fq 'object-fit: contain' src/styles/r20-fix11-country-cards.css
grep -Fq 'overflow-wrap: anywhere' src/styles/r20-fix11-country-cards.css

git diff --check
