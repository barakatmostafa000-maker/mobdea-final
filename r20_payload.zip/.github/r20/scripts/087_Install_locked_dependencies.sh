set -euo pipefail
npm ci --ignore-scripts
