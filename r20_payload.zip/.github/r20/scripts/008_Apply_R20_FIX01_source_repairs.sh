set -euo pipefail

python3 - <<'PY'
from pathlib import Path
import re

class_mode = Path("src/pages/ClassMode.jsx")
if not class_mode.is_file():
    raise SystemExit("src/pages/ClassMode.jsx is missing")

source = class_mode.read_text(encoding="utf-8")
related_start_marker = "  const relatedQuestions = useMemo(() => {"
related_end_marker = "\n\n  const rememberGameQuestions"
project12_marker = "  const [project12QuestionScope, setProject12QuestionScope] = useState('page');"

related_start = source.find(related_start_marker)
related_end = source.find(related_end_marker, related_start)
project12_pos = source.find(project12_marker)

if related_start >= 0 and related_end >= 0 and project12_pos >= 0:
    if related_start > project12_pos:
        related_block = source[related_start:related_end].rstrip() + "\n\n"
        source = source[:related_start] + source[related_end + 2:]
        project12_pos = source.find(project12_marker)
        source = source[:project12_pos] + related_block + source[project12_pos:]
        class_mode.write_text(source, encoding="utf-8")

    check = class_mode.read_text(encoding="utf-8")
    if check.find(related_start_marker) > check.find(project12_marker):
        raise SystemExit("ClassMode TDZ repair did not hold")

css = r'''/* R20_FIX01_CORE_RUNTIME_V1 */

html, body, #root {
  max-width: 100%;
}

.lesson-mode-shell,
.classmode-page,
.classmode-v103 {
  min-width: 0 !important;
  max-width: 100% !important;
  overflow: hidden !important;
}

.classmode-v103 .classmode-main,
.classmode-v103 .classmode-content,
.classmode-v103 .classmode-stage,
.classmode-v103 .classmode-resource-area,
.classmode-v103 .classmode-media-stage,
.classmode-v103 .classmode-whiteboard-stage {
  min-width: 0 !important;
  max-width: 100% !important;
}

.classmode-v103 .classmode-students-list,
.classmode-v103 .r19-split-source,
.classmode-v103 .student-list,
.classmode-v103 [data-r20-scroll="students"] {
  min-height: 0 !important;
  max-height: min(68dvh, 610px) !important;
  overflow-y: auto !important;
  overscroll-behavior: contain !important;
  -webkit-overflow-scrolling: touch !important;
  touch-action: pan-y !important;
  scrollbar-gutter: stable;
}

.classmode-v103 .classmode-page-nav,
.classmode-v103 [data-r20-page-nav="true"] {
  opacity: .62 !important;
  transform: scale(.82);
  transform-origin: bottom center;
}

.classmode-v103 .r20-return-control {
  position: fixed !important;
  top: calc(6px + env(safe-area-inset-top, 0px)) !important;
  left: 8px !important;
  right: auto !important;
  bottom: auto !important;
  width: 38px !important;
  min-width: 38px !important;
  height: 38px !important;
  min-height: 38px !important;
  padding: 0 !important;
  border-radius: 50% !important;
  font-size: 0 !important;
  opacity: .78 !important;
  z-index: 1400 !important;
}

.classmode-v103 .r20-return-control::before {
  content: "←";
  font-size: 22px;
  line-height: 1;
}

.classmode-v103 .r20-save-control {
  width: 38px !important;
  min-width: 38px !important;
  height: 38px !important;
  min-height: 38px !important;
  padding: 0 !important;
  font-size: 0 !important;
  opacity: .64 !important;
}

.classmode-v103 .r20-save-control::before {
  content: "💾";
  font-size: 18px;
}

.classmode-v103 .r20-student-control {
  width: 40px !important;
  min-width: 40px !important;
  height: 40px !important;
  min-height: 40px !important;
  padding: 0 !important;
  font-size: 0 !important;
  opacity: .78 !important;
}

.classmode-v103 .r20-student-control::before {
  content: "👥";
  font-size: 19px;
}

.classmode-v103 .r20-duplicate-student-control,
.classmode-v103 .r20-old-random-dialog {
  display: none !important;
}

/* Preserve the working R19 Online Lesson action. Only neutralize floating geometry. */
.classmode-v103 .r20-online-floating-control {
  display: inline-flex !important;
  position: static !important;
  inset: auto !important;
  transform: none !important;
  margin: 0 !important;
  z-index: auto !important;
}

.classmode-v103 .r20-board-tools-control,
.classmode-v103 .r20-cards-control {
  width: 42px !important;
  min-width: 42px !important;
  height: 42px !important;
  min-height: 42px !important;
  padding: 0 !important;
  font-size: 0 !important;
  border-radius: 12px !important;
}

.classmode-v103 .r20-board-tools-control::before {
  content: "🖍️";
  font-size: 19px;
}

.classmode-v103 .r20-cards-control::before {
  content: "🗂️";
  font-size: 19px;
}

.classmode-v103 .whiteboard-shell,
.classmode-v103 .whiteboard-stage,
.classmode-v103 .board-stage,
.classmode-v103 .classmode-board {
  box-sizing: border-box !important;
  width: 100% !important;
  max-width: 100% !important;
  margin-inline: auto !important;
}

.classmode-v103 .game-shell,
.classmode-v103 .classmode-game,
.classmode-v103 .map-game-layout,
.map-challenge-pro > .map-game-layout {
  min-width: 0 !important;
  max-width: 100% !important;
}

.classmode-v103 .game-shell,
.classmode-v103 .classmode-game,
.map-challenge-pro {
  overflow: auto !important;
  overscroll-behavior: contain !important;
  -webkit-overflow-scrolling: touch !important;
}

.classmode-v103 dialog,
.classmode-v103 [role="dialog"],
.classmode-v103 .modal,
.classmode-v103 .dialog {
  max-height: min(88dvh, 720px) !important;
  max-width: min(94vw, 760px) !important;
}

.classmode-v103 dialog .modal-body,
.classmode-v103 [role="dialog"] .modal-body,
.classmode-v103 .modal .modal-body,
.classmode-v103 .dialog .dialog-body {
  min-height: 0 !important;
  max-height: 74dvh !important;
  overflow-y: auto !important;
  overscroll-behavior: contain !important;
  -webkit-overflow-scrolling: touch !important;
}

.dashboard-v103,
.dashboard-v103 .dashboard-reference-hero,
.dashboard-v103 .dashboard-reference-copy,
.dashboard-v103 .dashboard-feature-grid {
  min-width: 0 !important;
  max-width: 100% !important;
}

.dashboard-v103 .dashboard-reference-copy {
  overflow: visible !important;
}

.dashboard-v103 .dashboard-reference-copy p,
.dashboard-v103 .dashboard-reference-copy h1,
.dashboard-v103 .dashboard-reference-copy h2 {
  max-width: 100% !important;
  overflow-wrap: anywhere;
}

@media (orientation: landscape) and (max-width: 1400px) {
  .classmode-v103 .classmode-students-list,
  .classmode-v103 .r19-split-source {
    max-height: calc(100dvh - 160px) !important;
  }
}
'''

css_path = Path("src/styles/r20-fix01-core-runtime.css")
css_path.parent.mkdir(parents=True, exist_ok=True)
css_path.write_text(css.strip() + "\n", encoding="utf-8")

runtime = r'''const R20_MARKER = "R20_FIX01_CORE_RUNTIME_V1";

const norm = (value) =>
  String(value ?? "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();

function classModeRoot() {
  return document.querySelector(
    ".classmode-v103, .classmode-page, .lesson-mode-shell",
  );
}

function visible(element) {
  if (!element) return false;
  const style = getComputedStyle(element);
  return (
    style.display !== "none" &&
    style.visibility !== "hidden" &&
    element.getClientRects().length > 0
  );
}

function elementLabel(element) {
  return norm(
    [
      element?.getAttribute?.("aria-label"),
      element?.getAttribute?.("title"),
      element?.textContent,
    ]
      .filter(Boolean)
      .join(" "),
  );
}

function classifyControls(root) {
  if (!root) return;

  const controls = [
    ...root.querySelectorAll(
      'button, [role="button"], a[class*="button"], a[class*="btn"]',
    ),
  ];
  const studentButtons = [];

  for (const control of controls) {
    const label = elementLabel(control);

    if (/عودة الحصة|العودة للحصة|رجوع للحصة/.test(label)) {
      control.classList.add("r20-return-control");
      control.setAttribute("aria-label", "عودة للحصة");
      control.setAttribute("title", "عودة للحصة");
    }

    if (/^حفظ$| حفظ |حفظ السبورة|حفظ الصفحة/.test(` ${label} `)) {
      control.classList.add("r20-save-control");
      control.setAttribute("aria-label", "حفظ");
    }

    if (/إدارة طالب|إدارة الطلاب|قائمة الطلاب/.test(label)) {
      control.classList.add("r20-student-control");
      studentButtons.push(control);
    }

    if (/الحصة الأونلاين|الحصة الاونلاين|online lesson|online class/.test(label)) {
      control.classList.add("r20-online-floating-control");
    }

    if (/أدوات السبورة|ادوات السبورة|board tools|whiteboard tools/.test(label)) {
      control.classList.add("r20-board-tools-control");
      control.setAttribute("aria-label", "أدوات السبورة");
    }

    if (/^البطاقات$|^بطاقات$|الكروت|cards/.test(label)) {
      control.classList.add("r20-cards-control");
      control.setAttribute("aria-label", "البطاقات");
    }
  }

  studentButtons
    .filter((button) => visible(button))
    .slice(1)
    .forEach((button) =>
      button.classList.add("r20-duplicate-student-control"),
    );

  root
    .querySelectorAll(".classmode-page-nav, [class*='page-nav']")
    .forEach((element) =>
      element.setAttribute("data-r20-page-nav", "true"),
    );

  root
    .querySelectorAll(
      ".classmode-students-list, .r19-split-source, [class*='student-list']",
    )
    .forEach((element) =>
      element.setAttribute("data-r20-scroll", "students"),
    );

  for (const dialog of root.querySelectorAll(
    'dialog, [role="dialog"], .modal, [class*="dialog"], [class*="modal"]',
  )) {
    const label = elementLabel(dialog);
    if (
      /اختيار عشوائي|الاختيار العشوائي/.test(label) &&
      !dialog.closest(".r20-random-picker")
    ) {
      dialog.classList.add("r20-old-random-dialog");
    }
  }
}

function scrubInternalOcrPath(root = document.body) {
  if (!root) return;

  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);

  for (const node of nodes) {
    const text = String(node.nodeValue || "");
    if (
      /(?:^|[/\\])tess304[/\\]/i.test(text) ||
      /\b(?:ara|eng)\.traineddata\b/i.test(text)
    ) {
      node.nodeValue = text.replace(
        /(?:[\w.-]+[/\\])*tess304[/\\][\w.-]+|(?:ara|eng)\.traineddata/gi,
        "OCR العربي",
      );
    }
  }
}

let audioContext = null;

async function unlockTabletMedia() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (AudioCtx) {
      if (!audioContext) audioContext = new AudioCtx();
      if (audioContext.state === "suspended") {
        await audioContext.resume();
      }
    }
  } catch {
    // Native audio/TTS remains available.
  }

  try {
    window.speechSynthesis?.resume?.();
  } catch {
    // No-op.
  }

  document.dispatchEvent(
    new CustomEvent("mobdea:r20-media-unlocked", {
      detail: { marker: R20_MARKER },
    }),
  );
}

export async function r20SpeakArabic(text) {
  const safe = String(text || "").trim();
  if (!safe) return false;

  await unlockTabletMedia();

  try {
    const plugins = globalThis.Capacitor?.Plugins || {};
    const nativeTts =
      plugins.MobdeaTextToSpeech ||
      plugins.MobdeaTTS ||
      plugins.TextToSpeech;

    if (nativeTts?.speak) {
      await nativeTts.speak({
        text: safe,
        language: "ar-EG",
        lang: "ar-EG",
        rate: 0.92,
      });
      return true;
    }
  } catch {
    // Fall back to browser TTS.
  }

  try {
    if ("speechSynthesis" in window && "SpeechSynthesisUtterance" in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(safe);
      utterance.lang = "ar-EG";
      utterance.rate = 0.92;
      window.speechSynthesis.speak(utterance);
      return true;
    }
  } catch {
    // No-op.
  }

  return false;
}

function installRuntime() {
  if (typeof document === "undefined") return;

  const run = () => {
    const root = classModeRoot();
    if (root) classifyControls(root);
    scrubInternalOcrPath(document.body);
  };

  for (const eventName of ["pointerdown", "touchend", "keydown"]) {
    document.addEventListener(eventName, unlockTabletMedia, {
      capture: true,
      passive: true,
    });
  }

  window.addEventListener("error", (event) => {
    try {
      sessionStorage.setItem(
        "mobdea:r20:last-runtime-error",
        JSON.stringify({
          message: String(event?.message || "Runtime error"),
          source: String(event?.filename || ""),
          line: Number(event?.lineno || 0),
          at: new Date().toISOString(),
        }),
      );
    } catch {
      // Diagnostics must never crash the UI.
    }
  });

  window.addEventListener("unhandledrejection", (event) => {
    try {
      sessionStorage.setItem(
        "mobdea:r20:last-runtime-rejection",
        JSON.stringify({
          message: String(event?.reason?.message || event?.reason || "Promise rejection"),
          at: new Date().toISOString(),
        }),
      );
    } catch {
      // Diagnostics must never crash the UI.
    }
  });

  let queued = false;
  const observer = new MutationObserver(() => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      run();
    });
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true,
  });

  run();
}

if (typeof window !== "undefined") {
  window.__MOBDEA_R20_FIX01__ = R20_MARKER;
  window.mobdeaR20SpeakArabic = r20SpeakArabic;

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", installRuntime, {
      once: true,
    });
  } else {
    installRuntime();
  }
}
'''

runtime_path = Path("src/services/r20RuntimeCore.js")
runtime_path.parent.mkdir(parents=True, exist_ok=True)
runtime_path.write_text(runtime.strip() + "\n", encoding="utf-8")

main = Path("src/main.jsx")
if not main.is_file():
    raise SystemExit("src/main.jsx is missing")

main_source = main.read_text(encoding="utf-8")
imports = [
    "import './styles/r20-fix01-core-runtime.css';",
    "import './services/r20RuntimeCore.js';",
]

for item in imports:
    if item not in main_source:
        matches = list(
            re.finditer(r"^import[\s\S]*?;\s*$", main_source, flags=re.M)
        )
        if not matches:
            raise SystemExit("main.jsx import block not found")
        pos = matches[-1].end()
        main_source = main_source[:pos] + "\n" + item + main_source[pos:]

main.write_text(main_source, encoding="utf-8")

activity = Path(
    "android/app/src/main/java/com/mobdea/education/MainActivity.java"
)
if not activity.is_file():
    raise SystemExit("MainActivity.java is missing")

java = activity.read_text(encoding="utf-8")
marker = "R20_FIX01_TABLET_MEDIA_WEBVIEW_V1"

if marker not in java:
    anchor = "super.onCreate(savedInstanceState);"
    pos = java.find(anchor)
    if pos < 0:
        raise SystemExit("MainActivity onCreate anchor not found")

    insert_pos = pos + len(anchor)
    code = r'''
        // R20_FIX01_TABLET_MEDIA_WEBVIEW_V1
        if (getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().post(() -> {
                android.webkit.WebSettings settings =
                    getBridge().getWebView().getSettings();
                settings.setMediaPlaybackRequiresUserGesture(false);
                settings.setDomStorageEnabled(true);
                settings.setAllowContentAccess(true);
                settings.setAllowFileAccess(true);
                if (android.os.Build.VERSION.SDK_INT >=
                    android.os.Build.VERSION_CODES.LOLLIPOP) {
                    settings.setMixedContentMode(
                        android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    );
                }
            });
        }
'''
    java = java[:insert_pos] + code + java[insert_pos:]
    activity.write_text(java, encoding="utf-8")

test = r'''import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

const read = (path) => fs.readFileSync(path, "utf8");

test("R20 core runtime and native tablet media are installed", () => {
  const main = read("src/main.jsx");
  assert.match(main, /r20-fix01-core-runtime\.css/);
  assert.match(main, /r20RuntimeCore\.js/);

  const runtime = read("src/services/r20RuntimeCore.js");
  assert.match(runtime, /R20_FIX01_CORE_RUNTIME_V1/);
  assert.match(runtime, /mobdea:r20-media-unlocked/);
  assert.match(runtime, /r20SpeakArabic/);
  assert.match(runtime, /tess304/);
  assert.match(runtime, /r20-return-control/);

  const css = read("src/styles/r20-fix01-core-runtime.css");
  assert.match(css, /R20_FIX01_CORE_RUNTIME_V1/);
  assert.match(css, /overflow-y:\s*auto\s*!important/);
  assert.match(css, /r20-online-floating-control/);
  assert.match(css, /r20-board-tools-control/);

  const activity = read(
    "android/app/src/main/java/com/mobdea/education/MainActivity.java",
  );
  assert.match(activity, /R20_FIX01_TABLET_MEDIA_WEBVIEW_V1/);
  assert.match(activity, /setMediaPlaybackRequiresUserGesture\(false\)/);
  assert.match(activity, /setDomStorageEnabled\(true\)/);
});

test("ClassMode Project12 dependency cannot precede relatedQuestions", () => {
  const source = read("src/pages/ClassMode.jsx");
  const related = source.indexOf("const relatedQuestions = useMemo");
  const project12 = source.indexOf("const [project12QuestionScope");
  if (related >= 0 && project12 >= 0) {
    assert.ok(
      related < project12,
      "relatedQuestions must initialize before Project12 state",
    );
  }
});
'''

test_path = Path("tests/r20-fix01-core-runtime.test.mjs")
test_path.parent.mkdir(parents=True, exist_ok=True)
test_path.write_text(test.strip() + "\n", encoding="utf-8")

print("R20 FIX01 source repairs installed.")
PY

git add -N \
  src/services/r20RuntimeCore.js \
  src/styles/r20-fix01-core-runtime.css \
  tests/r20-fix01-core-runtime.test.mjs

git diff --check
node --check src/services/r20RuntimeCore.js
node --check tests/r20-fix01-core-runtime.test.mjs
node --test tests/r20-fix01-core-runtime.test.mjs
