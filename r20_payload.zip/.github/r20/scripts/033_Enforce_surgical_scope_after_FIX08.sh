set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix08.json \
  --phase FIX08 \
  --allow "android/app/src/main/java/com/mobdea/education/ocr/R20PageOcrPlugin.java" \
  --allow "src/services/r20PageOcrPipeline.js" \
  --allow "src/services/r20OcrUiGuard.js" \
  --allow "src/styles/r20-fix08-ocr-page-questions.css" \
  --allow "tests/r20-fix08-ocr-page-questions.test.mjs" \
  --allow "src/main.jsx" \
  --allow "src/pages/ClassMode.jsx" \
  --allow "android/app/src/main/java/com/mobdea/education/MainActivity.java" \
  --allow "android/app/build.gradle"
git diff --check
