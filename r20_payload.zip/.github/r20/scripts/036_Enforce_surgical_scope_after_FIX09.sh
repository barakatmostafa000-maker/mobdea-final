set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix09.json \
  --phase FIX09 \
  --allow "src/services/r20WhiteboardRuntime.js" \
  --allow "src/styles/r20-fix09-whiteboard.css" \
  --allow "tests/r20-fix09-whiteboard.test.mjs" \
  --allow "scripts/r20-fix09-whiteboard-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
