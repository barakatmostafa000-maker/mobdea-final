set +e

OUT="/tmp/mobdea-r20-final-audited-01-26-failure"
mkdir -p "$OUT"

git status --short > "$OUT/git-status.txt" 2>&1
git diff --check > "$OUT/git-diff-check.txt" 2>&1
git diff --binary > "$OUT/current.patch" 2>&1
git diff --stat > "$OUT/current-stat.txt" 2>&1

cp /tmp/r20-source-label.txt "$OUT/RECOVERED-SOURCE.txt" 2>/dev/null || true
cp -r android/app/build/reports "$OUT/android-reports" 2>/dev/null || true
cp -r android/app/build/test-results "$OUT/android-test-results" 2>/dev/null || true
cp android/app/build/outputs/apk/debug/app-debug.apk \
  "$OUT/partial-debug.apk" 2>/dev/null || true

grep -R -n -E 'student-session:|studentPinHash|studentPinSalt' \
  cloud-worker/worker.js > "$OUT/student-worker-contract.txt" 2>&1 || true

grep -n -E 'pullCloudDataIfExists|mergeAppData|pushCloudData' \
  src/App.jsx > "$OUT/app-cloud-flow.txt" 2>&1 || true

cp /tmp/r20-fix06-preview.log "$OUT/preview.log" 2>/dev/null || true
cp -r r19-fix8-smoke "$OUT/tablet-smoke" 2>/dev/null || true

cp /tmp/r20-phase01-08-preview.log "$OUT/browser-preview.log" 2>/dev/null || true
cp /tmp/r20-online-lesson-sources.txt "$OUT/online-lesson-sources.txt" 2>/dev/null || true
cp -r r20-phase01-08-audit "$OUT/browser-audit" 2>/dev/null || true

cp /tmp/r20-fix08-ocr-callers.txt "$OUT/OCR-CALLERS.txt" 2>/dev/null || true

cp /tmp/r20-fix09-preview.log "$OUT/whiteboard-preview.log" 2>/dev/null || true
cp /tmp/r20-fix09-whiteboard-sources.txt "$OUT/WHITEBOARD-SOURCES.txt" 2>/dev/null || true
cp -r r20-whiteboard-smoke "$OUT/whiteboard-smoke" 2>/dev/null || true

cp /tmp/r20-fix10-preview.log "$OUT/cards-preview.log" 2>/dev/null || true
cp /tmp/r20-fix10-card-sources.txt "$OUT/EDUCATIONAL-CARD-SOURCES.txt" 2>/dev/null || true
cp -r r20-educational-cards-smoke "$OUT/educational-cards-smoke" 2>/dev/null || true

cp /tmp/r20-fix11-preview.log "$OUT/country-cards-preview.log" 2>/dev/null || true
cp /tmp/r20-fix11-country-card-sources.txt "$OUT/COUNTRY-CARD-SOURCES.txt" 2>/dev/null || true
cp -r r20-country-cards-smoke "$OUT/country-cards-smoke" 2>/dev/null || true

cp /tmp/r20-fix12-preview.log "$OUT/maps-preview.log" 2>/dev/null || true
cp /tmp/r20-fix12-map-sources.txt "$OUT/MAP-SOURCES.txt" 2>/dev/null || true
cp -r r20-maps-smoke "$OUT/maps-smoke" 2>/dev/null || true

cp /tmp/r20-fix13-preview.log "$OUT/atlas-preview.log" 2>/dev/null || true
cp /tmp/r20-fix13-atlas-sources.txt "$OUT/ATLAS-SOURCES.txt" 2>/dev/null || true
cp -r r20-atlas-smoke "$OUT/atlas-smoke" 2>/dev/null || true

cp /tmp/r20-fix14-preview.log "$OUT/geography-preview.log" 2>/dev/null || true
cp /tmp/r20-fix14-geography-sources.txt "$OUT/GEOGRAPHY-SOURCES.txt" 2>/dev/null || true
cp /tmp/r20-fix14-geography-patched.txt "$OUT/GEOGRAPHY-PATCHED-SOURCES.txt" 2>/dev/null || true
cp -r r20-geography-smoke "$OUT/geography-smoke" 2>/dev/null || true

cp /tmp/r20-fix15-preview.log "$OUT/map-challenge-preview.log" 2>/dev/null || true
cp /tmp/r20-fix15-map-challenge-sources.txt "$OUT/MAP-CHALLENGE-SOURCES.txt" 2>/dev/null || true
cp /tmp/r20-fix15-map-challenge-before.sha256 "$OUT/MAP-CHALLENGE-BEFORE.sha256" 2>/dev/null || true
cp /tmp/r20-fix15-map-challenge-after.sha256 "$OUT/MAP-CHALLENGE-AFTER.sha256" 2>/dev/null || true
cp src/config/r20MapChallengeConfig.js "$OUT/MAP-CHALLENGE-CONFIG.js" 2>/dev/null || true
cp -r r20-map-challenge-smoke "$OUT/map-challenge-smoke" 2>/dev/null || true

cp /tmp/r20-fix16-natural-preview.log "$OUT/natural-preview.log" 2>/dev/null || true
cp /tmp/r20-fix16-image-preview.log "$OUT/image-preview.log" 2>/dev/null || true
cp /tmp/r20-fix16-natural-layer-sources.txt "$OUT/NATURAL-LAYER-SOURCES.txt" 2>/dev/null || true
cp src/config/r20MapChallengeNaturalLayersConfig.js "$OUT/NATURAL-LAYER-CONFIG.js" 2>/dev/null || true
cp -r r20-natural-layers-smoke "$OUT/natural-layers-smoke" 2>/dev/null || true
cp -r r20-image-mode-smoke "$OUT/image-mode-smoke" 2>/dev/null || true

cp /tmp/r20-fix17-preview.log "$OUT/media-preview.log" 2>/dev/null || true
cp /tmp/r20-fix17-media-sources.txt "$OUT/MEDIA-SOURCES.txt" 2>/dev/null || true
cp /tmp/r20-fix17-media-before.sha256 "$OUT/MEDIA-BEFORE.sha256" 2>/dev/null || true
cp /tmp/r20-fix17-media-after.sha256 "$OUT/MEDIA-AFTER.sha256" 2>/dev/null || true
cp src/config/r20MediaCapabilities.js "$OUT/MEDIA-CAPABILITIES.js" 2>/dev/null || true
cp -r r20-media-smoke "$OUT/media-smoke" 2>/dev/null || true

cp /tmp/r20-fix18-preview.log "$OUT/games-preview.log" 2>/dev/null || true
cp /tmp/r20-fix18-games-sources.txt "$OUT/GAMES-SOURCES.txt" 2>/dev/null || true
cp /tmp/r20-fix18-games-before.sha256 "$OUT/GAMES-BEFORE.sha256" 2>/dev/null || true
cp /tmp/r20-fix18-games-after.sha256 "$OUT/GAMES-AFTER.sha256" 2>/dev/null || true
cp src/config/r20GamesConfig.js "$OUT/GAMES-CONFIG.js" 2>/dev/null || true
cp -r r20-games-smoke "$OUT/games-smoke" 2>/dev/null || true

cp /tmp/r20-fix19-preview.log "$OUT/question-bank-preview.log" 2>/dev/null || true
cp /tmp/r20-fix19-question-bank-sources.txt "$OUT/QUESTION-BANK-SOURCES.txt" 2>/dev/null || true
cp /tmp/r20-fix19-question-bank-before.sha256 "$OUT/QUESTION-BANK-BEFORE.sha256" 2>/dev/null || true
cp /tmp/r20-fix19-question-bank-after.sha256 "$OUT/QUESTION-BANK-AFTER.sha256" 2>/dev/null || true
cp src/config/r20QuestionBankConfig.js "$OUT/QUESTION-BANK-CONFIG.js" 2>/dev/null || true
cp -r r20-question-bank-smoke "$OUT/question-bank-smoke" 2>/dev/null || true

cp /tmp/r20-fix20-preview.log "$OUT/exam-tracking-preview.log" 2>/dev/null || true
cp /tmp/r20-fix20-exam-sources.txt "$OUT/EXAM-SOURCES.txt" 2>/dev/null || true
cp /tmp/r20-fix20-exam-before.sha256 "$OUT/EXAM-BEFORE.sha256" 2>/dev/null || true
cp /tmp/r20-fix20-exam-after.sha256 "$OUT/EXAM-AFTER.sha256" 2>/dev/null || true
cp src/config/r20ExamTrackingConfig.js "$OUT/EXAM-TRACKING-CONFIG.js" 2>/dev/null || true
cp -r r20-exam-tracking-smoke "$OUT/exam-tracking-smoke" 2>/dev/null || true

cp /tmp/r20-fix21-preview.log "$OUT/reports-preview.log" 2>/dev/null || true
cp /tmp/r20-fix21-report-sources.txt "$OUT/REPORT-SOURCES.txt" 2>/dev/null || true
cp /tmp/r20-fix21-report-before.sha256 "$OUT/REPORT-BEFORE.sha256" 2>/dev/null || true
cp /tmp/r20-fix21-report-after.sha256 "$OUT/REPORT-AFTER.sha256" 2>/dev/null || true
cp src/config/r20ReportsWhatsAppConfig.js "$OUT/REPORTS-WHATSAPP-CONFIG.js" 2>/dev/null || true
cp -r r20-reports-whatsapp-smoke "$OUT/reports-whatsapp-smoke" 2>/dev/null || true

cp /tmp/r20-fix22-preview.log "$OUT/remedial-preview.log" 2>/dev/null || true
cp /tmp/r20-fix22-remedial-sources.txt "$OUT/REMEDIAL-SOURCES.txt" 2>/dev/null || true
cp /tmp/r20-fix22-remedial-before.sha256 "$OUT/REMEDIAL-BEFORE.sha256" 2>/dev/null || true
cp /tmp/r20-fix22-remedial-after.sha256 "$OUT/REMEDIAL-AFTER.sha256" 2>/dev/null || true
cp src/config/r20RemedialAssistantConfig.js "$OUT/REMEDIAL-CONFIG.js" 2>/dev/null || true
cp -r r20-remedial-smoke "$OUT/remedial-smoke" 2>/dev/null || true

cp /tmp/r20-fix23-preview.log "$OUT/duplex-preview.log" 2>/dev/null || true
cp /tmp/r20-fix23-print-sources.txt "$OUT/DUPLEX-PRINT-SOURCES.txt" 2>/dev/null || true
cp /tmp/r20-fix23-print-before.sha256 "$OUT/DUPLEX-BEFORE.sha256" 2>/dev/null || true
cp /tmp/r20-fix23-print-after.sha256 "$OUT/DUPLEX-AFTER.sha256" 2>/dev/null || true
cp src/config/r20DuplexPrintConfig.js "$OUT/DUPLEX-PRINT-CONFIG.js" 2>/dev/null || true
cp -r r20-duplex-print-smoke "$OUT/duplex-print-smoke" 2>/dev/null || true

cp /tmp/r20-fix24-social-links.txt "$OUT/SOCIAL-LINKS.txt" 2>/dev/null || true
cp -r r20-mobdea-online-smoke "$OUT/mobdea-online-smoke" 2>/dev/null || true

cp /tmp/r20-fix25-monthly-sources.txt "$OUT/MONTHLY-SOURCES.txt" 2>/dev/null || true
cp /tmp/r20-fix25-monthly-before.sha256 "$OUT/MONTHLY-BEFORE.sha256" 2>/dev/null || true
cp /tmp/r20-fix25-monthly-after.sha256 "$OUT/MONTHLY-AFTER.sha256" 2>/dev/null || true
cp src/config/r20MonthlyEvaluationConfig.js "$OUT/MONTHLY-CONFIG.js" 2>/dev/null || true
cp -r r20-monthly-evaluation-smoke "$OUT/monthly-smoke" 2>/dev/null || true

cp /tmp/r20-toolchain-contract.txt "$OUT/TOOLCHAIN-CONTRACT.txt" 2>/dev/null || true
cp /tmp/r20-node-version.txt "$OUT/NODE-VERSION.txt" 2>/dev/null || true
cp /tmp/r20-gradle-version.txt "$OUT/GRADLE-VERSION.txt" 2>/dev/null || true
cp /tmp/r20-fix24-social-links.txt "$OUT/VERIFIED-SOCIAL-LINKS.txt" 2>/dev/null || true
