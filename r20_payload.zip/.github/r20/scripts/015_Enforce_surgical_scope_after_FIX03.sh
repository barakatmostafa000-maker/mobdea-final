set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix03.json \
  --phase FIX03 \
  --allow "src/styles/r20-fix03-student-management.css" \
  --allow "src/services/r20StudentManagement.js" \
  --allow "tests/r20-fix03-student-management.test.mjs" \
  --allow "src/main.jsx" \
  --allow "src/pages/ClassMode.jsx"
git diff --check
