set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix22.json \
  --phase FIX22 \
  --allow "src/config/r20RemedialAssistantConfig.js" \
  --allow "src/services/r20RemedialAssistant.js" \
  --allow "src/styles/r20-fix22-remedial-assistant.css" \
  --allow "tests/r20-fix22-remedial-assistant.test.mjs" \
  --allow "scripts/r20-fix22-detect-remedial.py" \
  --allow "scripts/r20-fix22-remedial-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
