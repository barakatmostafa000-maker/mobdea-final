set -euo pipefail
cat > /tmp/r20-surgical-guard.py <<'PY_GUARD'
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import subprocess
from pathlib import Path


def repo_files():
    raw = subprocess.check_output([
        "git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"
    ])
    return sorted({p.decode("utf-8") for p in raw.split(b"\0") if p})


def digest(path: Path):
    if path.is_symlink():
        return "SYMLINK:" + str(path.readlink())
    if not path.exists():
        return "MISSING"
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def scan():
    return {name: digest(Path(name)) for name in repo_files()}


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("snapshot")
    s.add_argument("output")
    v = sub.add_parser("verify")
    v.add_argument("snapshot")
    v.add_argument("--phase", required=True)
    v.add_argument("--allow", action="append", default=[])
    v.add_argument("--allow-file-list", action="append", default=[])
    args = ap.parse_args()

    if args.cmd == "snapshot":
        Path(args.output).write_text(
            json.dumps(scan(), ensure_ascii=False, sort_keys=True),
            encoding="utf-8",
        )
        return

    before = json.loads(Path(args.snapshot).read_text(encoding="utf-8"))
    after = scan()
    changed = sorted(
        path for path in (set(before) | set(after))
        if before.get(path, "MISSING") != after.get(path, "MISSING")
    )

    allowed_exact = set()
    for listing in args.allow_file_list:
        p = Path(listing)
        if p.is_file():
            allowed_exact.update(
                line.strip().replace("\\", "/")
                for line in p.read_text(encoding="utf-8", errors="ignore").splitlines()
                if line.strip()
            )

    def okay(path: str):
        norm = path.replace("\\", "/")
        return norm in allowed_exact or any(fnmatch.fnmatch(norm, pat) for pat in args.allow)

    unexpected = [path for path in changed if not okay(path)]

    print(f"SURGICAL_GUARD {args.phase}: changed={len(changed)}")
    for path in changed:
        print(("ALLOW " if okay(path) else "BLOCK ") + path)

    if unexpected:
        raise SystemExit(
            f"{args.phase}: repair attempted to change files outside its allowed surgical scope: "
            + ", ".join(unexpected)
        )


if __name__ == "__main__":
    main()

PY_GUARD
python3 -m py_compile /tmp/r20-surgical-guard.py
