set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix19.json \
  --phase FIX19 \
  --allow "src/config/r20QuestionBankConfig.js" \
  --allow "src/services/r20QuestionBankPipeline.js" \
  --allow "tests/r20-fix19-question-bank-pipeline.test.mjs" \
  --allow "scripts/r20-fix19-detect-question-bank.py" \
  --allow "scripts/r20-fix19-question-bank-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
