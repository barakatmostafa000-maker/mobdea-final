set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix06.json \
  --phase FIX06 \
  --allow "src/services/r20TeacherTabletDashboard.js" \
  --allow "src/styles/r20-fix06-teacher-tablet-dashboard.css" \
  --allow "tests/r20-fix06-teacher-tablet-dashboard.test.mjs" \
  --allow "src/main.jsx"
git diff --check
