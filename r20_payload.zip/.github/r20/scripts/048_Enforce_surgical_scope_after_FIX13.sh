set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix13.json \
  --phase FIX13 \
  --allow "src/services/r20AtlasRuntime.js" \
  --allow "src/styles/r20-fix13-atlas.css" \
  --allow "tests/r20-fix13-atlas.test.mjs" \
  --allow "scripts/r20-fix13-atlas-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
