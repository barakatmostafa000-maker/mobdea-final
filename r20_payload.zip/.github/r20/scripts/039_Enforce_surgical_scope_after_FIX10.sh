set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix10.json \
  --phase FIX10 \
  --allow "src/services/r20EducationalCards.js" \
  --allow "src/styles/r20-fix10-educational-cards.css" \
  --allow "tests/r20-fix10-educational-cards.test.mjs" \
  --allow "scripts/r20-fix10-educational-cards-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
