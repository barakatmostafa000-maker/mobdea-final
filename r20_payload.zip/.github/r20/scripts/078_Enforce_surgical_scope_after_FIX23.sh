set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix23.json \
  --phase FIX23 \
  --allow "src/config/r20DuplexPrintConfig.js" \
  --allow "src/services/r20DuplexPrinting.js" \
  --allow "src/styles/r20-fix23-duplex-print.css" \
  --allow "tests/r20-fix23-duplex-printing.test.mjs" \
  --allow "scripts/r20-fix23-detect-duplex-print.py" \
  --allow "scripts/r20-fix23-duplex-print-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
