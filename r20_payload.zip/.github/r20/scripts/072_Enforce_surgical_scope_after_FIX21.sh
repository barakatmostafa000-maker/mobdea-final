set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix21.json \
  --phase FIX21 \
  --allow "src/config/r20ReportsWhatsAppConfig.js" \
  --allow "src/services/r20ReportsWhatsApp.js" \
  --allow "src/styles/r20-fix21-reports-whatsapp.css" \
  --allow "tests/r20-fix21-reports-whatsapp.test.mjs" \
  --allow "scripts/r20-fix21-detect-reports.py" \
  --allow "scripts/r20-fix21-reports-whatsapp-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
