set -euo pipefail

node --test \
  tests/r20-fix23-duplex-printing.test.mjs

node --test \
  tests/student-card-printing-r14.test.mjs \
  tests/r20-fix22-remedial-assistant.test.mjs

grep -Fq \
  'R20_FIX23_DUPLEX_PRINT_CONFIG_V1' \
  src/config/r20DuplexPrintConfig.js

grep -Fq \
  'R20_FIX23_DUPLEX_PRINTING_V1' \
  src/services/r20DuplexPrinting.js

grep -Fq \
  'physicalBackSlotIndex' \
  src/services/r20DuplexPrinting.js

grep -Fq \
  'buildDuplexManifest' \
  src/services/r20DuplexPrinting.js

grep -Fq \
  'data-r20-duplex-sheet-page' \
  src/services/r20DuplexPrinting.js

grep -Fq \
  'data-r20-duplex-slot' \
  src/services/r20DuplexPrinting.js

grep -Fq \
  '@page' \
  src/styles/r20-fix23-duplex-print.css

grep -Fq \
  '210mm' \
  src/styles/r20-fix23-duplex-print.css

grep -Fq \
  '297mm' \
  src/styles/r20-fix23-duplex-print.css

grep -Fq \
  'repeat(' \
  src/styles/r20-fix23-duplex-print.css

if [ -s /tmp/r20-fix23-print-protected-sources.txt ]; then
  : > \
    /tmp/r20-fix23-print-after.sha256

  while IFS= read -r file; do
    sha256sum "$file"
  done < \
    /tmp/r20-fix23-print-protected-sources.txt \
    > /tmp/r20-fix23-print-after.sha256

  cmp \
    /tmp/r20-fix23-print-before.sha256 \
    /tmp/r20-fix23-print-after.sha256
fi



git diff --check
