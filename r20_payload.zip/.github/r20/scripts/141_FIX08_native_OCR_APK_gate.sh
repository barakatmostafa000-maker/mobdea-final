set -euo pipefail

chmod +x gradlew
./gradlew --no-daemon :app:compileDebugJavaWithJavac --stacktrace
./gradlew --no-daemon :app:mergeDebugAssets --stacktrace
./gradlew --no-daemon testDebugUnitTest --stacktrace
./gradlew --no-daemon lintDebug --stacktrace
./gradlew --no-daemon assembleDebug --stacktrace

APK="app/build/outputs/apk/debug/app-debug.apk"
test -s "$APK"

MODEL_COUNT="$(unzip -Z1 "$APK" | grep -Ec '^assets/tess304/[^/]+$' || true)"
test "$MODEL_COUNT" -eq 17

unzip -Z1 "$APK" | grep -Fxq 'assets/tess304/ara.traineddata'
unzip -Z1 "$APK" | grep -Fxq 'assets/tess304/eng.traineddata'
unzip -Z1 "$APK" | grep -Fxq 'assets/tess304/eng.tesseract_cube.nn'

unzip -p "$APK" classes.dex | strings | grep -Fq 'R20PageOcrPlugin'
unzip -p "$APK" classes.dex | strings | grep -Fq 'R20_FIX08_NATIVE_PAGE_OCR_V1'

grep -Fq 'versionCode 118' app/build.gradle
grep -Fq 'versionName "10.14.1"' app/build.gradle
