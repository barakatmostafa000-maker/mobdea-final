set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix05.json \
  --phase FIX05 \
  --allow "src/services/r20PortalDashboard.js" \
  --allow "src/styles/r20-fix05-role-dashboard.css" \
  --allow "tests/r20-fix05-role-dashboard.test.mjs" \
  --allow "src/main.jsx"
git diff --check
