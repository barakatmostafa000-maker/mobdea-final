set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix01.json \
  --phase FIX01 \
  --allow "src/services/r20RuntimeCore.js" \
  --allow "src/styles/r20-fix01-core-runtime.css" \
  --allow "tests/r20-fix01-core-runtime.test.mjs" \
  --allow "src/main.jsx" \
  --allow "src/pages/ClassMode.jsx" \
  --allow "android/app/src/main/java/com/mobdea/education/MainActivity.java"
git diff --check
