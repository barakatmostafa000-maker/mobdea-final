set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix18.json \
  --phase FIX18 \
  --allow "src/config/r20GamesConfig.js" \
  --allow "src/services/r20GamesRuntime.js" \
  --allow "src/styles/r20-fix18-games.css" \
  --allow "tests/r20-fix18-games.test.mjs" \
  --allow "scripts/r20-fix18-detect-games.py" \
  --allow "scripts/r20-fix18-games-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
