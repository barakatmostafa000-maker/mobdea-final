set -euo pipefail

npm run preview -- --host 127.0.0.1 --port 4173 \
  > /tmp/r20-fix11-preview.log 2>&1 &
PID=$!
trap 'kill "$PID" 2>/dev/null || true' EXIT

READY=0
for attempt in $(seq 1 60); do
  if curl --fail --silent http://127.0.0.1:4173/ >/dev/null; then
    READY=1
    break
  fi
  sleep 1
done
test "$READY" -eq 1

rm -rf r20-country-cards-smoke

R20_COUNTRY_CARDS_URL=http://127.0.0.1:4173 \
  node scripts/r20-fix11-country-cards-smoke.mjs

test -s r20-country-cards-smoke/tablet-1280x800-country-card.png
test -s r20-country-cards-smoke/tablet-1920x1080-country-card.png
