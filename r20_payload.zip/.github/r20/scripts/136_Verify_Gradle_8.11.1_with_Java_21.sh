set -euo pipefail

java -version 2>&1 | tee /tmp/r20-java-version.txt
grep -Eq 'version "21|openjdk 21|Java 21' /tmp/r20-java-version.txt

chmod +x gradlew
./gradlew --no-daemon --version | tee /tmp/r20-gradle-version.txt
grep -Fq 'Gradle 8.11.1' /tmp/r20-gradle-version.txt
