set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix15.json \
  --phase FIX15 \
  --allow "src/config/r20MapChallengeConfig.js" \
  --allow "src/services/r20MapChallengeRuntime.js" \
  --allow "src/styles/r20-fix15-map-challenge.css" \
  --allow "scripts/r20-fix15-detect-map-challenge.py" \
  --allow "tests/r20-fix15-map-challenge.test.mjs" \
  --allow "scripts/r20-fix15-map-challenge-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
