set -euo pipefail

node --test \
  tests/r20-fix19-question-bank-pipeline.test.mjs

node --test \
  tests/question-rotation.test.mjs \
  tests/pdf-question-ocr.test.mjs \
  tests/r20-fix08-ocr-page-questions.test.mjs \
  tests/r20-fix18-games.test.mjs

grep -Fq \
  'R20_FIX19_QUESTION_BANK_CONFIG_V1' \
  src/config/r20QuestionBankConfig.js

grep -Fq \
  'R20_FIX19_QUESTION_BANK_PIPELINE_V1' \
  src/services/r20QuestionBankPipeline.js

grep -Fq \
  'stableQuestionId' \
  src/services/r20QuestionBankPipeline.js

grep -Fq \
  'mobdea:r20-page-questions' \
  src/services/r20QuestionBankPipeline.js

grep -Fq \
  'mobdea:r20-question-bank-source' \
  src/services/r20QuestionBankPipeline.js

grep -Fq \
  'mobdea:r20-question-bank-request' \
  src/services/r20QuestionBankPipeline.js

if [ -s /tmp/r20-fix19-question-bank-protected-sources.txt ]; then
  : > \
    /tmp/r20-fix19-question-bank-after.sha256

  while IFS= read -r file; do
    sha256sum "$file"
  done < \
    /tmp/r20-fix19-question-bank-protected-sources.txt \
    > /tmp/r20-fix19-question-bank-after.sha256

  cmp \
    /tmp/r20-fix19-question-bank-before.sha256 \
    /tmp/r20-fix19-question-bank-after.sha256
fi


git diff --check
