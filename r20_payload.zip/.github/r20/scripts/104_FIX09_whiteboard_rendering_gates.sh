set -euo pipefail

node --test tests/r20-fix09-whiteboard.test.mjs

# Previous ClassMode/PDF/student behavior stays mandatory.
node --test tests/r20-fix02-unified-classmode-layout.test.mjs
node --test tests/r20-fix03-student-management.test.mjs
node --test tests/r20-fix07-pdf-gestures.test.mjs

grep -Fq 'R20_FIX09_WHITEBOARD_RENDERING_LAYOUT_V1' \
  src/services/r20WhiteboardRuntime.js
grep -Fq 'proto.stroke = function' \
  src/services/r20WhiteboardRuntime.js
grep -Fq 'destination-out' \
  src/services/r20WhiteboardRuntime.js
grep -Fq 'data-r20-whiteboard-bottom-control="tools"' \
  src/styles/r20-fix09-whiteboard.css
grep -Fq 'data-r20-whiteboard-bottom-control="cards"' \
  src/styles/r20-fix09-whiteboard.css
grep -Fq 'place-items: center' \
  src/styles/r20-fix09-whiteboard.css

git diff --check
