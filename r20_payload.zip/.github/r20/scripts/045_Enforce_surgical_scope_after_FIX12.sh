set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix12.json \
  --phase FIX12 \
  --allow "src/services/r20MapsRuntime.js" \
  --allow "src/styles/r20-fix12-maps.css" \
  --allow "tests/r20-fix12-maps.test.mjs" \
  --allow "scripts/r20-fix12-maps-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
