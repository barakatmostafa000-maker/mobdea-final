set -euo pipefail

node --test \
  tests/r20-fix13-atlas.test.mjs

node --test \
  tests/r20-fix12-maps.test.mjs \
  tests/geography-maps.test.mjs \
  tests/map-symbol-library-v13.test.mjs

mapfile -t ATLAS_TESTS < <(
  find tests \
    -maxdepth 1 \
    -type f \
    -iname '*atlas*.test.mjs' \
    ! -name 'r20-fix13-atlas.test.mjs' \
    -print
)

if [ "${#ATLAS_TESTS[@]}" -gt 0 ]; then
  node --test \
    "${ATLAS_TESTS[@]}"
fi

grep -Fq \
  'R20_FIX13_ATLAS_BOUNDARIES_NAMES_V1' \
  src/services/r20AtlasRuntime.js

grep -Fq \
  'data-r20-atlas-boundary' \
  src/services/r20AtlasRuntime.js

grep -Fq \
  'data-r20-atlas-label' \
  src/services/r20AtlasRuntime.js

grep -Fq \
  'data-r20-atlas-toggle' \
  src/services/r20AtlasRuntime.js

grep -Fq \
  'stroke-opacity:' \
  src/styles/r20-fix13-atlas.css

grep -Fq \
  'data-r20-atlas-names-visible="false"' \
  src/styles/r20-fix13-atlas.css



git diff --check
