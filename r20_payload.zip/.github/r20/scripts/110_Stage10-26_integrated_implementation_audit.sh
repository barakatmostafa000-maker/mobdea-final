set -euo pipefail

STAGE_TESTS=(
  tests/r20-fix09-whiteboard.test.mjs
  tests/r20-fix10-educational-cards.test.mjs
  tests/r20-fix11-country-cards.test.mjs
  tests/r20-fix12-maps.test.mjs
  tests/r20-fix13-atlas.test.mjs
  tests/r20-fix14-geography-correctness.test.mjs
  tests/r20-fix15-map-challenge.test.mjs
  tests/r20-fix16-map-natural-layers.test.mjs
  tests/r20-fix16-image-mode.test.mjs
  tests/r20-fix17-media.test.mjs
  tests/r20-fix18-games.test.mjs
  tests/r20-fix19-question-bank-pipeline.test.mjs
  tests/r20-fix20-exam-tracking.test.mjs
  tests/r20-fix21-reports-whatsapp.test.mjs
  tests/r20-fix22-remedial-assistant.test.mjs
  tests/r20-fix23-duplex-printing.test.mjs
  tests/r20-fix24-mobdea-online.test.mjs
  tests/r20-fix25-monthly-evaluation.test.mjs
)

for file in "${STAGE_TESTS[@]}"; do
  test -s "$file"
done

node --test "${STAGE_TESTS[@]}"

# Explicit runtime list prevents a filename-pattern audit from missing services
# such as r20WhiteboardRuntime.js that do not contain the FIX number.
RUNTIME_FILES=(
  src/services/r20WhiteboardRuntime.js
  src/services/r20EducationalCards.js
  src/services/r20CountryCards.js
  src/services/r20MapsRuntime.js
  src/services/r20AtlasRuntime.js
  src/services/r20GeographyTruth.js
  src/services/r20GeographyCorrectnessRuntime.js
  src/services/r20MapChallengeRuntime.js
  src/services/r20MapChallengeNaturalLayers.js
  src/services/r20ImageMode.js
  src/services/r20MediaControls.js
  src/services/r20PowerPointMode.js
  src/services/r20GamesRuntime.js
  src/services/r20QuestionBankPipeline.js
  src/services/r20ExamTracking.js
  src/services/r20ReportsWhatsApp.js
  src/services/r20RemedialAssistant.js
  src/services/r20DuplexPrinting.js
  src/services/r20MobdeaOnline.js
  src/services/r20MonthlyEvaluation.js
)

for file in "${RUNTIME_FILES[@]}"; do
  test -s "$file"
  node --check "$file"
done

while IFS= read -r file; do
  node --check "$file"
done < <(find scripts tests -type f \
  \( -name 'r20-fix09*' -o -name 'r20-fix10*' -o -name 'r20-fix11*' -o -name 'r20-fix12*' -o -name 'r20-fix13*' -o -name 'r20-fix14*' -o -name 'r20-fix15*' -o -name 'r20-fix16*' -o -name 'r20-fix17*' -o -name 'r20-fix18*' -o -name 'r20-fix19*' -o -name 'r20-fix20*' -o -name 'r20-fix21*' -o -name 'r20-fix22*' -o -name 'r20-fix23*' -o -name 'r20-fix24*' -o -name 'r20-fix25*' \) \
  \( -name '*.js' -o -name '*.mjs' \) | sort)

while IFS= read -r file; do
  python3 -m py_compile "$file"
done < <(find scripts -type f \
  \( -name 'r20-fix14*.py' -o -name 'r20-fix15*.py' -o -name 'r20-fix16*.py' -o -name 'r20-fix17*.py' -o -name 'r20-fix18*.py' -o -name 'r20-fix19*.py' -o -name 'r20-fix20*.py' -o -name 'r20-fix21*.py' -o -name 'r20-fix22*.py' -o -name 'r20-fix23*.py' -o -name 'r20-fix24*.py' -o -name 'r20-fix25*.py' \) | sort)

# Exact social links are part of the release contract.
grep -Fq 'R20_FIX24_MOBDEA_ONLINE_CONFIG_V2_VERIFIED_LINKS' src/config/r20MobdeaOnlineConfig.js
grep -Fq 'https://youtube.com/@mostafabarakat21?si=j81UCr73vvnZtpPn' src/config/r20MobdeaOnlineConfig.js
grep -Fq 'https://www.facebook.com/share/18DaQCzDzT/' src/config/r20MobdeaOnlineConfig.js
grep -Fq 'https://www.tiktok.com/@mostafabarakat210?_r=1&_t=ZS-99GSdfl3yi0' src/config/r20MobdeaOnlineConfig.js

# Latest requested monthly ranking dimensions must all remain explicit.
grep -Fq 'ترتيب درجات الامتحانات' src/services/r20MonthlyEvaluation.js
grep -Fq 'ترتيب نقاط الحصص' src/services/r20MonthlyEvaluation.js
grep -Fq 'الأكثر تحسنًا' src/services/r20MonthlyEvaluation.js

git diff --check
