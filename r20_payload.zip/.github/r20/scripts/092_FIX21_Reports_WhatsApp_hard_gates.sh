set -euo pipefail

node --test \
  tests/r20-fix21-reports-whatsapp.test.mjs

node --test \
  tests/r20-fix20-exam-tracking.test.mjs \
  tests/r20-fix04-student-parent-accounts.test.mjs \
  tests/r20-fix05-role-dashboard.test.mjs

grep -Fq \
  'R20_FIX21_REPORTS_WHATSAPP_CONFIG_V1' \
  src/config/r20ReportsWhatsAppConfig.js

grep -Fq \
  'R20_FIX21_REPORTS_WHATSAPP_V1' \
  src/services/r20ReportsWhatsApp.js

grep -Fq \
  'viewerCanAccessStudent' \
  src/services/r20ReportsWhatsApp.js

grep -Fq \
  'formatWhatsAppReport' \
  src/services/r20ReportsWhatsApp.js

grep -Fq \
  'buildWhatsAppUrl' \
  src/services/r20ReportsWhatsApp.js

grep -Fq \
  'data-r20-report-ready-panel' \
  src/services/r20ReportsWhatsApp.js

grep -Fq \
  'data-r20-report-portal-card' \
  src/services/r20ReportsWhatsApp.js

: > \
  /tmp/r20-fix21-report-after.sha256

while IFS= read -r file; do
  sha256sum "$file"
done < \
  /tmp/r20-fix21-report-protected-sources.txt \
  > /tmp/r20-fix21-report-after.sha256

cmp \
  /tmp/r20-fix21-report-before.sha256 \
  /tmp/r20-fix21-report-after.sha256



git diff --check
