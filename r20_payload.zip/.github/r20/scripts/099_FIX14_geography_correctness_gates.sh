set -euo pipefail

node --test \
  tests/r20-fix14-geography-correctness.test.mjs

node --test \
  tests/r20-fix13-atlas.test.mjs \
  tests/r20-fix12-maps.test.mjs \
  tests/geography-maps.test.mjs \
  tests/map-symbol-library-v13.test.mjs

grep -Fq \
  'R20_FIX14_GEOGRAPHY_CORRECTNESS_V1' \
  src/services/r20GeographyTruth.js

grep -Fq \
  'R20_FIX14_GEOGRAPHY_RUNTIME_V1' \
  src/services/r20GeographyCorrectnessRuntime.js

for token in \
  Djibouti \
  Somalia \
  Comoros \
  'South Sudan' \
  'Democratic Republic of the Congo' \
  'Kagera River' \
  'Lake Victoria' \
  'Blue Nile' \
  Atbara \
  Sobat; do

  grep -Fq "$token" \
    src/services/r20GeographyTruth.js
done



git diff --check
