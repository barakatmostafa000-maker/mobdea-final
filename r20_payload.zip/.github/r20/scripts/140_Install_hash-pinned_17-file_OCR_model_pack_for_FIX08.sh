set -euo pipefail

DEST="android/app/src/main/assets/tess304"
BASE="https://raw.githubusercontent.com/tesseract-ocr/tessdata/3.04.00"
rm -rf "$DEST"
mkdir -p "$DEST"

declare -A EXPECTED=(
  ["ara.traineddata"]="916200c13339f81f3b04a83ceeca7d023d70c81e"
  ["ara.cube.bigrams"]="524d5908c5900178640836ab1d24e9476e6759aa"
  ["ara.cube.fold"]="ae213c70ba834dd8d2a515d6917506275caef0f4"
  ["ara.cube.lm"]="0c94223f1870f98839a41deaff590bd0a0f46d00"
  ["ara.cube.nn"]="4e3c952a7607f73cacc1f9ada23ffd2408c662d8"
  ["ara.cube.params"]="b06e24d8380f2a238e608c6d934ce52ad38dcae3"
  ["ara.cube.size"]="6d10090f390ed0d47c275b0811b63d2f1fb817b8"
  ["ara.cube.word-freq"]="aab2db4056f020f98cac2dcd3d1a91d71543ed0f"
  ["eng.traineddata"]="9f4704c9c54910e0953fd9a7e34a1a3f18829664"
  ["eng.cube.bigrams"]="3929380ee9d8193c5d7aa8eac0a9c2c2e3f5037e"
  ["eng.cube.fold"]="ac96315ce04c5fdf3be82704e37197599de6807e"
  ["eng.cube.lm"]="de0c085c00d4f4d191605c9ad97f67cd2926062f"
  ["eng.cube.nn"]="c7e3a14be217e9b68bb9c34908b46b790200d5db"
  ["eng.cube.params"]="ce9e2c720430efeba23dccf67913327e70de5c71"
  ["eng.cube.size"]="5f840a893e4a53d2ed535ed8f0d49d4f7351a862"
  ["eng.cube.word-freq"]="b5347b286a619f07792dcf3221c5676630ede683"
  ["eng.tesseract_cube.nn"]="ec483e0ac6175d1daadfa596cb157fa42229be10"
)

FILES=(
  ara.traineddata ara.cube.bigrams ara.cube.fold ara.cube.lm
  ara.cube.nn ara.cube.params ara.cube.size ara.cube.word-freq
  eng.traineddata eng.cube.bigrams eng.cube.fold eng.cube.lm
  eng.cube.nn eng.cube.params eng.cube.size eng.cube.word-freq
  eng.tesseract_cube.nn
)

test "${#FILES[@]}" -eq 17

for file in "${FILES[@]}"; do
  curl --fail --location \
    --retry 6 --retry-all-errors --retry-delay 2 \
    --connect-timeout 30 --max-time 600 \
    "$BASE/$file" -o "$DEST/$file"
  test -s "$DEST/$file"

  actual="$(git hash-object "$DEST/$file")"
  test "$actual" = "${EXPECTED[$file]}"
done

test "$(find "$DEST" -maxdepth 1 -type f | wc -l)" -eq 17
echo "17/17 OCR model files hash-pinned PASS"
