set -euo pipefail

node --test tests/r20-fix22-remedial-assistant.test.mjs

node --test \
  tests/r20-fix21-reports-whatsapp.test.mjs \
  tests/r20-fix20-exam-tracking.test.mjs \
  tests/r20-fix19-question-bank-pipeline.test.mjs

grep -Fq 'R20_FIX22_REMEDIAL_ASSISTANT_CONFIG_V1' src/config/r20RemedialAssistantConfig.js
grep -Fq 'R20_FIX22_REMEDIAL_ASSISTANT_V1' src/services/r20RemedialAssistant.js
grep -Fq 'buildWeaknessTargets' src/services/r20RemedialAssistant.js
grep -Fq 'no unseen graded remedial questions' src/services/r20RemedialAssistant.js
grep -Fq 'computeImprovement' src/services/r20RemedialAssistant.js
grep -Fq 'data-r20-remedial-assistant-card' src/services/r20RemedialAssistant.js
grep -Fq 'data-r20-remedial-question' src/services/r20RemedialAssistant.js
grep -Fq 'mobdea:r20-remedial-progress-ready' src/services/r20RemedialAssistant.js

: > /tmp/r20-fix22-remedial-after.sha256

while IFS= read -r file; do
  sha256sum "$file"
done < /tmp/r20-fix22-remedial-protected-sources.txt \
  > /tmp/r20-fix22-remedial-after.sha256

cmp \
  /tmp/r20-fix22-remedial-before.sha256 \
  /tmp/r20-fix22-remedial-after.sha256


git diff --check
