set -euo pipefail

node --test tests/r20-fix25-monthly-evaluation.test.mjs

node --test \
  tests/student-ranking.test.mjs \
  tests/r20-fix20-exam-tracking.test.mjs \
  tests/r20-fix21-reports-whatsapp.test.mjs \
  tests/r20-fix05-role-dashboard.test.mjs

grep -Fq 'R20_FIX25_MONTHLY_EVALUATION_V1' src/services/r20MonthlyEvaluation.js
grep -Fq 'data-r20-monthly-evaluation-card' src/services/r20MonthlyEvaluation.js
grep -Fq 'الأكثر تحسنًا' src/services/r20MonthlyEvaluation.js
grep -Fq 'formatExamShare' src/services/r20MonthlyEvaluation.js
grep -Fq 'formatMonthlyShare' src/services/r20MonthlyEvaluation.js
grep -Fq 'viewerCanSeeMonthlyStudent' src/services/r20MonthlyEvaluation.js

if [ -s /tmp/r20-fix25-monthly-protected-sources.txt ]; then
  : > /tmp/r20-fix25-monthly-after.sha256

  while IFS= read -r file; do
    sha256sum "$file"
  done < /tmp/r20-fix25-monthly-protected-sources.txt \
    > /tmp/r20-fix25-monthly-after.sha256

  cmp \
    /tmp/r20-fix25-monthly-before.sha256 \
    /tmp/r20-fix25-monthly-after.sha256
fi


git diff --check
