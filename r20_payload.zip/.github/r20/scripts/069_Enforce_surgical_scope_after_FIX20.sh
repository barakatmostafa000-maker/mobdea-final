set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix20.json \
  --phase FIX20 \
  --allow "src/config/r20ExamTrackingConfig.js" \
  --allow "src/services/r20ExamTracking.js" \
  --allow "tests/r20-fix20-exam-tracking.test.mjs" \
  --allow "scripts/r20-fix20-detect-exam-tracking.py" \
  --allow "scripts/r20-fix20-exam-tracking-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
