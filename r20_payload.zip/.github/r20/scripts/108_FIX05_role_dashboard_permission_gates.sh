set -euo pipefail

node --test tests/r20-fix05-role-dashboard.test.mjs

# Phase 5 account lifecycle remains mandatory because dashboard access
# depends on a valid changed-password session.
node --test tests/r20-fix04-student-parent-accounts.test.mjs
node --test tests/student-portal-sync.test.mjs

grep -Fq 'R20_FIX05_ROLE_DASHBOARD_V1' \
  src/services/r20PortalDashboard.js
grep -Fq 'STUDENT_FEATURES' \
  src/services/r20PortalDashboard.js
grep -Fq 'PARENT_FEATURES' \
  src/services/r20PortalDashboard.js
grep -Fq 'TEACHER_ONLY' \
  src/services/r20PortalDashboard.js
grep -Fq 'مرحبًا بك يا' \
  src/services/r20PortalDashboard.js
grep -Fq 'منصة المُبدع مصطفى بركات' \
  src/services/r20PortalDashboard.js
grep -Fq 'نتمنى لك تعلّمًا ممتعًا' \
  src/services/r20PortalDashboard.js

git diff --check
