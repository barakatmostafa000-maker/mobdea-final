set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix24.json \
  --phase FIX24 \
  --allow "src/config/r20MobdeaOnlineConfig.js" \
  --allow "src/services/r20MobdeaOnline.js" \
  --allow "src/styles/r20-fix24-mobdea-online.css" \
  --allow "tests/r20-fix24-mobdea-online.test.mjs" \
  --allow "scripts/r20-fix24-detect-social-links.py" \
  --allow "scripts/r20-fix24-mobdea-online-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
