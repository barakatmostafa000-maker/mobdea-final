set -euo pipefail

node --test \
  tests/r20-fix16-map-natural-layers.test.mjs \
  tests/r20-fix16-image-mode.test.mjs

# Previous Map Challenge + maps + atlas + geography stay mandatory.
node --test \
  tests/r20-fix15-map-challenge.test.mjs \
  tests/r20-fix14-geography-correctness.test.mjs \
  tests/r20-fix13-atlas.test.mjs \
  tests/r20-fix12-maps.test.mjs \
  tests/geography-maps.test.mjs \
  tests/map-symbol-library-v13.test.mjs

grep -Fq \
  'R20_FIX16_MAP_NATURAL_LAYERS_V1' \
  src/services/r20MapChallengeNaturalLayers.js

grep -Fq \
  'R20_FIX16_IMAGE_MODE_V1' \
  src/services/r20ImageMode.js

for layer in \
  terrain \
  minerals \
  forests \
  grasslands \
  deserts; do

  grep -Eq \
    "\"${layer}\"[[:space:]]*:[[:space:]]*true" \
    src/config/r20MapChallengeNaturalLayersConfig.js
done

for kind in \
  mountains \
  plateaus \
  plains \
  islands; do

  grep -Fq \
    "$kind" \
    src/services/r20MapChallengeNaturalLayers.js
done

grep -Fq \
  'MAX_SCALE = 6' \
  src/services/r20ImageMode.js

grep -Fq \
  'object-fit:' \
  src/styles/r20-fix16-image-mode.css



git diff --check
