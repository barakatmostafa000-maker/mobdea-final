set -euo pipefail

node --test tests/r20-fix10-educational-cards.test.mjs
node --test tests/r20-fix09-whiteboard.test.mjs

grep -Fq 'R20_FIX10_EDUCATIONAL_CARDS_V1' \
  src/services/r20EducationalCards.js
grep -Fq 'data-r20-educational-card-body' \
  src/services/r20EducationalCards.js
grep -Fq 'cardFontScale' \
  src/services/r20EducationalCards.js
grep -Fq 'measureOverflow' \
  src/services/r20EducationalCards.js
grep -Fq 'display: contents' \
  src/styles/r20-fix10-educational-cards.css
grep -Fq 'phase10-country-card-untouched' \
  src/styles/r20-fix10-educational-cards.css

git diff --check
