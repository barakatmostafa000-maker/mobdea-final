set -euo pipefail

OCR="android/app/src/main/java/com/mobdea/education/ocr/MobdeaPdfOcrPlugin.java"
test -s "$OCR"
grep -Fq "tess304/" "$OCR"
grep -Fq "Bitmap.Config.ARGB_8888" "$OCR"
! grep -Fq '@tesseract.js-data/' android/app/build.gradle
