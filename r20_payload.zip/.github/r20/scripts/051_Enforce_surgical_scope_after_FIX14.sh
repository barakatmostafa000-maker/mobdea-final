set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix14.json \
  --phase FIX14 \
  --allow "src/services/r20GeographyTruth.js" \
  --allow "src/services/r20GeographyCorrectnessRuntime.js" \
  --allow "src/styles/r20-fix14-geography-correctness.css" \
  --allow "scripts/r20-fix14-patch-geography-data.py" \
  --allow "tests/r20-fix14-geography-correctness.test.mjs" \
  --allow "scripts/r20-fix14-geography-smoke.mjs" \
  --allow "src/main.jsx" \
  --allow-file-list /tmp/r20-fix14-geography-patched.txt
git diff --check
