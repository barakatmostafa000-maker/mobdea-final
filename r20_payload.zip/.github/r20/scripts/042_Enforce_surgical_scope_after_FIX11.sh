set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix11.json \
  --phase FIX11 \
  --allow "src/services/r20CountryCards.js" \
  --allow "src/styles/r20-fix11-country-cards.css" \
  --allow "tests/r20-fix11-country-cards.test.mjs" \
  --allow "scripts/r20-fix11-country-cards-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
