set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix07.json \
  --phase FIX07 \
  --allow "src/services/r20PdfGestures.js" \
  --allow "src/styles/r20-fix07-pdf-gestures.css" \
  --allow "tests/r20-fix07-pdf-gestures.test.mjs" \
  --allow "src/main.jsx"
git diff --check
