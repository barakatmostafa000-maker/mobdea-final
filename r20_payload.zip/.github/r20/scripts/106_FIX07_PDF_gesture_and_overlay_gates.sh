set -euo pipefail

node --test tests/r20-fix07-pdf-gestures.test.mjs

# Existing PDF/OCR/media tests remain mandatory.
if [ -s tests/pdf-question-ocr.test.mjs ]; then
  node --test tests/pdf-question-ocr.test.mjs
fi

if [ -s tests/media-renderer.test.mjs ]; then
  node --test tests/media-renderer.test.mjs
fi

if [ -s tests/media-navigation.test.mjs ]; then
  node --test tests/media-navigation.test.mjs
fi

grep -Fq 'R20_FIX07_PDF_PINCH_PAN_BOARD_OVERLAY_V1' \
  src/services/r20PdfGestures.js
grep -Fq 'MAX_SCALE = 6' \
  src/services/r20PdfGestures.js
grep -Fq 'state.pointers.size === 2' \
  src/services/r20PdfGestures.js
grep -Fq 'beginPan' \
  src/services/r20PdfGestures.js
grep -Fq 'wireBoardOverlayGuard' \
  src/services/r20PdfGestures.js
grep -Fq 'data-r20-pdf-pager' \
  src/styles/r20-fix07-pdf-gestures.css
grep -Fq 'background: transparent' \
  src/styles/r20-fix07-pdf-gestures.css

git diff --check
