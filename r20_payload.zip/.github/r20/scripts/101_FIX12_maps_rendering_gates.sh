set -euo pipefail

node --test tests/r20-fix12-maps.test.mjs

node --test \
  tests/geography-maps.test.mjs \
  tests/map-symbol-library-v13.test.mjs

grep -Fq 'R20_FIX12_MAPS_RENDERING_INTERACTION_V1' \
  src/services/r20MapsRuntime.js
grep -Fq 'MAX_SCALE = 5' \
  src/services/r20MapsRuntime.js
grep -Fq 'data-r20-map-land-black' \
  src/services/r20MapsRuntime.js
grep -Fq 'data-r20-map-river' \
  src/services/r20MapsRuntime.js
grep -Fq 'data-r20-map-symbols-control' \
  src/services/r20MapsRuntime.js
grep -Fq 'data-r20-map-reference-control' \
  src/styles/r20-fix12-maps.css

git diff --check
