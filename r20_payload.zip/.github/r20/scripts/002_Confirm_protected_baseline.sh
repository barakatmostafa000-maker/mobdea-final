set -euo pipefail
test "$(git rev-parse HEAD)" = "$R19_BASE_COMMIT"
test -z "$(git status --porcelain)"
