set -euo pipefail

# Keep the locked application dependency graph for the authoritative build;
# add audit-only packages afterwards without touching package-lock.json.
npm install \
  --no-save \
  --package-lock=false \
  --ignore-scripts \
  playwright@1.55.0 \
  pdf-lib@1.17.1

npx playwright install --with-deps chromium

node -e 'import("playwright").then(()=>console.log("playwright-ok"))'
node -e 'import("pdf-lib").then(()=>console.log("pdf-lib-ok"))'
