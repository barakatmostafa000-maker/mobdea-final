set -euo pipefail

node --test \
  tests/r20-fix15-map-challenge.test.mjs

# Student permissions must remain exact.
node --test \
  tests/r20-fix05-role-dashboard.test.mjs

# Preserve the existing game engine, scoring, rooms, ranking and geography.
node --test \
  tests/online-game.test.mjs \
  tests/gamification.test.mjs \
  tests/student-ranking.test.mjs \
  tests/geography-maps.test.mjs \
  tests/map-symbol-library-v13.test.mjs \
  tests/r20-fix12-maps.test.mjs \
  tests/r20-fix13-atlas.test.mjs \
  tests/r20-fix14-geography-correctness.test.mjs

cmp \
  /tmp/r20-fix15-map-challenge-before.sha256 \
  /tmp/r20-fix15-map-challenge-after.sha256

grep -Fq \
  'R20_FIX15_MAP_CHALLENGE_V1' \
  src/services/r20MapChallengeRuntime.js

grep -Eq \
  'R20_MAP_CHALLENGE_PATH = ".+"' \
  src/config/r20MapChallengeConfig.js

grep -Fq \
  'data-r20-map-challenge-dashboard-entry' \
  src/services/r20MapChallengeRuntime.js

grep -Fq \
  'data-r20-map-challenge-layer-toggle' \
  src/services/r20MapChallengeRuntime.js

grep -Fq \
  'data-r20-map-challenge-map' \
  src/styles/r20-fix15-map-challenge.css



git diff --check
