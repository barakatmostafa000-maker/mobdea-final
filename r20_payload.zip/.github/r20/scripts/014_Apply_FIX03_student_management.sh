set -euo pipefail

python3 - <<'PY'
from pathlib import Path
import re

css = r'''/* R20_FIX03_STUDENT_MANAGEMENT_V1
   Student roster + exact-candidate random picker + compact student modal.
   No React-owned student row is re-parented.
*/

[data-r20-student-list="true"],
.classmode-students-list,
.classmode-student-list {
  min-height: 0 !important;
  max-height: min(68dvh, 680px) !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  overscroll-behavior: contain !important;
  -webkit-overflow-scrolling: touch !important;
  touch-action: pan-y !important;
  scrollbar-gutter: stable !important;
  overflow-anchor: none !important;
  padding-bottom: 10px !important;
}

[data-r20-student-list="true"] [data-student-id],
.classmode-students-list [data-student-id],
.classmode-student-list [data-student-id] {
  flex: 0 0 auto !important;
  min-height: 42px !important;
}

.r20-random-picker {
  direction: rtl;
  width: 100%;
  min-width: 0;
  box-sizing: border-box;
  display: grid;
  gap: 7px;
  padding: 8px;
  margin: 0 0 8px;
  border-radius: 14px;
  background: color-mix(in srgb, Canvas 88%, transparent);
  border: 1px solid color-mix(in srgb, currentColor 15%, transparent);
  box-shadow: 0 6px 18px rgb(0 0 0 / 8%);
  position: relative;
  z-index: 2;
  overflow: visible;
  font-size: 13px;
}

.r20-random-picker__top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 6px;
  min-width: 0;
}

.r20-random-picker__title {
  font-weight: 800;
  font-size: 13px;
  line-height: 1.25;
  min-width: 0;
}

.r20-random-picker__buttons {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 5px;
}

.r20-random-picker button,
.r20-random-picker summary {
  min-height: 32px;
  border-radius: 10px;
  padding: 5px 9px;
  font: inherit;
  cursor: pointer;
}

.r20-random-picker__draw {
  font-weight: 800;
}

.r20-random-picker__candidates {
  min-width: 0;
}

.r20-random-picker__candidates > summary {
  list-style: none;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  user-select: none;
}

.r20-random-picker__candidates > summary::-webkit-details-marker {
  display: none;
}

.r20-random-picker__options {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 5px;
  max-height: min(28dvh, 220px);
  overflow-y: auto;
  overscroll-behavior: contain;
  touch-action: pan-y;
  padding: 7px 2px 2px;
}

.r20-random-picker__option {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 7px;
  border-radius: 10px;
  background: color-mix(in srgb, Canvas 94%, currentColor 6%);
}

.r20-random-picker__option input {
  flex: 0 0 auto;
  width: 17px;
  height: 17px;
  margin: 0;
}

.r20-random-picker__option span {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.r20-random-picker__status {
  min-height: 20px;
  font-size: 12px;
  line-height: 1.45;
  opacity: .86;
}

.r20-random-picker__result {
  font-weight: 900;
  font-size: 13px;
}

[data-r20-random-selected="true"] {
  outline: 2px solid currentColor !important;
  outline-offset: -2px !important;
  border-radius: 10px !important;
}

[data-r20-legacy-random-modal="true"],
[data-r20-legacy-random-trigger="true"] {
  display: none !important;
}

/* Compact, stable Add Student dialog. */
[data-r20-student-modal="true"] {
  width: min(94vw, 760px) !important;
  max-width: min(94vw, 760px) !important;
  max-height: calc(100dvh - 16px) !important;
  overflow: auto !important;
  overscroll-behavior: contain !important;
  scrollbar-gutter: stable !important;
  overflow-anchor: none !important;
  box-sizing: border-box !important;
  animation: none !important;
  transition: none !important;
}

[data-r20-student-modal="true"] *,
[data-r20-student-modal="true"] *::before,
[data-r20-student-modal="true"] *::after {
  animation-duration: 0s !important;
  animation-delay: 0s !important;
}

[data-r20-student-modal="true"] form {
  min-width: 0 !important;
  width: 100% !important;
  box-sizing: border-box !important;
  display: grid !important;
  grid-template-columns: minmax(0, 1fr) !important;
  gap: 8px !important;
}

[data-r20-student-modal="true"] label,
[data-r20-student-modal="true"] input,
[data-r20-student-modal="true"] select,
[data-r20-student-modal="true"] textarea,
[data-r20-student-modal="true"] button {
  min-width: 0 !important;
  box-sizing: border-box !important;
}

[data-r20-student-modal="true"] input,
[data-r20-student-modal="true"] select {
  min-height: 38px !important;
  padding-block: 6px !important;
}

[data-r20-student-modal="true"] textarea {
  min-height: 74px !important;
}

[data-r20-student-modal="true"] [data-r20-modal-wide="true"] {
  grid-column: 1 / -1 !important;
}

@media (min-width: 700px) {
  [data-r20-student-modal="true"] form {
    grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
  }

  [data-r20-student-modal="true"] h1,
  [data-r20-student-modal="true"] h2,
  [data-r20-student-modal="true"] h3,
  [data-r20-student-modal="true"] .modal-actions,
  [data-r20-student-modal="true"] .dialog-actions,
  [data-r20-student-modal="true"] [class*="actions"] {
    grid-column: 1 / -1 !important;
  }

  .r20-random-picker__options {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}

@media (max-width: 699px) {
  .r20-random-picker__options {
    grid-template-columns: minmax(0, 1fr);
  }
}
'''

css_path = Path("src/styles/r20-fix03-student-management.css")
css_path.parent.mkdir(parents=True, exist_ok=True)
css_path.write_text(css.strip() + "\n", encoding="utf-8")

runtime = r'''export const R20_FIX03_MARKER = "R20_FIX03_STUDENT_MANAGEMENT_V1";

const ROOT_SELECTORS = [
  ".classmode-v103",
  ".classmode-page",
  ".lesson-mode-shell",
  "[data-r20-classmode-root='true']",
];

const LIST_SELECTORS = [
  ".classmode-students-list",
  ".classmode-student-list",
  ".students-list",
  "[data-students-list]",
  "[class*='student-list']",
];

const selectedCandidateIds = new Set();
let drawnCandidateIds = new Set();
let installed = false;
let panel = null;
let optionBox = null;
let statusBox = null;
let candidateSummary = null;
let currentList = null;
let lastRosterSignature = "";
let initialRosterObserved = false;
let previousRosterIds = new Set();
let scheduled = false;

const normalize = (value) =>
  String(value ?? "")
    .replace(/\s+/g, " ")
    .trim();

const normalizeLower = (value) => normalize(value).toLowerCase();

export function normalizeStudentCredentialDigits(value) {
  return String(value ?? "")
    .replace(/[٠-٩]/g, (digit) =>
      String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)),
    )
    .replace(/[۰-۹]/g, (digit) =>
      String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)),
    )
    .trim();
}

export function chooseRandomCandidate(
  candidateIds,
  alreadyDrawn = [],
  rng = Math.random,
) {
  const pool = [...new Set([...candidateIds].map(String).filter(Boolean))];

  if (!pool.length) {
    return {
      id: null,
      nextDrawn: new Set(),
      cycleReset: false,
    };
  }

  const drawn = new Set(
    [...alreadyDrawn].map(String).filter((id) => pool.includes(id)),
  );

  let remaining = pool.filter((id) => !drawn.has(id));
  let cycleReset = false;

  if (!remaining.length) {
    drawn.clear();
    remaining = [...pool];
    cycleReset = true;
  }

  const safeRandom = Math.min(
    0.999999999,
    Math.max(0, Number(rng?.() ?? 0)),
  );
  const index = Math.floor(safeRandom * remaining.length);
  const id = remaining[index];

  drawn.add(id);

  return {
    id,
    nextDrawn: drawn,
    cycleReset,
  };
}

function getRoot() {
  for (const selector of ROOT_SELECTORS) {
    const found = document.querySelector(selector);
    if (found) return found;
  }
  return null;
}

function isVisible(element) {
  if (!element) return false;
  const style = getComputedStyle(element);
  return (
    style.display !== "none" &&
    style.visibility !== "hidden" &&
    element.getClientRects().length > 0
  );
}

function studentRows(root) {
  return [...root.querySelectorAll("[data-student-id]")].filter(
    (row) => !row.closest(".r20-random-picker"),
  );
}

function candidateNameFromRow(row) {
  const direct =
    row.querySelector(
      "[data-student-name], .student-name, .classmode-student-name, .student-display-name, strong, b",
    )?.textContent || "";

  const directName = normalize(direct);
  if (directName && /[\p{L}]/u.test(directName)) {
    return directName;
  }

  const clone = row.cloneNode(true);
  clone
    .querySelectorAll(
      "button, input, select, textarea, svg, [role='button'], .student-actions, .student-points",
    )
    .forEach((node) => node.remove());

  const text = normalize(clone.textContent)
    .replace(
      /(تشجيع|تنبيه|حاضر|غائب|إضافة نقطة|نقطة|نقاط|درجة|درجات)/g,
      " ",
    )
    .replace(/\s+/g, " ")
    .trim();

  const parts = text
    .split(/[|•·—–\-,:،؛]/)
    .map((part) => normalize(part))
    .filter(Boolean);

  return (
    parts.find(
      (part) =>
        /[\p{L}]/u.test(part) &&
        !/^\d+$/.test(part) &&
        part.length <= 80,
    ) ||
    text ||
    `طالب ${row.getAttribute("data-student-id")}`
  );
}

function discoverStudentLists(root) {
  const lists = new Set();

  for (const selector of LIST_SELECTORS) {
    root.querySelectorAll(selector).forEach((list) => {
      if (list.querySelector("[data-student-id]")) lists.add(list);
    });
  }

  const rows = studentRows(root);
  const parentCounts = new Map();

  for (const row of rows) {
    const parent = row.parentElement;
    if (!parent) continue;
    parentCounts.set(parent, (parentCounts.get(parent) || 0) + 1);
  }

  for (const [parent, count] of parentCounts) {
    if (count >= 1) lists.add(parent);
  }

  return [...lists];
}

function choosePrimaryList(lists) {
  if (!lists.length) return null;

  return [...lists].sort((a, b) => {
    const visibleDelta = Number(isVisible(b)) - Number(isVisible(a));
    if (visibleDelta) return visibleDelta;

    const rowDelta =
      b.querySelectorAll("[data-student-id]").length -
      a.querySelectorAll("[data-student-id]").length;
    if (rowDelta) return rowDelta;

    return 0;
  })[0];
}

function createPanel() {
  const root = document.createElement("section");
  root.className = "r20-random-picker";
  root.setAttribute("data-r20-random-picker", "true");
  root.setAttribute(
    "aria-label",
    "اختيار عشوائي من أسماء طلاب محددة",
  );

  root.innerHTML = `
    <div class="r20-random-picker__top">
      <div class="r20-random-picker__title">🎲 اختيار عشوائي من أسماء محددة</div>
      <div class="r20-random-picker__buttons">
        <button type="button" data-r20-action="select-all">الكل</button>
        <button type="button" data-r20-action="clear">مسح</button>
        <button type="button" class="r20-random-picker__draw" data-r20-action="draw">اختيار</button>
      </div>
    </div>
    <details class="r20-random-picker__candidates">
      <summary>حدد الطلاب <span data-r20-candidate-count>0</span></summary>
      <div class="r20-random-picker__options" data-r20-options></div>
    </details>
    <div class="r20-random-picker__status" data-r20-status>
      حدد اسمًا واحدًا أو أكثر أولًا.
    </div>
  `;

  optionBox = root.querySelector("[data-r20-options]");
  statusBox = root.querySelector("[data-r20-status]");
  candidateSummary = root.querySelector("[data-r20-candidate-count]");

  root.addEventListener("change", (event) => {
    const input = event.target.closest?.(
      'input[type="checkbox"][data-r20-candidate-id]',
    );
    if (!input) return;

    const id = String(input.dataset.r20CandidateId || "");
    if (!id) return;

    if (input.checked) selectedCandidateIds.add(id);
    else selectedCandidateIds.delete(id);

    drawnCandidateIds = new Set(
      [...drawnCandidateIds].filter((item) =>
        selectedCandidateIds.has(item),
      ),
    );

    updateCandidateCount();
    setStatus(
      selectedCandidateIds.size
        ? `تم تحديد ${selectedCandidateIds.size} طالب.`
        : "حدد اسمًا واحدًا أو أكثر أولًا.",
    );
  });

  root.addEventListener("click", (event) => {
    const button = event.target.closest?.("[data-r20-action]");
    if (!button) return;

    const action = button.dataset.r20Action;

    if (action === "select-all") {
      for (const input of optionBox.querySelectorAll(
        'input[type="checkbox"][data-r20-candidate-id]',
      )) {
        input.checked = true;
        selectedCandidateIds.add(
          String(input.dataset.r20CandidateId),
        );
      }
      drawnCandidateIds.clear();
      updateCandidateCount();
      setStatus(`تم تحديد ${selectedCandidateIds.size} طالب.`);
      return;
    }

    if (action === "clear") {
      selectedCandidateIds.clear();
      drawnCandidateIds.clear();
      optionBox
        .querySelectorAll(
          'input[type="checkbox"][data-r20-candidate-id]',
        )
        .forEach((input) => {
          input.checked = false;
        });
      updateCandidateCount();
      setStatus("حدد اسمًا واحدًا أو أكثر أولًا.");
      return;
    }

    if (action === "draw") {
      drawFromExactCandidates();
    }
  });

  return root;
}

function updateCandidateCount() {
  if (candidateSummary) {
    candidateSummary.textContent = String(selectedCandidateIds.size);
  }
}

function setStatus(message, isResult = false) {
  if (!statusBox) return;
  statusBox.textContent = message;
  statusBox.classList.toggle(
    "r20-random-picker__result",
    Boolean(isResult),
  );
}

function syncCandidateOptions(list) {
  if (!panel || !optionBox || !list) return;

  const rows = [...list.querySelectorAll("[data-student-id]")];
  const roster = rows
    .map((row) => ({
      id: String(row.getAttribute("data-student-id") || "").trim(),
      name: candidateNameFromRow(row),
    }))
    .filter((item) => item.id);

  const signature = roster
    .map((item) => `${item.id}:${item.name}`)
    .join("|");

  if (signature === lastRosterSignature) return;
  lastRosterSignature = signature;

  const rosterIds = new Set(roster.map((item) => item.id));

  for (const id of [...selectedCandidateIds]) {
    if (!rosterIds.has(id)) selectedCandidateIds.delete(id);
  }

  drawnCandidateIds = new Set(
    [...drawnCandidateIds].filter((id) => rosterIds.has(id)),
  );

  const previousScroll = optionBox.scrollTop;
  const fragment = document.createDocumentFragment();

  for (const item of roster) {
    const label = document.createElement("label");
    label.className = "r20-random-picker__option";

    const input = document.createElement("input");
    input.type = "checkbox";
    input.dataset.r20CandidateId = item.id;
    input.checked = selectedCandidateIds.has(item.id);

    const span = document.createElement("span");
    span.textContent = item.name;
    span.title = item.name;

    label.append(input, span);
    fragment.append(label);
  }

  optionBox.replaceChildren(fragment);
  optionBox.scrollTop = previousScroll;
  updateCandidateCount();
}

async function speakStudentName(name) {
  const text = normalize(name);
  if (!text) return false;

  try {
    if (typeof window.mobdeaR20SpeakArabic === "function") {
      const result = await window.mobdeaR20SpeakArabic(text);
      if (result !== false) return true;
    }
  } catch {
    // Continue to browser fallback.
  }

  try {
    if (!("speechSynthesis" in window)) return false;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "ar-EG";
    utterance.rate = 0.92;
    utterance.volume = 1;
    window.speechSynthesis.speak(utterance);
    return true;
  } catch {
    return false;
  }
}

function activateStudentRow(row) {
  if (!row) return;

  const root = getRoot();
  root
    ?.querySelectorAll('[data-r20-random-selected="true"]')
    .forEach((item) =>
      item.removeAttribute("data-r20-random-selected"),
    );

  row.setAttribute("data-r20-random-selected", "true");
  row.scrollIntoView?.({ block: "nearest", behavior: "smooth" });

  const target =
    row.querySelector(
      "[data-student-select], [data-testid*='student-select'], .student-main, .student-info",
    ) || row;

  try {
    target.click();
  } catch {
    target.dispatchEvent(
      new MouseEvent("click", {
        bubbles: true,
        cancelable: true,
        view: window,
      }),
    );
  }
}

function drawFromExactCandidates() {
  if (!selectedCandidateIds.size) {
    setStatus("حدد طالبًا واحدًا على الأقل قبل الاختيار.");
    return;
  }

  const result = chooseRandomCandidate(
    selectedCandidateIds,
    drawnCandidateIds,
  );

  if (!result.id) {
    setStatus("لا يوجد طالب صالح للاختيار.");
    return;
  }

  drawnCandidateIds = result.nextDrawn;

  const root = getRoot();
  const row = root?.querySelector(
    `[data-student-id="${CSS.escape(result.id)}"]`,
  );

  if (!row) {
    selectedCandidateIds.delete(result.id);
    drawnCandidateIds.delete(result.id);
    updateCandidateCount();
    scheduleRun();
    setStatus("تم تحديث قائمة الطلاب. أعد الاختيار.");
    return;
  }

  const name = candidateNameFromRow(row);
  activateStudentRow(row);
  setStatus(`تم اختيار: ${name}`, true);
  void speakStudentName(name);
}

function classifyLegacyRandomUi(root) {
  const modalCandidates = root.querySelectorAll(
    "[role='dialog'], dialog, .modal, .dialog, .popup, [class*='modal'], [class*='popup'], [class*='random']",
  );

  for (const element of modalCandidates) {
    if (element.closest(".r20-random-picker")) continue;
    const text = normalizeLower(
      [
        element.textContent,
        element.getAttribute("aria-label"),
        element.getAttribute("title"),
      ].join(" "),
    );

    if (
      /تم اختيار الطلاب|تم اختيار الطالب|اختيار عشوائي للطلاب|اختيار الطلاب عشوائي|سحب عشوائي للطلاب/.test(
        text,
      )
    ) {
      element.setAttribute(
        "data-r20-legacy-random-modal",
        "true",
      );
    }
  }

  const controls = root.querySelectorAll(
    "button, [role='button'], a",
  );

  for (const control of controls) {
    if (control.closest(".r20-random-picker")) continue;

    const label = normalizeLower(
      [
        control.textContent,
        control.getAttribute("aria-label"),
        control.getAttribute("title"),
      ].join(" "),
    );

    if (
      /اختيار عشوائي للطلاب|اختيار الطلاب عشوائي|سحب عشوائي للطلاب|random student|random picker/.test(
        label,
      )
    ) {
      control.setAttribute(
        "data-r20-legacy-random-trigger",
        "true",
      );
    }
  }
}

function looksLikeStudentModal(element) {
  if (!element || element.closest(".r20-random-picker")) return false;

  const text = normalizeLower(
    [
      element.textContent,
      element.getAttribute?.("aria-label"),
      element.getAttribute?.("title"),
    ].join(" "),
  );

  if (/إضافة طالب|اضافة طالب|طالب جديد|add student|new student/.test(text)) {
    return true;
  }

  const fields = [...element.querySelectorAll("input, select")];
  const fieldText = normalizeLower(
    fields
      .map((field) =>
        [
          field.name,
          field.placeholder,
          field.getAttribute("aria-label"),
        ]
          .filter(Boolean)
          .join(" "),
      )
      .join(" "),
  );

  return (
    /(student|طالب)/.test(fieldText) &&
    /(code|كود|phone|هاتف|ولي الأمر|المجموعة|group)/.test(fieldText)
  );
}

function classifyStudentModal() {
  const candidates = document.querySelectorAll(
    "[role='dialog'], dialog, .modal, .dialog, [class*='modal'], [class*='dialog']",
  );

  for (const element of candidates) {
    if (!looksLikeStudentModal(element)) continue;
    element.setAttribute("data-r20-student-modal", "true");

    element
      .querySelectorAll("h1, h2, h3, .modal-actions, .dialog-actions")
      .forEach((node) =>
        node.setAttribute("data-r20-modal-wide", "true"),
      );
  }
}

function credentialFieldKind(input) {
  const context = normalizeLower(
    [
      input.name,
      input.id,
      input.placeholder,
      input.getAttribute("aria-label"),
      input.closest("label")?.textContent,
    ]
      .filter(Boolean)
      .join(" "),
  );

  if (/(pin|كلمة المرور|الرقم السري|رمز الدخول|كود الدخول)/.test(context)) {
    return "pin";
  }

  if (/(student.?code|كود الطالب|رقم الطالب|student id)/.test(context)) {
    return "student-code";
  }

  return null;
}

function normalizeCredentialInput(input) {
  const kind = credentialFieldKind(input);
  if (!kind) return false;

  const normalized = normalizeStudentCredentialDigits(input.value);
  const compact =
    kind === "pin"
      ? normalized.replace(/\s+/g, "")
      : normalized.replace(/\s+/g, "");

  if (input.value !== compact) {
    const descriptor = Object.getOwnPropertyDescriptor(
      HTMLInputElement.prototype,
      "value",
    );
    if (descriptor?.set) descriptor.set.call(input, compact);
    else input.value = compact;

    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  if (kind === "pin") {
    input.inputMode = "numeric";
    input.autocomplete = "current-password";
  }

  return true;
}

function normalizeCredentialsWithin(scope) {
  scope
    .querySelectorAll?.("input")
    .forEach((input) => normalizeCredentialInput(input));
}

function requestStudentCloudSync(reason = "student-roster-changed") {
  if (typeof window === "undefined") return;

  const detail = {
    reason,
    at: Date.now(),
  };

  try {
    localStorage.setItem(
      "mobdea:r20:student-sync-requested",
      JSON.stringify(detail),
    );
  } catch {
    // Storage can be unavailable in a restricted WebView.
  }

  for (const type of [
    "mobdea:sync-requested",
    "mobdea:data-changed",
    "mobdea:student-roster-changed",
  ]) {
    try {
      window.dispatchEvent(new CustomEvent(type, { detail }));
    } catch {
      // Ignore optional event channels.
    }
  }

  /*
   * Existing Mobdea releases already sync on connectivity/focus.
   * These standard lifecycle nudges make a newly-created student
   * eligible for the existing pull/merge/push path immediately,
   * without duplicating cloud credentials in this repair layer.
   */
  try {
    window.dispatchEvent(new Event("online"));
    window.dispatchEvent(new Event("focus"));
  } catch {
    // Ignore.
  }
}

function observeRosterChanges(root) {
  const ids = new Set(
    studentRows(root)
      .map((row) =>
        String(row.getAttribute("data-student-id") || "").trim(),
      )
      .filter(Boolean),
  );

  if (!initialRosterObserved) {
    previousRosterIds = ids;
    initialRosterObserved = true;
    return;
  }

  const newIds = [...ids].filter((id) => !previousRosterIds.has(id));
  previousRosterIds = ids;

  if (newIds.length) {
    setTimeout(
      () => requestStudentCloudSync("student-created"),
      250,
    );
    setTimeout(
      () => requestStudentCloudSync("student-created-confirm"),
      1400,
    );
  }
}

function attachPanel(root) {
  const lists = discoverStudentLists(root);

  for (const list of lists) {
    list.setAttribute("data-r20-student-list", "true");
  }

  const nextList = choosePrimaryList(lists);
  if (!nextList) return;

  if (!panel) panel = createPanel();

  if (currentList !== nextList || !panel.isConnected) {
    currentList = nextList;
    nextList.insertAdjacentElement("beforebegin", panel);
  }

  syncCandidateOptions(nextList);
}

function run() {
  const root = getRoot();

  classifyStudentModal();
  normalizeCredentialsWithin(document);

  if (!root) return;

  classifyLegacyRandomUi(root);
  attachPanel(root);
  observeRosterChanges(root);
}

function scheduleRun() {
  if (scheduled) return;
  scheduled = true;

  requestAnimationFrame(() => {
    scheduled = false;
    run();
  });
}

function install() {
  if (installed || typeof document === "undefined") return;
  installed = true;

  const observer = new MutationObserver(scheduleRun);
  observer.observe(document.documentElement, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: [
      "class",
      "style",
      "aria-label",
      "title",
      "data-student-id",
    ],
  });

  document.addEventListener(
    "input",
    (event) => {
      if (event.target instanceof HTMLInputElement) {
        normalizeCredentialInput(event.target);
      }
    },
    true,
  );

  document.addEventListener(
    "submit",
    (event) => {
      const form = event.target;
      if (!(form instanceof HTMLFormElement)) return;

      normalizeCredentialsWithin(form);

      if (form.closest('[data-r20-student-modal="true"]')) {
        setTimeout(
          () => requestStudentCloudSync("student-form-submit"),
          500,
        );
        setTimeout(
          () => requestStudentCloudSync("student-form-submit-confirm"),
          2000,
        );
      }
    },
    true,
  );

  document.addEventListener(
    "click",
    (event) => {
      const button = event.target.closest?.("button");
      if (!button) return;

      const modal = button.closest(
        '[data-r20-student-modal="true"]',
      );
      if (!modal) return;

      const label = normalizeLower(
        [
          button.textContent,
          button.getAttribute("aria-label"),
          button.getAttribute("title"),
        ].join(" "),
      );

      if (/إضافة|اضافة|حفظ|تسجيل|إنشاء|انشاء|add|save|create/.test(label)) {
        setTimeout(
          () => requestStudentCloudSync("student-save-click"),
          800,
        );
        setTimeout(
          () => requestStudentCloudSync("student-save-confirm"),
          2600,
        );
      }
    },
    true,
  );

  window.addEventListener("resize", scheduleRun, { passive: true });
  window.addEventListener("orientationchange", scheduleRun, {
    passive: true,
  });

  run();
}

if (typeof window !== "undefined" && typeof document !== "undefined") {
  window.__MOBDEA_R20_FIX03__ = R20_FIX03_MARKER;

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", install, {
      once: true,
    });
  } else {
    install();
  }
}
'''

runtime_path = Path("src/services/r20StudentManagement.js")
runtime_path.parent.mkdir(parents=True, exist_ok=True)
runtime_path.write_text(runtime.strip() + "\n", encoding="utf-8")

# Keep all students renderable if a historical four-row cap still exists.
class_mode = Path("src/pages/ClassMode.jsx")
if class_mode.is_file():
    source = class_mode.read_text(encoding="utf-8")

    hard_caps = [
        (
            r"\bstudents\.slice\(\s*0\s*,\s*4\s*\)",
            "students",
        ),
        (
            r"\bfilteredStudents\.slice\(\s*0\s*,\s*4\s*\)",
            "filteredStudents",
        ),
        (
            r"\bsortedStudents\.slice\(\s*0\s*,\s*4\s*\)",
            "sortedStudents",
        ),
        (
            r"\bgroupStudents\.slice\(\s*0\s*,\s*4\s*\)",
            "groupStudents",
        ),
        (
            r"\bvisibleStudents\.slice\(\s*0\s*,\s*4\s*\)",
            "visibleStudents",
        ),
    ]

    removed_caps = 0
    for pattern, replacement in hard_caps:
        source, count = re.subn(pattern, replacement, source)
        removed_caps += count

    if "data-student-id={String(student.id)}" not in source:
        pattern = re.compile(
            r"(key=\{student\.id\}\s*\n)(\s*)(className=\{`classmode-student-row )"
        )
        source, count = pattern.subn(
            r"\1\2data-student-id={String(student.id)}\n\2\3",
            source,
            count=1,
        )
        if count == 0:
            print(
                "NOTE: stable data-student-id insertion anchor not found; "
                "existing row markup will be checked later."
            )

    class_mode.write_text(source.rstrip("\r\n") + "\n", encoding="utf-8")
    print(f"Historical four-student render caps removed: {removed_caps}")

main = Path("src/main.jsx")
if not main.is_file():
    raise SystemExit("src/main.jsx missing")

main_source = main.read_text(encoding="utf-8")
imports = [
    "import './styles/r20-fix03-student-management.css';",
    "import './services/r20StudentManagement.js';",
]

for item in imports:
    if item in main_source:
        continue

    matches = list(
        re.finditer(r"^import[\s\S]*?;\s*$", main_source, flags=re.M)
    )
    if not matches:
        raise SystemExit("main.jsx import block not found")

    pos = matches[-1].end()
    main_source = main_source[:pos] + "\n" + item + main_source[pos:]

main.write_text(main_source, encoding="utf-8")

test = r'''import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {
  chooseRandomCandidate,
  normalizeStudentCredentialDigits,
} from "../src/services/r20StudentManagement.js";

const read = (path) => fs.readFileSync(path, "utf8");

test("FIX03 requires an exact selected candidate pool", () => {
  const none = chooseRandomCandidate([], [], () => 0);
  assert.equal(none.id, null);

  const first = chooseRandomCandidate(["a", "c"], [], () => 0);
  assert.equal(first.id, "a");
  assert.ok(!["b"].includes(first.id));

  const second = chooseRandomCandidate(
    ["a", "c"],
    first.nextDrawn,
    () => 0,
  );
  assert.equal(second.id, "c");

  const third = chooseRandomCandidate(
    ["a", "c"],
    second.nextDrawn,
    () => 0,
  );
  assert.equal(third.id, "a");
  assert.equal(third.cycleReset, true);
});

test("FIX03 normalizes Arabic and Persian digits for code and PIN login", () => {
  assert.equal(
    normalizeStudentCredentialDigits(" ١٢٣٤٥٦ "),
    "123456",
  );
  assert.equal(
    normalizeStudentCredentialDigits("۱۲۳۴۵۶"),
    "123456",
  );
});

test("FIX03 imports student management CSS and runtime", () => {
  const main = read("src/main.jsx");
  assert.match(main, /r20-fix03-student-management\.css/);
  assert.match(main, /r20StudentManagement\.js/);
});

test("FIX03 student list is touch-scrollable and legacy random popup is hidden", () => {
  const css = read("src/styles/r20-fix03-student-management.css");
  assert.match(css, /overflow-y:\s*auto\s*!important/);
  assert.match(css, /touch-action:\s*pan-y\s*!important/);
  assert.match(css, /data-r20-legacy-random-modal="true"/);
  assert.match(css, /data-r20-student-modal="true"/);
});

test("FIX03 picker speaks the chosen student and does not re-parent React student rows", () => {
  const runtime = read("src/services/r20StudentManagement.js");
  assert.match(runtime, /mobdeaR20SpeakArabic/);
  assert.match(runtime, /selectedCandidateIds = new Set/);
  assert.match(runtime, /insertAdjacentElement\("beforebegin", panel\)/);
  assert.doesNotMatch(runtime, /appendChild\(row\)/);
  assert.doesNotMatch(runtime, /prepend\(row\)/);
});

test("FIX03 keeps stable student row identifiers when available", () => {
  const source = read("src/pages/ClassMode.jsx");
  assert.match(source, /data-student-id=\{String\(student\.id\)\}/);
});
'''

test_path = Path("tests/r20-fix03-student-management.test.mjs")
test_path.parent.mkdir(parents=True, exist_ok=True)
test_path.write_text(test.strip() + "\n", encoding="utf-8")

print("FIX03 student management installed.")
PY

git add -N \
  src/styles/r20-fix03-student-management.css \
  src/services/r20StudentManagement.js \
  tests/r20-fix03-student-management.test.mjs

git diff --check
node --check src/services/r20StudentManagement.js
node --check tests/r20-fix03-student-management.test.mjs
node --test tests/r20-fix03-student-management.test.mjs
