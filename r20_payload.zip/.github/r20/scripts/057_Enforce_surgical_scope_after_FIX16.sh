set -euo pipefail
python3 /tmp/r20-surgical-guard.py verify /tmp/r20-surgical-fix16.json \
  --phase FIX16 \
  --allow "src/config/r20MapChallengeNaturalLayersConfig.js" \
  --allow "src/services/r20MapChallengeNaturalLayers.js" \
  --allow "src/styles/r20-fix16-map-natural-layers.css" \
  --allow "src/services/r20ImageMode.js" \
  --allow "src/styles/r20-fix16-image-mode.css" \
  --allow "tests/r20-fix16-map-natural-layers.test.mjs" \
  --allow "tests/r20-fix16-image-mode.test.mjs" \
  --allow "scripts/r20-fix16-detect-natural-layers.py" \
  --allow "scripts/r20-fix16-map-natural-layers-smoke.mjs" \
  --allow "scripts/r20-fix16-image-mode-smoke.mjs" \
  --allow "src/main.jsx"
git diff --check
