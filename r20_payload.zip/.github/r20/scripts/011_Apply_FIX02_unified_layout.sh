set -euo pipefail

python3 - <<'PY'
from pathlib import Path
import re

css = r'''/* R20_FIX02_UNIFIED_CLASSMODE_LAYOUT_V1
   Unified ClassMode chrome for:
   PDF, whiteboard, images, video, audio, PowerPoint, maps, games.
   This phase intentionally changes layout/chrome only.
*/

:root {
  --r20-class-top-gap: max(6px, env(safe-area-inset-top, 0px));
  --r20-class-side-gap: 8px;
  --r20-class-control-size: 38px;
  --r20-class-control-radius: 12px;
  --r20-class-control-opacity: .72;
  --r20-class-bottom-gap: max(8px, env(safe-area-inset-bottom, 0px));
}

.classmode-v103,
.classmode-page,
.lesson-mode-shell,
[data-r20-classmode-root="true"] {
  position: relative !important;
  width: 100% !important;
  max-width: 100% !important;
  min-width: 0 !important;
  height: 100dvh !important;
  max-height: 100dvh !important;
  overflow: hidden !important;
  box-sizing: border-box !important;
}

[data-r20-classmode-stage="true"] {
  position: absolute !important;
  inset:
    calc(var(--r20-class-top-gap) + 48px)
    0
    calc(var(--r20-class-bottom-gap) + 54px)
    0 !important;
  width: auto !important;
  height: auto !important;
  min-width: 0 !important;
  min-height: 0 !important;
  max-width: 100% !important;
  max-height: none !important;
  box-sizing: border-box !important;
  overflow: hidden !important;
  margin: 0 !important;
  padding: 0 !important;
}

[data-r20-classmode-content="true"] {
  width: 100% !important;
  height: 100% !important;
  min-width: 0 !important;
  min-height: 0 !important;
  max-width: 100% !important;
  max-height: 100% !important;
  box-sizing: border-box !important;
  margin: 0 auto !important;
}

/* Top bar: back arrow only. */
[data-r20-control="back"] {
  position: fixed !important;
  top: var(--r20-class-top-gap) !important;
  left: var(--r20-class-side-gap) !important;
  right: auto !important;
  bottom: auto !important;
  width: var(--r20-class-control-size) !important;
  min-width: var(--r20-class-control-size) !important;
  height: var(--r20-class-control-size) !important;
  min-height: var(--r20-class-control-size) !important;
  padding: 0 !important;
  margin: 0 !important;
  border-radius: 50% !important;
  font-size: 0 !important;
  line-height: 1 !important;
  opacity: .82 !important;
  z-index: 2200 !important;
}

[data-r20-control="back"]::before {
  content: "←";
  font-size: 22px !important;
  line-height: 1 !important;
}

/* Bottom shared controls. */
[data-r20-control="students"],
[data-r20-control="save"],
[data-r20-control="board-tools"],
[data-r20-control="cards"],
[data-r20-control="symbols"] {
  position: fixed !important;
  bottom: var(--r20-class-bottom-gap) !important;
  width: var(--r20-class-control-size) !important;
  min-width: var(--r20-class-control-size) !important;
  height: var(--r20-class-control-size) !important;
  min-height: var(--r20-class-control-size) !important;
  padding: 0 !important;
  margin: 0 !important;
  border-radius: var(--r20-class-control-radius) !important;
  font-size: 0 !important;
  line-height: 1 !important;
  opacity: var(--r20-class-control-opacity) !important;
  z-index: 2200 !important;
}

[data-r20-control="students"] {
  right: var(--r20-class-side-gap) !important;
}

[data-r20-control="save"] {
  right: calc(var(--r20-class-side-gap) + 46px) !important;
  opacity: .62 !important;
}

[data-r20-control="board-tools"] {
  left: var(--r20-class-side-gap) !important;
}

[data-r20-control="cards"] {
  left: calc(var(--r20-class-side-gap) + 46px) !important;
}

[data-r20-control="symbols"] {
  left: calc(var(--r20-class-side-gap) + 92px) !important;
}

[data-r20-control="students"]::before {
  content: "👥";
  font-size: 18px !important;
}

[data-r20-control="save"]::before {
  content: "💾";
  font-size: 17px !important;
}

[data-r20-control="board-tools"]::before {
  content: "🖍️";
  font-size: 18px !important;
}

[data-r20-control="cards"]::before {
  content: "🗂️";
  font-size: 18px !important;
}

[data-r20-control="symbols"]::before {
  content: "📍";
  font-size: 18px !important;
}

/* Only one student-management button survives. */
[data-r20-duplicate-control="true"] {
  display: none !important;
}

/* Preserve R19 Online Lesson; make it non-floating so it cannot cover lesson content. */
[data-r20-control="online-floating"] {
  display: inline-flex !important;
  position: static !important;
  inset: auto !important;
  transform: none !important;
  margin: 0 !important;
  z-index: auto !important;
}

/* Shared media/content normalization. */
[data-r20-resource-kind="pdf"],
[data-r20-resource-kind="whiteboard"],
[data-r20-resource-kind="image"],
[data-r20-resource-kind="video"],
[data-r20-resource-kind="audio"],
[data-r20-resource-kind="powerpoint"],
[data-r20-resource-kind="map"],
[data-r20-resource-kind="game"] {
  width: 100% !important;
  height: 100% !important;
  min-width: 0 !important;
  min-height: 0 !important;
  max-width: 100% !important;
  max-height: 100% !important;
  margin: 0 auto !important;
  box-sizing: border-box !important;
}

[data-r20-resource-kind="video"] video,
[data-r20-resource-kind="audio"] audio,
[data-r20-resource-kind="image"] img,
[data-r20-resource-kind="pdf"] canvas,
[data-r20-resource-kind="whiteboard"] canvas {
  max-width: 100% !important;
  max-height: 100% !important;
  box-sizing: border-box !important;
}

/* Avoid the old left-shifted / clipped tablet composition. */
[data-r20-resource-kind="whiteboard"],
[data-r20-resource-kind="map"],
[data-r20-resource-kind="game"],
[data-r20-resource-kind="powerpoint"] {
  margin-inline: auto !important;
  translate: none !important;
  transform-origin: center center !important;
}

/* Pager must never cover the PDF. */
[data-r20-pager="true"] {
  position: fixed !important;
  bottom: calc(var(--r20-class-bottom-gap) + 2px) !important;
  left: 50% !important;
  transform: translateX(-50%) scale(.78) !important;
  transform-origin: bottom center !important;
  opacity: .56 !important;
  z-index: 2150 !important;
}

/* Generic small tablet modal shell. */
[data-r20-classmode-root="true"] [role="dialog"],
[data-r20-classmode-root="true"] dialog,
[data-r20-classmode-root="true"] .modal,
[data-r20-classmode-root="true"] .dialog {
  max-width: min(92vw, 720px) !important;
  max-height: min(86dvh, 700px) !important;
  box-sizing: border-box !important;
}

@media (orientation: landscape) and (min-width: 700px) {
  [data-r20-classmode-stage="true"] {
    inset:
      calc(var(--r20-class-top-gap) + 44px)
      0
      calc(var(--r20-class-bottom-gap) + 48px)
      0 !important;
  }

  [data-r20-control="back"],
  [data-r20-control="students"],
  [data-r20-control="save"],
  [data-r20-control="board-tools"],
  [data-r20-control="cards"],
  [data-r20-control="symbols"] {
    --r20-class-control-size: 36px;
  }
}
'''

css_path = Path("src/styles/r20-fix02-unified-classmode-layout.css")
css_path.parent.mkdir(parents=True, exist_ok=True)
css_path.write_text(css.strip() + "\n", encoding="utf-8")

runtime = r'''const R20_FIX02_MARKER = "R20_FIX02_UNIFIED_CLASSMODE_LAYOUT_V1";

const normalize = (value) =>
  String(value ?? "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();

const CLASSMODE_ROOT_SELECTORS = [
  ".classmode-v103",
  ".classmode-page",
  ".lesson-mode-shell",
  "[class*='class-mode']",
  "[class*='classmode']",
];

const STAGE_SELECTORS = [
  ".classmode-main",
  ".classmode-content",
  ".classmode-stage",
  ".classmode-resource-area",
  ".classmode-media-stage",
  ".classmode-whiteboard-stage",
  ".lesson-content",
  ".resource-stage",
];

function firstExisting(root, selectors) {
  for (const selector of selectors) {
    const found = root.querySelector(selector);
    if (found) return found;
  }
  return null;
}

function getRoot() {
  for (const selector of CLASSMODE_ROOT_SELECTORS) {
    const root = document.querySelector(selector);
    if (root) return root;
  }
  return null;
}

function labelOf(element) {
  return normalize(
    [
      element?.getAttribute?.("aria-label"),
      element?.getAttribute?.("title"),
      element?.textContent,
    ]
      .filter(Boolean)
      .join(" "),
  );
}

function isVisible(element) {
  if (!element) return false;
  const style = getComputedStyle(element);
  return (
    style.display !== "none" &&
    style.visibility !== "hidden" &&
    element.getClientRects().length > 0
  );
}

function classifyResource(element) {
  if (!element) return null;

  const cls = normalize(element.className);
  const id = normalize(element.id);
  const label = normalize(
    [
      cls,
      id,
      element.getAttribute?.("data-type"),
      element.getAttribute?.("data-mode"),
      element.getAttribute?.("aria-label"),
    ].join(" "),
  );

  if (/pdf|document|viewer/.test(label)) return "pdf";
  if (/whiteboard|board|سبورة/.test(label)) return "whiteboard";
  if (/powerpoint|pptx|\bppt\b|presentation/.test(label)) return "powerpoint";
  if (/video|youtube/.test(label)) return "video";
  if (/audio|sound|صوت/.test(label)) return "audio";
  if (/map|atlas|خريطة|خرائط/.test(label)) return "map";
  if (/game|challenge|لعبة|العاب|ألعاب/.test(label)) return "game";
  if (/image|photo|صورة|صور/.test(label)) return "image";

  if (element.querySelector?.("video")) return "video";
  if (element.querySelector?.("audio")) return "audio";
  if (element.querySelector?.("iframe[src*='.ppt'], iframe[src*='office']")) {
    return "powerpoint";
  }

  return null;
}

function markResourceNodes(root) {
  const selectors = [
    ".pdf-viewer",
    ".pdf-stage",
    ".whiteboard-shell",
    ".whiteboard-stage",
    ".board-stage",
    ".image-viewer",
    ".media-image",
    ".video-player",
    ".audio-player",
    ".powerpoint-viewer",
    ".ppt-viewer",
    ".map-shell",
    ".map-stage",
    ".atlas",
    ".map-challenge-pro",
    ".game-shell",
    ".classmode-game",
    "[data-resource-type]",
    "[data-media-type]",
    "[data-viewer-type]",
  ];

  for (const element of root.querySelectorAll(selectors.join(","))) {
    const kind = classifyResource(element);
    if (kind) element.setAttribute("data-r20-resource-kind", kind);
  }

  const stage = firstExisting(root, STAGE_SELECTORS) || root;
  stage.setAttribute("data-r20-classmode-stage", "true");

  let content =
    firstExisting(stage, [
      ".classmode-content-inner",
      ".resource-content",
      ".media-content",
      ".viewer-content",
    ]) || stage.firstElementChild;

  if (content && content !== stage) {
    content.setAttribute("data-r20-classmode-content", "true");
  }
}

function classifyControls(root) {
  const controls = [
    ...root.querySelectorAll(
      'button, [role="button"], a[class*="button"], a[class*="btn"]',
    ),
  ];

  const studentControls = [];

  for (const control of controls) {
    const label = labelOf(control);

    if (/عودة الحصة|العودة للحصة|رجوع للحصة|back to lesson/.test(label)) {
      control.setAttribute("data-r20-control", "back");
      control.setAttribute("aria-label", "عودة للحصة");
      control.setAttribute("title", "عودة للحصة");
      continue;
    }

    if (/إدارة الطلاب|إدارة طالب|قائمة الطلاب|students/.test(label)) {
      control.setAttribute("data-r20-control", "students");
      studentControls.push(control);
      continue;
    }

    if (/^حفظ$|حفظ السبورة|حفظ الصفحة|save/.test(label)) {
      control.setAttribute("data-r20-control", "save");
      control.setAttribute("aria-label", "حفظ");
      continue;
    }

    if (/أدوات السبورة|ادوات السبورة|whiteboard tools|board tools/.test(label)) {
      control.setAttribute("data-r20-control", "board-tools");
      control.setAttribute("aria-label", "أدوات السبورة");
      continue;
    }

    if (/^البطاقات$|^بطاقات$|الكروت|cards/.test(label)) {
      control.setAttribute("data-r20-control", "cards");
      control.setAttribute("aria-label", "البطاقات");
      continue;
    }

    if (/الرموز|رموز الخرائط|symbols/.test(label)) {
      control.setAttribute("data-r20-control", "symbols");
      control.setAttribute("aria-label", "الرموز");
      continue;
    }

    if (/الحصة الأونلاين|الحصة الاونلاين|online lesson|online class/.test(label)) {
      control.setAttribute("data-r20-control", "online-floating");
    }
  }

  studentControls
    .filter((element) => isVisible(element))
    .slice(1)
    .forEach((element) =>
      element.setAttribute("data-r20-duplicate-control", "true"),
    );

  for (const pager of root.querySelectorAll(
    ".classmode-page-nav, [class*='page-nav'], [class*='pager']",
  )) {
    pager.setAttribute("data-r20-pager", "true");
  }
}

function runFix02Layout() {
  const root = getRoot();
  if (!root) return;

  root.setAttribute("data-r20-classmode-root", "true");
  classifyControls(root);
  markResourceNodes(root);
}

function installFix02() {
  if (typeof document === "undefined") return;

  let queued = false;
  const schedule = () => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      runFix02Layout();
    });
  };

  const observer = new MutationObserver(schedule);
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["class", "style", "aria-label", "title"],
  });

  window.addEventListener("resize", schedule, { passive: true });
  window.addEventListener("orientationchange", schedule, { passive: true });

  runFix02Layout();
}

if (typeof window !== "undefined") {
  window.__MOBDEA_R20_FIX02__ = R20_FIX02_MARKER;

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", installFix02, {
      once: true,
    });
  } else {
    installFix02();
  }
}
'''

runtime_path = Path("src/services/r20UnifiedClassModeLayout.js")
runtime_path.parent.mkdir(parents=True, exist_ok=True)
runtime_path.write_text(runtime.strip() + "\n", encoding="utf-8")

main = Path("src/main.jsx")
if not main.is_file():
    raise SystemExit("src/main.jsx missing")

main_source = main.read_text(encoding="utf-8")
imports = [
    "import './styles/r20-fix02-unified-classmode-layout.css';",
    "import './services/r20UnifiedClassModeLayout.js';",
]

for item in imports:
    if item in main_source:
        continue

    matches = list(
        re.finditer(r"^import[\s\S]*?;\s*$", main_source, flags=re.M)
    )
    if not matches:
        raise SystemExit("main.jsx import block not found")

    pos = matches[-1].end()
    main_source = main_source[:pos] + "\n" + item + main_source[pos:]

main.write_text(main_source, encoding="utf-8")

test = r'''import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

const read = (path) => fs.readFileSync(path, "utf8");

test("FIX02 imports the unified ClassMode layout", () => {
  const main = read("src/main.jsx");
  assert.match(main, /r20-fix02-unified-classmode-layout\.css/);
  assert.match(main, /r20UnifiedClassModeLayout\.js/);
});

test("FIX02 covers all required resource kinds", () => {
  const runtime = read("src/services/r20UnifiedClassModeLayout.js");
  for (const kind of [
    "pdf",
    "whiteboard",
    "image",
    "video",
    "audio",
    "powerpoint",
    "map",
    "game",
  ]) {
    assert.match(runtime, new RegExp(`"${kind}"`));
  }
});

test("FIX02 has one shared control contract", () => {
  const css = read("src/styles/r20-fix02-unified-classmode-layout.css");

  for (const control of [
    "back",
    "students",
    "save",
    "board-tools",
    "cards",
    "symbols",
  ]) {
    assert.match(css, new RegExp(`data-r20-control="${control}"`));
  }

  assert.match(css, /\[data-r20-control="online-floating"\][\s\S]*?display:\s*inline-flex\s*!important/);
  assert.doesNotMatch(css, /\[data-r20-control="online-floating"\]\s*\{[^}]*display:\s*none\s*!important/s);
  assert.match(css, /data-r20-duplicate-control="true"[\s\S]*?display:\s*none\s*!important/);
});

test("FIX02 back control is compact top-only and shared controls are compact bottom controls", () => {
  const css = read("src/styles/r20-fix02-unified-classmode-layout.css");

  assert.match(css, /--r20-class-control-size:\s*38px/);
  assert.match(css, /data-r20-control="back"/);
  assert.match(css, /top:\s*var\(--r20-class-top-gap\)/);
  assert.match(css, /data-r20-control="students"/);
  assert.match(css, /bottom:\s*var\(--r20-class-bottom-gap\)/);
  assert.match(css, /data-r20-pager="true"/);
});
'''

test_path = Path("tests/r20-fix02-unified-classmode-layout.test.mjs")
test_path.parent.mkdir(parents=True, exist_ok=True)
test_path.write_text(test.strip() + "\n", encoding="utf-8")

print("FIX02 unified ClassMode layout installed.")
PY

git add -N \
  src/styles/r20-fix02-unified-classmode-layout.css \
  src/services/r20UnifiedClassModeLayout.js \
  tests/r20-fix02-unified-classmode-layout.test.mjs

git diff --check
node --check src/services/r20UnifiedClassModeLayout.js
node --check tests/r20-fix02-unified-classmode-layout.test.mjs
node --test tests/r20-fix02-unified-classmode-layout.test.mjs
