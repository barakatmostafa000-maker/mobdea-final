set -euo pipefail

node --test tests/r20-fix04-student-parent-accounts.test.mjs

# Existing portal architecture remains a hard release gate.
node --test tests/student-portal-sync.test.mjs
node --test tests/cloud-worker.test.mjs

if [ -s tests/project12-integrated.test.mjs ]; then
  node --test tests/project12-integrated.test.mjs
fi

if [ -s tests/r19-final-v3.test.mjs ]; then
  node --test \
    --test-name-pattern="student portal remains portable to a fresh phone|app uses the actual pull merge push cloud flow|phone and tablet records merge without losing unique data" \
    tests/r19-final-v3.test.mjs
fi

grep -Fq 'MOBDEA_DEFAULT_PORTAL_PASSWORD = "123456"' \
  src/services/r20AccountPolicy.js
grep -Fq 'R20_DEFAULT_PASSWORD = "123456"' \
  cloud-worker/r20PortalAccounts.js
grep -Fq 'PBKDF2' cloud-worker/r20PortalAccounts.js
grep -Fq 'SHA-256' cloud-worker/r20PortalAccounts.js
grep -Fq 'mustChangePassword' cloud-worker/r20PortalAccounts.js
grep -Fq 'sessionVersion' cloud-worker/r20PortalAccounts.js
grep -Fq 'linkedStudentIds' cloud-worker/r20PortalAccounts.js

grep -Fq 'student-session:' cloud-worker/worker.js
grep -Fq 'studentPinHash' cloud-worker/worker.js
grep -Fq 'studentPinSalt' cloud-worker/worker.js

git diff --check
