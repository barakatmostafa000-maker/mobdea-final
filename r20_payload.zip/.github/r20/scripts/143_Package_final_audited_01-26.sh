set -euo pipefail

OUT="/tmp/mobdea-r20-final-audited-01-26"

rm -rf "$OUT"
mkdir -p "$OUT"

APK="android/app/build/outputs/apk/debug/app-debug.apk"
test -s "$APK"

cp "$APK" "$OUT/mobdea-r20-final-audited-01-26-debug.apk"
sha256sum "$OUT/mobdea-r20-final-audited-01-26-debug.apk" > "$OUT/mobdea-r20-final-audited-01-26-debug.apk.sha256"

git diff --binary > "$OUT/R20-SAFE-SURGICAL-MERGE-R19-FIX01-25.patch"
cp /tmp/r20-final-source-diff-files.txt "$OUT/SURGICAL-DIFF-FILES.txt" 2>/dev/null || true
cat > "$OUT/R19-PRESERVATION-CONTRACT.txt" <<'EOF_R19'
R19 remains the protected baseline.
FIX01-FIX25 are applied as scoped repairs only.
Each repair is surrounded by a hash-based worktree guard.
Unexpected file changes fail the workflow immediately.
Legacy OCR callers are preserved; FIX08 adds a compatible OCR path without repository-wide renaming.
FIX14 may patch only detector-approved legacy geography files and never prior r20 modules.
The existing R19 Online Lesson entry point remains visible/clickable; floating geometry is neutralized instead of hiding the control.
EOF_R19

cp /tmp/r20-fix25-monthly-sources.txt "$OUT/MONTHLY-SOURCES.txt"
cp src/config/r20MonthlyEvaluationConfig.js "$OUT/MONTHLY-CONFIG.js"

if [ -d r20-monthly-evaluation-smoke ]; then
  cp -r r20-monthly-evaluation-smoke "$OUT/monthly-smoke"
fi

cat > "$OUT/VERIFY-FIX25.txt" <<'EOF'
R20 MONTHLY STUDENT EVALUATION

- Existing student-ranking is preserved and remains a regression gate.
- Detector records whether a legacy monthly ranking already exists.
- Three separate rankings: exam grades, class points, most improved.
- Overall ranking across all groups and independent ranking per group.
- Exam ranking uses monthly cumulative percentages, then average and exam count.
- Class ranking uses class/lesson/participation/attendance point data only when present.
- Most improved compares current month to previous month without inventing missing baseline data.
- Student sees own overall and group ranks.
- Parent sees only linkedStudentIds.
- Teacher/admin can view all rankings.
- Each exam result becomes a ready ranked share text.
- Monthly parent-group share includes exams, class points and most improved.
- WhatsApp sharing is explicit via wa.me text URL.
- Dashboard icon label: التقييم الشهري.

EOF

cp /tmp/r20-toolchain-contract.txt "$OUT/TOOLCHAIN-CONTRACT.txt" 2>/dev/null || true
cp /tmp/r20-node-version.txt "$OUT/NODE-VERSION.txt" 2>/dev/null || true
cp /tmp/r20-gradle-version.txt "$OUT/GRADLE-VERSION.txt" 2>/dev/null || true
cp /tmp/r20-fix24-social-links.txt "$OUT/VERIFIED-SOCIAL-LINKS.txt" 2>/dev/null || true
