set -euo pipefail
node --test tests/r20-fix24-mobdea-online.test.mjs
node --test tests/r20-fix05-role-dashboard.test.mjs tests/r20-fix06-teacher-tablet-dashboard.test.mjs

grep -Fq 'R20_FIX24_MOBDEA_ONLINE_CONFIG_V2_VERIFIED_LINKS' src/config/r20MobdeaOnlineConfig.js
grep -Fq 'https://youtube.com/@mostafabarakat21?si=j81UCr73vvnZtpPn' src/config/r20MobdeaOnlineConfig.js
grep -Fq 'https://www.facebook.com/share/18DaQCzDzT/' src/config/r20MobdeaOnlineConfig.js
grep -Fq 'https://www.tiktok.com/@mostafabarakat210?_r=1&_t=ZS-99GSdfl3yi0' src/config/r20MobdeaOnlineConfig.js
grep -Fq 'R20_FIX24_MOBDEA_ONLINE_V1' src/services/r20MobdeaOnline.js
grep -Fq 'data-r20-mobdea-online-card' src/services/r20MobdeaOnline.js
grep -Fq 'data-r20-social' src/services/r20MobdeaOnline.js
git diff --check
