set -euo pipefail
node --test tests/r20-fix01-core-runtime.test.mjs tests/r20-fix02-unified-classmode-layout.test.mjs tests/r20-fix03-student-management.test.mjs tests/r20-fix04-student-parent-accounts.test.mjs tests/r20-fix05-role-dashboard.test.mjs tests/r20-fix06-teacher-tablet-dashboard.test.mjs tests/r20-fix07-pdf-gestures.test.mjs tests/r20-audit-phase01-08.test.mjs \
  tests/r20-fix08-ocr-page-questions.test.mjs \
  tests/r20-fix09-whiteboard.test.mjs \
  tests/r20-fix10-educational-cards.test.mjs \
  tests/r20-fix11-country-cards.test.mjs \
  tests/r20-fix12-maps.test.mjs \
  tests/r20-fix13-atlas.test.mjs \
  tests/r20-fix14-geography-correctness.test.mjs \
  tests/r20-fix15-map-challenge.test.mjs \
  tests/r20-fix16-map-natural-layers.test.mjs \
  tests/r20-fix16-image-mode.test.mjs \
  tests/r20-fix17-media.test.mjs \
  tests/r20-fix18-games.test.mjs \
  tests/r20-fix19-question-bank-pipeline.test.mjs \
  tests/r20-fix20-exam-tracking.test.mjs \
  tests/r20-fix21-reports-whatsapp.test.mjs \
  tests/r20-fix22-remedial-assistant.test.mjs \
  tests/r20-fix23-duplex-printing.test.mjs \
  tests/r20-fix24-mobdea-online.test.mjs \
  tests/r20-fix25-monthly-evaluation.test.mjs
node scripts/sync-version.mjs
node scripts/verify-project.mjs
RELEASE_TESTS=(tests/asset-store.test.mjs tests/auto-backup.test.mjs tests/backup.test.mjs tests/cloud-worker.test.mjs tests/content-library.test.mjs tests/gamification.test.mjs tests/geography-maps.test.mjs tests/global-search.test.mjs tests/library-model.test.mjs tests/map-symbol-library-v13.test.mjs tests/media-navigation.test.mjs tests/media-renderer.test.mjs tests/native-asset-bridge.test.mjs tests/online-game.test.mjs tests/pdf-question-ocr.test.mjs tests/question-rotation.test.mjs tests/security.test.mjs tests/share.test.mjs tests/student-card-printing-r14.test.mjs tests/student-portal-sync.test.mjs tests/student-ranking.test.mjs tests/ui-helpers.test.mjs)
for f in "${RELEASE_TESTS[@]}"; do test -s "$f"; done
node --test "${RELEASE_TESTS[@]}"
node --test --test-name-pattern="phone and tablet records merge without losing unique data|app uses the actual pull merge push cloud flow|student portal remains portable to a fresh phone|live class captures server TURN" tests/r19-final-v3.test.mjs
test -s tests/r19-interaction-stability.test.mjs
node --test tests/r19-interaction-stability.test.mjs
npm run lint
npm run format:check
npm run build
test -d dist && test -s dist/index.html
grep -Eq 'MAX_ASSET_BYTES[[:space:]]*=[[:space:]]*200[[:space:]]*\*[[:space:]]*1024[[:space:]]*\*[[:space:]]*1024' src/services/cloudSync.js
grep -Eq 'MAX_ASSET_BYTES[[:space:]]*=[[:space:]]*200[[:space:]]*\*[[:space:]]*1024[[:space:]]*\*[[:space:]]*1024' cloud-worker/worker.js
grep -Eq 'APP_VERSION[[:space:]]*=[[:space:]]*["'"'"']10\.14\.1["'"'"']' src/config/version.js
grep -Eq 'APP_VERSION_CODE[[:space:]]*=[[:space:]]*118' src/config/version.js
grep -Fq 'DEFAULT_R20_WORKER_URL' src/services/r20PortalAuthClient.js
grep -Fq 'R20_PORTAL_ALIAS_PREFIX' cloud-worker/r20PortalAccounts.js
grep -Fq 'portal-auth/authorize-student' cloud-worker/r20PortalAccounts.js
git diff --check
