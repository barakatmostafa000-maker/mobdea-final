set -euo pipefail

node --test \
  tests/r20-fix17-media.test.mjs

# Existing media/navigation tests, when present, are mandatory.
mapfile -t EXISTING_MEDIA_TESTS < <(
  find tests \
    -maxdepth 1 \
    -type f \
    \( \
      -iname '*media*.test.mjs' \
      -o -iname '*video*.test.mjs' \
      -o -iname '*audio*.test.mjs' \
      -o -iname '*powerpoint*.test.mjs' \
      -o -iname '*ppt*.test.mjs' \
    \) \
    ! -name 'r20-fix17-media.test.mjs' \
    -print
)

if [ "${#EXISTING_MEDIA_TESTS[@]}" -gt 0 ]; then
  node --test \
    "${EXISTING_MEDIA_TESTS[@]}"
fi

for capability in \
  video \
  audio \
  powerpoint \
  powerpointNavigation; do

  grep -Eq \
    "\"${capability}\"[[:space:]]*:[[:space:]]*true" \
    src/config/r20MediaCapabilities.js
done

grep -Fq \
  'R20_FIX17_MEDIA_CONTROLS_V1' \
  src/services/r20MediaControls.js

grep -Fq \
  'R20_FIX17_POWERPOINT_MODE_V1' \
  src/services/r20PowerPointMode.js

grep -Fq \
  'data-r20-media-controls' \
  src/services/r20MediaControls.js

grep -Fq \
  'data-r20-ppt-controls' \
  src/services/r20PowerPointMode.js

grep -Fq \
  'object-fit:' \
  src/styles/r20-fix17-media.css

# Re-hash pre-existing media implementations and require no direct FIX17 edits.
if [ -s /tmp/r20-fix17-media-protected-sources.txt ]; then
  : > \
    /tmp/r20-fix17-media-after.sha256

  while IFS= read -r file; do
    sha256sum "$file"
  done < \
    /tmp/r20-fix17-media-protected-sources.txt \
    > /tmp/r20-fix17-media-after.sha256

  cmp \
    /tmp/r20-fix17-media-before.sha256 \
    /tmp/r20-fix17-media-after.sha256
fi



git diff --check
