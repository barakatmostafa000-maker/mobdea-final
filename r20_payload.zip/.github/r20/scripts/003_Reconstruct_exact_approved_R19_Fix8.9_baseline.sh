set -euo pipefail

test "$(git rev-parse HEAD)" = "$R19_BASE_COMMIT"
test -z "$(git status --porcelain)"
EXPECTED_PATCH_SHA="cdde2432847080323e32430c86e5a717877a6f54a5c21a32820072c1761c7332"
FIX3_COMMIT="3477b1b9b7f2210823054634e4f840ff9744910c"
WORK="/tmp/r20-approved-r19"
rm -rf "$WORK" && mkdir -p "$WORK"
RUN_ID="$(gh run list --repo "$GITHUB_REPOSITORY" --workflow "R19_FINAL_RELEASE_FIX8_9.yml" --status success --limit 1 --json databaseId --jq '.[0].databaseId // empty')"
test -n "$RUN_ID"
gh run download "$RUN_ID" --repo "$GITHUB_REPOSITORY" --name "mobdea-r19-final-release-fix8-9-apk" --dir "$WORK"
PATCH="$(find "$WORK" -type f -name 'R19-FIX8-9-applied.patch' -print -quit)"
test -n "$PATCH" && test -s "$PATCH"
ACTUAL_SHA="$(sha256sum "$PATCH" | awk '{print $1}')"
test "$ACTUAL_SHA" = "$EXPECTED_PATCH_SHA"
git reset --hard "$R19_BASE_COMMIT"
git clean -fdx
git apply --check "$PATCH"
git apply "$PATCH"
git diff --check

git fetch --no-tags origin "$FIX3_COMMIT" --depth=1
git show "$FIX3_COMMIT:.github/workflows/R19_FINAL_RELEASE_FIX3.yml" > /tmp/r19-fix3-pinned.yml
python3 <<'PY_CSS'
from pathlib import Path
import base64,re
src=Path('/tmp/r19-fix3-pinned.yml').read_text(encoding='utf-8')
m=re.search(r"cat > /tmp/css\.b64 <<'EOF_CSS'\n(.*?)\n\s*EOF_CSS",src,re.S)
if not m: raise SystemExit('Pinned Fix3 CSS payload not found')
css=base64.b64decode(''.join(m.group(1).split())).decode('utf-8')
p=Path('src/styles/r19-targeted-fixes.css'); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(css.rstrip('\r\n')+'\n',encoding='utf-8')
PY_CSS
test -s src/styles/r19-targeted-fixes.css
grep -Fq '.classmode-students-list' src/styles/r19-targeted-fixes.css
grep -Fq 'object-fit: fill !important' src/styles/r19-targeted-fixes.css
grep -Fq '.lesson-map-symbol-list button' src/styles/r19-targeted-fixes.css
git add -N src/styles/r19-targeted-fixes.css
git diff --check
printf 'R19-FIX8.9 run=%s patch_sha=%s fix3=%s\n' "$RUN_ID" "$ACTUAL_SHA" "$FIX3_COMMIT" > /tmp/r20-source-label.txt
