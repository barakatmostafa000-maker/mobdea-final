import { BookOpenCheck, Globe2, Sparkles, ShieldCheck } from 'lucide-react';
import LoginForm from '../components/LoginForm';
import { identity } from '../config/identity';
import '../styles/login.css';
import heroImage from '../assets/1000369205.jpg';

const highlights = [
  { title: 'حسب الدور', text: 'المعلم، الإدارة، الطالب، ولي الأمر، والزائر.' },
  { title: 'QR والكود', text: 'دخول الطالب بكوده أو بمسح الكارت مباشرة.' },
  { title: 'واجهة حية', text: 'تصميم ذهبي داكن متجاوب للموبايل والتابلت.' },
];

export default function Login({ data, onUnlock }) {
  return (
    <div className="login-page">
      <section className="login-shell">
        <div className="login-hero-panel panel">
          <div className="login-hero-copy">
            <span className="eyebrow">أهلاً بك في {identity.schoolName}</span>
            <h1>{identity.teacherName}</h1>
            <p>
              دخول آمن ومرن حسب الدور، مع تصميم احترافي مطابق لهوية المنصة وسريع على الهاتف والتابلت.
            </p>
            <div className="login-highlights-grid">
              {highlights.map((item) => (
                <article key={item.title} className="login-highlight-card">
                  <strong>{item.title}</strong>
                  <span>{item.text}</span>
                </article>
              ))}
            </div>
          </div>

          <div className="login-hero-image-wrap">
            <img src={heroImage} alt={identity.teacherName} className="login-hero-image" />
            <div className="login-hero-overlay" />
            <div className="login-hero-badges">
              <span><ShieldCheck size={14} /> آمن</span>
              <span><Sparkles size={14} /> Premium</span>
              <span><BookOpenCheck size={14} /> Live</span>
              <span><Globe2 size={14} /> Mobile Ready</span>
            </div>
          </div>
        </div>

        <LoginForm data={data} onUnlock={onUnlock} />
      </section>
    </div>
  );
}
