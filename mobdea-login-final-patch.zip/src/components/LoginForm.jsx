import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowRight, BadgeInfo, Camera, PersonStanding, QrCode, ScanLine, ShieldCheck, UserRound, UsersRound } from 'lucide-react';
import { identity } from '../config/identity';
import { LOGIN_ROLES, normalizeRole } from '../utils/auth';
import { loginUser, visitorLogin } from '../services/auth';

function stopCamera(streamRef, videoRef, detectorRef, timerRef) {
  if (timerRef.current) {
    window.clearInterval(timerRef.current);
    timerRef.current = null;
  }
  if (streamRef.current) {
    streamRef.current.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
  }
  detectorRef.current = null;
  if (videoRef.current) {
    videoRef.current.srcObject = null;
  }
}

export default function LoginForm({ data, onUnlock }) {
  const [role, setRole] = useState('teacher');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [visitorName, setVisitorName] = useState('');
  const [remember, setRemember] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [cameraOpen, setCameraOpen] = useState(false);
  const [scanMessage, setScanMessage] = useState('');
  const [scannedValue, setScannedValue] = useState('');
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const detectorRef = useRef(null);
  const scanTimerRef = useRef(null);

  const activeRole = useMemo(() => normalizeRole(role), [role]);
  const roleInfo = LOGIN_ROLES.find((item) => item.key === role) || LOGIN_ROLES[0];
  const roleIcons = {
    teacher: ShieldCheck,
    admin: ShieldCheck,
    student: UserRound,
    parent: UsersRound,
    visitor: PersonStanding,
  };

  useEffect(() => {
    setIdentifier('');
    setPassword('');
    setVisitorName('');
    setError('');
    setScannedValue('');
    setCameraOpen(false);
    setScanMessage('');
    setShowPassword(false);
    stopCamera(streamRef, videoRef, detectorRef, scanTimerRef);
  }, [role]);

  useEffect(() => () => stopCamera(streamRef, videoRef, detectorRef, scanTimerRef), []);

  useEffect(() => {
    if (!cameraOpen) return undefined;
    let cancelled = false;

    const launch = async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          setScanMessage('الكاميرا غير مدعومة على هذا الجهاز.');
          return;
        }
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
        if (cancelled) {
          stream.getTracks().forEach((track) => track.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        if ('BarcodeDetector' in window) {
          detectorRef.current = new window.BarcodeDetector({ formats: ['qr_code', 'code_128', 'code_39'] });
          scanTimerRef.current = window.setInterval(async () => {
            if (!videoRef.current || !detectorRef.current) return;
            try {
              const codes = await detectorRef.current.detect(videoRef.current);
              const rawValue = String(codes?.[0]?.rawValue || '').trim();
              if (!rawValue) return;
              setScanMessage('تم التقاط QR بنجاح.');
              setScannedValue(rawValue);
              setIdentifier(rawValue);
              if (activeRole === 'student' || activeRole === 'guardian') {
                await submitLogin(rawValue, { qrPayload: rawValue });
              }
            } catch {
              // ignore scan loop errors
            }
          }, 1100);
        } else {
          setScanMessage('المتصفح الحالي لا يدعم القراءة التلقائية؛ الصق الكود يدويًا.');
        }
      } catch (scanError) {
        setScanMessage(scanError?.message || 'تعذر فتح الكاميرا.');
      }
    };

    launch();
    return () => {
      cancelled = true;
      stopCamera(streamRef, videoRef, detectorRef, scanTimerRef);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cameraOpen, activeRole]);

  const submitLogin = async (identifierOverride = identifier, extra = {}) => {
    setLoading(true);
    setError('');
    try {
      const response = await loginUser({
        role,
        identifier: identifierOverride,
        password,
        visitorName,
        remember,
        qrPayload: extra.qrPayload || scannedValue,
      }, data);
      if (response?.success) {
        stopCamera(streamRef, videoRef, detectorRef, scanTimerRef);
        onUnlock(response.session);
      }
    } catch (loginError) {
      setError(loginError?.message || 'تعذر تسجيل الدخول.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (activeRole === 'visitor') {
      const response = visitorLogin(visitorName);
      onUnlock(response.session);
      return;
    }
    await submitLogin();
  };


  return (
    <div className="login-form-card">
      <div className="login-header">
        <div className="login-brand-badge">
          <img src={identity.icon} alt={identity.schoolName} />
          <div>
            <span className="eyebrow">منصة المُبدع</span>
            <strong>{identity.schoolName}</strong>
          </div>
        </div>
        <h2>تسجيل دخول حسب الدور</h2>
        <p>اختر نوع الحساب ثم أدخل البيانات المناسبة للوصول إلى الواجهة المرتبطة به.</p>
      </div>

      <div className="role-selector" role="tablist" aria-label="اختيار نوع الحساب">
        {LOGIN_ROLES.map((item) => {
          const ItemIcon = roleIcons[item.key] || ShieldCheck;
          return (
            <button
              key={item.key}
              type="button"
              className={`role-chip ${role === item.key ? 'active' : ''}`}
              onClick={() => setRole(item.key)}
            >
              <ItemIcon size={16} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      <div className="login-role-note">
        <BadgeInfo size={16} />
        <span>{roleInfo.hint}</span>
      </div>

      {error && <div className="login-alert error">{error}</div>}
      {scanMessage && <div className="login-alert info">{scanMessage}</div>}

      <form onSubmit={handleSubmit} className="login-form">
        {activeRole === 'visitor' ? (
          <div className="field-group">
            <label>اسم الزائر</label>
            <input
              type="text"
              className="login-input"
              placeholder="اكتب اسم الزائر"
              value={visitorName}
              onChange={(e) => setVisitorName(e.target.value)}
              required
            />
          </div>
        ) : (
          <>
            <div className="field-group">
              <label>{activeRole === 'admin' ? 'اسم المستخدم أو الرقم' : activeRole === 'teacher' ? 'اسم المعلم أو الرقم' : activeRole === 'parent' ? 'رقم ولي الأمر أو كود الطالب' : 'كود الطالب أو QR'}</label>
              <div className="login-input-row">
                <input
                  type="text"
                  className="login-input"
                  placeholder={activeRole === 'student' ? 'مثال: 123 أو بيانات QR' : 'أدخل البيانات هنا'}
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  required={activeRole !== 'visitor' && activeRole !== 'admin' && activeRole !== 'teacher' ? true : false}
                />
                {(activeRole === 'student' || activeRole === 'guardian') && (
                  <button type="button" className="qr-action-btn" onClick={() => setCameraOpen((open) => !open)}>
                    <Camera size={16} />
                    {cameraOpen ? 'إغلاق الكاميرا' : 'مسح QR'}
                  </button>
                )}
              </div>
            </div>

            <div className="field-group">
              <label>{activeRole === 'admin' || activeRole === 'teacher' ? 'الرقم السري' : 'كلمة المرور أو تأكيد الكود (اختياري)'}</label>
              <div className="password-field">
                <input
                  type={showPassword ? 'text' : 'password'}
                  className="login-input"
                  placeholder={activeRole === 'admin' || activeRole === 'teacher' ? '••••••••' : 'اختياري'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required={activeRole === 'admin' || activeRole === 'teacher'}
                />
                <button type="button" className="toggle-password-btn" onClick={() => setShowPassword((value) => !value)}>
                  {showPassword ? 'إخفاء' : 'إظهار'}
                </button>
              </div>
            </div>
          </>
        )}

        <div className="login-options-row">
          <label className="remember-option">
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
            <span>تذكرني</span>
          </label>
          <button type="button" className="text-link" onClick={() => setError('أعد ضبط كلمة المرور من لوحة الإدارة أو قاعدة البيانات.')}>نسيت كلمة المرور؟</button>
        </div>

        {cameraOpen && (activeRole === 'student' || activeRole === 'guardian') && (
          <div className="qr-preview">
            <div className="qr-preview-head">
              <QrCode size={16} />
              <span>مسح الكارت / QR</span>
            </div>
            <video ref={videoRef} className="qr-video" muted playsInline />
            <div className="qr-preview-foot">
              <ScanLine size={16} />
              <span>{scannedValue ? `تم التقاط: ${scannedValue}` : 'وجّه الكاميرا نحو الكود ثم انتظر.'}</span>
            </div>
          </div>
        )}

        <button type="submit" className="login-submit" disabled={loading}>
          <ArrowRight size={18} />
          <span>{loading ? 'جاري التحقق...' : 'دخول'}</span>
        </button>

        <div className="login-split-actions">
          <button type="button" className="login-secondary" onClick={() => onUnlock(visitorLogin('الزائر').session)}>
            <PersonStanding size={16} />
            <span>دخول كزائر سريع</span>
          </button>
        </div>
      </form>

      <div className="login-footer">
        <p>بمجرد الدخول ستظهر الصلاحيات والصفحات المسموح بها فقط حسب الدور.</p>
      </div>
    </div>
  );
}
