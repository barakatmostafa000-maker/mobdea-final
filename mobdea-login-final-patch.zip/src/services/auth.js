import { verifyPinSecret } from '../utils/security';
import {
  defaultAuthState,
  normalizeDigits,
  normalizeRole,
  resolveGuardianByPhone,
  resolveStudentByCode,
  resolveStudentFromQrPayload,
  roleGreeting,
} from '../utils/auth';

function buildDisplayName(role, data, student, visitorName) {
  if (role === 'admin') return data?.settings?.teacherName || 'الإدارة';
  if (role === 'student') return student?.name || 'الطالب';
  if (role === 'guardian') return student?.guardianName || `ولي أمر ${student?.name || ''}`.trim() || 'ولي الأمر';
  if (role === 'visitor') return visitorName || 'الزائر';
  return roleGreeting(role);
}

function sessionPayload({ role, data, student = null, remember = false, visitorName = '', loginRole = '' }) {
  const displayName = buildDisplayName(role, data, student, visitorName);
  const labelKey = loginRole || role;
  return defaultAuthState(role, student, {
    loginRole: labelKey,
    displayName,
    visitorName,
    remember,
    roleLabel: labelKey === 'parent' || labelKey === 'guardian' ? 'ولي الأمر' : labelKey === 'visitor' ? 'الزائر' : labelKey === 'admin' ? 'الإدارة' : labelKey === 'teacher' ? 'المعلم' : 'الطالب',
    loggedInAt: new Date().toISOString(),
  });
}

export async function loginUser({
  role = 'student',
  identifier = '',
  password = '',
  visitorName = '',
  remember = false,
  qrPayload = null,
} = {}, data = {}) {
  const normalizedRole = normalizeRole(role);
  const rawIdentifier = String(identifier ?? '').trim();
  const rawPassword = String(password ?? '').trim();

  if (normalizedRole === 'admin') {
    const pin = rawPassword || rawIdentifier;
    if (!pin) throw new Error('أدخل الرقم السري أولًا.');
    const ok = await verifyPinSecret(pin, data?.settings || {});
    if (!ok) throw new Error('الرقم السري غير صحيح.');
    return {
      success: true,
      session: sessionPayload({ role: 'admin', data, remember, loginRole: role }),
    };
  }

  if (normalizedRole === 'student') {
    const student = resolveStudentFromQrPayload(data, qrPayload || rawIdentifier)
      || resolveStudentByCode(data, rawIdentifier);
    if (!student) throw new Error('لم يتم العثور على الطالب بهذا الكود أو QR.');
    if (rawPassword) {
      const expected = normalizeDigits(student.code);
      if (normalizeDigits(rawPassword) !== expected) {
        throw new Error('بيانات الطالب غير صحيحة.');
      }
    }
    return {
      success: true,
      session: sessionPayload({ role: 'student', data, student, remember, loginRole: role }),
    };
  }

  if (normalizedRole === 'guardian') {
    const student = resolveGuardianByPhone(data, rawIdentifier)
      || resolveStudentByCode(data, rawIdentifier)
      || resolveStudentFromQrPayload(data, qrPayload || rawIdentifier);
    if (!student) throw new Error('لم يتم العثور على ولي الأمر أو الطالب المرتبط به.');
    if (rawPassword) {
      const expected = normalizeDigits(student.code);
      if (normalizeDigits(rawPassword) !== expected) {
        throw new Error('بيانات ولي الأمر غير صحيحة.');
      }
    }
    return {
      success: true,
      session: sessionPayload({ role: 'guardian', data, student, remember, loginRole: role }),
    };
  }

  const cleanVisitorName = String(visitorName || rawIdentifier).trim();
  if (!cleanVisitorName) throw new Error('اكتب اسم الزائر أولًا.');
  return {
    success: true,
    session: sessionPayload({ role: 'visitor', data, remember, visitorName: cleanVisitorName, loginRole: role }),
  };
}

export function visitorLogin(visitorName = '') {
  const cleanVisitorName = String(visitorName).trim() || 'الزائر';
  return {
    success: true,
    session: defaultAuthState('visitor', null, {
      loginRole: 'visitor',
      roleLabel: 'الزائر',
      visitorName: cleanVisitorName,
      displayName: cleanVisitorName,
      remember: false,
      loggedInAt: new Date().toISOString(),
    }),
  };
}
