export const ROLE_LABELS = {
  admin: 'الإدارة',
  teacher: 'المعلم',
  student: 'الطالب',
  guardian: 'ولي الأمر',
  visitor: 'الزائر',
};

export const LOGIN_ROLES = [
  { key: 'teacher', label: 'المعلم', hint: 'بيانات المعلم والرقم السري' },
  { key: 'admin', label: 'الإدارة', hint: 'الرقم السري الخاص بالإدارة' },
  { key: 'student', label: 'الطالب', hint: 'الكود أو QR الكارت' },
  { key: 'parent', label: 'ولي الأمر', hint: 'الرقم المسجل أو كود الطالب' },
  { key: 'visitor', label: 'الزائر', hint: 'دخول سريع للعرض فقط' },
];

const ROLE_ALIASES = {
  admin: 'admin',
  teacher: 'admin',
  student: 'student',
  parent: 'guardian',
  guardian: 'guardian',
  visitor: 'visitor',
};

export const ROLE_HOME = {
  admin: 'dashboard',
  teacher: 'dashboard',
  student: 'dashboard',
  guardian: 'dashboard',
  visitor: 'dashboard',
};

export const ROLE_ACCESS = {
  admin: null,
  student: new Set(['dashboard', 'portalPreview', 'studentCards', 'grades', 'games', 'mapChallenge', 'contentLibrary', 'messages']),
  guardian: new Set(['dashboard', 'portalPreview', 'attendance', 'grades', 'payments', 'messages', 'reports', 'contentLibrary']),
  visitor: new Set(['dashboard', 'portalPreview', 'contentLibrary', 'updates']),
};

export function normalizeRole(role) {
  const key = String(role || '').trim().toLowerCase();
  return ROLE_ALIASES[key] || 'visitor';
}

export function normalizeDigits(value) {
  return String(value ?? '').replace(/\D/g, '').trim();
}

export function resolveStudentByCode(data, input) {
  const value = normalizeDigits(input);
  if (!value) return null;
  return (data?.students || []).find((student) => String(student.code) === value || String(student.id) === value) || null;
}

export function resolveGuardianByPhone(data, input) {
  const value = normalizeDigits(input);
  if (!value) return null;
  return (data?.students || []).find((student) => normalizeDigits(student.guardianPhone) === value) || null;
}

export function resolveStudentFromQrPayload(data, payload) {
  if (!payload) return null;
  try {
    const parsed = typeof payload === 'string' ? JSON.parse(payload) : payload;
    const candidates = [parsed?.code, parsed?.studentCode, parsed?.id, parsed?.studentId, parsed?.phone, parsed?.guardianPhone]
      .map(normalizeDigits)
      .filter(Boolean);
    for (const candidate of candidates) {
      const student = resolveStudentByCode(data, candidate);
      if (student) return student;
    }
  } catch {
    // Fallback to direct string lookup.
  }
  return resolveStudentByCode(data, payload);
}

export function roleGreeting(role) {
  return ROLE_LABELS[normalizeRole(role)] || 'المستخدم';
}

export function defaultAuthState(role = 'admin', student = null, extra = {}) {
  const normalizedRole = normalizeRole(role);
  return {
    role: normalizedRole,
    loginRole: extra.loginRole || role,
    roleLabel: extra.roleLabel || ROLE_LABELS[normalizedRole] || 'المستخدم',
    studentId: student?.id || null,
    studentCode: student?.code || null,
    displayName: extra.displayName || student?.name || '',
    visitorName: extra.visitorName || '',
    remember: Boolean(extra.remember),
    permissions: student?.permissions || null,
    parentPermissions: student?.parentPermissions || null,
    loggedInAt: extra.loggedInAt || new Date().toISOString(),
  };
}

export function getRoleModules(role) {
  return ROLE_ACCESS[normalizeRole(role)] || null;
}
