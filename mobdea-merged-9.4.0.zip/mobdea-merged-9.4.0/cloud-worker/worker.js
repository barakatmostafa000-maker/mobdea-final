const MAX_SYNC_BYTES = 8_000_000;
const MAX_SHARE_BYTES = 6_000_000;
const MAX_ASSET_BYTES = 25 * 1024 * 1024;
const MAX_ASSET_COUNT = 500;
const MAX_READS_PER_MINUTE = 90;
const MAX_WRITES_PER_MINUTE = 25;
const MAX_ASSET_READS_PER_MINUTE = 600;
const MAX_ASSET_WRITES_PER_MINUTE = 550;
const encoder = new TextEncoder();
const decoder = new TextDecoder();

function allowedOrigins(env) {
  return String(env.MOBDEA_ALLOWED_ORIGINS || '').split(',').map((item) => item.trim()).filter(Boolean);
}

function corsHeaders(request, env) {
  const origin = request.headers.get('Origin');
  const allowed = allowedOrigins(env);
  const headers = {
    'Vary': 'Origin',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Mobdea-Workspace,X-Mobdea-Client,If-Match,X-Mobdea-Asset-Name,X-Mobdea-Asset-Kind,X-Mobdea-Asset-Sha256,X-Mobdea-Asset-Size,X-Mobdea-Live-Token,X-Mobdea-Game-Token',
    'Access-Control-Expose-Headers': 'ETag,X-Mobdea-Asset-Sha256,X-Mobdea-Asset-Size,X-Mobdea-Asset-Name,X-Mobdea-Asset-Kind',
    'Access-Control-Allow-Methods': 'GET,HEAD,PUT,POST,PATCH,DELETE,OPTIONS',
    'Access-Control-Max-Age': '86400',
  };
  if (origin && allowed.includes(origin)) headers['Access-Control-Allow-Origin'] = origin;
  return headers;
}

function securityHeaders() {
  return {
    'Content-Type': 'application/json;charset=UTF-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Cross-Origin-Resource-Policy': 'cross-origin',
  };
}

function json(request, env, body, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...securityHeaders(), ...corsHeaders(request, env), ...extraHeaders },
  });
}

function validWorkspace(value) {
  const workspace = String(value || '').trim();
  return /^[a-zA-Z0-9_-]{3,80}$/.test(workspace) ? workspace : '';
}

function workspaceTokens(env) {
  try {
    const parsed = JSON.parse(env.MOBDEA_WORKSPACE_TOKENS || '{}');
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

async function tokenDigest(value) {
  return new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(String(value || ''))));
}

async function tokenEquals(left, right) {
  const a = await tokenDigest(left);
  const b = await tokenDigest(right);
  let diff = 0;
  for (let index = 0; index < a.length; index += 1) diff |= a[index] ^ b[index];
  return diff === 0;
}

async function authenticate(request, env) {
  const workspace = validWorkspace(request.headers.get('X-Mobdea-Workspace'));
  const token = (request.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '').trim();
  const expected = workspaceTokens(env)[workspace];
  if (!workspace || !token || typeof expected !== 'string' || expected.length < 24 || !(await tokenEquals(token, expected))) return null;
  return { workspace };
}

function bytesToBase64(bytes) {
  let binary = '';
  for (let offset = 0; offset < bytes.length; offset += 0x8000) binary += String.fromCharCode(...bytes.subarray(offset, Math.min(bytes.length, offset + 0x8000)));
  return btoa(binary);
}

function base64ToBytes(value) {
  const binary = atob(String(value || ''));
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

async function encryptionKey(env) {
  const secret = String(env.MOBDEA_ENCRYPTION_KEY || '');
  if (secret.length < 32) throw new Error('MOBDEA_ENCRYPTION_KEY must contain at least 32 characters.');
  const digest = await crypto.subtle.digest('SHA-256', encoder.encode(secret));
  return crypto.subtle.importKey('raw', digest, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
}

async function encryptJson(value, env, aad) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await encryptionKey(env);
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: encoder.encode(aad), tagLength: 128 }, key, encoder.encode(JSON.stringify(value)));
  return JSON.stringify({ version: 1, iv: bytesToBase64(iv), ciphertext: bytesToBase64(new Uint8Array(ciphertext)) });
}

async function decryptJson(value, env, aad) {
  if (!value) return null;
  const envelope = JSON.parse(value);
  if (envelope.version !== 1 || !envelope.iv || !envelope.ciphertext) throw new Error('Invalid encrypted envelope.');
  const key = await encryptionKey(env);
  const plaintext = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: base64ToBytes(envelope.iv), additionalData: encoder.encode(aad), tagLength: 128 }, key, base64ToBytes(envelope.ciphertext));
  return JSON.parse(decoder.decode(plaintext));
}

async function sha256Hex(bytes) {
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function encryptBinary(bytes, env, aad) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await encryptionKey(env);
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: encoder.encode(aad), tagLength: 128 }, key, bytes);
  return { iv: bytesToBase64(iv), ciphertext };
}

async function decryptBinary(bytes, iv, env, aad) {
  const key = await encryptionKey(env);
  return crypto.subtle.decrypt({ name: 'AES-GCM', iv: base64ToBytes(iv), additionalData: encoder.encode(aad), tagLength: 128 }, key, bytes);
}

async function parseJsonBody(request, maxBytes) {
  const declared = Number(request.headers.get('Content-Length') || 0);
  if (declared && declared > maxBytes) throw Object.assign(new Error('payload_too_large'), { status: 413 });
  const text = await request.text();
  if (encoder.encode(text).byteLength > maxBytes) throw Object.assign(new Error('payload_too_large'), { status: 413 });
  try { return JSON.parse(text); } catch { throw Object.assign(new Error('invalid_json'), { status: 400 }); }
}

function validateSyncPayload(payload, workspace) {
  if (!payload || typeof payload !== 'object' || payload.workspaceId !== workspace || !payload.data || typeof payload.data !== 'object') return false;
  if (!Number.isInteger(Number(payload.schemaVersion)) || Number(payload.schemaVersion) < 1 || Number(payload.schemaVersion) > 100) return false;
  if (!Array.isArray(payload.data.students) || !Array.isArray(payload.data.sessions)) return false;
  if (!payload.data.settings || typeof payload.data.settings !== 'object') return false;
  if (payload.assetManifest !== undefined) {
    if (!Array.isArray(payload.assetManifest) || payload.assetManifest.length > MAX_ASSET_COUNT) return false;
    for (const asset of payload.assetManifest) {
      if (!asset || !/^[a-zA-Z0-9._-]{1,100}$/.test(String(asset.id || ''))) return false;
      if (!/^[a-f0-9]{64}$/.test(String(asset.sha256 || ''))) return false;
      if (!Number.isInteger(Number(asset.size)) || Number(asset.size) <= 0 || Number(asset.size) > MAX_ASSET_BYTES) return false;
    }
  }
  return true;
}

function validateSharePayload(payload) {
  return payload && typeof payload === 'object'
    && /^[a-zA-Z0-9_-]{1,30}$/.test(String(payload.kind || ''))
    && payload.payload && typeof payload.payload === 'object';
}

async function rateLimit(request, env, workspace, write = false, overrideLimit = 0, category = '') {
  const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
  const minute = Math.floor(Date.now() / 60000);
  const scope = workspace || 'public';
  const key = `rate:${scope}:${ip}:${minute}:${category || (write ? 'w' : 'r')}`;
  const limit = overrideLimit || (write ? MAX_WRITES_PER_MINUTE : MAX_READS_PER_MINUTE);
  const count = Number(await env.MOBDEA_DATA.get(key) || 0) + 1;
  await env.MOBDEA_DATA.put(key, String(count), { expirationTtl: 120 });
  return count <= limit;
}

function randomToken() {
  return bytesToBase64(crypto.getRandomValues(new Uint8Array(24))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function safeAssetMetadata(value, maxLength = 180) {
  try { return decodeURIComponent(String(value || '')).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, maxLength); } catch { return ''; }
}

function assetResponseHeaders(request, env, metadata = {}) {
  return {
    ...corsHeaders(request, env),
    ...securityHeaders(),
    'Content-Type': metadata.type || 'application/octet-stream',
    'X-Mobdea-Asset-Sha256': metadata.sha256 || '',
    'X-Mobdea-Asset-Size': String(metadata.size || 0),
    'X-Mobdea-Asset-Name': encodeURIComponent(metadata.name || 'file'),
    'X-Mobdea-Asset-Kind': encodeURIComponent(metadata.kind || 'resource'),
  };
}

async function handleAssetStatus(request, env, auth) {
  if (!env.MOBDEA_ASSETS) return json(request, env, { error: 'asset_storage_not_configured', message: 'مخزن الملفات السحابي غير مفعّل.' }, 503);
  if (!(await rateLimit(request, env, auth.workspace, false))) return json(request, env, { error: 'rate_limited' }, 429, { 'Retry-After': '60' });
  const body = await parseJsonBody(request, 80_000);
  const ids = Array.isArray(body?.ids) ? [...new Set(body.ids.map((id) => String(id || '')))] : [];
  if (!ids.length || ids.length > MAX_ASSET_COUNT || ids.some((id) => !/^[a-zA-Z0-9._-]{1,100}$/.test(id))) {
    return json(request, env, { error: 'invalid_asset_list' }, 400);
  }
  const assets = {};
  for (let offset = 0; offset < ids.length; offset += 25) {
    const chunk = ids.slice(offset, offset + 25);
    const records = await Promise.all(chunk.map(async (id) => ({
      id,
      object: await env.MOBDEA_ASSETS.head(`workspace/${auth.workspace}/${id}`),
    })));
    for (const { id, object } of records) {
      const hash = String(object?.customMetadata?.sha256 || '').toLowerCase();
      if (/^[a-f0-9]{64}$/.test(hash)) assets[id] = hash;
    }
  }
  return json(request, env, { assets });
}

async function pruneWorkspaceAssets(env, workspace, manifest = [], previousManifest = []) {
  if (!env.MOBDEA_ASSETS) return;
  const retained = new Set(manifest.map((asset) => String(asset.id || '')).filter(Boolean));
  const prefix = `workspace/${workspace}/`;
  const obsolete = new Set(previousManifest
    .map((asset) => String(asset.id || ''))
    .filter((id) => id && !retained.has(id))
    .map((id) => `${prefix}${id}`));

  if (typeof env.MOBDEA_ASSETS.list === 'function') {
    let cursor;
    do {
      const page = await env.MOBDEA_ASSETS.list({ prefix, cursor, limit: 1000 });
      for (const object of page?.objects || []) if (!retained.has(String(object.key || '').slice(prefix.length))) obsolete.add(object.key);
      cursor = page?.truncated ? page.cursor : undefined;
    } while (cursor);
  }
  await Promise.allSettled([...obsolete].map((key) => env.MOBDEA_ASSETS.delete(key)));
}

async function handleAsset(request, env, auth, assetId) {
  if (!env.MOBDEA_ASSETS) return json(request, env, { error: 'asset_storage_not_configured', message: 'مخزن الملفات السحابي غير مفعّل.' }, 503);
  if (!/^[a-zA-Z0-9._-]{1,100}$/.test(assetId)) return json(request, env, { error: 'not_found' }, 404);
  const write = request.method === 'PUT' || request.method === 'DELETE';
  if (!(await rateLimit(
    request,
    env,
    auth.workspace,
    write,
    write ? MAX_ASSET_WRITES_PER_MINUTE : MAX_ASSET_READS_PER_MINUTE,
    write ? 'asset-w' : 'asset-r',
  ))) return json(request, env, { error: 'rate_limited' }, 429, { 'Retry-After': '60' });
  const key = `workspace/${auth.workspace}/${assetId}`;
  const aad = `asset:${auth.workspace}:${assetId}`;

  if (request.method === 'HEAD') {
    const object = await env.MOBDEA_ASSETS.head(key);
    if (!object) return new Response(null, { status: 404, headers: assetResponseHeaders(request, env) });
    return new Response(null, { status: 200, headers: assetResponseHeaders(request, env, object.customMetadata || {}) });
  }

  if (request.method === 'GET') {
    const object = await env.MOBDEA_ASSETS.get(key);
    if (!object) return json(request, env, { error: 'not_found' }, 404);
    const metadata = object.customMetadata || {};
    const encrypted = await object.arrayBuffer();
    const plaintext = await decryptBinary(encrypted, metadata.iv, env, aad);
    if (Number(metadata.size || 0) !== plaintext.byteLength || await sha256Hex(plaintext) !== metadata.sha256) throw new Error('Stored asset integrity check failed.');
    const headers = assetResponseHeaders(request, env, metadata);
    headers['Content-Length'] = String(plaintext.byteLength);
    headers['Content-Disposition'] = `inline; filename*=UTF-8''${encodeURIComponent(metadata.name || 'file')}`;
    return new Response(plaintext, { status: 200, headers });
  }

  if (request.method === 'PUT') {
    const declared = Number(request.headers.get('Content-Length') || request.headers.get('X-Mobdea-Asset-Size') || 0);
    if (declared <= 0 || declared > MAX_ASSET_BYTES) return json(request, env, { error: 'payload_too_large' }, 413);
    const bytes = await request.arrayBuffer();
    if (bytes.byteLength <= 0 || bytes.byteLength > MAX_ASSET_BYTES || bytes.byteLength !== declared) return json(request, env, { error: 'invalid_asset_size' }, 400);
    const expectedHash = String(request.headers.get('X-Mobdea-Asset-Sha256') || '').toLowerCase();
    const actualHash = await sha256Hex(bytes);
    if (!/^[a-f0-9]{64}$/.test(expectedHash) || expectedHash !== actualHash) return json(request, env, { error: 'asset_hash_mismatch' }, 400);
    const name = safeAssetMetadata(request.headers.get('X-Mobdea-Asset-Name')) || 'file';
    const kind = safeAssetMetadata(request.headers.get('X-Mobdea-Asset-Kind'), 40) || 'resource';
    const type = String(request.headers.get('Content-Type') || 'application/octet-stream').split(';')[0].trim().slice(0, 120);
    const encrypted = await encryptBinary(bytes, env, aad);
    const metadata = { iv: encrypted.iv, sha256: actualHash, size: String(bytes.byteLength), name, kind, type, updatedAt: new Date().toISOString() };
    await env.MOBDEA_ASSETS.put(key, encrypted.ciphertext, { customMetadata: metadata, httpMetadata: { contentType: 'application/octet-stream' } });
    return json(request, env, { ok: true, id: assetId, sha256: actualHash, size: bytes.byteLength }, 200);
  }

  if (request.method === 'DELETE') {
    await env.MOBDEA_ASSETS.delete(key);
    return json(request, env, { ok: true });
  }

  return json(request, env, { error: 'method_not_allowed' }, 405);
}

async function handleSync(request, env, auth) {
  if (!(await rateLimit(request, env, auth.workspace, request.method === 'PUT'))) return json(request, env, { error: 'rate_limited' }, 429, { 'Retry-After': '60' });
  const key = `workspace:${auth.workspace}`;
  const aad = `sync:${auth.workspace}`;
  if (request.method === 'GET') {
    const encrypted = await env.MOBDEA_DATA.get(key);
    if (!encrypted) return json(request, env, { error: 'not_found' }, 404);
    const value = await decryptJson(encrypted, env, aad);
    return json(request, env, value, 200, { ETag: value.revision });
  }
  if (request.method === 'PUT') {
    const payload = await parseJsonBody(request, MAX_SYNC_BYTES);
    if (!validateSyncPayload(payload, auth.workspace)) return json(request, env, { error: 'invalid_payload' }, 400);
    const existingEncrypted = await env.MOBDEA_DATA.get(key);
    const existing = existingEncrypted ? await decryptJson(existingEncrypted, env, aad) : null;
    const suppliedRevision = String(request.headers.get('If-Match') || payload.baseRevision || '').trim();
    if (existing?.revision && suppliedRevision !== existing.revision) {
      return json(request, env, { error: 'revision_conflict', currentRevision: existing.revision, updatedAt: existing.updatedAt }, 409);
    }
    const revision = crypto.randomUUID();
    const stored = { ...payload, revision, updatedAt: new Date().toISOString() };
    await env.MOBDEA_DATA.put(key, await encryptJson(stored, env, aad));
    try {
      await pruneWorkspaceAssets(env, auth.workspace, stored.assetManifest || [], existing?.assetManifest || []);
    } catch {
      // Synchronization data is already committed; orphan cleanup can retry on the next successful push.
    }
    return json(request, env, { ok: true, workspace: auth.workspace, revision, updatedAt: stored.updatedAt }, 200, { ETag: revision });
  }
  return json(request, env, { error: 'method_not_allowed' }, 405);
}

async function handleCreateShare(request, env, auth) {
  if (!(await rateLimit(request, env, auth.workspace, true))) return json(request, env, { error: 'rate_limited' }, 429, { 'Retry-After': '60' });
  const body = await parseJsonBody(request, MAX_SHARE_BYTES);
  if (!validateSharePayload(body)) return json(request, env, { error: 'invalid_payload', message: 'محتوى المشاركة غير صالح.' }, 400);
  const ttl = Math.max(3600, Math.min(7 * 24 * 60 * 60, Number(body.expiresInSeconds || 7 * 24 * 60 * 60)));
  const token = randomToken();
  const expiresAt = new Date(Date.now() + ttl * 1000).toISOString();
  const record = { kind: body.kind, payload: body.payload, workspace: auth.workspace, createdAt: new Date().toISOString(), expiresAt };
  const key = `share:${auth.workspace}:${token}`;
  await env.MOBDEA_DATA.put(key, await encryptJson(record, env, `share:${auth.workspace}:${token}`), { expirationTtl: ttl });
  return json(request, env, { ok: true, token, expiresAt }, 201);
}

async function handleReadShare(request, env, token, workspace) {
  if (!(await rateLimit(request, env, 'public', false))) return json(request, env, { error: 'rate_limited' }, 429, { 'Retry-After': '60' });
  if (!/^[a-zA-Z0-9_-]{20,80}$/.test(token) || !workspace) return json(request, env, { error: 'not_found' }, 404);
  const key = `share:${workspace}:${token}`;
  const encrypted = await env.MOBDEA_DATA.get(key);
  if (!encrypted) return json(request, env, { error: 'not_found' }, 404);
  const record = await decryptJson(encrypted, env, `share:${workspace}:${token}`);
  if (!record || Date.parse(record.expiresAt) <= Date.now()) return json(request, env, { error: 'not_found' }, 404);
  return json(request, env, { kind: record.kind, payload: record.payload, expiresAt: record.expiresAt });
}


/* MOBDEA_LIVE_GAME_ROUTES_V1 */
const MAX_ROOM_EVENT_BYTES = 180_000;
const MAX_ROOM_EVENTS = 600;
const MAX_ROOM_PARTICIPANTS = 80;

function cleanText(value, maxLength = 300) {
  return String(value ?? '')
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLength);
}

function roomTtl(value) {
  return Math.max(3600, Math.min(12 * 60 * 60, Number(value || 6 * 60 * 60)));
}

function joinCode() {
  return String(crypto.getRandomValues(new Uint32Array(1))[0] % 1_000_000).padStart(6, '0');
}

function roomKey(kind, workspace, roomId) {
  return `${kind}:${workspace}:${roomId}`;
}

function roomAad(kind, workspace, roomId) {
  return `${kind}:${workspace}:${roomId}`;
}

async function readRoom(env, kind, workspace, roomId) {
  if (!workspace || !/^[a-zA-Z0-9_-]{8,120}$/.test(roomId)) return null;
  const encrypted = await env.MOBDEA_DATA.get(roomKey(kind, workspace, roomId));
  if (!encrypted) return null;
  const room = await decryptJson(encrypted, env, roomAad(kind, workspace, roomId));
  if (!room || Date.parse(room.expiresAt || 0) <= Date.now()) return null;
  return room;
}

async function writeRoom(env, kind, room) {
  const ttl = Math.max(60, Math.ceil((Date.parse(room.expiresAt) - Date.now()) / 1000));
  await env.MOBDEA_DATA.put(
    roomKey(kind, room.workspace, room.roomId),
    await encryptJson(room, env, roomAad(kind, room.workspace, room.roomId)),
    { expirationTtl: ttl },
  );
}

function publicParticipant(participant = {}) {
  return {
    id: participant.id,
    participantId: participant.id,
    name: participant.name || participant.displayName || 'طالب',
    displayName: participant.displayName || participant.name || 'طالب',
    studentCode: participant.studentCode || participant.studentId || '',
    studentId: participant.studentId || participant.studentCode || '',
    team: participant.team || '',
    status: participant.removed ? 'removed' : participant.status || 'online',
    online: participant.removed !== true && Date.now() - Number(participant.lastSeen || 0) < 45_000,
    micState: participant.micState || 'muted',
    muted: participant.muted !== false,
    joinedAt: participant.joinedAt,
    score: Number(participant.score || 0),
  };
}

async function roomActor(request, room, tokenHeader) {
  const token = cleanText(request.headers.get(tokenHeader), 260);
  if (!token) return null;
  if (await tokenEquals(token, room.teacherToken)) return { role: 'teacher', id: 'teacher' };
  for (const participant of room.participants || []) {
    if (participant.token && await tokenEquals(token, participant.token)) {
      return { role: 'participant', id: participant.id, participant };
    }
  }
  return null;
}

function appendRoomEvent(room, actor, body = {}) {
  room.cursor = Number(room.cursor || 0) + 1;
  const event = {
    id: room.cursor,
    type: cleanText(body.type, 60),
    sourceId: actor?.id || 'system',
    targetId: cleanText(body.targetId || 'all', 100) || 'all',
    data: body.data && typeof body.data === 'object' && !Array.isArray(body.data) ? body.data : {},
    createdAt: new Date().toISOString(),
  };
  room.events = [...(room.events || []), event].slice(-MAX_ROOM_EVENTS);
  return event;
}

function eventsForActor(room, actor, after) {
  const cursor = Math.max(0, Number(after || 0));
  return (room.events || []).filter((event) => {
    if (Number(event.id || 0) <= cursor) return false;
    if (actor.role === 'teacher') return true;
    return !event.targetId || event.targetId === 'all' || event.targetId === actor.id;
  });
}

async function createLiveRoomRoute(request, env, auth) {
  if (!(await rateLimit(request, env, auth.workspace, true, 30, 'live-create'))) return json(request, env, { error: 'rate_limited' }, 429);
  const body = await parseJsonBody(request, 100_000);
  const ttl = roomTtl(body.ttlSeconds);
  const roomId = crypto.randomUUID();
  const createdAt = new Date().toISOString();
  const room = {
    kind: 'live', workspace: auth.workspace, roomId, joinCode: joinCode(), teacherToken: randomToken(),
    status: 'open', cursor: 0, events: [], participants: [], createdAt,
    expiresAt: new Date(Date.now() + ttl * 1000).toISOString(),
    metadata: {
      title: cleanText(body.title || 'حصة مباشرة', 140),
      grade: cleanText(body.grade, 80), lesson: cleanText(body.lesson, 140),
      sessionId: body.sessionId ?? null, lessonId: body.lessonId ?? null,
    },
  };
  await writeRoom(env, 'live', room);
  return json(request, env, { roomId, joinCode: room.joinCode, teacherToken: room.teacherToken, status: room.status, expiresAt: room.expiresAt }, 201);
}

async function joinLiveRoomRoute(request, env, workspace, roomId) {
  if (!(await rateLimit(request, env, workspace, true, 90, 'live-join'))) return json(request, env, { error: 'rate_limited' }, 429);
  const room = await readRoom(env, 'live', workspace, roomId);
  if (!room || room.status !== 'open') return json(request, env, { error: 'not_found', message: 'الحصة غير متاحة.' }, 404);
  const body = await parseJsonBody(request, 30_000);
  if (!(await tokenEquals(cleanText(body.joinCode, 20), room.joinCode))) return json(request, env, { error: 'invalid_join_code', message: 'كود الدخول غير صحيح.' }, 403);
  if ((room.participants || []).filter((item) => !item.removed).length >= MAX_ROOM_PARTICIPANTS) return json(request, env, { error: 'room_full', message: 'اكتمل عدد الطلاب في الحصة.' }, 409);
  const participant = {
    id: crypto.randomUUID(), token: randomToken(), name: cleanText(body.name || 'طالب', 100),
    studentCode: cleanText(body.studentCode, 40), micState: 'muted', muted: true,
    status: 'online', removed: false, joinedAt: new Date().toISOString(), lastSeen: Date.now(),
  };
  room.participants.push(participant);
  appendRoomEvent(room, { id: participant.id }, { type: 'participant-joined', targetId: 'teacher', data: publicParticipant(participant) });
  await writeRoom(env, 'live', room);
  return json(request, env, {
    roomId, participantId: participant.id, participantToken: participant.token,
    participant: publicParticipant(participant), room: room.metadata, roomStatus: room.status, expiresAt: room.expiresAt,
  }, 201);
}

async function liveEventsRoute(request, env, workspace, roomId) {
  const room = await readRoom(env, 'live', workspace, roomId);
  if (!room) return json(request, env, { error: 'not_found' }, 404);
  const actor = await roomActor(request, room, 'X-Mobdea-Live-Token');
  if (!actor || (actor.role === 'participant' && actor.participant.removed)) return json(request, env, { error: 'unauthorized' }, 401);
  if (actor.participant) actor.participant.lastSeen = Date.now();
  if (request.method === 'GET') {
    const after = new URL(request.url).searchParams.get('after');
    await writeRoom(env, 'live', room);
    return json(request, env, { events: eventsForActor(room, actor, after), cursor: room.cursor || 0, roomStatus: room.status });
  }
  const body = await parseJsonBody(request, MAX_ROOM_EVENT_BYTES);
  const type = cleanText(body.type, 60);
  if (!type) return json(request, env, { error: 'invalid_event' }, 400);
  if (actor.role === 'participant' && ['room-closed', 'participant-updated', 'participant-removed'].includes(type)) return json(request, env, { error: 'forbidden' }, 403);
  if (actor.role === 'participant') {
    if (type === 'heartbeat') {
      await writeRoom(env, 'live', room);
      return json(request, env, { ok: true, heartbeat: true, cursor: room.cursor || 0 });
    }
    if (type === 'mic-request') actor.participant.micState = 'requested';
    if (type === 'mic-started') { actor.participant.micState = 'speaking'; actor.participant.muted = false; }
    if (type === 'mic-stopped') { actor.participant.micState = 'muted'; actor.participant.muted = true; }
    body.data = { ...body.data, name: actor.participant.name, studentCode: actor.participant.studentCode };
  }
  const event = appendRoomEvent(room, actor, body);
  await writeRoom(env, 'live', room);
  return json(request, env, { ok: true, event, cursor: room.cursor }, 201);
}

async function liveParticipantsRoute(request, env, workspace, roomId, participantId = '') {
  const room = await readRoom(env, 'live', workspace, roomId);
  if (!room) return json(request, env, { error: 'not_found' }, 404);
  const actor = await roomActor(request, room, 'X-Mobdea-Live-Token');
  if (!actor || actor.role !== 'teacher') return json(request, env, { error: 'unauthorized' }, 401);
  if (request.method === 'GET') return json(request, env, { participants: room.participants.filter((item) => !item.removed).map(publicParticipant), roomStatus: room.status });
  const participant = room.participants.find((item) => item.id === participantId);
  if (!participant) return json(request, env, { error: 'not_found' }, 404);
  const patch = await parseJsonBody(request, 20_000);
  if (['muted', 'requested', 'approved', 'speaking'].includes(cleanText(patch.micState, 30))) participant.micState = cleanText(patch.micState, 30);
  if (typeof patch.muted === 'boolean') participant.muted = patch.muted;
  if (patch.removed === true) { participant.removed = true; participant.status = 'removed'; participant.muted = true; participant.micState = 'muted'; }
  const data = { participant: publicParticipant(participant), removed: participant.removed };
  appendRoomEvent(room, actor, { type: 'participant-updated', targetId: participant.id, data });
  if (participant.removed) appendRoomEvent(room, actor, { type: 'participant-removed', targetId: participant.id, data });
  await writeRoom(env, 'live', room);
  return json(request, env, data);
}

async function closeLiveRoomRoute(request, env, workspace, roomId) {
  const room = await readRoom(env, 'live', workspace, roomId);
  if (!room) return json(request, env, { error: 'not_found' }, 404);
  const actor = await roomActor(request, room, 'X-Mobdea-Live-Token');
  if (!actor || actor.role !== 'teacher') return json(request, env, { error: 'unauthorized' }, 401);
  room.status = 'closed';
  appendRoomEvent(room, actor, { type: 'room-closed', targetId: 'all', data: {} });
  await writeRoom(env, 'live', room);
  return json(request, env, { ok: true, roomId, status: room.status });
}

async function createGameRoomRoute(request, env, auth) {
  if (!(await rateLimit(request, env, auth.workspace, true, 30, 'game-create'))) return json(request, env, { error: 'rate_limited' }, 429);
  const body = await parseJsonBody(request, 160_000);
  const ttl = roomTtl(body.ttlSeconds);
  const roomId = crypto.randomUUID();
  let code = joinCode();
  for (let attempt = 0; attempt < 4; attempt += 1) {
    if (!(await env.MOBDEA_DATA.get(`game-code:${auth.workspace}:${code}`))) break;
    code = joinCode();
  }
  const room = {
    kind: 'game', workspace: auth.workspace, roomId, joinCode: code, teacherToken: randomToken(),
    status: 'waiting', cursor: 0, events: [], participants: [], answers: [], createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + ttl * 1000).toISOString(), maxParticipants: Math.max(2, Math.min(MAX_ROOM_PARTICIPANTS, Number(body.maxParticipants || 40))),
    metadata: { title: cleanText(body.title || 'تحدي مباشر', 140), teacherName: cleanText(body.teacherName || 'المعلم', 80), mode: cleanText(body.mode || 'individual', 30), teamMode: Boolean(body.teamMode), teams: Array.isArray(body.teams) ? body.teams.slice(0, 20) : [] },
    state: body.state && typeof body.state === 'object' ? body.state : {},
  };
  await writeRoom(env, 'game', room);
  await env.MOBDEA_DATA.put(`game-code:${auth.workspace}:${code}`, roomId, { expirationTtl: ttl });
  return json(request, env, { roomId, joinCode: code, teacherToken: room.teacherToken, status: room.status, expiresAt: room.expiresAt }, 201);
}

async function joinGameRoomRoute(request, env, workspace) {
  if (!(await rateLimit(request, env, workspace, true, 120, 'game-join'))) return json(request, env, { error: 'rate_limited' }, 429);
  const body = await parseJsonBody(request, 30_000);
  const code = cleanText(body.joinCode, 12);
  const roomId = await env.MOBDEA_DATA.get(`game-code:${workspace}:${code}`);
  const room = roomId ? await readRoom(env, 'game', workspace, roomId) : null;
  if (!room || room.status === 'closed') return json(request, env, { error: 'not_found', message: 'غرفة اللعب غير متاحة.' }, 404);
  if (room.participants.filter((item) => !item.removed).length >= room.maxParticipants) return json(request, env, { error: 'room_full', message: 'اكتمل عدد المشاركين.' }, 409);
  const participant = {
    id: crypto.randomUUID(), token: randomToken(), name: cleanText(body.displayName || 'طالب', 80),
    displayName: cleanText(body.displayName || 'طالب', 80), studentId: cleanText(body.studentId, 80),
    studentCode: cleanText(body.studentId, 80), team: cleanText(body.team, 40), score: 0,
    status: 'online', removed: false, joinedAt: new Date().toISOString(), lastSeen: Date.now(),
  };
  room.participants.push(participant);
  appendRoomEvent(room, { id: participant.id }, { type: 'participant-joined', targetId: 'teacher', data: publicParticipant(participant) });
  await writeRoom(env, 'game', room);
  return json(request, env, { roomId, participantId: participant.id, participantToken: participant.token, participant: publicParticipant(participant), state: room.state, roomStatus: room.status, expiresAt: room.expiresAt }, 201);
}

async function gameAuthorizedRoom(request, env, workspace, roomId) {
  const room = await readRoom(env, 'game', workspace, roomId);
  if (!room) return { error: json(request, env, { error: 'not_found' }, 404) };
  const actor = await roomActor(request, room, 'X-Mobdea-Game-Token');
  if (!actor || (actor.role === 'participant' && actor.participant.removed)) return { error: json(request, env, { error: 'unauthorized' }, 401) };
  if (actor.participant) actor.participant.lastSeen = Date.now();
  return { room, actor };
}

async function gameStateRoute(request, env, workspace, roomId) {
  const result = await gameAuthorizedRoom(request, env, workspace, roomId);
  if (result.error) return result.error;
  const { room, actor } = result;
  if (request.method === 'GET') {
    await writeRoom(env, 'game', room);
    return json(request, env, { state: room.state, status: room.status, roomStatus: room.status, cursor: room.cursor || 0 });
  }
  if (actor.role !== 'teacher') return json(request, env, { error: 'forbidden' }, 403);
  const patch = await parseJsonBody(request, 100_000);
  if (patch.status) room.status = cleanText(patch.status, 30);
  if (patch.state && typeof patch.state === 'object') room.state = { ...room.state, ...patch.state };
  for (const key of ['questionId', 'answerKey', 'pointsPerCorrect']) if (patch[key] !== undefined) room.state[key] = patch[key];
  appendRoomEvent(room, actor, { type: 'game-state', targetId: 'all', data: { status: room.status, state: room.state } });
  await writeRoom(env, 'game', room);
  return json(request, env, { ok: true, state: room.state, status: room.status });
}

async function gameParticipantsRoute(request, env, workspace, roomId) {
  const result = await gameAuthorizedRoom(request, env, workspace, roomId);
  if (result.error) return result.error;
  const { room, actor } = result;
  if (actor.role !== 'teacher') return json(request, env, { error: 'forbidden' }, 403);
  await writeRoom(env, 'game', room);
  return json(request, env, { participants: room.participants.filter((item) => !item.removed).map(publicParticipant), roomStatus: room.status });
}

async function gameEventsRoute(request, env, workspace, roomId) {
  const result = await gameAuthorizedRoom(request, env, workspace, roomId);
  if (result.error) return result.error;
  const { room, actor } = result;
  if (request.method === 'GET') {
    const after = new URL(request.url).searchParams.get('after');
    await writeRoom(env, 'game', room);
    return json(request, env, { events: eventsForActor(room, actor, after), cursor: room.cursor || 0, roomStatus: room.status });
  }
  const body = await parseJsonBody(request, MAX_ROOM_EVENT_BYTES);
  const type = cleanText(body.type, 60);
  if (!type) return json(request, env, { error: 'invalid_event' }, 400);
  if (actor.role === 'participant' && ['game-question', 'game-score', 'game-finished', 'room-closed'].includes(type)) return json(request, env, { error: 'forbidden' }, 403);
  if (actor.role === 'participant') {
    if (type === 'heartbeat') {
      await writeRoom(env, 'game', room);
      return json(request, env, { ok: true, heartbeat: true, cursor: room.cursor || 0 });
    }
    body.data = { ...body.data, name: actor.participant.name, studentCode: actor.participant.studentCode };
  }
  const event = appendRoomEvent(room, actor, body);
  await writeRoom(env, 'game', room);
  return json(request, env, { ok: true, event, cursor: room.cursor }, 201);
}

async function gameAnswerRoute(request, env, workspace, roomId) {
  const result = await gameAuthorizedRoom(request, env, workspace, roomId);
  if (result.error) return result.error;
  const { room, actor } = result;
  if (actor.role !== 'participant') return json(request, env, { error: 'forbidden' }, 403);
  const body = await parseJsonBody(request, 30_000);
  const answer = { participantId: actor.id, questionId: cleanText(body.questionId, 100), answer: body.answer, elapsedMs: Math.max(0, Number(body.elapsedMs || 0)), createdAt: new Date().toISOString() };
  room.answers = [...(room.answers || []), answer].slice(-1000);
  const event = appendRoomEvent(room, actor, { type: 'game-answer', targetId: 'teacher', data: answer });
  await writeRoom(env, 'game', room);
  return json(request, env, { ok: true, eventId: event.id }, 201);
}

async function closeGameRoomRoute(request, env, workspace, roomId) {
  const result = await gameAuthorizedRoom(request, env, workspace, roomId);
  if (result.error) return result.error;
  const { room, actor } = result;
  if (actor.role !== 'teacher') return json(request, env, { error: 'forbidden' }, 403);
  room.status = 'closed';
  appendRoomEvent(room, actor, { type: 'room-closed', targetId: 'all', data: {} });
  await writeRoom(env, 'game', room);
  await env.MOBDEA_DATA.delete?.(`game-code:${workspace}:${room.joinCode}`);
  return json(request, env, { ok: true, roomId, status: room.status });
}

async function routeLiveGame(request, env, url, auth = null) {
  const workspace = validWorkspace(request.headers.get('X-Mobdea-Workspace'));
  if (url.pathname === '/live/rooms' && request.method === 'POST') {
    if (!auth) return null;
    return createLiveRoomRoute(request, env, auth);
  }
  const liveJoin = /^\/live\/rooms\/([a-zA-Z0-9_-]{8,120})\/join$/.exec(url.pathname);
  if (liveJoin && request.method === 'POST' && workspace) return joinLiveRoomRoute(request, env, workspace, liveJoin[1]);
  const liveEvents = /^\/live\/rooms\/([a-zA-Z0-9_-]{8,120})\/events$/.exec(url.pathname);
  if (liveEvents && ['GET', 'POST'].includes(request.method) && workspace) return liveEventsRoute(request, env, workspace, liveEvents[1]);
  const liveParticipant = /^\/live\/rooms\/([a-zA-Z0-9_-]{8,120})\/participants\/([a-zA-Z0-9_-]{8,120})$/.exec(url.pathname);
  if (liveParticipant && request.method === 'PATCH' && workspace) return liveParticipantsRoute(request, env, workspace, liveParticipant[1], liveParticipant[2]);
  const liveParticipants = /^\/live\/rooms\/([a-zA-Z0-9_-]{8,120})\/participants$/.exec(url.pathname);
  if (liveParticipants && request.method === 'GET' && workspace) return liveParticipantsRoute(request, env, workspace, liveParticipants[1]);
  const liveClose = /^\/live\/rooms\/([a-zA-Z0-9_-]{8,120})$/.exec(url.pathname);
  if (liveClose && request.method === 'DELETE' && workspace) return closeLiveRoomRoute(request, env, workspace, liveClose[1]);

  if (url.pathname === '/game/rooms' && request.method === 'POST') {
    if (!auth) return null;
    return createGameRoomRoute(request, env, auth);
  }
  if (url.pathname === '/game/rooms/join' && request.method === 'POST' && workspace) return joinGameRoomRoute(request, env, workspace);
  const gameState = /^\/game\/rooms\/([a-zA-Z0-9_-]{8,120})\/state$/.exec(url.pathname);
  if (gameState && ['GET', 'PATCH'].includes(request.method) && workspace) return gameStateRoute(request, env, workspace, gameState[1]);
  const gameParticipants = /^\/game\/rooms\/([a-zA-Z0-9_-]{8,120})\/participants$/.exec(url.pathname);
  if (gameParticipants && request.method === 'GET' && workspace) return gameParticipantsRoute(request, env, workspace, gameParticipants[1]);
  const gameEvents = /^\/game\/rooms\/([a-zA-Z0-9_-]{8,120})\/events$/.exec(url.pathname);
  if (gameEvents && ['GET', 'POST'].includes(request.method) && workspace) return gameEventsRoute(request, env, workspace, gameEvents[1]);
  const gameAnswer = /^\/game\/rooms\/([a-zA-Z0-9_-]{8,120})\/answer$/.exec(url.pathname);
  if (gameAnswer && request.method === 'POST' && workspace) return gameAnswerRoute(request, env, workspace, gameAnswer[1]);
  const gameClose = /^\/game\/rooms\/([a-zA-Z0-9_-]{8,120})$/.exec(url.pathname);
  if (gameClose && request.method === 'DELETE' && workspace) return closeGameRoomRoute(request, env, workspace, gameClose[1]);
  return null;
}

export default {
  async fetch(request, env) {
    try {
      const origin = request.headers.get('Origin');
      if (request.method === 'OPTIONS') {
        if (origin && !allowedOrigins(env).includes(origin)) return json(request, env, { error: 'origin_not_allowed' }, 403);
        return new Response(null, { status: 204, headers: corsHeaders(request, env) });
      }
      const url = new URL(request.url);
      const shareMatch = /^\/share\/([a-zA-Z0-9_-]+)$/.exec(url.pathname);
      if (request.method === 'GET' && shareMatch) return handleReadShare(request, env, shareMatch[1], validWorkspace(url.searchParams.get('workspace')));

      const publicLiveGame = await routeLiveGame(request, env, url, null);
      if (publicLiveGame) return publicLiveGame;

      const auth = await authenticate(request, env);
      if (!auth) {
        const allowed = await rateLimit(request, env, 'auth', true);
        return allowed
          ? json(request, env, { error: 'unauthorized' }, 401)
          : json(request, env, { error: 'rate_limited' }, 429, { 'Retry-After': '60' });
      }
      const authenticatedLiveGame = await routeLiveGame(request, env, url, auth);
      if (authenticatedLiveGame) return authenticatedLiveGame;
      if (url.pathname === '/assets/status' && request.method === 'POST') return handleAssetStatus(request, env, auth);
      const assetMatch = /^\/assets\/([a-zA-Z0-9._-]+)$/.exec(url.pathname);
      if (assetMatch && ['GET', 'HEAD', 'PUT', 'DELETE'].includes(request.method)) return handleAsset(request, env, auth, assetMatch[1]);
      if (url.pathname === '/health' && request.method === 'GET') {
        if (!(await rateLimit(request, env, auth.workspace, false))) return json(request, env, { error: 'rate_limited' }, 429);
        return json(request, env, { ok: true, service: 'mobdea-sync', workspace: auth.workspace, time: new Date().toISOString(), version: 2 });
      }
      if (url.pathname === '/sync') return handleSync(request, env, auth);
      if (url.pathname === '/share' && request.method === 'POST') return handleCreateShare(request, env, auth);
      return json(request, env, { error: 'not_found' }, 404);
    } catch (error) {
      const status = Number(error?.status || 500);
      const message = status >= 500 ? 'internal_error' : error?.message || 'bad_request';
      return json(request, env, { error: message }, status);
    }
  },
};
