import { Copy, Download, ExternalLink, FileClock, PlayCircle } from 'lucide-react';
import { useAssetUrl } from '../../hooks/useAssetUrl';
import { copyToClipboard } from '../../services/share';
import { formatDateAr } from '../../utils/time';

export default function LessonRecordingItem({ recording = {}, onNotice }) {
  const mediaUrl = useAssetUrl(recording.videoAssetId || recording.assetId || recording.boardAssetId, recording.videoUrl || recording.url || recording.boardImage || '');
  const shareUrl = recording.shareUrl || recording.recordingShareUrl || '';
  const title = recording.sessionTitle || recording.title || 'حصة محفوظة';
  const copy = async () => {
    if (!shareUrl) { onNotice?.('لا يوجد رابط مشاركة لهذا التسجيل.'); return; }
    const ok = await copyToClipboard(shareUrl);
    onNotice?.(ok ? 'تم نسخ رابط التسجيل.' : 'تعذر نسخ الرابط.');
  };
  const download = () => {
    if (!mediaUrl) { onNotice?.('ملف الفيديو غير متاح على هذا الجهاز.'); return; }
    const anchor = document.createElement('a');
    anchor.href = mediaUrl;
    anchor.download = recording.fileName || recording.name || `${title}.webm`;
    anchor.click();
  };
  return (
    <article className="lesson-recording-item">
      <div className="lesson-recording-copy"><FileClock size={19} /><div><strong>{title}</strong><small>{formatDateAr(recording.createdAt || recording.updatedAt)} • {recording.grade || 'الصف'}{recording.durationSeconds ? ` • ${Math.ceil(Number(recording.durationSeconds) / 60)} د` : ''}</small></div></div>
      {mediaUrl ? <video className="lesson-recording-player" src={mediaUrl} controls preload="metadata" /> : <div className="lesson-recording-fallback"><PlayCircle size={22} /><span>سجل زمني محفوظ دون فيديو</span></div>}
      <div className="lesson-recording-actions">
        <button className="secondary-btn" type="button" onClick={download} disabled={!mediaUrl}><Download size={15} /> تنزيل</button>
        <button className="secondary-btn" type="button" onClick={copy} disabled={!shareUrl}><Copy size={15} /> نسخ الرابط</button>
        {shareUrl && <button className="secondary-btn" type="button" onClick={() => globalThis.open?.(shareUrl, '_blank', 'noopener,noreferrer')}><ExternalLink size={15} /> فتح</button>}
      </div>
    </article>
  );
}
