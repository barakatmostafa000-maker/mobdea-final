import { File, FileImage, FileText, Headphones, Images, Presentation, Video } from 'lucide-react';

const icons = { pdf: FileText, textbook: FileText, image: FileImage, video: Video, audio: Headphones, slides: Presentation, file: File, document: File, link: File };
const labels = { pdf: 'PDF', images: 'الصور', videos: 'الفيديوهات', audio: 'الصوت', slides: 'العروض', files: 'الملفات', board: 'السبورة', maps: 'الخرائط' };

export default function MediaNavigator({ resources = [], selectedId = '', contentMode = '', onSelect }) {
  const list = Array.isArray(resources) ? resources : [];
  if (!list.length) return null;
  return (
    <div className="classmode-media-navigator" aria-label="التنقل بين محتويات الدرس">
      <div className="classmode-media-navigator-center">
        <span><Images size={16} /> {labels[contentMode] || 'محتوى الدرس'}</span>
        <select value={selectedId || list[0]?.id || ''} onChange={(event) => onSelect?.(event.target.value)}>
          {list.map((resource, index) => (
            <option key={resource.id || index} value={resource.id || ''}>{index + 1}. {resource.title || resource.fileName || 'مورد الدرس'}</option>
          ))}
        </select>
      </div>
      <div className="classmode-media-strip">
        {list.map((resource, index) => {
          const Icon = icons[resource.type] || File;
          return <button key={resource.id || index} type="button" className={String(resource.id) === String(selectedId) ? 'active' : ''} onClick={() => onSelect?.(resource.id)} title={resource.title || resource.fileName}><Icon size={16} /><span>{resource.title || resource.fileName || `مورد ${index + 1}`}</span></button>;
        })}
      </div>
    </div>
  );
}
