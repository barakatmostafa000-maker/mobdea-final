import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  Hand,
  LoaderCircle,
  LogIn,
  MessageCircle,
  Mic,
  MicOff,
  Radio,
  Send,
  ThumbsUp,
  Video,
} from 'lucide-react';
import { identity } from '../../config/identity';
import {
  createLivePoller,
  defaultIceServers,
  fetchLiveEvents,
  joinLiveRoom,
  liveClassSupported,
  postLiveEvent,
} from '../../services/liveClass';

function errorText(error) {
  return error?.message || 'تعذر الاتصال بالحصة الأونلاين.';
}

export default function StudentLiveClassRoom({ payload, onGoHome }) {
  const [name, setName] = useState('');
  const [studentCode, setStudentCode] = useState('');
  const [session, setSession] = useState(null);
  const [joining, setJoining] = useState(false);
  const [notice, setNotice] = useState('');
  const [roomClosed, setRoomClosed] = useState(false);
  const [snapshot, setSnapshot] = useState('');
  const [classState, setClassState] = useState({});
  const [micState, setMicState] = useState('muted');
  const [micActive, setMicActive] = useState(false);
  const [chat, setChat] = useState('');
  const videoRef = useRef(null);
  const audioRef = useRef(null);
  const peerRef = useRef(null);
  const micStreamRef = useRef(null);
  const cursorRef = useRef(0);
  const pendingIceRef = useRef([]);
  const processedRef = useRef(new Set());
  const sessionRef = useRef(null);

  useEffect(() => { sessionRef.current = session; }, [session]);

  const send = useCallback(async (event) => {
    const active = sessionRef.current;
    if (!active) return null;
    return postLiveEvent(active, active.roomId, active.participantToken, event);
  }, []);

  const closePeer = useCallback(() => {
    const peer = peerRef.current;
    if (peer) {
      peer.ontrack = null;
      peer.onicecandidate = null;
      peer.close();
    }
    peerRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    if (audioRef.current) audioRef.current.srcObject = null;
  }, []);

  const ensurePeer = useCallback(() => {
    if (peerRef.current && peerRef.current.connectionState !== 'closed') return peerRef.current;
    const peer = new RTCPeerConnection({ iceServers: defaultIceServers() });
    peer.onicecandidate = (event) => {
      if (!event.candidate) return;
      void send({
        type: 'webrtc-ice',
        targetId: 'teacher',
        data: { candidate: event.candidate.toJSON?.() || event.candidate },
      });
    };
    peer.ontrack = (event) => {
      const stream = event.streams?.[0] || new MediaStream([event.track]);
      if (event.track.kind === 'video' && videoRef.current) {
        videoRef.current.srcObject = stream;
        void videoRef.current.play().catch(() => setNotice('اضغط على شاشة البث لتشغيل الفيديو.'));
      } else if (audioRef.current) {
        audioRef.current.srcObject = stream;
        void audioRef.current.play().catch(() => setNotice('اضغط داخل الصفحة مرة واحدة لتشغيل صوت المعلم.'));
      }
    };
    peer.onconnectionstatechange = () => {
      if (peer.connectionState === 'failed') setNotice('انقطع البث مؤقتًا. يتم انتظار إعادة الاتصال.');
    };
    peerRef.current = peer;
    return peer;
  }, [send]);

  const flushIce = useCallback(async (peer) => {
    const pending = pendingIceRef.current.splice(0);
    for (const candidate of pending) await peer.addIceCandidate(candidate).catch(() => null);
  }, []);

  const stopMic = useCallback(async ({ notify = true } = {}) => {
    micStreamRef.current?.getTracks().forEach((track) => track.stop());
    micStreamRef.current = null;
    setMicActive(false);
    if (notify && sessionRef.current) {
      await send({ type: 'mic-stopped', targetId: 'teacher', data: { name } }).catch(() => null);
    }
  }, [name, send]);

  const startMic = useCallback(async () => {
    if (!liveClassSupported()) {
      setNotice('الميكروفون المباشر يحتاج متصفحًا حديثًا واتصال HTTPS.');
      return;
    }
    if (!['approved', 'speaking'].includes(micState)) {
      await send({ type: 'mic-request', targetId: 'teacher', data: { name, studentCode } });
      setMicState('requested');
      setNotice('تم إرسال طلب فتح الميكروفون إلى المعلم.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      micStreamRef.current?.getTracks().forEach((track) => track.stop());
      micStreamRef.current = stream;
      const peer = ensurePeer();
      const existing = peer.getSenders().find((sender) => sender.track?.kind === 'audio');
      const track = stream.getAudioTracks()[0];
      if (existing) await existing.replaceTrack(track);
      else peer.addTrack(track, stream);
      const offer = await peer.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: true });
      await peer.setLocalDescription(offer);
      await send({ type: 'webrtc-offer', targetId: 'teacher', data: { description: peer.localDescription } });
      await send({ type: 'mic-started', targetId: 'teacher', data: { name, studentCode } });
      setMicActive(true);
      setMicState('speaking');
      setNotice('الميكروفون يعمل الآن.');
    } catch (error) {
      setNotice(errorText(error));
      await stopMic({ notify: false });
    }
  }, [ensurePeer, micState, name, send, stopMic, studentCode]);

  useEffect(() => {
    if (!session) return undefined;
    const poller = createLivePoller({
      intervalMs: 800,
      poll: () => fetchLiveEvents(session, session.roomId, session.participantToken, cursorRef.current),
      onData: async (result) => {
        cursorRef.current = Math.max(cursorRef.current, Number(result.cursor || 0));
        if (result.roomStatus === 'closed') setRoomClosed(true);
        for (const event of result.events || []) {
          if (!event?.id || processedRef.current.has(event.id)) continue;
          processedRef.current.add(event.id);
          if (event.type === 'class-state') {
            setClassState(event.data || {});
            if (event.data?.snapshot) setSnapshot(event.data.snapshot);
          }
          if (event.type === 'screen-started') setNotice('بدأ المعلم مشاركة الشاشة.');
          if (event.type === 'screen-stopped') setNotice('توقفت مشاركة الشاشة، وما زالت الحصة مفتوحة.');
          if (event.type === 'participant-updated') {
            const next = event.data?.participant || event.data || {};
            if (next.removed) {
              setRoomClosed(true);
              setNotice('تم إخراجك من الحصة.');
            }
            if (next.micState) {
              setMicState(next.micState);
              if (next.micState === 'approved') setNotice('وافق المعلم. اضغط تشغيل الميكروفون للبدء.');
              if (next.muted || next.micState === 'muted') await stopMic({ notify: false });
            }
          }
          if (event.type === 'participant-removed' || event.type === 'room-closed') {
            setRoomClosed(true);
            setNotice('تم إنهاء الحصة أو إخراجك منها.');
          }
          if (event.type === 'webrtc-offer' && event.data?.description) {
            const peer = ensurePeer();
            await peer.setRemoteDescription(event.data.description);
            await flushIce(peer);
            const answer = await peer.createAnswer();
            await peer.setLocalDescription(answer);
            await send({ type: 'webrtc-answer', targetId: 'teacher', data: { description: peer.localDescription } });
          }
          if (event.type === 'webrtc-answer' && event.data?.description) {
            const peer = ensurePeer();
            await peer.setRemoteDescription(event.data.description).catch(() => null);
            await flushIce(peer);
          }
          if (event.type === 'webrtc-ice' && event.data?.candidate) {
            const peer = ensurePeer();
            if (peer.remoteDescription) await peer.addIceCandidate(event.data.candidate).catch(() => null);
            else pendingIceRef.current.push(event.data.candidate);
          }
        }
      },
      onError: (error) => setNotice(errorText(error)),
    });
    const heartbeat = setInterval(() => {
      void send({ type: 'heartbeat', targetId: 'teacher', data: {} });
    }, 15_000);
    return () => {
      poller();
      clearInterval(heartbeat);
    };
  }, [ensurePeer, flushIce, send, session, stopMic]);

  useEffect(() => () => {
    void stopMic({ notify: false });
    closePeer();
  }, [closePeer, stopMic]);

  const join = async (event) => {
    event.preventDefault();
    if (!name.trim()) return setNotice('اكتب اسم الطالب أولًا.');
    setJoining(true);
    setNotice('');
    try {
      const joined = await joinLiveRoom(
        { endpoint: payload.endpoint, workspaceId: payload.workspaceId },
        payload.roomId,
        payload.joinCode,
        { name, studentCode },
      );
      const next = { ...joined, roomId: payload.roomId };
      setSession(next);
      sessionRef.current = next;
      cursorRef.current = 0;
      processedRef.current.clear();
      await postLiveEvent(next, next.roomId, next.participantToken, {
        type: 'student-ready',
        targetId: 'teacher',
        data: { name: name.trim(), studentCode: studentCode.trim() },
      });
      setNotice('تم الدخول إلى الحصة. انتظر بدء البث.');
    } catch (error) {
      setNotice(errorText(error));
    } finally {
      setJoining(false);
    }
  };

  const sendSimpleEvent = async (type, data = {}) => {
    try {
      await send({ type, targetId: 'teacher', data: { name, studentCode, ...data } });
    } catch (error) {
      setNotice(errorText(error));
    }
  };

  const sendChat = async (event) => {
    event.preventDefault();
    const message = chat.trim();
    if (!message) return;
    await sendSimpleEvent('chat', { message });
    setChat('');
  };

  if (!payload?.roomId || !payload?.joinCode || !payload?.endpoint || !payload?.workspaceId) {
    return <section className="page student-live-room"><article className="panel live-student-error"><AlertTriangle size={32} /><h2>رابط الحصة غير مكتمل</h2><p>اطلب من المعلم إرسال رابط جديد.</p><button className="primary-btn" type="button" onClick={onGoHome}>العودة</button></article></section>;
  }

  if (!session) {
    return (
      <section className="page student-live-room">
        <div className="live-student-join-shell">
          <article className="panel live-student-brand"><img src={identity.icon} alt={identity.schoolName} /><span className="eyebrow">الحصة الأونلاين</span><h2>{payload.title || 'حصة مباشرة'}</h2><p>{payload.grade || ''} {payload.lesson ? `• ${payload.lesson}` : ''}</p><strong>كود الدخول: {payload.joinCode}</strong></article>
          <form className="panel live-student-join-form" onSubmit={join}>
            <label>اسم الطالب<input value={name} maxLength={100} onChange={(event) => setName(event.target.value)} autoComplete="name" /></label>
            <label>كود الطالب — اختياري<input value={studentCode} maxLength={40} onChange={(event) => setStudentCode(event.target.value)} /></label>
            <button className="primary-btn" type="submit" disabled={joining}>{joining ? <LoaderCircle className="spin" size={18} /> : <LogIn size={18} />} دخول الحصة</button>
            {notice && <div className="settings-notice">{notice}</div>}
          </form>
        </div>
      </section>
    );
  }

  return (
    <section className="page student-live-room">
      <header className="panel student-live-header"><div><span className="eyebrow"><Radio size={14} /> مباشر</span><h2>{payload.title || 'الحصة المباشرة'}</h2><p>{name}{studentCode ? ` — ${studentCode}` : ''}</p></div><button className="secondary-btn" type="button" onClick={onGoHome}>الخروج</button></header>
      <div className="student-live-grid">
        <article className="panel student-live-stage" onClick={() => { void videoRef.current?.play?.(); void audioRef.current?.play?.(); }}>
          <video ref={videoRef} autoPlay playsInline controls={false} />
          <audio ref={audioRef} autoPlay playsInline />
          {!videoRef.current?.srcObject && snapshot && <img src={snapshot} alt="شرح المعلم" />}
          {!snapshot && <div className="student-live-waiting"><Video size={44} /><h3>في انتظار بث المعلم</h3><p>{classState?.resourceTitle || classState?.contentMode || 'ستظهر شاشة الشرح هنا تلقائيًا.'}</p></div>}
        </article>
        <aside className="panel student-live-controls">
          <button className="primary-btn" type="button" onClick={() => void startMic()}>{micActive ? <Mic size={17} /> : micState === 'requested' ? <LoaderCircle className="spin" size={17} /> : <Mic size={17} />}{micActive ? 'الميكروفون يعمل' : micState === 'approved' ? 'تشغيل الميكروفون' : 'طلب فتح الميكروفون'}</button>
          {micActive && <button className="danger-btn" type="button" onClick={() => void stopMic()}><MicOff size={17} /> إيقاف الميكروفون</button>}
          <button className="secondary-btn" type="button" onClick={() => void sendSimpleEvent('hand-raised')}><Hand size={17} /> رفع اليد</button>
          <button className="secondary-btn" type="button" onClick={() => void sendSimpleEvent('reaction', { reaction: '👍' })}><ThumbsUp size={17} /> تفاعل</button>
          <form className="student-live-chat" onSubmit={sendChat}><input value={chat} maxLength={300} placeholder="اكتب رسالة للمعلم" onChange={(event) => setChat(event.target.value)} /><button className="icon-action" type="submit" title="إرسال"><Send size={16} /></button></form>
          <div className="student-live-state"><MessageCircle size={15} /><span>{notice || 'متصل بالحصة.'}</span></div>
          {roomClosed && <div className="settings-notice warning">انتهت الحصة. يمكنك العودة للمنصة.</div>}
        </aside>
      </div>
    </section>
  );
}
