export const APP_VERSION = '9.4.0';
export const APP_VERSION_CODE = 94;
export const DATA_SCHEMA_VERSION = 10;
export const RELEASE_CHANNEL = 'stable';
export const RELEASE_TAG = 'R2';
