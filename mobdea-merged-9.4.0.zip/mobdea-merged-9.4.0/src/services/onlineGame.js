const clean = (value, max = 300) => String(value ?? '')
  .replace(/[\u0000-\u001f\u007f]/g, ' ')
  .replace(/\s+/g, ' ')
  .trim()
  .slice(0, max);

function choiceList(question = {}) {
  const raw = question.choices || question.options || question.answers || [];
  return Array.isArray(raw)
    ? raw
      .map((item) => clean(typeof item === 'object' ? item.text ?? item.label ?? item.value : item, 180))
      .filter(Boolean)
      .slice(0, 6)
    : [];
}

function correctChoiceIndex(question = {}, choices = choiceList(question)) {
  const explicit = Number(
    question.correctIndex
      ?? question.answerIndex
      ?? question.correctChoiceIndex,
  );
  if (Number.isInteger(explicit) && explicit >= 0 && explicit < choices.length) return explicit;
  const answer = clean(
    question.correctAnswer ?? question.answer ?? question.solution,
    180,
  ).toLocaleLowerCase('ar-EG');
  if (answer) {
    const index = choices.findIndex(
      (choice) => clean(choice, 180).toLocaleLowerCase('ar-EG') === answer,
    );
    if (index >= 0) return index;
  }
  return 0;
}

export function normalizeOnlineQuestions(questions = [], limit = 10) {
  return (Array.isArray(questions) ? questions : [])
    .map((question, index) => {
      const options = choiceList(question);
      const text = clean(question?.text || question?.question, 500);
      if (!text || options.length < 2) return null;
      const answerIndex = correctChoiceIndex(question, options);
      return {
        id: clean(question.id || `online-${index + 1}`, 100),
        text,
        options,
        choices: options,
        answerIndex,
        correctIndex: answerIndex,
        answer: options[answerIndex] || '',
        explanation: clean(question.explanation || question.notes || '', 500),
        points: Math.max(10, Math.min(1000, Number(question.points || 100))),
      };
    })
    .filter(Boolean)
    .slice(0, Math.max(1, Number(limit || 10)));
}

export function publicOnlineQuestion(question = {}, indexOrSeconds = 0, total = 1, seconds = 25) {
  // Backward compatible with the older two-argument form: (question, seconds).
  const fourArgumentCall = arguments.length >= 3;
  const index = fourArgumentCall ? Number(indexOrSeconds || 0) : 0;
  const durationSec = fourArgumentCall ? Number(seconds || 25) : Number(indexOrSeconds || 25);
  const options = choiceList(question);
  return {
    id: clean(question.id, 100),
    text: clean(question.text || question.question, 500),
    options,
    choices: options,
    explanation: clean(question.explanation || '', 500),
    index,
    total: Math.max(1, Number(total || 1)),
    durationSec: Math.max(5, Math.min(180, durationSec)),
    seconds: Math.max(5, Math.min(180, durationSec)),
  };
}

export function scoreOnlineAnswer(question = {}, choiceIndex, elapsedMs = 0, seconds = 25) {
  const answerIndex = correctChoiceIndex(question, choiceList(question));
  const correct = Number(choiceIndex) === answerIndex;
  const maxMs = Math.max(1000, Number(seconds || 25) * 1000);
  const speedRatio = Math.max(0, Math.min(1, 1 - Number(elapsedMs || 0) / maxMs));
  const base = Math.max(10, Number(question.points || 100));
  const points = correct ? Math.round(base + base * 0.5 * speedRatio) : 0;
  const options = choiceList(question);
  return {
    correct,
    points,
    correctIndex: answerIndex,
    answerIndex,
    correctAnswer: options[answerIndex] || '',
    explanation: question.explanation || '',
  };
}

export function sortedOnlineScoreboard(participants = [], scores = {}) {
  const byId = scores && typeof scores === 'object' ? scores : {};
  return (Array.isArray(participants) ? participants : [])
    .filter((participant) => participant?.status !== 'removed')
    .map((participant) => {
      const id = participant.id || participant.participantId;
      return {
        id,
        name: participant.name || participant.displayName || 'طالب',
        studentCode: participant.studentCode || participant.studentId || '',
        score: Number(byId[id] || participant.score || 0),
      };
    })
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name, 'ar'));
}
