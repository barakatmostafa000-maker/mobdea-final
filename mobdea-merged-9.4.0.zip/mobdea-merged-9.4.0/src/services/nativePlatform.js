import { Capacitor } from '@capacitor/core';
import { Share } from '@capacitor/share';

export async function openResourceDocument(resource = {}, resolvedUrl = '') {
  const url = String(resolvedUrl || resource.url || '').trim();
  if (!url) throw new Error('ملف المورد غير متاح على هذا الجهاز.');
  const title = resource.title || resource.fileName || 'ملف الدرس';
  if (Capacitor.isNativePlatform() && /^https?:|^file:|^content:/i.test(url)) {
    try {
      await Share.share({ title, text: title, url, dialogTitle: `فتح ${title}` });
      return true;
    } catch {
      // Continue to the browser fallback.
    }
  }
  const opened = globalThis.open?.(url, '_blank', 'noopener,noreferrer');
  if (opened) return true;
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.target = '_blank';
  anchor.rel = 'noopener noreferrer';
  anchor.download = resource.fileName || '';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  return true;
}
