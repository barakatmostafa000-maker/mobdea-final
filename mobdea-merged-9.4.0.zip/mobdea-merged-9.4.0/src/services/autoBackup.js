import { cloudConfigured } from './cloudSync';

const DEFAULT_INTERVAL_HOURS = 24;
const MIN_INTERVAL_HOURS = 1;
const MAX_INTERVAL_HOURS = 24 * 30;

export function shouldRunAutoBackup(settings = {}, now = Date.now()) {
  const cloud = settings?.cloudSync || {};
  if (cloud.autoBackup !== true || !cloudConfigured({ cloudSync: cloud })) return false;
  const hours = Math.max(MIN_INTERVAL_HOURS, Math.min(MAX_INTERVAL_HOURS, Number(cloud.autoBackupIntervalHours || DEFAULT_INTERVAL_HOURS)));
  const last = Date.parse(cloud.lastAutoBackupAt || cloud.lastPushAt || '');
  if (!Number.isFinite(last)) return true;
  return Number(now) - last >= hours * 60 * 60 * 1000;
}
