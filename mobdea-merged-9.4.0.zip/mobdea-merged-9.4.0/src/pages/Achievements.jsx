import { Award, MapPinned, Sparkles, Trophy } from 'lucide-react';

export default function Achievements({ data }) {
  const mapResults = Array.isArray(data?.mapResults) ? data.mapResults : [];
  const assessments = Array.isArray(data?.assessments) ? data.assessments : [];
  const bestMap = Math.max(0, ...mapResults.map((item) => Number(item.score || 0)));
  const completedMaps = mapResults.filter((item) => ['completed', 'explored'].includes(item.status)).length;
  const badges = [
    { title: 'مستكشف الخرائط', value: completedMaps, hint: 'جولات خرائط مكتملة', icon: MapPinned },
    { title: 'أفضل نتيجة', value: bestMap, hint: 'نقطة في تحدي الخرائط', icon: Trophy },
    { title: 'أنشطة محفوظة', value: assessments.length, hint: 'اختبار أو نشاط', icon: Award },
  ];
  return <section className="page achievements-page"><div className="page-heading"><div><span className="eyebrow">التقدم والتحفيز</span><h2>الإنجازات</h2><p>ملخص حي للنتائج والأنشطة المسجلة داخل المنصة.</p></div><Sparkles size={28}/></div><div className="stats-grid">{badges.map(({ title, value, hint, icon: Icon }) => <article className="panel stat-card" key={title}><Icon size={24}/><strong>{value}</strong><span>{title}</span><small>{hint}</small></article>)}</div></section>;
}
