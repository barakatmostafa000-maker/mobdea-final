import { registerPlugin } from '@capacitor/core';
import { getAssetBlob } from './assetStore';
import { structureOcrQuestions } from './ocrQuestionParser';

const NativePdfOcr = registerPlugin('MobdeaPdfOcr');
export const OCR_MAX_PAGES = 20;

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = '';
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }
  return btoa(binary);
}

export { normalizeOcrText, structureOcrQuestions } from './ocrQuestionParser';

export async function extractQuestionsFromPdfAsset({
  assetId,
  startPage = 1,
  endPage = startPage,
  onProgress,
} = {}) {
  if (!assetId) throw new Error('ارفع كتاب الشرح الأساسي لهذا الصف أولًا.');
  if (!globalThis.Capacitor?.isNativePlatform?.()) {
    throw new Error('استخراج OCR يعمل داخل تطبيق Android على الموبايل أو التابلت.');
  }

  const firstPage = Math.max(1, Number(startPage || 1));
  const lastPage = Math.max(firstPage, Number(endPage || firstPage));
  if (lastPage - firstPage + 1 > OCR_MAX_PAGES) {
    throw new Error(`يمكن استخراج ${OCR_MAX_PAGES} صفحة كحد أقصى في العملية الواحدة.`);
  }

  const blob = await getAssetBlob(assetId);
  if (!(blob instanceof Blob)) throw new Error('تعذر قراءة ملف الكتاب من ذاكرة المنصة.');
  if (blob.size > 160 * 1024 * 1024) throw new Error('حجم ملف PDF أكبر من الحد المدعوم لاستخراج الأسئلة.');

  let listener;
  try {
    listener = await NativePdfOcr.addListener('progress', (event) => {
      onProgress?.({
        page: Number(event?.page || firstPage),
        totalPages: Number(event?.totalPages || lastPage - firstPage + 1),
        stage: String(event?.stage || 'recognizing'),
      });
    });

    const result = await NativePdfOcr.recognizePdfPages({
      base64: arrayBufferToBase64(await blob.arrayBuffer()),
      startPage: firstPage,
      endPage: lastPage,
      language: 'ara+eng',
      maxWidth: 1800,
    });
    const structured = structureOcrQuestions(result?.text || '');
    return {
      ...structured,
      pageCount: Number(result?.pageCount || 0),
      processedPages: Number(result?.processedPages || 0),
      startPage: firstPage,
      endPage: lastPage,
      modelDownloaded: Boolean(result?.modelDownloaded),
    };
  } finally {
    await listener?.remove?.().catch?.(() => {});
  }
}
