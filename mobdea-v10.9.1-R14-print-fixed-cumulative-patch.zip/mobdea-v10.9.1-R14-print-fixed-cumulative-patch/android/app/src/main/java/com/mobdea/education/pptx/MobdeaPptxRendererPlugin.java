package com.mobdea.education.pptx;

import android.util.Base64;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@CapacitorPlugin(name = "MobdeaPptxRenderer")
public class MobdeaPptxRendererPlugin extends Plugin {
    private static final long MAX_PPTX_BYTES = 100L * 1024L * 1024L;
    private static final long MAX_ENTRY_BYTES = 18L * 1024L * 1024L;
    private static final long MAX_IMAGE_BYTES = 6L * 1024L * 1024L;
    private static final long MAX_TOTAL_IMAGE_BYTES = 24L * 1024L * 1024L;
    private static final Pattern SLIDE_PATTERN = Pattern.compile("ppt/slides/slide(\\d+)\\.xml", Pattern.CASE_INSENSITIVE);
    private static final Pattern TEXT_PATTERN = Pattern.compile("<(?:[a-zA-Z0-9_]+:)?t(?:\\s[^>]*)?>(.*?)</(?:[a-zA-Z0-9_]+:)?t>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern REL_PATTERN = Pattern.compile("<Relationship[^>]+Type=\"[^\"]*/image\"[^>]+Target=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);
    private static final Pattern REL_PATTERN_REVERSED = Pattern.compile("<Relationship[^>]+Target=\"([^\"]+)\"[^>]+Type=\"[^\"]*/image\"", Pattern.CASE_INSENSITIVE);

    @PluginMethod
    public void parse(PluginCall call) {
        final String base64 = call.getString("base64", "");
        if (base64.isEmpty()) {
            call.reject("PowerPoint data is required.");
            return;
        }

        new Thread(() -> {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                if (bytes.length == 0 || bytes.length > MAX_PPTX_BYTES) {
                    throw new IllegalArgumentException("حجم ملف PowerPoint غير مدعوم داخل المنصة.");
                }
                Map<String, byte[]> entries = readEntries(bytes);
                List<SlideEntry> slideEntries = new ArrayList<>();
                for (String name : entries.keySet()) {
                    Matcher matcher = SLIDE_PATTERN.matcher(name);
                    if (matcher.matches()) {
                        slideEntries.add(new SlideEntry(name, Integer.parseInt(matcher.group(1))));
                    }
                }
                Collections.sort(slideEntries, Comparator.comparingInt(item -> item.number));
                if (slideEntries.isEmpty()) throw new IllegalArgumentException("لم يتم العثور على شرائح داخل ملف PowerPoint.");

                JSArray slides = new JSArray();
                long totalImageBytes = 0;
                for (SlideEntry slideEntry : slideEntries) {
                    JSObject slide = new JSObject();
                    slide.put("id", slideEntry.path);
                    slide.put("number", slideEntry.number);
                    slide.put("texts", extractTexts(entries.get(slideEntry.path)));

                    JSArray images = new JSArray();
                    String relsPath = "ppt/slides/_rels/slide" + slideEntry.number + ".xml.rels";
                    for (String imagePath : extractImagePaths(entries.get(relsPath), slideEntry.path)) {
                        byte[] imageBytes = entries.get(imagePath);
                        if (imageBytes == null || imageBytes.length == 0 || imageBytes.length > MAX_IMAGE_BYTES) continue;
                        if (totalImageBytes + imageBytes.length > MAX_TOTAL_IMAGE_BYTES) break;
                        totalImageBytes += imageBytes.length;
                        images.put("data:" + imageMime(imagePath) + ";base64," + Base64.encodeToString(imageBytes, Base64.NO_WRAP));
                    }
                    slide.put("images", images);
                    slides.put(slide);
                }

                JSObject result = new JSObject();
                result.put("slides", slides);
                result.put("slideCount", slides.length());
                getActivity().runOnUiThread(() -> call.resolve(result));
            } catch (Exception error) {
                String message = error.getMessage() == null ? "تعذر تجهيز عرض PowerPoint." : error.getMessage();
                getActivity().runOnUiThread(() -> call.reject(message, error));
            }
        }).start();
    }

    private Map<String, byte[]> readEntries(byte[] source) throws Exception {
        Map<String, byte[]> entries = new HashMap<>();
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(source))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if (entry.isDirectory()) continue;
                String name = normalizePath(entry.getName());
                if (!(name.startsWith("ppt/slides/") || name.startsWith("ppt/media/"))) continue;
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                byte[] buffer = new byte[32 * 1024];
                int read;
                long total = 0;
                while ((read = zip.read(buffer)) != -1) {
                    total += read;
                    if (total > MAX_ENTRY_BYTES) throw new IllegalArgumentException("يحتوي العرض على عنصر أكبر من الحد المدعوم.");
                    output.write(buffer, 0, read);
                }
                entries.put(name, output.toByteArray());
            }
        }
        return entries;
    }

    private JSArray extractTexts(byte[] xmlBytes) throws JSONException {
        JSArray texts = new JSArray();
        if (xmlBytes == null) return texts;
        String xml = new String(xmlBytes, StandardCharsets.UTF_8);
        Matcher matcher = TEXT_PATTERN.matcher(xml);
        while (matcher.find()) {
            String text = unescapeXml(matcher.group(1)).trim();
            if (!text.isEmpty()) texts.put(text);
        }
        return texts;
    }

    private Set<String> extractImagePaths(byte[] relBytes, String slidePath) {
        Set<String> paths = new LinkedHashSet<>();
        if (relBytes == null) return paths;
        String xml = new String(relBytes, StandardCharsets.UTF_8);
        collectRelationshipTargets(paths, REL_PATTERN.matcher(xml), slidePath);
        collectRelationshipTargets(paths, REL_PATTERN_REVERSED.matcher(xml), slidePath);
        return paths;
    }

    private void collectRelationshipTargets(Set<String> paths, Matcher matcher, String slidePath) {
        while (matcher.find()) {
            String target = unescapeXml(matcher.group(1));
            String base = slidePath.substring(0, slidePath.lastIndexOf('/') + 1);
            paths.add(normalizePath(base + target));
        }
    }

    private String normalizePath(String raw) {
        String[] parts = raw.replace('\\', '/').split("/");
        List<String> normalized = new ArrayList<>();
        for (String part : parts) {
            if (part.isEmpty() || ".".equals(part)) continue;
            if ("..".equals(part)) {
                if (!normalized.isEmpty()) normalized.remove(normalized.size() - 1);
            } else {
                normalized.add(part);
            }
        }
        return String.join("/", normalized);
    }

    private String imageMime(String path) {
        String lower = path.toLowerCase(Locale.US);
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".gif")) return "image/gif";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".bmp")) return "image/bmp";
        return "application/octet-stream";
    }

    private String unescapeXml(String value) {
        return String.valueOf(value)
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
            .replace("&amp;", "&");
    }

    private static final class SlideEntry {
        final String path;
        final int number;

        SlideEntry(String path, int number) {
            this.path = path;
            this.number = number;
        }
    }
}
