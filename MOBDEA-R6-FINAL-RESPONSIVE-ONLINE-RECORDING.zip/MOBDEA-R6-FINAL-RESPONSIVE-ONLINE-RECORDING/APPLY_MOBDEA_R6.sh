#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FILES_DIR="$SCRIPT_DIR/FILES"
SUPPORT_DIR="$SCRIPT_DIR/SUPPORT"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$ROOT/.mobdea-r6-backup-$STAMP"
MISSING_FILE="$BACKUP_DIR/.missing-before"

fail() {
  echo "❌ $1" >&2
  exit 1
}

[[ -f "$ROOT/package.json" ]] || fail "شغّل السكربت من جذر مشروع mobdea-final"
[[ -d "$ROOT/src" ]] || fail "مجلد src غير موجود"
[[ -d "$FILES_DIR/src" ]] || fail "ملفات R6 غير مكتملة"

mapfile -t PATCH_FILES < "$SCRIPT_DIR/PATCH_FILES.txt"
[[ ${#PATCH_FILES[@]} -gt 0 ]] || fail "قائمة ملفات التحديث فارغة"

ANDROID_PLUGIN_REL="android/app/src/main/java/com/mobdea/education/recording/MobdeaScreenRecorderPlugin.java"
ANDROID_SERVICE_REL="android/app/src/main/java/com/mobdea/education/recording/MobdeaScreenRecorderService.java"
ANDROID_MAIN_REL="android/app/src/main/java/com/mobdea/education/MainActivity.java"
ANDROID_MANIFEST_REL="android/app/src/main/AndroidManifest.xml"
ANDROID_ENABLED=0
if [[ -d "$ROOT/android/app/src/main" ]]; then
  ANDROID_ENABLED=1
  PATCH_FILES+=("$ANDROID_PLUGIN_REL" "$ANDROID_SERVICE_REL" "$ANDROID_MAIN_REL" "$ANDROID_MANIFEST_REL")
fi

mkdir -p "$BACKUP_DIR"
: > "$MISSING_FILE"

backup_one() {
  local rel="$1"
  if [[ -e "$ROOT/$rel" ]]; then
    mkdir -p "$BACKUP_DIR/$(dirname "$rel")"
    cp -a "$ROOT/$rel" "$BACKUP_DIR/$rel"
  else
    echo "$rel" >> "$MISSING_FILE"
  fi
}

restore_backup() {
  echo "↩️ تتم استعادة النسخة السابقة..."
  local rel
  for rel in "${PATCH_FILES[@]}"; do
    if [[ -e "$BACKUP_DIR/$rel" ]]; then
      mkdir -p "$ROOT/$(dirname "$rel")"
      rm -rf "$ROOT/$rel"
      cp -a "$BACKUP_DIR/$rel" "$ROOT/$rel"
    elif grep -Fxq "$rel" "$MISSING_FILE" 2>/dev/null; then
      rm -rf "$ROOT/$rel"
    fi
  done
}
trap 'code=$?; if [[ $code -ne 0 ]]; then restore_backup; echo "❌ لم يكتمل R6؛ تمت إعادة الملفات القديمة."; fi; exit $code' EXIT

for rel in "${PATCH_FILES[@]}"; do backup_one "$rel"; done

# Install the cumulative web source files.
while IFS= read -r rel; do
  [[ -n "$rel" ]] || continue
  [[ -f "$FILES_DIR/$rel" ]] || fail "ملف R6 مفقود: $rel"
  mkdir -p "$ROOT/$(dirname "$rel")"
  cp -a "$FILES_DIR/$rel" "$ROOT/$rel"
done < "$SCRIPT_DIR/PATCH_FILES.txt"

# Repair the native Android recorder and landscape lock without overwriting other native plugins.
if [[ "$ANDROID_ENABLED" -eq 1 ]]; then
  mkdir -p "$ROOT/$(dirname "$ANDROID_PLUGIN_REL")"
  cp -a "$SUPPORT_DIR/$ANDROID_PLUGIN_REL" "$ROOT/$ANDROID_PLUGIN_REL"
  cp -a "$SUPPORT_DIR/$ANDROID_SERVICE_REL" "$ROOT/$ANDROID_SERVICE_REL"

  python3 - "$ROOT/$ANDROID_MAIN_REL" "$ROOT/$ANDROID_MANIFEST_REL" <<'PY'
import re
import sys
from pathlib import Path

main_path = Path(sys.argv[1])
manifest_path = Path(sys.argv[2])

if not main_path.exists():
    raise SystemExit('MainActivity.java غير موجود')
if not manifest_path.exists():
    raise SystemExit('AndroidManifest.xml غير موجود')

main = main_path.read_text(encoding='utf-8')
package_match = re.search(r'^package\s+([\w.]+)\s*;', main, re.M)
if not package_match or package_match.group(1) != 'com.mobdea.education':
    raise SystemExit('حزمة Android الحالية لا تطابق com.mobdea.education؛ أوقفنا التعديل لحماية المشروع')

import_line = 'import com.mobdea.education.recording.MobdeaScreenRecorderPlugin;'
if import_line not in main:
    class_index = main.find('public class MainActivity')
    if class_index < 0:
        raise SystemExit('تعذر تحديد MainActivity')
    main = main[:class_index].rstrip() + '\n' + import_line + '\n\n' + main[class_index:]

registration = 'registerPlugin(MobdeaScreenRecorderPlugin.class);'
if registration not in main:
    match = re.search(r'(public\s+void\s+onCreate\s*\([^)]*\)\s*\{)', main)
    if not match:
        raise SystemExit('تعذر تحديد onCreate داخل MainActivity')
    main = main[:match.end()] + '\n        ' + registration + main[match.end():]
main_path.write_text(main, encoding='utf-8')

manifest = manifest_path.read_text(encoding='utf-8')
permissions = [
    'android.permission.RECORD_AUDIO',
    'android.permission.FOREGROUND_SERVICE',
    'android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION',
    'android.permission.FOREGROUND_SERVICE_MICROPHONE',
    'android.permission.POST_NOTIFICATIONS',
]
missing = [p for p in permissions if p not in manifest]
if missing:
    insertion = ''.join(f'    <uses-permission android:name="{p}" />\n' for p in missing)
    manifest = manifest.replace('<application', insertion + '\n    <application', 1)

activity_match = re.search(r'<activity\b[^>]*android:name="\.MainActivity"[^>]*>', manifest, re.S)
if not activity_match:
    activity_match = re.search(r'<activity\b[^>]*android:name="com\.mobdea\.education\.MainActivity"[^>]*>', manifest, re.S)
if not activity_match:
    raise SystemExit('تعذر تحديد MainActivity داخل AndroidManifest')
activity_tag = activity_match.group(0)
if 'android:screenOrientation=' in activity_tag:
    updated_tag = re.sub(r'android:screenOrientation="[^"]*"', 'android:screenOrientation="sensorLandscape"', activity_tag)
else:
    updated_tag = activity_tag[:-1].rstrip() + '\n            android:screenOrientation="sensorLandscape">'
manifest = manifest[:activity_match.start()] + updated_tag + manifest[activity_match.end():]

service_name = '.recording.MobdeaScreenRecorderService'
if service_name not in manifest:
    service = '''\n        <service\n            android:name=".recording.MobdeaScreenRecorderService"\n            android:exported="false"\n            android:foregroundServiceType="mediaProjection|microphone"\n            android:stopWithTask="false" />\n'''
    manifest = manifest.replace('</application>', service + '    </application>', 1)
manifest_path.write_text(manifest, encoding='utf-8')
PY
fi

# Fast integrity checks before the full Vite build.
grep -q "classmode-record-btn" "$ROOT/src/pages/ClassMode.jsx" || fail "زر تسجيل الحصة غير موجود بعد النسخ"
grep -q "navigate('sessions')" "$ROOT/src/pages/ClassMode.jsx" || fail "زر قائمة التسجيلات غير مربوط"
grep -q "lessonRecordings" "$ROOT/src/pages/Sessions.jsx" || fail "قائمة التسجيلات غير مربوطة بالبيانات"
grep -q "validateLiveStudentLink" "$ROOT/src/services/liveClass.js" || fail "فحص رابط الحصة غير موجود"
grep -q "live-teacher-panel:not(.is-idle)" "$ROOT/src/styles/v103.css" || fail "لوحة الحصة الأونلاين قد تكون مخفية"
grep -q "MOBDEA R6" "$ROOT/src/styles/v103.css" || fail "تنسيق R6 غير موجود"

if [[ "$ANDROID_ENABLED" -eq 1 ]]; then
  grep -q "MobdeaScreenRecorderPlugin.class" "$ROOT/$ANDROID_MAIN_REL" || fail "إضافة تسجيل Android لم تُسجل"
  grep -q 'screenOrientation="sensorLandscape"' "$ROOT/$ANDROID_MANIFEST_REL" || fail "الوضع العرضي لم يُثبت"
  grep -q 'MobdeaScreenRecorderService' "$ROOT/$ANDROID_MANIFEST_REL" || fail "خدمة تسجيل الشاشة غير مسجلة"
fi

echo "✅ تم تثبيت ملفات R6 وتجهيز الفحص"
echo "🧪 جارٍ بناء نسخة الويب..."
npm run build

if [[ "$ANDROID_ENABLED" -eq 1 ]]; then
  echo "🤖 جارٍ مزامنة ملفات الويب وإضافة التسجيل داخل Android..."
  npx cap sync android
fi

trap - EXIT
echo
echo "✅ تم تطبيق MOBDEA R6 بنجاح"
echo "📦 النسخة الاحتياطية: $(basename "$BACKUP_DIR")"
echo "📱 وضع الحصة مضبوط على العرض لأي موبايل أو تابلت مع بقاء الأوامر الرئيسية ظاهرة"
echo "🎥 تسجيل الحصة يحفظ الفيديو أو السجل البديل داخل قائمة التسجيلات"
echo "🌐 زر الحصة الأونلاين ينشئ الرابط وينسخه تلقائيًا عند وجود رمز مساحة عمل صالح"
echo "ℹ️ R6 يتضمن R5 وR4؛ لا تطبق التحديثات القديمة بعده."
