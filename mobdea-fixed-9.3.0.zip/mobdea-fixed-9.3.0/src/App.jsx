import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import AppShell from './components/AppShell';
import LockScreen from './components/LockScreen';
import Placeholder from './pages/Placeholder';
import SharedAccess from './pages/SharedAccess';
import { loadAppData, saveAppData, resetAppData } from './services/storage';
import { checkForUpdate, openApkDownload } from './services/updater';
import { registerServiceWorker, applyServiceWorkerUpdate } from './services/pwaUpdate';
import UpdatePrompt from './components/UpdatePrompt';
import { speakWelcome } from './services/voice';
import { readShareFromLocation, resolveShareFromLocation } from './services/share';
import { release } from './config/release';
import { ROLE_HOME, getRoleModules, buildWelcomeMessage } from './utils/auth';
import { identity } from './config/identity';

const Dashboard = lazy(() => import('./pages/Dashboard'));
const Students = lazy(() => import('./pages/Students'));
const Attendance = lazy(() => import('./pages/Attendance'));
const Sessions = lazy(() => import('./pages/Sessions'));
const Grades = lazy(() => import('./pages/Grades'));
const GradeScanner = lazy(() => import('./pages/GradeScanner'));
const ResultDetails = lazy(() => import('./pages/ResultDetails'));
const Payments = lazy(() => import('./pages/Payments'));
const Messages = lazy(() => import('./pages/Messages'));
const Reports = lazy(() => import('./pages/Reports'));
const Games = lazy(() => import('./pages/Games'));
const QuestionBankManager = lazy(() => import('./pages/QuestionBankManager'));
const MapChallenge = lazy(() => import('./pages/MapChallenge'));
const ClassMode = lazy(() => import('./pages/ClassMode'));
const Whiteboard = lazy(() => import('./pages/Whiteboard'));
const StudentCards = lazy(() => import('./pages/StudentCards'));
const Settings = lazy(() => import('./pages/Settings'));
const PortalPreview = lazy(() => import('./pages/PortalPreview'));
const DeviceDiagnostics = lazy(() => import('./pages/DeviceDiagnostics'));
const SmartAssistant = lazy(() => import('./pages/SmartAssistant'));
const ContentLibrary = lazy(() => import('./pages/ContentLibrary'));
const Updates = lazy(() => import('./pages/Updates'));

const LoadingScreen = () => <div className="loading-screen"><div className="loading-mark">م</div><h1>منصة المُبدع</h1><p>جارٍ تحميل الصفحة...</p></div>;

const AUTH_STORAGE_KEY = 'mobdea_mobile_auth_v2';
const AUTH_TTL_REMEMBERED = 7 * 24 * 60 * 60 * 1000;
const AUTH_TTL_SESSION = 12 * 60 * 60 * 1000;
const VALID_ROLES = new Set(['admin', 'teacher', 'student', 'guardian', 'visitor']);

function validateStoredAuth(raw, storage) {
  try {
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || !VALID_ROLES.has(parsed.role) || !Number.isFinite(Number(parsed.expiresAt)) || Number(parsed.expiresAt) <= Date.now()) {
      storage?.removeItem(AUTH_STORAGE_KEY);
      return null;
    }
    return parsed;
  } catch {
    storage?.removeItem(AUTH_STORAGE_KEY);
    return null;
  }
}

function readAuthFromStorage() {
  try {
    // "تذكرني" sessions are kept in localStorage so they survive app restarts;
    // regular sessions live only in sessionStorage for the current tab.
    const persisted = globalThis.localStorage?.getItem(AUTH_STORAGE_KEY);
    const remembered = validateStoredAuth(persisted, globalThis.localStorage);
    if (remembered) return remembered;
    return validateStoredAuth(globalThis.sessionStorage?.getItem(AUTH_STORAGE_KEY), globalThis.sessionStorage);
  } catch {
    return null;
  }
}

export default function App() {
  const [active, setActive] = useState('dashboard');
  const [data, setData] = useState(null);
  const [loadError, setLoadError] = useState('');
  const [auth, setAuth] = useState(() => readAuthFromStorage());
  const rememberRef = useRef(Boolean(globalThis.localStorage?.getItem(AUTH_STORAGE_KEY)));
  const [welcomePlayed, setWelcomePlayed] = useState(false);
  const [welcomeToast, setWelcomeToast] = useState('');
  const [updateInfo, setUpdateInfo] = useState(null);
  const [updateBusy, setUpdateBusy] = useState(false);
  const swReadyRef = useRef(false);
  const dataRef = useRef(null);
  const persistedDataRef = useRef(null);
  const saveQueueRef = useRef(Promise.resolve());

  useEffect(() => registerServiceWorker(() => { swReadyRef.current = true; }), []);

  useEffect(() => {
    dataRef.current = data;
  }, [data]);

  useEffect(() => {
    if (!welcomeToast) return undefined;
    const timer = setTimeout(() => setWelcomeToast(''), 5000);
    return () => clearTimeout(timer);
  }, [welcomeToast]);
  const [shareState, setShareState] = useState(() => readShareFromLocation(globalThis.location));
  const autoCheckedRef = useRef(false);

  useEffect(() => {
    let cancelled = false;
    loadAppData()
      .then((loaded) => { if (!cancelled) { dataRef.current = loaded; persistedDataRef.current = loaded; setData(loaded); } })
      .catch((error) => { if (!cancelled) setLoadError(error?.message || 'تعذر فتح بيانات التطبيق المشفرة.'); });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    try {
      if (auth && rememberRef.current) {
        globalThis.localStorage?.setItem(AUTH_STORAGE_KEY, JSON.stringify(auth));
        globalThis.sessionStorage?.removeItem(AUTH_STORAGE_KEY);
      } else if (auth) {
        globalThis.sessionStorage?.setItem(AUTH_STORAGE_KEY, JSON.stringify(auth));
        globalThis.localStorage?.removeItem(AUTH_STORAGE_KEY);
      } else {
        globalThis.sessionStorage?.removeItem(AUTH_STORAGE_KEY);
        globalThis.localStorage?.removeItem(AUTH_STORAGE_KEY);
      }
    } catch {
      // ignore storage failures
    }
  }, [auth]);

  useEffect(() => {
    if (!auth) return undefined;
    const expiresIn = Number(auth.expiresAt) - Date.now();
    if (expiresIn <= 0) {
      handleLogout();
      return undefined;
    }
    const timer = setTimeout(handleLogout, Math.min(expiresIn, 2_147_000_000));
    return () => clearTimeout(timer);
  }, [auth?.expiresAt]);

  useEffect(() => {
    if (!data || !auth || !['student', 'guardian'].includes(auth.role)) return;
    const stillExists = data.students.some((student) => String(student.id) === String(auth.studentId));
    if (!stillExists) handleLogout();
  }, [data?.students, auth?.role, auth?.studentId]);

  useEffect(() => {
    let cancelled = false;
    const initial = readShareFromLocation(globalThis.location);
    setShareState(initial);
    if (initial.mode === 'remote') {
      resolveShareFromLocation(globalThis.location).then((resolved) => { if (!cancelled) setShareState(resolved); });
    }
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!data || !auth || !data.settings.lockEnabled) return undefined;
    let timer;
    const resetTimer = () => {
      clearTimeout(timer);
      timer = setTimeout(() => setAuth(null), Math.max(1, Number(data.settings.lockAfterMinutes || 10)) * 60 * 1000);
    };
    const events = ['pointerdown', 'keydown', 'touchstart'];
    events.forEach((event) => window.addEventListener(event, resetTimer, { passive: true }));
    resetTimer();
    return () => { clearTimeout(timer); events.forEach((event) => window.removeEventListener(event, resetTimer)); };
  }, [data?.settings?.lockEnabled, data?.settings?.lockAfterMinutes, auth]);

  const updateData = useCallback((nextOrUpdater) => {
    const candidate = typeof nextOrUpdater === 'function' ? nextOrUpdater(dataRef.current) : nextOrUpdater;
    if (!candidate || typeof candidate !== 'object') return Promise.reject(new Error('بيانات الحفظ غير صالحة.'));
    dataRef.current = candidate;
    setData(candidate);

    const operation = saveQueueRef.current
      .catch(() => undefined)
      .then(() => saveAppData(candidate));
    saveQueueRef.current = operation.catch(() => undefined);

    return operation.then((saved) => {
      persistedDataRef.current = saved;
      if (dataRef.current === candidate) {
        dataRef.current = saved;
        setData(saved);
      }
      return saved;
    }).catch((error) => {
      if (dataRef.current === candidate) {
        dataRef.current = persistedDataRef.current;
        setData(persistedDataRef.current);
      }
      throw error;
    });
  }, []);

  useEffect(() => {
    if (!data || !auth || welcomePlayed || !data.settings.welcomeVoice) return;
    const timer = setTimeout(() => {
      speakWelcome(data.settings);
      setWelcomePlayed(true);
    }, 500);
    return () => clearTimeout(timer);
  }, [data, auth, welcomePlayed]);

  useEffect(() => {
    if (!data?.settings?.update?.autoCheck) return undefined;
    let cancelled = false;
    let running = false;

    const run = async () => {
      const current = dataRef.current;
      if (!current?.settings?.update?.autoCheck || running) return;
      running = true;
      try {
        const result = await checkForUpdate(current.settings, release.appVersion);
        if (cancelled) return;
        const checkedAt = new Date().toISOString();
        const latest = dataRef.current || current;
        const history = [{ checkedAt, version: result.version, available: result.available }, ...(latest.updateHistory || [])].slice(0, 20);
        const next = {
          ...latest,
          updateHistory: history,
          settings: {
            ...latest.settings,
            update: {
              ...(latest.settings.update || {}),
              manifestUrl: latest.settings.update?.manifestUrl || release.manifestPath,
              autoCheck: true,
              lastAutoCheckAt: checkedAt,
              lastAutoCheckVersion: result.version,
              lastAutoCheckAvailable: result.available,
            },
          },
        };
        const saved = await updateData(next);
        if (cancelled) return;
        const dismissed = saved.settings.update?.dismissedVersion;
        if (result.available && (result.mandatory || dismissed !== result.version)) setUpdateInfo(result);
      } catch {
        // Update checks must never interrupt normal app use.
      } finally {
        running = false;
      }
    };

    if (!autoCheckedRef.current) {
      autoCheckedRef.current = true;
      void run();
    }
    const interval = setInterval(run, 60 * 60 * 1000);
    const onVisible = () => {
      if (!document.hidden) void run();
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      cancelled = true;
      clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [data?.settings?.update?.autoCheck, data?.settings?.update?.manifestUrl, updateData]);

  const handleUnlock = (session, options = {}) => {
    const remember = Boolean(options.remember);
    const next = { ...(session || { role: 'admin' }), expiresAt: Date.now() + (remember ? AUTH_TTL_REMEMBERED : AUTH_TTL_SESSION) };
    rememberRef.current = remember;
    setAuth(next);
    setActive(ROLE_HOME[next.role] || 'dashboard');
    if (shareState.kind === 'game') setActive('games');
    if (shareState.kind === 'lesson' || shareState.kind === 'portal') setActive('classMode');
    setWelcomeToast(buildWelcomeMessage(next, identity));
  };

  const handleLogout = () => {
    rememberRef.current = false;
    setAuth(null);
    setWelcomePlayed(false);
    setWelcomeToast('');
    setActive('dashboard');
  };

  const handleUpdateNow = async () => {
    if (!updateInfo) return;
    setUpdateBusy(true);
    try {
      if (window.Capacitor?.isNativePlatform?.()) {
        await openApkDownload(updateInfo);
      } else if (swReadyRef.current) {
        applyServiceWorkerUpdate();
      } else {
        window.location.reload();
      }
    } catch {
      window.location.reload();
    } finally {
      setUpdateBusy(false);
    }
  };

  const handleUpdateLater = async () => {
    if (!updateInfo || updateInfo.mandatory) return;
    const next = { ...data, settings: { ...data.settings, update: { ...(data.settings.update || {}), dismissedVersion: updateInfo.version } } };
    await updateData(next);
    setUpdateInfo(null);
  };

  const allowedModules = useMemo(() => getRoleModules(auth?.role), [auth?.role]);

  const goHomeFromShare = () => {
    const url = new URL(globalThis.location?.href || '/');
    url.search = '';
    url.hash = '';
    globalThis.history?.replaceState({}, '', url.toString());
    setShareState({ kind: '', payload: null, token: null, mode: 'none' });
    if (auth) setActive('dashboard');
  };

  if (loadError) return <div className="loading-screen"><div className="loading-mark">!</div><h1>تعذر فتح المنصة</h1><p>{loadError}</p><button className="primary-btn" type="button" onClick={() => globalThis.location?.reload?.()}>إعادة المحاولة</button></div>;
  if (!data) return <LoadingScreen />;
  if (shareState.kind && !auth) {
    return (
      <>
        {updateInfo && <UpdatePrompt currentVersion={release.displayVersion} newVersion={updateInfo.version} notes={updateInfo.notes} mandatory={updateInfo.mandatory} busy={updateBusy} onUpdateNow={handleUpdateNow} onLater={handleUpdateLater} />}
        <SharedAccess shareKind={shareState.kind} sharePayload={shareState.payload} shareLoading={shareState.loading} shareError={shareState.error} onGoHome={goHomeFromShare} />
      </>
    );
  }
  if (!auth) {
    return (
      <>
        {updateInfo && <UpdatePrompt currentVersion={release.displayVersion} newVersion={updateInfo.version} notes={updateInfo.notes} mandatory={updateInfo.mandatory} busy={updateBusy} onUpdateNow={handleUpdateNow} onLater={handleUpdateLater} />}
        <LockScreen data={data} onUnlock={handleUnlock} updateData={updateData} />
      </>
    );
  }

  const common = { data, updateData, auth, role: auth.role };
  const screenProps = {
    dashboard: { data, navigate: setActive, auth },
    classMode: { ...common, navigate: setActive, shareState },
    whiteboard: { ...common, navigate: setActive },
    students: common,
    studentCards: { data, auth },
    portalPreview: { data, auth },
    diagnostics: { data, auth },
    smartAssistant: { data, auth },
    contentLibrary: { ...common, navigate: setActive },
    updates: common,
    sessions: common,
    attendance: common,
    gradeScanner: common,
    resultDetails: common,
    grades: common,
    payments: common,
    questionBank: common,
    games: { ...common, shareState },
    mapChallenge: { ...common, navigate: setActive },
    messages: common,
    reports: { data, auth },
    settings: { ...common, resetAppData },
  };

  const screenMap = {
    dashboard: Dashboard,
    classMode: ClassMode,
    whiteboard: Whiteboard,
    students: Students,
    studentCards: StudentCards,
    portalPreview: PortalPreview,
    diagnostics: DeviceDiagnostics,
    smartAssistant: SmartAssistant,
    contentLibrary: ContentLibrary,
    updates: Updates,
    sessions: Sessions,
    attendance: Attendance,
    gradeScanner: GradeScanner,
    resultDetails: ResultDetails,
    grades: Grades,
    payments: Payments,
    questionBank: QuestionBankManager,
    games: Games,
    mapChallenge: MapChallenge,
    messages: Messages,
    reports: Reports,
    settings: Settings,
  };

  const constrainedActive = allowedModules && !allowedModules.has(active) ? 'dashboard' : active;
  const Screen = screenMap[constrainedActive] || Placeholder;
  const ScreenProps = screenProps[constrainedActive] || { title: 'قيد التطوير', subtitle: 'سيتم استكمال الوحدة في الإصدار التالي.' };

  return (
    <>
      {updateInfo && <UpdatePrompt currentVersion={release.displayVersion} newVersion={updateInfo.version} notes={updateInfo.notes} mandatory={updateInfo.mandatory} busy={updateBusy} onUpdateNow={handleUpdateNow} onLater={handleUpdateLater} />}
      {welcomeToast && (
        <div className="welcome-toast" role="status">
          <span>{welcomeToast}</span>
        </div>
      )}
      <AppShell
        active={constrainedActive}
        onChange={setActive}
        settings={data.settings}
        data={data}
        auth={auth}
        onLogout={handleLogout}
      >
        <Suspense fallback={<LoadingScreen />}>
          <div key={constrainedActive} className="screen-stage">
            <Screen {...ScreenProps} />
          </div>
        </Suspense>
      </AppShell>
    </>
  );
}
