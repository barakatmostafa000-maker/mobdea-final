#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${1:-/workspaces/mobdea-final}"

if [[ ! -f "$PROJECT_ROOT/package.json" || ! -d "$PROJECT_ROOT/src" ]]; then
  echo "❌ لم يتم العثور على مشروع المبدع في: $PROJECT_ROOT"
  exit 1
fi

cd "$PROJECT_ROOT"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR=".mobdea-ui-backup-$STAMP"
mkdir -p "$BACKUP_DIR/src/components/live" "$BACKUP_DIR/src/components" "$BACKUP_DIR/src/pages" "$BACKUP_DIR/src/styles"

for FILE in \
  src/components/AppShell.jsx \
  src/components/live/TeacherLivePanel.jsx \
  src/pages/ClassMode.jsx \
  src/styles/app.css \
  src/styles/v103.css
do
  if [[ -f "$FILE" ]]; then
    cp "$FILE" "$BACKUP_DIR/$FILE"
  fi
done

cp "$SCRIPT_DIR/files/src/components/AppShell.jsx" src/components/AppShell.jsx
cp "$SCRIPT_DIR/files/src/components/live/TeacherLivePanel.jsx" src/components/live/TeacherLivePanel.jsx
cp "$SCRIPT_DIR/files/src/pages/ClassMode.jsx" src/pages/ClassMode.jsx
cp "$SCRIPT_DIR/files/src/styles/app.css" src/styles/app.css
cp "$SCRIPT_DIR/files/src/styles/v103.css" src/styles/v103.css

echo "✅ تم تطبيق إصلاح الواجهة"
echo "✅ النسخة الاحتياطية: $BACKUP_DIR"
echo "===== فحص البناء ====="
npm run build

echo
echo "✅ نجح البناء. لا تنشئ APK الآن؛ اختبر الواجهة في المتصفح أولًا."
