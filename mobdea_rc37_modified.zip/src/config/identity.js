export const identity = {
  teacherName: 'المُبدع مصطفى بركات',
  teacherTitle: 'معلم تاريخ ودراسات',
  schoolName: 'المُبدع لتعليم ممتع',
  portrait: '/identity/mostafa-barakat.jpg',
  icon: '/identity/mostafa-barakat-icon.png'
};
