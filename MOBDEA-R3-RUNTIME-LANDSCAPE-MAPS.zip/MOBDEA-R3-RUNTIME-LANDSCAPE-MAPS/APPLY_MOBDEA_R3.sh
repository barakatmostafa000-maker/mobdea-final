#!/usr/bin/env bash
set -euo pipefail

PROJECT="${1:-/workspaces/mobdea-final}"
cd "$PROJECT"

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP=".mobdea-r3-backup-$STAMP"
mkdir -p \
  "$BACKUP/src/pages" \
  "$BACKUP/src/services" \
  "$BACKUP/src/styles"

for file in \
  src/App.jsx \
  src/pages/ContentLibrary.jsx \
  src/services/pwaUpdate.js \
  src/styles/app.css \
  src/styles/v103.css
do
  if [ -f "$file" ]; then
    mkdir -p "$BACKUP/$(dirname "$file")"
    cp "$file" "$BACKUP/$file"
  fi
done

python3 - <<'PY'
from pathlib import Path
import re

library = Path("src/pages/ContentLibrary.jsx")
if not library.exists():
    raise SystemExit("❌ ملف ContentLibrary.jsx غير موجود")

text = library.read_text(encoding="utf-8")
match = re.search(
    r"import\s*\{\s*(?P<names>[^}]*)\}\s*from\s*(['\"])react\2\s*;",
    text,
    re.S,
)
if not match:
    raise SystemExit("❌ تعذر تحديد React import داخل ContentLibrary.jsx")

names = [name.strip() for name in match.group("names").split(",") if name.strip()]
if "useEffect" not in names:
    names.insert(0, "useEffect")
    replacement = "import { " + ", ".join(names) + " } from 'react';"
    text = text[:match.start()] + replacement + text[match.end():]

library.write_text(text, encoding="utf-8")

app = Path("src/App.jsx")
if not app.exists():
    raise SystemExit("❌ ملف src/App.jsx غير موجود")

text = app.read_text(encoding="utf-8")
static_imports = [
    ("MapChallenge", "./pages/MapChallenge"),
    ("ContentLibrary", "./pages/ContentLibrary"),
]

for component, source in static_imports:
    text = re.sub(
        rf"^\s*const\s+{component}\s*=\s*lazy\(\(\)\s*=>\s*import\(['\"]{re.escape(source)}['\"]\)\s*\)\s*;\s*$",
        "",
        text,
        flags=re.M,
    )

    if not re.search(
        rf"^\s*import\s+{component}\s+from\s+['\"]{re.escape(source)}['\"]\s*;\s*$",
        text,
        flags=re.M,
    ):
        imports = list(re.finditer(r"^\s*import\b.*?;\s*$", text, flags=re.M))
        if not imports:
            raise SystemExit(f"❌ لم يتم العثور على موضع import لإضافة {component}")
        insert_at = imports[-1].end()
        text = text[:insert_at] + f"\nimport {component} from '{source}';" + text[insert_at:]

app.write_text(text, encoding="utf-8")

pwa = Path("src/services/pwaUpdate.js")
if pwa.exists():
    text = pwa.read_text(encoding="utf-8")

    marker_start = "/* MOBDEA R3 DEV SW CLEANUP START */"
    marker_end = "/* MOBDEA R3 DEV SW CLEANUP END */"

    if marker_start in text and marker_end in text:
        before = text.split(marker_start, 1)[0]
        after = text.split(marker_end, 1)[1]
        text = before.rstrip() + "\n\n" + after.lstrip()

    helper = r'''
/* MOBDEA R3 DEV SW CLEANUP START */
async function cleanupDevelopmentServiceWorker() {
  if (!import.meta.env.DEV || typeof window === 'undefined') return;

  try {
    if ('serviceWorker' in navigator) {
      const registrations = await navigator.serviceWorker.getRegistrations();
      await Promise.all(registrations.map((registration) => registration.unregister()));
    }
  } catch {
    // Development cleanup is best-effort.
  }

  try {
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((key) => key.startsWith('mobdea-shell-'))
          .map((key) => caches.delete(key)),
      );
    }
  } catch {
    // Development cleanup is best-effort.
  }
}
/* MOBDEA R3 DEV SW CLEANUP END */
'''.strip()

    variable_matches = list(
        re.finditer(
            r"^(?:let|const|var)\s+[A-Za-z_$][\w$]*.*?;\s*$",
            text,
            flags=re.M,
        )
    )
    insert_at = variable_matches[-1].end() if variable_matches else 0
    text = text[:insert_at] + "\n\n" + helper + text[insert_at:]

    text = re.sub(
        r"(export\s+function\s+isServiceWorkerSupported\s*\(\)\s*\{\s*)",
        r"\1\n  if (import.meta.env.DEV) return false;",
        text,
        count=1,
    )

    text = re.sub(
        r"(export\s+function\s+registerServiceWorker\s*\([^)]*\)\s*\{\s*)",
        r"\1\n  if (import.meta.env.DEV) {\n    void cleanupDevelopmentServiceWorker();\n    return () => {};\n  }",
        text,
        count=1,
    )

    pwa.write_text(text, encoding="utf-8")

css_override = r'''
/* ===== MOBDEA R3 START ===== */

.map-pro-stage {
  position: relative !important;
  width: 100% !important;
  height: 100% !important;
  min-width: 0 !important;
  min-height: 0 !important;
  overflow: hidden !important;
  background:
    radial-gradient(circle at 50% 42%, #14577a 0%, #08293d 52%, #03111b 100%) !important;
}

.map-pro-stage > .map-pro-transform {
  position: absolute !important;
  inset: 0 !important;
  width: 100% !important;
  height: 100% !important;
  min-width: 0 !important;
  min-height: 0 !important;
  display: block !important;
  transform-origin: center center !important;
}

.map-pro-stage .map-pro-svg {
  position: absolute !important;
  inset: 0 !important;
  z-index: 1 !important;
  display: block !important;
  visibility: visible !important;
  opacity: 1 !important;
  width: 100% !important;
  height: 100% !important;
  min-width: 100% !important;
  min-height: 100% !important;
}

.map-pro-stage .map-pro-placement-layer {
  position: absolute !important;
  inset: 0 !important;
  z-index: 2 !important;
  width: 100% !important;
  height: 100% !important;
}

.map-pro-stage .map-pro-draw-canvas {
  position: absolute !important;
  inset: 0 !important;
  z-index: 3 !important;
  width: 100% !important;
  height: 100% !important;
}

@media (orientation: landscape) and (max-height: 760px) {
  .app-shell-v103:not(.lesson-mode-shell) {
    width: 100vw !important;
    height: 100dvh !important;
    grid-template-rows: 40px minmax(0, 1fr) !important;
    overflow: hidden !important;
  }

  .app-shell-v103:not(.lesson-mode-shell) > .mobile-header {
    height: 40px !important;
    min-height: 40px !important;
    max-height: 40px !important;
    padding: 2px 5px !important;
  }

  .app-shell-v103:not(.lesson-mode-shell) > .app-content {
    width: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    padding: 4px !important;
    overflow: hidden !important;
  }

  .dashboard-page.dashboard-v103,
  .dashboard-reference-layout.dashboard-v103 {
    width: 100% !important;
    height: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    display: grid !important;
    grid-template-rows: 72px minmax(0, 1fr) !important;
    gap: 5px !important;
    padding: 0 !important;
    overflow: hidden !important;
  }

  .dashboard-v103 .dashboard-desktop-topbar,
  .dashboard-v103 .dashboard-reference-portrait,
  .dashboard-v103 .dashboard-today-panel,
  .dashboard-v103 .dashboard-reference-bottom,
  .dashboard-v103 .dashboard-hidden-live-metrics {
    display: none !important;
  }

  .dashboard-v103 .dashboard-reference-hero {
    width: 100% !important;
    height: 72px !important;
    min-height: 72px !important;
    max-height: 72px !important;
    display: block !important;
    margin: 0 !important;
    overflow: hidden !important;
    border-radius: 12px !important;
  }

  .dashboard-v103 .dashboard-reference-copy {
    width: 100% !important;
    height: 100% !important;
    min-width: 0 !important;
    display: grid !important;
    grid-template-columns: auto minmax(0, 1fr) auto !important;
    align-items: center !important;
    gap: 9px !important;
    padding: 6px 12px !important;
  }

  .dashboard-v103 .dashboard-reference-kicker,
  .dashboard-v103 .dashboard-reference-copy h3,
  .dashboard-v103 .dashboard-reference-copy p {
    display: none !important;
  }

  .dashboard-v103 .dashboard-reference-copy h2 {
    grid-column: 1 !important;
    margin: 0 !important;
    font-size: clamp(1.25rem, 3.3vw, 2rem) !important;
    line-height: 1 !important;
    white-space: nowrap !important;
  }

  .dashboard-v103 .dashboard-reference-cta {
    grid-column: 3 !important;
    display: flex !important;
    align-items: center !important;
    gap: 5px !important;
    margin: 0 !important;
  }

  .dashboard-v103 .dashboard-reference-cta button {
    min-height: 32px !important;
    padding: 5px 9px !important;
    font-size: .67rem !important;
    white-space: nowrap !important;
  }

  .dashboard-v103 .dashboard-feature-grid {
    width: 100% !important;
    height: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    display: grid !important;
    grid-template-columns: repeat(3, minmax(0, 1fr)) !important;
    grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
    gap: 5px !important;
    padding: 0 !important;
    overflow: hidden !important;
  }

  .dashboard-v103 .dashboard-feature-card {
    width: 100% !important;
    height: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    display: grid !important;
    grid-template-columns: 40px minmax(0, 1fr) !important;
    grid-template-rows: minmax(0, 1fr) auto !important;
    align-items: center !important;
    gap: 4px 7px !important;
    padding: 6px 8px !important;
    text-align: right !important;
    overflow: hidden !important;
  }

  .dashboard-v103 .dashboard-feature-icon {
    grid-column: 1 !important;
    grid-row: 1 / 3 !important;
    width: 38px !important;
    height: 38px !important;
    min-width: 38px !important;
    min-height: 38px !important;
    display: grid !important;
    place-items: center !important;
  }

  .dashboard-v103 .dashboard-feature-card strong {
    grid-column: 2 !important;
    margin: 0 !important;
    font-size: .76rem !important;
    line-height: 1.15 !important;
  }

  .dashboard-v103 .dashboard-feature-card small {
    display: none !important;
  }

  .dashboard-v103 .dashboard-feature-link {
    grid-column: 2 !important;
    display: inline-flex !important;
    align-items: center !important;
    gap: 3px !important;
    font-size: .58rem !important;
    line-height: 1 !important;
  }
}

@media (orientation: landscape) and (max-height: 760px) {
  .classmode-v103.classmode-final-layout,
  .classmode-v103.classmode-final-layout.fullscreen {
    width: 100% !important;
    height: 100dvh !important;
    min-height: 0 !important;
    grid-template-rows: 42px minmax(0, 1fr) 38px !important;
    gap: 3px !important;
    padding: 3px !important;
    overflow: hidden !important;
  }

  .classmode-v103.classmode-final-layout .classmode-top-header {
    height: 42px !important;
    min-height: 42px !important;
    max-height: 42px !important;
    grid-template-columns: 42px minmax(330px, 1fr) 52px !important;
    gap: 3px !important;
    padding: 2px 4px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-header-brand > div,
  .classmode-v103.classmode-final-layout .classmode-header-meta .header-meta-item:not(:first-child) {
    display: none !important;
  }

  .classmode-v103.classmode-final-layout .classmode-header-brand img {
    width: 33px !important;
    height: 33px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-header-tabs {
    gap: 3px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-header-tabs button {
    min-height: 35px !important;
    padding: 2px 4px !important;
    font-size: .56rem !important;
  }

  .classmode-v103.classmode-final-layout .classmode-header-tabs svg {
    width: 16px !important;
    height: 16px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-layout {
    height: 100% !important;
    min-height: 0 !important;
    grid-template-columns: minmax(0, 1fr) clamp(138px, 15vw, 172px) !important;
    gap: 3px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-board-panel {
    gap: 3px !important;
    padding: 3px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-board-topbar {
    flex-basis: 29px !important;
    min-height: 29px !important;
    max-height: 29px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-current-badge,
  .classmode-v103.classmode-final-layout .classmode-top-actions .secondary-btn,
  .classmode-v103.classmode-final-layout .classmode-top-actions .danger-btn {
    display: none !important;
  }

  .classmode-v103.classmode-final-layout .classmode-media-navigator {
    flex-basis: 30px !important;
    min-height: 30px !important;
    max-height: 30px !important;
    padding: 2px 5px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-board-frame {
    padding: 0 !important;
  }

  .classmode-v103.classmode-final-layout .classmode-toolbar {
    min-height: 31px !important;
    max-height: 31px !important;
    padding: 2px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-side-column {
    gap: 3px !important;
  }

  .classmode-v103.classmode-final-layout .live-teacher-panel {
    display: none !important;
  }

  .classmode-v103.classmode-final-layout .classmode-students-panel {
    padding: 4px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-student-row {
    padding: 2px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-student-row-main {
    min-height: 31px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-student-row-actions button {
    min-width: 23px !important;
    min-height: 23px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-phrases-panel {
    display: none !important;
  }

  .classmode-v103.classmode-final-layout .classmode-bottom-actions {
    min-height: 38px !important;
    height: 38px !important;
    padding: 2px 5px !important;
  }

  .classmode-v103.classmode-final-layout .classmode-bottom-actions button {
    min-height: 29px !important;
    padding: 3px 6px !important;
    font-size: .62rem !important;
  }
}

@media (orientation: landscape) and (max-height: 760px) {
  .classmode-map-embed .lesson-map-studio {
    width: 100% !important;
    height: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    display: grid !important;
    grid-template-columns: 108px minmax(0, 1fr) !important;
    grid-template-rows: minmax(0, 1fr) !important;
    overflow: hidden !important;
  }

  .classmode-map-embed .lesson-map-symbol-sidebar {
    width: 108px !important;
    min-width: 108px !important;
    min-height: 0 !important;
    max-height: none !important;
    padding: 3px !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
  }

  .classmode-map-embed .lesson-map-sidebar-title small,
  .classmode-map-embed .lesson-map-custom-label,
  .classmode-map-embed .lesson-map-placed-list {
    display: none !important;
  }

  .classmode-map-embed .lesson-map-sidebar-title {
    padding: 3px !important;
    font-size: .58rem !important;
  }

  .classmode-map-embed .lesson-map-group-tabs {
    flex-wrap: nowrap !important;
    overflow-x: auto !important;
  }

  .classmode-map-embed .lesson-map-group-tabs button {
    flex: 0 0 auto !important;
    padding: 3px 4px !important;
    font-size: .5rem !important;
  }

  .classmode-map-embed .lesson-map-symbol-list {
    grid-template-columns: 1fr !important;
    gap: 3px !important;
  }

  .classmode-map-embed .lesson-map-symbol-list button {
    min-height: 31px !important;
    padding: 3px !important;
  }

  .classmode-map-embed .lesson-map-symbol-list button small {
    display: none !important;
  }

  .classmode-map-embed .lesson-map-main {
    width: 100% !important;
    height: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    display: grid !important;
    grid-template-rows: auto auto minmax(0, 1fr) auto !important;
    overflow: hidden !important;
  }

  .classmode-map-embed .lesson-map-recommendation,
  .classmode-map-embed .lesson-map-search-row {
    display: none !important;
  }

  .classmode-map-embed .lesson-map-topbar,
  .classmode-map-embed .lesson-map-controlbar {
    min-width: 0 !important;
    padding: 3px 5px !important;
    overflow-x: auto !important;
    overflow-y: hidden !important;
  }

  .classmode-map-embed .lesson-map-region-tabs,
  .classmode-map-embed .lesson-map-layer-tabs,
  .classmode-map-embed .lesson-map-draw-tools {
    flex-wrap: nowrap !important;
    overflow-x: auto !important;
  }

  .classmode-map-embed .lesson-map-region-tabs button,
  .classmode-map-embed .lesson-map-layer-tabs button,
  .classmode-map-embed .lesson-map-draw-tools button {
    flex: 0 0 auto !important;
    min-height: 25px !important;
    padding: 2px 4px !important;
    font-size: .5rem !important;
  }

  .classmode-map-embed .lesson-map-canvas-shell {
    position: relative !important;
    width: 100% !important;
    height: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    overflow: hidden !important;
  }

  .classmode-map-embed .lesson-map-canvas-shell .map-pro-stage {
    width: 100% !important;
    height: 100% !important;
    min-height: 0 !important;
  }

  .classmode-map-embed .lesson-map-footer-info {
    min-height: 20px !important;
    padding: 2px 5px !important;
    font-size: .5rem !important;
  }
}

@media (orientation: landscape) and (max-height: 760px) {
  .map-game-page {
    width: 100% !important;
    height: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    padding: 3px !important;
    overflow: hidden !important;
  }

  .map-challenge-pro {
    width: 100% !important;
    height: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    display: grid !important;
    grid-template-rows: 42px minmax(0, 1fr) !important;
    overflow: hidden !important;
  }

  .map-challenge-pro .map-game-layout {
    width: 100% !important;
    height: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    display: grid !important;
    grid-template-columns: 118px minmax(0, 1fr) 172px !important;
    grid-template-rows: minmax(0, 1fr) !important;
    overflow: hidden !important;
  }

  .map-challenge-pro .map-game-nav,
  .map-challenge-pro .map-game-question-panel {
    min-width: 0 !important;
    min-height: 0 !important;
    height: 100% !important;
    padding: 4px !important;
    overflow-y: auto !important;
  }

  .map-challenge-pro .map-game-main {
    width: 100% !important;
    height: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    display: grid !important;
    grid-template-rows: 33px minmax(0, 1fr) !important;
    overflow: hidden !important;
  }

  .map-challenge-pro .map-game-canvas-shell {
    position: relative !important;
    width: 100% !important;
    height: 100% !important;
    min-width: 0 !important;
    min-height: 0 !important;
    overflow: hidden !important;
  }

  .map-challenge-pro .map-game-canvas-shell .map-pro-stage {
    width: 100% !important;
    height: 100% !important;
    min-height: 0 !important;
  }
}

@media (orientation: portrait) {
  .map-game-page {
    width: 100% !important;
    min-width: 0 !important;
    overflow-y: auto !important;
  }

  .map-challenge-pro {
    width: 100% !important;
    height: auto !important;
    min-height: calc(100dvh - 48px) !important;
    overflow: visible !important;
  }

  .map-challenge-pro .map-game-layout {
    width: 100% !important;
    height: auto !important;
    display: grid !important;
    grid-template-columns: minmax(0, 1fr) !important;
    grid-template-rows: auto minmax(460px, 64dvh) auto !important;
    overflow: visible !important;
  }

  .map-challenge-pro .map-game-main {
    min-height: 460px !important;
    grid-template-rows: auto minmax(400px, 1fr) !important;
  }

  .map-challenge-pro .map-game-canvas-shell,
  .map-challenge-pro .map-game-canvas-shell .map-pro-stage {
    min-height: 400px !important;
  }
}

/* ===== MOBDEA R3 END ===== */
'''

for css_name in ("src/styles/app.css", "src/styles/v103.css"):
    path = Path(css_name)
    if not path.exists():
        continue

    css = path.read_text(encoding="utf-8")
    start = "/* ===== MOBDEA R3 START ===== */"
    end = "/* ===== MOBDEA R3 END ===== */"

    if start in css and end in css:
        before = css.split(start, 1)[0]
        after = css.split(end, 1)[1]
        css = before.rstrip() + "\n\n" + after.lstrip()

    css = css.rstrip() + "\n\n" + css_override.strip() + "\n"
    path.write_text(css, encoding="utf-8")

print("✅ تم إصلاح تحميل مكتبة المحتوى وتحدي الخرائط")
print("✅ تم تعطيل وتنظيف Service Worker أثناء المعاينة")
print("✅ تم ضبط Dashboard العرضي")
print("✅ تم تكبير مساحة العرض داخل وضع الحصة")
print("✅ تم تنظيم الخرائط داخل الحصة والتحدي")
PY

echo "===== فحص البناء ====="
npm run build

echo
echo "✅ تم تطبيق MOBDEA R3 بنجاح"
echo "✅ النسخة الاحتياطية: $BACKUP"
echo
echo "مهم: أوقف خادم التطوير القديم ثم شغله من جديد."
