MOBDEA R3

الإصلاحات:
- ContentLibrary: إضافة useEffect بصورة صحيحة.
- MapChallenge وContentLibrary: تحويلهما إلى imports ثابتة لمنع فشل lazy loading.
- تعطيل وتنظيف Service Worker أثناء npm run dev.
- Dashboard عرضي جديد مضغوط: شريط علوي + 6 بطاقات منظمة.
- تكبير مساحة السبورة/العرض داخل وضع الحصة.
- تنظيم أدوات الخرائط داخل الحصة.
- تثبيت مساحة SVG للخريطة داخل الحصة وتحدي الخرائط.

طريقة التطبيق:
bash APPLY_MOBDEA_R3.sh

بعد نجاح البناء:
1) أوقف npm run dev القديم.
2) شغّل npm run dev -- --host 0.0.0.0
3) اقفل تبويب المعاينة القديم وافتح المنفذ 5173 من جديد.
