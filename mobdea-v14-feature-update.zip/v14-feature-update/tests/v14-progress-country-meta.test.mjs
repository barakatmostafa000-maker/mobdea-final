import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const classMode = await readFile(new URL('../src/pages/ClassMode.jsx', import.meta.url), 'utf8');
const countryCards = await readFile(new URL('../src/data/countryCards.js', import.meta.url), 'utf8');

test('class mode tracks per-session student point progress and exposes progress sorting', () => {
  assert.match(classMode, /classPointSessions/);
  assert.match(classMode, /studentProgress/);
  assert.match(classMode, /الأكثر تحسنًا/);
  assert.match(classMode, /↑ \+\{studentProgress\[student\.id\]\.delta\}/);
});

test('country cards expose country name, capital and official language metadata', () => {
  assert.match(countryCards, /'القاهرة', 'العربية'/);
  assert.match(countryCards, /capital/);
  assert.match(countryCards, /language/);
  assert.match(classMode, /الدولة/);
  assert.match(classMode, /العاصمة/);
  assert.match(classMode, /اللغة/);
});
