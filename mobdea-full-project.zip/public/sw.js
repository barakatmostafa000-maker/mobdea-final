// Service worker for المُبدع — enables offline use on the web/PWA build and
// powers the real in-app "update available" flow (no fake placeholder logic).
//
// Update lifecycle:
// 1. Browser detects a byte-different sw.js and installs it in the background.
// 2. The new worker calls self.skipWaiting() only when it receives an explicit
//    SKIP_WAITING message from the app (triggered by the person tapping
//    "تحديث الآن" in the in-app update prompt) — never automatically, so an
//    update never yanks the rug from under someone mid-lesson.
// 3. Once activated, it takes control of open tabs and the app reloads once.

const CACHE_VERSION = 'mobdea-v1'; // bumped automatically by the build's release version at fetch time via query param
const APP_SHELL = ['/', '/index.html'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => cache.addAll(APP_SHELL).catch(() => null))
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== CACHE_VERSION).map((key) => caches.delete(key)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  // Navigation requests: network-first so people always get the freshest
  // shell when online, falling back to the cached shell when offline.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put('/index.html', copy));
          return response;
        })
        .catch(() => caches.match('/index.html'))
    );
    return;
  }

  // Static assets: cache-first with a network fallback + cache fill.
  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request)
        .then((response) => {
          if (response.ok && new URL(request.url).origin === self.location.origin) {
            const copy = response.clone();
            caches.open(CACHE_VERSION).then((cache) => cache.put(request, copy));
          }
          return response;
        })
        .catch(() => cached);
    })
  );
});
