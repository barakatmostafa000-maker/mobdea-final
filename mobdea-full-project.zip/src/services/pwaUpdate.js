// Registers the service worker (web/PWA builds only — Capacitor's native
// Android wrapper doesn't run a browser service worker, so this is a no-op
// there and the APK manifest-based flow in updater.js is used instead) and
// reports when a new version has installed and is ready to activate.

let waitingWorker = null;
let onReadyCallback = null;

export function isServiceWorkerSupported() {
  return typeof navigator !== 'undefined' && 'serviceWorker' in navigator && !window.Capacitor?.isNativePlatform?.();
}

export function registerServiceWorker(onReady) {
  if (!isServiceWorkerSupported()) return;
  onReadyCallback = onReady;

  navigator.serviceWorker.register('/sw.js').then((registration) => {
    if (registration.waiting) {
      waitingWorker = registration.waiting;
      onReadyCallback?.();
    }
    registration.addEventListener('updatefound', () => {
      const installing = registration.installing;
      if (!installing) return;
      installing.addEventListener('statechange', () => {
        if (installing.state === 'installed' && navigator.serviceWorker.controller) {
          waitingWorker = installing;
          onReadyCallback?.();
        }
      });
    });
    // Re-check for a newer sw.js periodically while the app is open.
    setInterval(() => registration.update().catch(() => null), 15 * 60 * 1000);
  }).catch(() => null);

  let refreshing = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (refreshing) return;
    refreshing = true;
    window.location.reload();
  });
}

export function applyServiceWorkerUpdate() {
  if (!waitingWorker) {
    window.location.reload();
    return;
  }
  waitingWorker.postMessage('SKIP_WAITING');
}
