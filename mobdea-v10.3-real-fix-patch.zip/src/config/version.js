export const APP_VERSION = '10.3.0';
export const APP_VERSION_CODE = 103;
export const DATA_SCHEMA_VERSION = 12;
export const RELEASE_CHANNEL = 'stable';
export const RELEASE_TAG = 'R5';
