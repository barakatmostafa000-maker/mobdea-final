import ClassMode from './ClassMode';

/** Dedicated online-class route backed by the same proven ClassMode engine.
 * onlineEntry keeps live-room behavior separate from the local classroom route. */
export default function OnlineClass(props) {
  return <ClassMode {...props} onlineEntry />;
}
