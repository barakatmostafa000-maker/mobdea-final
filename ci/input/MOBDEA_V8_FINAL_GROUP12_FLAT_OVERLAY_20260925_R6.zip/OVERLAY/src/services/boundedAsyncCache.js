function characterCost(value, seen = new WeakSet()) {
  if (value == null) return 0;
  if (typeof value === 'string') return value.length;
  if (typeof value === 'number' || typeof value === 'boolean') return String(value).length;
  if (typeof value !== 'object') return 0;
  if (seen.has(value)) return 0;
  seen.add(value);
  if (Array.isArray(value)) return value.reduce((sum, item) => sum + characterCost(item, seen), 0);
  return Object.entries(value).reduce((sum, [key, item]) => sum + key.length + characterCost(item, seen), 0);
}

export function createBoundedAsyncCache({ maxEntries = 8, maxCharacters = 48_000_000 } = {}) {
  const entries = new Map();
  const inflight = new Map();
  let characters = 0;
  const touch = (key, row) => { entries.delete(key); entries.set(key, row); };
  const evict = () => {
    while (entries.size > Math.max(1, Number(maxEntries) || 1) || characters > Math.max(1, Number(maxCharacters) || 1)) {
      const oldest = entries.keys().next().value;
      if (oldest === undefined) break;
      const row = entries.get(oldest);
      entries.delete(oldest);
      characters = Math.max(0, characters - Number(row?.characters || 0));
    }
  };
  return {
    async get(key, loader) {
      const id = String(key);
      if (entries.has(id)) { const row = entries.get(id); touch(id, row); return row.value; }
      if (inflight.has(id)) return inflight.get(id);
      const task = Promise.resolve().then(loader).then((value) => {
        const cost = characterCost(value);
        const old = entries.get(id);
        if (old) characters -= Number(old.characters || 0);
        entries.set(id, { value, characters: cost });
        characters += cost;
        evict();
        return value;
      }).finally(() => inflight.delete(id));
      inflight.set(id, task);
      return task;
    },
    clear() { entries.clear(); inflight.clear(); characters = 0; },
    delete(key) {
      const id = String(key); const row = entries.get(id);
      if (!row) return false;
      entries.delete(id); characters = Math.max(0, characters - Number(row.characters || 0)); return true;
    },
    stats() { return { size: entries.size, characters, inflight: inflight.size, maxEntries, maxCharacters }; },
  };
}
