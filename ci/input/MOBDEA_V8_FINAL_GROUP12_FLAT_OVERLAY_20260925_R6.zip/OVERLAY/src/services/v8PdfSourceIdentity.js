export function isSamePdfPreview(previous = {}, next = {}) {
  return String(previous?.url || '') === String(next?.url || '')
    && previous?.blob === next?.blob
    && String(previous?.cacheKey || '') === String(next?.cacheKey || '')
    && Number(previous?.page || 1) === Number(next?.page || 1)
    && Number(previous?.maxWidth || 0) === Number(next?.maxWidth || 0);
}
