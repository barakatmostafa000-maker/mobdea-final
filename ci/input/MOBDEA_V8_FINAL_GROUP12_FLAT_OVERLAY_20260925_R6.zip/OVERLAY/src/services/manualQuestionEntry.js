import { sanitizeQuestion, normalizeText } from './assessment.js';
import { isQuestionReadyForGame } from './project08QuestionImport.js';
export function prepareManualGameQuestion(draft = {}, id = '') {
  const type = draft.type || 'mcq';
  let options = Array.isArray(draft.options) ? draft.options : String(draft.optionsText || '').split(/\r?\n/);
  options = options.map(normalizeText).filter(Boolean);
  if (type === 'tf') options = ['صح','خطأ'];
  const answer = normalizeText(draft.answer);
  let answerIndex = Number.isInteger(Number(draft.answerIndex)) ? Number(draft.answerIndex) : -1;
  if (type === 'mcq' && (answerIndex < 0 || !options[answerIndex]) && answer) answerIndex = options.findIndex((option) => normalizeText(option) === answer);
  if (type === 'tf' && answer) answerIndex = options.indexOf(answer);
  const question = sanitizeQuestion({ ...draft, id: id || draft.id, source: 'custom', type, options, answer, answerIndex }, { source: 'custom' });
  if (!question.text) return { error: 'اكتب نص السؤال أولًا.' };
  if (type === 'mcq' && options.length < 2) return { error: 'أضف اختيارين على الأقل للسؤال.' };
  if (!isQuestionReadyForGame(question)) return { error: 'حدد الإجابة الصحيحة قبل حفظ السؤال في بنك الألعاب.' };
  return { question: { ...question, needsAnswer: false, approved: true } };
}
