const blobIds = new WeakMap();
let nextBlobId = 0;
function blobIdentity(blob) {
  if (!blob || (typeof blob !== 'object' && typeof blob !== 'function')) return '';
  if (!blobIds.has(blob)) blobIds.set(blob, ++nextBlobId);
  return `blob:${blobIds.get(blob)}`;
}
export function pdfDocumentIdentity(source = {}, resourceId = '') {
  if (typeof source === 'string') return `resource:${String(resourceId)}|url:${source}`;
  const blob = source?.blob ? blobIdentity(source.blob) : '';
  const cacheKey = String(source?.cacheKey || '');
  const url = String(source?.url || '');
  return `resource:${String(resourceId || '')}|cache:${cacheKey}|url:${url}|${blob}`;
}
export function pdfPageIdentity(source = {}, resourceId = '', page = 1) {
  return `${pdfDocumentIdentity(source, resourceId)}|page:${Math.max(1, Math.round(Number(page) || 1))}`;
}
