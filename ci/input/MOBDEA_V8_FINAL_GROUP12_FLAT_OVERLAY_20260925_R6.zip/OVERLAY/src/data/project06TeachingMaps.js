// PROJECT06_PROFESSIONAL_TEACHING_MAPS_V1 + V8 VERIFIED NILE COMPLETION
// Coordinates are [longitude, latitude]. IDs are stable because saved lesson-map
// snapshots and the map-selection resolver use them as durable identifiers.

export const REFERENCE_LATITUDES = Object.freeze([
  { id: 'equator', value: 0, label: 'خط الاستواء 0°', major: true },
  { id: 'cancer', value: 23.5, label: 'مدار السرطان 23.5°ش', major: true },
  { id: 'capricorn', value: -23.5, label: 'مدار الجدي 23.5°ج', major: true },
  { id: 'arctic', value: 66.5, label: 'الدائرة القطبية الشمالية 66.5°ش', major: false },
  { id: 'antarctic', value: -66.5, label: 'الدائرة القطبية الجنوبية 66.5°ج', major: false },
]);

export const REFERENCE_LONGITUDES = Object.freeze([
  { id: 'greenwich', value: 0, label: 'خط جرينتش 0°', prime: true },
  { id: 'lon30e', value: 30, label: '30° شرقًا', prime: false },
  { id: 'lon60e', value: 60, label: '60° شرقًا', prime: false },
  { id: 'lon30w', value: -30, label: '30° غربًا', prime: false },
  { id: 'lon60w', value: -60, label: '60° غربًا', prime: false },
]);

const egyptNile = [
  [32.70,22.00],[32.88,23.97],[32.78,24.60],[32.64,25.15],[32.64,25.69],[32.45,26.02],
  [32.28,26.16],[31.98,26.38],[31.80,26.55],[31.52,26.82],[31.25,27.18],
  [31.16,27.70],[31.10,28.22],[31.05,28.72],[31.02,29.18],[31.10,29.62],
  [31.24,30.04],[31.18,30.35],[31.13,30.45],[31.10,30.70],[31.08,30.95],
];
const deltaWest = [[31.08,30.95],[30.75,31.12],[30.42,31.40]];
const deltaEast = [[31.08,30.95],[31.38,31.15],[31.81,31.42]];

const nileBasin = [
  { id:'kagera', name:'نهر كاجيرا', kind:'tributary', coords:[[29.60,-2.20],[30.05,-2.08],[30.45,-1.92],[30.85,-1.68],[31.25,-1.42],[31.70,-1.18],[32.10,-1.00]], labelCoord:[30.85,-1.68] },
  { id:'victoria-nile', name:'نهر فيكتوريا', kind:'tributary', coords:[[33.20,0.44],[33.12,0.78],[33.04,1.12],[33.00,1.50],[32.72,1.72],[32.40,1.95],[31.90,2.18],[31.15,2.25]], labelCoord:[32.65,1.65] },
  { id:'albert-nile', name:'نهر ألبرت', kind:'tributary', coords:[[31.15,2.25],[31.00,2.75],[31.02,3.25],[31.25,3.80],[31.45,4.32],[31.60,4.85]], labelCoord:[31.22,3.55] },
  { id:'bahr-jebel', name:'بحر الجبل', kind:'white', coords:[[31.60,4.85],[31.58,5.45],[31.55,6.05],[31.46,6.70],[31.30,7.35],[31.05,8.05],[30.85,8.65],[31.05,9.15],[31.65,9.55]], labelCoord:[31.35,6.8] },
  { id:'bahr-ghazal', name:'بحر الغزال', kind:'tributary', coords:[[25.90,8.25],[26.55,8.34],[27.20,8.45],[27.90,8.57],[28.55,8.72],[29.20,8.87],[29.90,9.03],[30.60,9.23],[31.10,9.38]], labelCoord:[28.5,8.75] },
  { id:'sobat', name:'نهر السوباط', kind:'tributary', coords:[[34.60,7.75],[34.15,7.95],[33.75,8.20],[33.30,8.50],[32.92,8.78],[32.55,9.03],[32.18,9.30],[31.65,9.55]], labelCoord:[33.1,8.6] },
  { id:'white-nile', name:'النيل الأبيض', kind:'white', coords:[[31.65,9.55],[31.72,10.18],[31.84,10.85],[31.98,11.55],[32.10,12.25],[32.22,12.95],[32.36,13.65],[32.48,14.35],[32.49,15.23],[32.54,15.60]], labelCoord:[32.05,12.2] },
  { id:'blue-nile', name:'النيل الأزرق', kind:'blue', coords:[[37.30,11.60],[36.95,11.72],[36.55,11.62],[36.15,11.48],[35.75,11.24],[35.35,11.08],[35.10,11.15],[34.72,11.43],[34.40,11.80],[34.02,12.42],[33.68,13.10],[33.55,13.55],[33.30,14.16],[33.03,14.70],[32.72,15.20],[32.54,15.60]], labelCoord:[35.0,11.7] },
  { id:'atbara', name:'نهر عطبرة', kind:'tributary', coords:[[38.30,13.40],[37.90,13.62],[37.50,13.92],[37.10,14.35],[36.70,14.82],[36.25,15.18],[35.75,15.48],[35.30,15.75],[34.92,16.18],[34.58,16.68],[34.30,17.18],[34.00,17.70],[33.55,17.95],[33.05,18.22],[32.55,18.50],[32.00,18.70]], labelCoord:[35.3,15.8] },
  { id:'main-nile', name:'النيل الرئيسي', kind:'main', coords:[[32.54,15.60],[32.72,16.25],[32.88,16.90],[32.72,17.55],[32.38,18.15],[32.00,18.70],[32.18,19.35],[32.34,20.05],[32.26,20.85],[32.38,21.55],[32.70,22.25],[32.88,23.10],[32.88,23.97],[32.78,24.60],[32.64,25.15],[32.64,25.69],[32.45,26.02],[32.28,26.16],[31.98,26.38],[31.80,26.55],[31.52,26.82],[31.25,27.18],[31.16,27.70],[31.10,28.22],[31.05,28.72],[31.02,29.18],[31.10,29.62],[31.24,30.04],[31.18,30.35],[31.13,30.45],[31.10,30.70],[31.08,30.95]], labelCoord:[32.2,22.5] },
  { id:'delta-west', name:'فرع رشيد', kind:'delta', coords:deltaWest, labelCoord:[30.75,31.12] },
  { id:'delta-east', name:'فرع دمياط', kind:'delta', coords:deltaEast, labelCoord:[31.38,31.15] },
];

export const TEACHING_RIVER_PATHS = Object.freeze({
  egypt: [
    { id:'nile-egypt', name:'نهر النيل', kind:'main', coords:egyptNile, labelCoord:[31.45,27.7] },
    { id:'delta-west-egypt', name:'فرع رشيد', kind:'delta', coords:deltaWest, labelCoord:[30.75,31.12] },
    { id:'delta-east-egypt', name:'فرع دمياط', kind:'delta', coords:deltaEast, labelCoord:[31.38,31.15] },
  ],
  arab: [
    { id:'nile-arab', name:'نهر النيل', kind:'main', coords:[[31.60,4.85],[31.55,6.05],[31.30,7.35],[31.05,8.65],[31.65,9.55],[31.84,10.85],[32.10,12.25],[32.36,13.65],[32.54,15.60],[32.88,16.90],[32.00,18.70],[32.34,20.05],[32.70,22.25],[32.88,23.97],[32.64,25.69],[32.28,26.16],[31.80,26.55],[31.25,27.18],[31.02,29.18],[31.24,30.04],[31.08,30.95]], labelCoord:[32.2,22.5] },
    { id:'tigris', name:'نهر دجلة', kind:'river', coords:[[39.6,38.4],[41.0,36.0],[43.1,34.3],[44.4,33.3],[47.0,31.0]], labelCoord:[43.1,34.3] },
    { id:'euphrates', name:'نهر الفرات', kind:'river', coords:[[38.2,38.8],[39.9,36.6],[40.8,35.1],[42.1,34.2],[44.2,32.2],[47.0,30.8]], labelCoord:[42.1,34.2] },
  ],
  africa: nileBasin,
  nile: nileBasin,
});

export const TEACHING_WATER_BODIES = Object.freeze({
  nile: [
    { id:'victoria-basin', name:'بحيرة فيكتوريا', kind:'lake', coords:[[31.6,-1.5],[32.2,-2.1],[33.2,-2.4],[34.1,-1.7],[34.7,-0.5],[34.3,0.4],[33.3,0.6],[32.2,0.2]] },
    { id:'albert-basin', name:'بحيرة ألبرت', kind:'lake', coords:[[30.55,2.3],[30.75,1.9],[30.95,1.45],[31.15,1.7],[31.08,2.25],[30.8,2.55]] },
    { id:'kyoga-lake', name:'بحيرة كيوجا', kind:'lake', coords:[[32.5,1.2],[33.1,1.05],[33.65,1.35],[33.55,1.75],[32.9,1.9],[32.45,1.6]] },
    { id:'tana-basin', name:'بحيرة تانا', kind:'lake', coords:[[36.8,11.6],[37.4,11.55],[37.75,12.0],[37.55,12.55],[36.95,12.6],[36.65,12.1]] },
    { id:'sudd-wetlands', name:'مستنقعات السد', kind:'wetland', coords:[[30.6,5.8],[31.7,5.4],[32.2,6.4],[32.0,8.2],[31.1,8.7],[30.4,7.4]] },
    { id:'nasser-lake', name:'بحيرة ناصر', kind:'reservoir', coords:[[32.6,22.0],[32.85,22.8],[32.95,23.6],[32.82,24.0],[32.65,23.2],[32.45,22.4]] },
  ],
  egypt: [
    { id:'nasser-lake', name:'بحيرة ناصر', kind:'reservoir', coords:[[32.6,22.0],[32.85,22.8],[32.95,23.6],[32.82,24.0],[32.65,23.2],[32.45,22.4]] },
  ],
  africa: [
    { id:'victoria-basin', name:'بحيرة فيكتوريا', kind:'lake', coords:[[31.6,-1.5],[32.2,-2.1],[33.2,-2.4],[34.1,-1.7],[34.7,-0.5],[34.3,0.4],[33.3,0.6],[32.2,0.2]] },
  ],
});

export const NILE_LANDMARKS = Object.freeze([
  { id:'victoria', name:'بحيرة فيكتوريا', coord:[33.0,-1.0], kind:'source' },
  { id:'edward', name:'بحيرة إدوارد', coord:[29.60,-0.33], kind:'lake' },
  { id:'kyoga', name:'بحيرة كيوجا', coord:[33.0,1.5], kind:'lake' },
  { id:'albert', name:'بحيرة ألبرت', coord:[30.9,1.7], kind:'lake' },
  { id:'owen', name:'سد أوين', coord:[33.19,0.44], kind:'dam' },
  { id:'sudd', name:'مستنقعات السد', coord:[31.25,7.0], kind:'wetland' },
  { id:'jebel-aulia', name:'خزان جبل الأولياء', coord:[32.49,15.23], kind:'dam' },
  { id:'sennar', name:'خزان سنار', coord:[33.62,13.55], kind:'dam' },
  { id:'tana', name:'بحيرة تانا', coord:[37.30,12.0], kind:'source' },
  { id:'khartoum', name:'ملتقى النيلين — الخرطوم', coord:[32.56,15.50], kind:'confluence' },
  { id:'atbara-city', name:'عطبرة', coord:[33.98,17.70], kind:'confluence' },
  { id:'lake-nasser', name:'بحيرة ناصر', coord:[32.75,22.8], kind:'lake' },
  { id:'aswan', name:'السد العالي — أسوان', coord:[32.90,24.09], kind:'dam' },
  { id:'cairo', name:'القاهرة', coord:[31.2357,30.0444], kind:'city' },
  { id:'delta', name:'دلتا النيل', coord:[31.12,30.95], kind:'delta' },
  { id:'rosetta-mouth', name:'مصب فرع رشيد — البحر المتوسط', coord:[30.42,31.40], kind:'mouth' },
  { id:'damietta-mouth', name:'مصب فرع دمياط — البحر المتوسط', coord:[31.81,31.42], kind:'mouth' },
  { id:'mediterranean', name:'البحر المتوسط', coord:[31.10,32.2], kind:'sea' },
]);

export function getTeachingRiverPaths(regionKey) {
  return TEACHING_RIVER_PATHS[regionKey] || [];
}
