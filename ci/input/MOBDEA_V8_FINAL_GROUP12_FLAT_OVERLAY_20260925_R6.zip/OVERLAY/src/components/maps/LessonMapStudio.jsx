import { memo, useEffect, useMemo, useRef, useState } from 'react';
import worldCountries from '../../data/world-countries.json';
import { COUNTRY_CARD_MAP } from '../../data/countryCards.js';
import { allMapCountryCards, teachingCategoryForLayer, resolveMapSelection } from '../../services/mapTeachingSelection.js';
import { countryCardByIso } from '../../services/mapCountryCard.js';
import { normalizeCountryCardName } from '../../services/countryCardCatalog.js';
import {
  Compass,
  Eraser,
  Eye,
  EyeOff,
  Highlighter,
  Layers3,
  SlidersHorizontal,
  MapPin,
  PenLine,
  RotateCcw,
  Save,
  Search,
  Trash2,
  Type,
  Undo2,
  Volume2,
  Waves,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import ProfessionalMap, { GeographyGlyph } from './ProfessionalMap';
import { percentWithinMapViewport } from '../../services/mapSvgViewport.js';
import '../../styles/v8-group10-map-interactions.css';
import { normalizeLessonMapState, normalizeMapRegionSnapshot } from '../../services/lessonMapState';
import {
  GEOGRAPHY_LAYERS,
  GEOGRAPHY_TEACHING_CATEGORIES,
  GEOGRAPHY_REGIONS,
  GEOGRAPHY_SYMBOL_GROUPS,
  createMapProjector,
  getGradeMapRecommendation,
  getRegionCountries,
  getRegionLayerItems,
} from '../../data/geography';
import {
  MAP_RIVER_LINES,
  flagEmoji,
  NILE_BASIN_ISO,
  NILE_POINTS,
  countryInfo,
  featureInfo,
} from '../../data/mapEnrichment';

const CORE_REGION_KEYS = ['egypt', 'arab', 'africa', 'asia', 'europe', 'eurasia', 'northAmerica', 'southAmerica', 'australia', 'world'];

function drawStrokes(canvas, strokes = []) {
  if (!canvas) return;
  const context = canvas.getContext('2d');
  context.clearRect(0, 0, 1000, 620);
  strokes.forEach((stroke) => {
    context.save();
    context.lineCap = 'round';
    context.lineJoin = 'round';
    context.globalAlpha = stroke.tool === 'highlighter' ? 0.3 : 1;
    context.globalCompositeOperation = stroke.tool === 'eraser' ? 'destination-out' : 'source-over';
    context.strokeStyle = stroke.color || '#ef4444';
    context.lineWidth = stroke.tool === 'eraser' ? 30 : stroke.tool === 'highlighter' ? 18 : stroke.width || 5;
    const points = stroke.points || [];
    if (points.length) {
      context.beginPath();
      context.moveTo(points[0].x, points[0].y);
      for (let index = 1; index < points.length - 1; index += 1) {
        const point = points[index];
        const next = points[index + 1];
        context.quadraticCurveTo(point.x, point.y, (point.x + next.x) / 2, (point.y + next.y) / 2);
      }
      if (points.length > 1) context.lineTo(points.at(-1).x, points.at(-1).y);
      context.stroke();
    }
    context.restore();
  });
}

const PROJECT12_MAP_SYMBOL_DRAWER_V1 = true;

function LessonMapStudio({ grade = '', lesson = null, onSaveState }) {
  const recommendation = useMemo(() => getGradeMapRecommendation(grade), [grade]);
  const initial = useMemo(() => normalizeLessonMapState(lesson?.mapState, grade), [lesson?.id, grade]);
  const [geo] = useState(worldCountries);
  const [regionKey, setRegionKey] = useState(initial.regionKey);
  const [regionStates, setRegionStates] = useState(initial.regions);
  const [layerKey, setLayerKey] = useState(initial.layerKey || 'countries');
  const [teachingCategory, setTeachingCategory] = useState(teachingCategoryForLayer(initial.layerKey));
  const [labels, setLabels] = useState(initial.labels);
  const [mapDisplayMode, setMapDisplayMode] = useState(initial.displayMode || 'atlas');
  const [mapStyle, setMapStyle] = useState(initial.mapStyle || 'relief');
  const [silentMap, setSilentMap] = useState(initial.silentMap === true);
  const [zoom, setZoom] = useState(initial.zoom);
  const [placements, setPlacements] = useState(initial.placements);
  const [strokes, setStrokes] = useState(initial.strokes);
  const [selectedId, setSelectedId] = useState(initial.selectedCountryId || initial.selectedPlaceId);
  const [selectedName, setSelectedName] = useState('');
  const [selectedSymbol, setSelectedSymbol] = useState(null);
  const [selectedPlacementId, setSelectedPlacementId] = useState('');
  const [symbolGroup, setSymbolGroup] = useState(GEOGRAPHY_SYMBOL_GROUPS[0].id);
  const [project12SymbolsOpen, setProject12SymbolsOpen] = useState(false);
  const [drawTool, setDrawTool] = useState('select');
  const [drawColor, setDrawColor] = useState('#ef4444');
  const [strokeWidth, setStrokeWidth] = useState(5);
  const [search, setSearch] = useState('');
  const [customLabel, setCustomLabel] = useState('');
  const [notice, setNotice] = useState('');
  const [dirty, setDirty] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const [mapControlsOpen, setMapControlsOpen] = useState(false);
  const [quickToolsOpen, setQuickToolsOpen] = useState(false);
  const [floatingControlPosition, setFloatingControlPosition] = useState(null);
  const [selectedEntity, setSelectedEntity] = useState(() => resolveMapSelection(worldCountries, initial.regionKey, initial.layerKey, initial.selectedCountryId || initial.selectedPlaceId));
  const [countryCardsOpen, setCountryCardsOpen] = useState(false);
  const [countryCardQuery, setCountryCardQuery] = useState('');
  const [countryCardImageFailed, setCountryCardImageFailed] = useState(false);
  const allCountryCards = useMemo(() => allMapCountryCards(), []);
  const [nileMode, setNileMode] = useState(initial.regionKey === 'nile');
  const previousRegionBeforeNileRef = useRef(initial.regionKey === 'nile' ? 'egypt' : initial.regionKey);
  const canvasRef = useRef(null);
  const drawingRef = useRef(false);
  const currentStrokeRef = useRef(null);
  const latestStateRef = useRef(null);
  const latestDirtyRef = useRef(false);
  const changeVersionRef = useRef(0);
  const saveCallbackRef = useRef(onSaveState);
  const saveQueueRef = useRef(Promise.resolve());
  const symbolPointerRef = useRef(null);
  const floatingControlDragRef = useRef(null);
  const floatingControlDraggedRef = useRef(false);

  saveCallbackRef.current = onSaveState;
  latestDirtyRef.current = dirty;

  const persistMapSnapshot = (snapshot, saveForLesson = saveCallbackRef.current) => {
    // Capture the lesson-specific callback at enqueue time. A save queued before
    // switching lessons must never be routed to the next lesson’s callback.
    const state = snapshot;
    const operation = saveQueueRef.current.catch(() => {}).then(() => {
      if (saveForLesson === onSaveState) return onSaveState?.(state);
      return saveForLesson?.(state);
    });
    saveQueueRef.current = operation;
    return operation;
  };

  useEffect(() => {
    const next = normalizeLessonMapState(lesson?.mapState, grade);
    setRegionKey(next.regionKey);
    setRegionStates(next.regions);
    setLayerKey(next.layerKey || 'countries');
    setTeachingCategory(teachingCategoryForLayer(next.layerKey));
    previousRegionBeforeNileRef.current = next.regionKey === 'nile' ? 'egypt' : next.regionKey;
    setLabels(next.labels);
    setMapDisplayMode(next.displayMode || 'atlas');
    setMapStyle(next.mapStyle || 'relief');
    setSilentMap(next.silentMap === true);
    setZoom(next.zoom);
    setPlacements(next.placements);
    setStrokes(next.strokes);
    setSelectedId(next.selectedCountryId || next.selectedPlaceId);
    setSelectedName('');
    setSelectedEntity(resolveMapSelection(worldCountries, next.regionKey, next.layerKey, next.selectedCountryId || next.selectedPlaceId));
    setCountryCardsOpen(false);
    setSelectedPlacementId('');
    setNileMode(next.regionKey === 'nile');
    changeVersionRef.current = 0;
    latestDirtyRef.current = false;
    setDirty(false);
  }, [lesson?.id, grade]);

  useEffect(() => drawStrokes(canvasRef.current, strokes), [strokes, regionKey, layerKey, zoom]);

  const region = GEOGRAPHY_REGIONS[regionKey] || GEOGRAPHY_REGIONS.world;
  const project = useMemo(() => createMapProjector(regionKey), [regionKey]);
  const countries = useMemo(() => getRegionCountries(geo, regionKey), [geo, regionKey]);
  const items = useMemo(() => getRegionLayerItems(geo, regionKey, layerKey), [geo, regionKey, layerKey]);
  // The teaching SVG draws Egypt/Nile rivers and landmarks once, with a single
  // set of selectable paths. Duplicating legacy overlays obscured labels and clicks.
  const riverLines = useMemo(() => ['nile', 'egypt'].includes(regionKey) ? [] : (MAP_RIVER_LINES[regionKey] || []), [regionKey]);
  // Keep the three additional Sudan/Ethiopia dams not already represented by
  // the detailed teaching landmark layer, without drawing duplicated markers.
  const nilePoints = nileMode ? NILE_POINTS.filter((point) => ['gerd', 'roseires', 'merowe'].includes(point.id)) : [];
  const activeGroup = GEOGRAPHY_SYMBOL_GROUPS.find((group) => group.id === symbolGroup) || GEOGRAPHY_SYMBOL_GROUPS[0];
  const searchable = useMemo(() => [
    ...getRegionLayerItems(geo, regionKey, 'countries').map((item) => ({ ...item, layer: 'countries' })),
    ...Object.keys(GEOGRAPHY_LAYERS).filter((key) => key !== 'countries').flatMap((key) => getRegionLayerItems(geo, regionKey, key).map((item) => ({ ...item, layer: key }))),
  ], [geo, regionKey]);
  const searchResults = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return [];
    return searchable.filter((item) => item.name.toLowerCase().includes(query)).slice(0, 8);
  }, [search, searchable]);

  const markDirty = () => {
    changeVersionRef.current += 1;
    latestDirtyRef.current = true;
    setDirty(true);
  };

  const selectLocation = (id, name, item = null) => {
    setSelectedId(id);
    setSelectedName(name);
    if (item?.geometry || item?.feature?.geometry) {
      setSelectedEntity({ type: 'country', ...countryInfo(item.feature || item) });
      setCountryCardImageFailed(false);
      setCountryCardsOpen(false);
    } else if (item) {
      setSelectedEntity({ type: 'feature', ...featureInfo(item, layerKey), raw: item });
    } else {
      setSelectedEntity(null);
    }
    markDirty();
  };

  const selectedCountryCard = selectedEntity?.type === 'country' ? (countryCardByIso(selectedEntity.iso) || allCountryCards.find(card => card.iso === selectedEntity.iso)) : null;
  const normalizedCardSearch = normalizeCountryCardName(countryCardQuery);
  const filteredCountryCards = allCountryCards.filter((card) => normalizeCountryCardName(`${card.name} ${card.capital} ${card.region} ${card.iso}`).includes(normalizedCardSearch));
  const openCountryCard = (card) => {
    // All 172 source-map countries/territories are browsable. If a country is
    // outside the current region, switch to the world before highlighting it.
    if (!getRegionLayerItems(geo, regionKey, 'countries').some((item) => item.id === card.iso)) changeRegion('world');
    setLayerKey('countries');
    setTeachingCategory('political');
    setSilentMap(false);
    setMapDisplayMode('atlas');
    setLabels(true);
    setSelectedEntity({ type: 'country', iso: card.iso, name: card.name, capital: card.capital, region: card.region, fact: card.fact, flag: card.flag || flagEmoji(card.iso), image: card.asset });
    setCountryCardImageFailed(false);
    setCountryCardsOpen(false);
    setSelectedId(card.iso);
    setSelectedName(card.name);
    markDirty();
  };

  const speakSelectedEntity = () => {
    if (!selectedEntity || typeof window === 'undefined' || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const text = selectedEntity.type === 'country'
      ? `${selectedEntity.name}. العاصمة ${selectedEntity.capital}. ${selectedEntity.fact}`
      : `${selectedEntity.name}. ${selectedEntity.fact}`;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'ar-EG';
    utterance.rate = 0.88;
    window.speechSynthesis.speak(utterance);
  };

  const addPlacement = (item, x, y) => {
    if (!item) return;
    const placement = {
      ...item,
      type: item.id,
      id: `${item.id}:${Date.now()}:${Math.random().toString(36).slice(2, 7)}`,
      x: Math.max(0, Math.min(100, x)),
      y: Math.max(0, Math.min(100, y)),
      size: Number(item.size || 1),
    };
    setPlacements((current) => [...current, placement]);
    setSelectedPlacementId(placement.id);
    setSelectedSymbol(null);
    if (item.id !== 'custom-label') setToolsOpen(false);
    markDirty();
  };

  const clientPointToLessonMapPercent = (clientX, clientY, stage = null) => {
    const rect = stage?.querySelector?.('.map-pro-placement-layer')?.getBoundingClientRect?.();
    // Do not clamp an off-map release to the border; that silently creates
    // a misleading marker, especially after pinch/pan and SVG letterboxing.
    return percentWithinMapViewport(clientX, clientY, rect);
  };

  const stagePointPercent = (event) =>
    clientPointToLessonMapPercent(
      event.clientX,
      event.clientY,
      event.currentTarget?.closest?.('.map-pro-stage') || event.currentTarget,
    );

  const handleStageClick = (event) => {
    if (drawTool !== 'select') return;
    const point = stagePointPercent(event);
    if (!point) return;
    if (selectedSymbol) {
      addPlacement(selectedSymbol, point.x, point.y);
      return;
    }
    if (customLabel.trim()) {
      addPlacement({ id: 'custom-label', label: customLabel.trim(), hint: '', symbol: '✎', color: drawColor, showLabel: true }, point.x, point.y);
      setCustomLabel('');
      return;
    }
    setSelectedPlacementId('');
  };

  const handleLocationClick = (id, name, item, event) => {
    if (drawTool === 'select' && selectedSymbol && event) {
      const point = stagePointPercent(event);
      if (!point) return;
      addPlacement(selectedSymbol, point.x, point.y);
      return;
    }
    selectLocation(id, name, item);
  };

  const handleDrop = (event) => {
    event.preventDefault();
    event.stopPropagation();
    try {
      const item = JSON.parse(event.dataTransfer.getData('application/json'));
      const point = stagePointPercent(event);
      if (!point) throw new Error('map-transform-unavailable');
      addPlacement(item, point.x, point.y);
    } catch {
      setNotice('تعذر وضع الشكل في هذا الموضع.');
    }
  };

  const startSymbolPointer = (event, item) => {
    setDrawTool('select');
    setSelectedSymbol(item);
    if (event.pointerType === 'mouse') return;
    symbolPointerRef.current = {
      item,
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      dragging: false,
      scrolling: false,
    };
  };

  useEffect(() => {
    const move = (event) => {
      const pending = symbolPointerRef.current;
      if (!pending || pending.pointerId !== event.pointerId) return;
      const dx = event.clientX - pending.startX;
      const dy = event.clientY - pending.startY;
      if (!pending.dragging && !pending.scrolling) {
        if (Math.abs(dy) > 10 && Math.abs(dy) > Math.abs(dx) * 1.15) {
          pending.scrolling = true;
          return;
        }
        if (Math.hypot(dx, dy) > 18) pending.dragging = true;
      }
    };
    const finish = (event) => {
      const pending = symbolPointerRef.current;
      if (!pending || pending.pointerId !== event.pointerId) return;
      symbolPointerRef.current = null;
      if (!pending.dragging || pending.scrolling) return;
      const stage = document.elementFromPoint(event.clientX, event.clientY)?.closest?.('.map-pro-stage');
      if (!stage) return;
      const point = clientPointToLessonMapPercent(
        event.clientX,
        event.clientY,
        stage,
      );
      if (!point) return;
      addPlacement(pending.item, point.x, point.y);
      setToolsOpen(false);
    };
    window.addEventListener('pointermove', move, { passive: true });
    window.addEventListener('pointerup', finish, { passive: true });
    window.addEventListener('pointercancel', finish, { passive: true });
    return () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', finish);
      window.removeEventListener('pointercancel', finish);
    };
  }, []);

  const mapPoint = (event) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const source = event.touches?.[0] || event;
    return { x: ((source.clientX - rect.left) / rect.width) * 1000, y: ((source.clientY - rect.top) / rect.height) * 620 };
  };

  const onPointerDown = (event) => {
    if (!['pen', 'highlighter', 'eraser'].includes(drawTool)) return;
    event.preventDefault();
    drawingRef.current = true;
    currentStrokeRef.current = {
      id: `stroke:${Date.now()}`,
      tool: drawTool,
      color: drawColor,
      width: strokeWidth,
      points: [mapPoint(event)],
    };
  };

  const onPointerMove = (event) => {
    if (!drawingRef.current || !currentStrokeRef.current) return;
    event.preventDefault();
    const nativeEvent = event.nativeEvent || event;
    const samples = nativeEvent.getCoalescedEvents?.() || [nativeEvent];
    for (const sample of samples) {
      const point = mapPoint(sample);
      const points = currentStrokeRef.current.points;
      const previous = points.at(-1);
      if (!previous) { points.push(point); continue; }
      const dx = point.x - previous.x;
      const dy = point.y - previous.y;
      const distance = Math.hypot(dx, dy);
      if (distance < 0.8) continue;
      // Fill gaps caused by slow touch event delivery on tablets.
      const steps = Math.max(1, Math.ceil(distance / 4));
      for (let step = 1; step <= steps; step += 1) {
        points.push({ x: previous.x + (dx * step) / steps, y: previous.y + (dy * step) / steps });
      }
    }
    drawStrokes(canvasRef.current, [...strokes, currentStrokeRef.current]);
  };

  const onPointerUp = () => {
    if (drawingRef.current && currentStrokeRef.current) {
      setStrokes((current) => [...current, currentStrokeRef.current]);
      markDirty();
    }
    drawingRef.current = false;
    currentStrokeRef.current = null;
  };

  const beginFloatingControlDrag = (event) => {
    if (event.button != null && event.button !== 0) return;
    const rect = event.currentTarget.getBoundingClientRect();
    floatingControlDragRef.current = { pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, offsetX: event.clientX - rect.left, offsetY: event.clientY - rect.top, width: rect.width, height: rect.height };
    floatingControlDraggedRef.current = false;
    try { event.currentTarget.setPointerCapture?.(event.pointerId); } catch { /* optional */ }
  };
  const moveFloatingControl = (event) => {
    const drag = floatingControlDragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    if (Math.hypot(event.clientX - drag.startX, event.clientY - drag.startY) > 5) floatingControlDraggedRef.current = true;
    if (!floatingControlDraggedRef.current) return;
    event.preventDefault();
    const stage = event.currentTarget.closest('.lesson-map-main')?.getBoundingClientRect();
    if (!stage) return;
    setFloatingControlPosition({
      x: Math.max(6, Math.min(stage.width - drag.width - 6, event.clientX - stage.left - drag.offsetX)),
      y: Math.max(6, Math.min(stage.height - drag.height - 6, event.clientY - stage.top - drag.offsetY)),
    });
  };
  const endFloatingControlDrag = () => { floatingControlDragRef.current = null; };
  const suppressFloatingControlClick = (event) => {
    if (!floatingControlDraggedRef.current) return;
    event.preventDefault(); event.stopPropagation(); floatingControlDraggedRef.current = false;
  };

  const currentRegionSnapshot = () => ({
    displayMode: mapDisplayMode,
    mapStyle,
    silentMap,
    labels,
    layerKey,
    selectedCountryId: ['countries', 'borders', 'population'].includes(layerKey) ? selectedId : '',
    selectedPlaceId: !['countries', 'borders', 'population'].includes(layerKey) ? selectedId : '',
    zoom,
    placements,
    strokes,
  });

  const activeSnapshot = currentRegionSnapshot();
  const persistableState = {
    regionKey,
    regions: { ...regionStates, [regionKey]: activeSnapshot },
    ...activeSnapshot,
  };
  latestStateRef.current = persistableState;

  useEffect(() => {
    if (!dirty || !lesson?.id || !saveCallbackRef.current) return undefined;
    const scheduledVersion = changeVersionRef.current;
    const timer = window.setTimeout(() => {
      const state = latestStateRef.current;
      persistMapSnapshot(state)
        .then(() => {
          // Older async save responses must not erase a more recent region switch.
          if (changeVersionRef.current === scheduledVersion) {
            latestDirtyRef.current = false;
            setDirty(false);
          }
        })
        .catch(() => setNotice('تعذر الحفظ التلقائي للخريطة — استخدم زر حفظ.'));
    }, 900);
    return () => window.clearTimeout(timer);
  }, [dirty, lesson?.id, regionKey, labels, mapStyle, silentMap, mapDisplayMode, zoom, placements, strokes, selectedId, layerKey]);

  useEffect(() => {
    const saveForLesson = onSaveState;
    return () => {
      if (!lesson?.id || !latestDirtyRef.current || !saveForLesson || !latestStateRef.current) return;
      // Preserve a pending snapshot under the lesson that owned the editor.
      void persistMapSnapshot(latestStateRef.current, saveForLesson).catch(() => {});
    };
  }, [lesson?.id]);

  const loadRegionSnapshot = (snapshot, activeLayer = 'countries', targetRegion = regionKey) => {
    const normalized = normalizeMapRegionSnapshot(snapshot);
    setMapDisplayMode(normalized.displayMode || 'atlas');
    setMapStyle(normalized.mapStyle || 'relief');
    setSilentMap(normalized.silentMap === true);
    setLabels(normalized.labels);
    const restoredLayer = snapshot?.layerKey ? normalized.layerKey : activeLayer;
    setLayerKey(normalized.layerKey && snapshot?.layerKey ? normalized.layerKey : activeLayer);
    setTeachingCategory(teachingCategoryForLayer(restoredLayer));
    setZoom(normalized.zoom);
    setPlacements(normalized.placements);
    setStrokes(normalized.strokes);
    const selected = ['countries', 'borders', 'population'].includes(restoredLayer) ? normalized.selectedCountryId : normalized.selectedPlaceId;
    const entity = resolveMapSelection(geo, targetRegion, restoredLayer, selected);
    setSelectedId(selected);
    setSelectedName(entity?.name || '');
    setSelectedEntity(entity);
    setSelectedSymbol(null);
    setSelectedPlacementId('');
  };

  const changeRegion = (key) => {
    if (!GEOGRAPHY_REGIONS[key] || key === regionKey) return;
    const nextStates = { ...regionStates, [regionKey]: currentRegionSnapshot() };
    setRegionStates(nextStates);
    if (key !== 'nile') previousRegionBeforeNileRef.current = key;
    else if (regionKey !== 'nile') previousRegionBeforeNileRef.current = regionKey;
    setRegionKey(key);
    setNileMode(key === 'nile');
    loadRegionSnapshot(nextStates[key] || {}, key === 'nile' ? 'rivers' : 'countries', key);
    markDirty();
  };

  const toggleNileLesson = () => {
    const nextStates = { ...regionStates, [regionKey]: currentRegionSnapshot() };
    if (nileMode) {
      // Close the detailed view by restoring the previous REAL region and its
      // own layer/zoom/placements; do not leave the map stuck on Nile bounds.
      const returnRegion = GEOGRAPHY_REGIONS[previousRegionBeforeNileRef.current]
        && previousRegionBeforeNileRef.current !== 'nile'
        ? previousRegionBeforeNileRef.current : 'egypt';
      setRegionStates(nextStates);
      setRegionKey(returnRegion);
      setNileMode(false);
      loadRegionSnapshot(nextStates[returnRegion] || {}, 'countries', returnRegion);
    } else {
      if (regionKey !== 'nile') previousRegionBeforeNileRef.current = regionKey;
      setRegionStates(nextStates);
      setRegionKey('nile');
      setNileMode(true);
      loadRegionSnapshot(nextStates.nile || {}, 'rivers', 'nile');
      setLayerKey('rivers');
      setTeachingCategory('water');
      setSilentMap(false);
      setMapStyle('atlas');
      setMapDisplayMode('atlas');
      setLabels(true);
      setSelectedEntity({ type:'feature', name:'نهر النيل', kind:'river', fact:'خريطة تعليمية مركزة على مجرى النيل الرئيسي والنيل الأبيض والنيل الأزرق ونهر عطبرة والبحيرات والسدود.' });
    }
    markDirty();
  };

  const changeZoom = (delta) => {
    setZoom((value) => Math.max(1, Math.min(3.2, Number((value + delta).toFixed(2)))));
    markDirty();
  };

  const save = async () => {
    if (!lesson || !onSaveState) {
      setNotice('اختر درسًا من المكتبة مع إتاحة الحفظ أولًا حتى تُحفظ الخريطة داخله.');
      return;
    }
    const state = latestStateRef.current || persistableState;
    const saveVersion = changeVersionRef.current;
    try {
      await persistMapSnapshot(state);
    } catch {
      setNotice('تعذر حفظ الخريطة. أعد المحاولة.');
      return;
    }
    // setRegionStates(nextRegions) here would discard snapshots made during
    // the async write; switching regions maintains its own regionStates.
    if (changeVersionRef.current === saveVersion) {
      latestDirtyRef.current = false;
      setDirty(false);
      setNotice('تم الحفظ.');
      window.setTimeout(() => setNotice(''), 1600);
    }
  };

  const resetMap = () => {
    setZoom(1);
    setSelectedId('');
    setSelectedName('');
    setSelectedEntity(null);
    setPlacements([]);
    setStrokes([]);
    setSelectedSymbol(null);
    setSelectedPlacementId('');
    markDirty();
  };

  return (
    <div className={`lesson-map-studio lesson-map-studio-v5 ${toolsOpen ? 'tools-open symbols-open' : 'tools-closed'} ${mapControlsOpen ? 'map-controls-open' : ''}`}>
      <button type="button" className={`project12-map-symbol-toggle ${project12SymbolsOpen ? "active" : ""}`} onClick={() => { const next = !toolsOpen; setProject12SymbolsOpen(next); setToolsOpen(next); setMapControlsOpen(false); }} title="رموز الخريطة"><Layers3 size={16}/> رموز الخريطة</button>
      {toolsOpen && (
        <aside className={`lesson-map-symbol-sidebar lesson-map-drawer lesson-map-drawer-symbols ${project12SymbolsOpen ? "project12-open" : ""}`}>
          <div className="lesson-map-drawer-head">
            <div className="lesson-map-sidebar-title"><Layers3 size={19}/><div><strong>رموز الخريطة</strong><small>19 تصنيفًا • 181 رمزًا — اختر التصنيف ثم اسحب الرمز إلى الخريطة</small></div></div>
            <button type="button" className="icon-action" onClick={() => setToolsOpen(false)} aria-label="إغلاق الرموز">×</button>
          </div>
          <div className="lesson-map-group-tabs" aria-label="تصنيفات رموز الخرائط">
            {GEOGRAPHY_SYMBOL_GROUPS.map((group) => <button key={group.id} type="button" className={symbolGroup === group.id ? 'active' : ''} onClick={() => setSymbolGroup(group.id)}>{group.label}</button>)}
          </div>
          <div className="lesson-map-active-group-heading"><strong>{activeGroup.label}</strong><small>{activeGroup.items.length} رمز</small></div>
          <div className="lesson-map-symbol-scroll">
            <div className="lesson-map-symbol-list">
              {activeGroup.items.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  className={selectedSymbol?.id === item.id ? 'active' : ''}
                  style={{ '--symbol-color': item.color }}
                  onPointerDown={(event) => startSymbolPointer(event, item)}
                  onPointerCancel={() => { symbolPointerRef.current = null; }}
                  onClick={() => { setDrawTool('select'); setSelectedSymbol(item); }}
                >
                  <b className="lesson-map-symbol-preview"><GeographyGlyph type={item.id} symbol={item.symbol} /></b>
                  <span><strong>{item.label}</strong><small>{item.hint}</small></span>
                </button>
              ))}
            </div>
            <div className="lesson-map-custom-label">
              <Type size={16}/><input value={customLabel} onChange={(event) => setCustomLabel(event.target.value)} placeholder="اسم مكان أو ملاحظة" />
              <button type="button" onClick={() => { if (customLabel.trim()) { setDrawTool('select'); setSelectedSymbol(null); } }}>وضع</button>
            </div>
            {placements.length > 0 && (
              <div className="lesson-map-placed-list">
                <strong>العناصر الموضوعة ({placements.length})</strong>
                {placements.slice().reverse().map((item) => <button key={item.id} type="button" onClick={() => { setPlacements((current) => current.filter((entry) => entry.id !== item.id)); setSelectedPlacementId((current) => current === item.id ? '' : current); markDirty(); }}><span><GeographyGlyph type={item.type} symbol={item.symbol}/> {item.label}</span><Trash2 size={14}/></button>)}
              </div>
            )}
          </div>
        </aside>
      )}

      {mapControlsOpen && (
        <aside className="lesson-map-drawer lesson-map-drawer-controls">
          <div className="lesson-map-drawer-head">
            <div className="lesson-map-sidebar-title"><Compass size={19}/><div><strong>الخرائط والتحديد</strong><small>الخريطة، الطبقات، المعلومات والبحث</small></div></div>
            <button type="button" className="icon-action" onClick={() => setMapControlsOpen(false)} aria-label="إغلاق أدوات الخرائط">×</button>
          </div>
          <div className="lesson-map-controls-scroll">
            <section className="lesson-map-control-section">
              <label>الخريطة</label>
              <div className="lesson-map-region-grid" aria-label="الخرائط الأساسية">
                {CORE_REGION_KEYS.map((key) => {
                  const item = GEOGRAPHY_REGIONS[key];
                  return (
                    <button key={key} type="button" className={`${regionKey === key ? 'active' : ''} ${recommendation.recommended.includes(key) ? 'recommended' : ''}`} onClick={() => changeRegion(key)}>
                      <span className={`region-mini-map region-${key}`} aria-hidden="true" />
                      <strong>{item.title}</strong>
                      <small>{key === 'world' ? 'خريطة العالم كاملة' : item.subtitle}</small>
                    </button>
                  );
                })}
              </div>

            </section>
            <section className="lesson-map-control-section">
              <label>شكل الخريطة</label>
              <div className="lesson-map-presentation-tabs project06-map-display-modes" role="group" aria-label="نمط عرض الخريطة">
                <button type="button" className={!silentMap && mapStyle === 'relief' ? 'active' : ''} onClick={() => { setSilentMap(false); setMapStyle('relief'); setMapDisplayMode('atlas'); setLabels(true); markDirty(); }}>طبيعية مجسمة</button>
                <button type="button" className={!silentMap && mapStyle === 'atlas' && mapDisplayMode === 'atlas' && labels ? 'active' : ''} onClick={() => { setSilentMap(false); setMapStyle('atlas'); setMapDisplayMode('atlas'); setLabels(true); markDirty(); }}>أطلس تعليمي بأسماء الدول</button>
                <button type="button" className={!silentMap && mapStyle === 'atlas' && mapDisplayMode === 'atlas' && !labels ? 'active' : ''} onClick={() => { setSilentMap(false); setMapStyle('atlas'); setMapDisplayMode('atlas'); setLabels(false); markDirty(); }}>أطلس بدون أسماء</button>
                <button type="button" className={silentMap || mapDisplayMode === 'blank' ? 'active' : ''} onClick={() => { setSilentMap(true); setMapStyle('atlas'); setMapDisplayMode('blank'); setLabels(false); markDirty(); }}>خريطة صماء</button>
              </div>
              <small className="lesson-map-silent-help">الخريطة الصماء تعرض شكل اليابس والمياه فقط لتشرح وتكتب عليها بنفسك.</small>
            </section>
            <section className="lesson-map-control-section lesson-map-nile-section">
              <label>درس نهر النيل</label>
              <button type="button" className={`lesson-map-nile-toggle ${nileMode ? 'active' : ''}`} onClick={toggleNileLesson}>
                <Waves size={18}/><span><strong>{nileMode ? 'إغلاق وضع نهر النيل' : 'فتح خريطة نهر النيل التفصيلية'}</strong><small>المجرى والروافد ودول الحوض والبحيرات والسدود</small></span>
              </button>
            </section>
            <section className="lesson-map-control-section">
              <label>الطبقات والتحديد</label>
              {regionKey === 'egypt' && (
                <div className="lesson-map-category-tabs" role="group" aria-label="تصنيفات خريطة مصر">
                  {Object.entries(GEOGRAPHY_TEACHING_CATEGORIES).map(([key, category]) => (
                    <button key={key} type="button" aria-pressed={teachingCategory === key} className={teachingCategory === key ? 'active' : ''}
                      onClick={() => { setTeachingCategory(key); setLayerKey(category.layers[0]); setSelectedId(''); setSelectedName(''); setSelectedEntity(null); markDirty(); }}>
                      {category.title}
                    </button>
                  ))}
                </div>
              )}
              <div className="lesson-map-layer-tabs">
                {Object.entries(GEOGRAPHY_LAYERS)
                  .filter(([key]) => regionKey !== 'egypt' || GEOGRAPHY_TEACHING_CATEGORIES[teachingCategory]?.layers.includes(key))
                  .map(([key, item]) => <button key={key} type="button" className={layerKey === key ? 'active' : ''} onClick={() => { setLayerKey(key); setSelectedId(''); setSelectedName(''); setSelectedEntity(null); markDirty(); }}>{item.title}</button>)}
              </div>
            </section>

            <section className="lesson-map-control-section">
              <label>بحث سريع</label>
              <div className="lesson-map-search"><Search size={16}/><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="دولة، جبل، نهر، عاصمة…" />
                {searchResults.length > 0 && <div className="lesson-map-search-results">{searchResults.map((item) => <button key={`${item.layer}:${item.id}`} type="button" onClick={() => { setLayerKey(item.layer); const entry = Object.entries(GEOGRAPHY_TEACHING_CATEGORIES).find(([, group]) => group.layers.includes(item.layer)); if (entry) setTeachingCategory(entry[0]); selectLocation(item.id, item.name, item); setSearch(''); markDirty(); }}>{item.name}<small>{GEOGRAPHY_LAYERS[item.layer]?.title}</small></button>)}</div>}
              </div>
            </section>
            <div className="lesson-map-control-summary">
              <strong>{selectedName || `خريطة ${region.title}`}</strong>
              <small>{region.subtitle} • {items.length} عنصر</small>
              {notice && <em>{notice}</em>}
            </div>
          </div>
        </aside>
      )}

      <div className="lesson-map-main lesson-map-main-v5">
        <button type="button" className="lesson-map-country-cards-toggle" onClick={() => setCountryCardsOpen((open) => !open)} aria-expanded={countryCardsOpen} aria-controls="lesson-map-country-cards" aria-label="عرض بطاقات الدول">بطاقات الدول ({allCountryCards.length})</button>
        {countryCardsOpen && <aside id="lesson-map-country-cards" className="lesson-map-country-cards-drawer" aria-label="مكتبة بطاقات الدول" dir="rtl">
          <div className="lesson-map-country-cards-head"><strong>بطاقات الدول</strong><button type="button" onClick={() => setCountryCardsOpen(false)} aria-label="إغلاق بطاقات الدول">×</button></div>
          <input type="search" value={countryCardQuery} onChange={(event) => setCountryCardQuery(event.target.value)} placeholder="ابحث عن دولة أو عاصمة..." aria-label="البحث في بطاقات الدول" />
          <div className="lesson-map-country-cards-list">{filteredCountryCards.map((card) => <button type="button" key={card.key} onClick={() => openCountryCard(card)}><strong>{card.name}</strong><small>{card.capital}</small></button>)}</div>
          {filteredCountryCards.length === 0 && <p>لا توجد دولة بهذا الاسم.</p>}
        </aside>}

        <div
          className={`lesson-map-floating-drawers ${floatingControlPosition ? 'is-positioned' : ''}`}
          style={floatingControlPosition ? { left: `${floatingControlPosition.x}px`, top: `${floatingControlPosition.y}px`, right: 'auto', bottom: 'auto' } : undefined}
          onPointerDown={beginFloatingControlDrag}
          onPointerMove={moveFloatingControl}
          onPointerUp={endFloatingControlDrag}
          onPointerCancel={endFloatingControlDrag}
          onClickCapture={suppressFloatingControlClick}
          onDoubleClick={() => setFloatingControlPosition(null)}
          title="اسحب الأدوات لأي مكان — ضغط مزدوج لإعادتها"
        >
          <button type="button" className={`lesson-map-drawer-toggle symbols ${toolsOpen ? 'active' : ''}`} onClick={() => { setToolsOpen((value) => !value); setMapControlsOpen(false); }} aria-expanded={toolsOpen}>
            <Layers3 size={19}/><span>الرموز</span>
          </button>
          <button type="button" className={`lesson-map-drawer-toggle controls ${mapControlsOpen ? 'active' : ''}`} onClick={() => { setMapControlsOpen((value) => !value); setToolsOpen(false); }} aria-expanded={mapControlsOpen}>
            <SlidersHorizontal size={19}/><span>الخرائط والتحديد</span>
          </button>
        </div>
        <div className={`lesson-map-quick-drawbar ${quickToolsOpen ? 'open' : 'collapsed'}`} role="toolbar" aria-label="أدوات الشرح على الخريطة">
          <button type="button" className="lesson-map-quick-toggle" onClick={() => setQuickToolsOpen((value) => !value)} title={quickToolsOpen ? 'إغلاق أدوات الرسم' : 'فتح أدوات الرسم'}><PenLine size={17}/></button>
          {quickToolsOpen && <>
          <button type="button" className={drawTool === 'select' ? 'active' : ''} onClick={() => setDrawTool('select')} title="تحديد ووضع عناصر"><MapPin size={17}/></button>
          <button type="button" className={drawTool === 'pen' ? 'active' : ''} onClick={() => setDrawTool('pen')} title="قلم"><PenLine size={17}/></button>
          <button type="button" className={drawTool === 'highlighter' ? 'active' : ''} onClick={() => setDrawTool('highlighter')} title="هايلايتر"><Highlighter size={17}/></button>
          <button type="button" className={drawTool === 'eraser' ? 'active' : ''} onClick={() => setDrawTool('eraser')} title="ممحاة"><Eraser size={17}/></button>
          <input type="color" value={drawColor} onChange={(event) => setDrawColor(event.target.value)} title="لون الرسم"/>
          <input className="lesson-map-stroke-range" type="range" min="2" max="16" value={strokeWidth} onChange={(event) => setStrokeWidth(Number(event.target.value))} title="سمك القلم"/>
          <button type="button" onClick={() => { setStrokes((current) => current.slice(0, -1)); markDirty(); }} disabled={!strokes.length} title="تراجع"><Undo2 size={16}/></button>
          <button type="button" onClick={() => setLabels((value) => { markDirty(); return !value; })} title="إظهار الأسماء">{labels ? <EyeOff size={16}/> : <Eye size={16}/>}</button>
          <button type="button" onClick={() => changeZoom(0.1)} title="تكبير"><ZoomIn size={16}/></button>
          <button type="button" onClick={() => changeZoom(-0.1)} title="تصغير"><ZoomOut size={16}/></button>
          <button type="button" onClick={resetMap} title="إعادة"><RotateCcw size={16}/></button>
          <button type="button" className={dirty ? 'save-needed' : ''} onClick={() => void save()} title="حفظ"><Save size={16}/></button>
          </>}
        </div>
        <div className="lesson-map-canvas-shell lesson-map-canvas-shell-v5">
          {!geo && <div className="map-game-loading">جارٍ تجهيز الخريطة التعليمية…</div>}
          <ProfessionalMap
            countries={countries}
            items={items}
            region={region}
            layerKey={layerKey}
            labels={labels}
            selectedId={selectedId}
            project={project}
            regionKey={regionKey}
            teachingMode
            displayMode={mapDisplayMode}
            zoom={zoom}
            onZoomChange={(value) => { setZoom(value); markDirty(); }}
            nileFocus={nileMode}
            placements={placements}
            selectedPlacementId={selectedPlacementId}
            onSelectPlacement={setSelectedPlacementId}
            onCountryClick={handleLocationClick}
            onFeatureClick={handleLocationClick}
            onDropPlacement={handleDrop}
            onMovePlacement={(id, x, y) => {
              setPlacements((current) => current.map((item) => item.id === id ? { ...item, x, y } : item));
              setSelectedPlacementId(id);
              markDirty();
            }}
            onResizePlacement={(id, delta) => {
              setPlacements((current) => current.map((item) => item.id === id
                ? { ...item, size: Math.max(0.5, Math.min(2.5, Number(((item.size || 1) + delta).toFixed(2)))) }
                : item));
              setSelectedPlacementId(id);
              markDirty();
            }}
            onDuplicatePlacement={(id) => {
              const source = placements.find((item) => item.id === id);
              if (!source) return;
              const copy = {
                ...source,
                id: `${source.type || 'symbol'}:${Date.now()}:${Math.random().toString(36).slice(2, 7)}`,
                x: Math.max(0, Math.min(100, Number(source.x || 0) + 2.5)),
                y: Math.max(0, Math.min(100, Number(source.y || 0) + 2.5)),
              };
              setPlacements((current) => [...current, copy]);
              setSelectedPlacementId(copy.id);
              markDirty();
            }}
            onRemovePlacement={(id) => {
              setPlacements((current) => current.filter((item) => item.id !== id));
              setSelectedPlacementId((current) => current === id ? '' : current);
              markDirty();
            }}
            onStageClick={handleStageClick}
            canvasRef={canvasRef}
            drawTool={drawTool}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            ariaLabel={`خريطة ${region.title} للشرح داخل الحصة`}
            mapStyle={mapStyle}
            silent={silentMap}
            lineFeatures={riverLines}
            pointFeatures={nilePoints}
            highlightCountryIsos={nileMode ? NILE_BASIN_ISO : []}
          />
        </div>
        {selectedSymbol && (
          <div className="lesson-map-selected-symbol-hint" role="status">
            <GeographyGlyph type={selectedSymbol.id} symbol={selectedSymbol.symbol} />
            <span>{selectedSymbol.label}</span>
            <small>المس الخريطة لوضع الرمز</small>
          </div>
        )}
        {selectedEntity && !silentMap && labels && (
          <aside className={`lesson-map-info-card type-${selectedEntity.type}`} aria-live="polite">
            <button type="button" className="lesson-map-info-close" onClick={() => { setSelectedEntity(null); setSelectedId(''); setSelectedName(''); }} aria-label="إغلاق المعلومات">×</button>
            <div className="lesson-map-info-visual">
              {selectedEntity.type === 'country'
                ? selectedCountryCard?.asset && !countryCardImageFailed
                  ? <img src={selectedCountryCard.asset} alt={`بطاقة دولة ${selectedCountryCard.name}`} onError={() => setCountryCardImageFailed(true)} />
                  : <span className="lesson-map-country-flag" aria-hidden="true">{selectedEntity.flag || '🌐'}</span>
                : selectedEntity.photo
                  ? <img src={selectedEntity.photo} alt={selectedEntity.name} />
                  : <GeographyGlyph type={selectedEntity.kind} symbol="●" />}
            </div>
            <div className="lesson-map-info-copy">
              <small>{selectedEntity.type === 'country' ? 'دولة' : nileMode ? 'حوض نهر النيل' : 'معلومة جغرافية'}</small>
              <strong>{selectedEntity.name}</strong>
              {selectedEntity.type === 'country' && <><span>العاصمة: <b>{selectedCountryCard?.capital || selectedEntity.capital}</b></span><span>الإقليم: <b>{selectedCountryCard?.region || selectedEntity.region}</b></span></>}
              <p>{selectedCountryCard?.fact || selectedEntity.fact}</p>
            </div>
            <button type="button" className="lesson-map-info-speak" onClick={speakSelectedEntity} title="استمع للمعلومة"><Volume2 size={18}/><span>استمع</span></button>
          </aside>
        )}
        {nileMode && <div className="lesson-map-nile-badge"><Waves size={16}/><span>وضع نهر النيل</span></div>}
        {selectedName && !selectedEntity && !silentMap && labels && <div className="lesson-map-selected-chip"><MapPin size={15}/><span>{selectedName}</span></div>}
      </div>
    </div>
  );
}

export default memo(LessonMapStudio);
