import { lazy, memo, Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { File, FileText, Pause, Play, Presentation, Volume2, VolumeX } from 'lucide-react';
import PdfCanvasPreview from './PdfCanvasPreview';
import PanZoomSurface from './PanZoomSurface';
import { readResourceState, writeResourceState } from '../../services/v8ResourceState';

const PptxPreview = lazy(() => import('./PptxPreview'));

const INLINE_MEDIA_TYPES = new Set(['image', 'video', 'audio', 'pdf', 'textbook', 'slides']);
const mediaPlaybackMemory = new Map();
const MAX_PLAYBACK_MEMORY = 48;

function rememberPlaybackPosition(key, value) {
  if (mediaPlaybackMemory.has(key)) mediaPlaybackMemory.delete(key);
  mediaPlaybackMemory.set(key, value);
  while (mediaPlaybackMemory.size > MAX_PLAYBACK_MEMORY) {
    mediaPlaybackMemory.delete(mediaPlaybackMemory.keys().next().value);
  }
  writeResourceState('playback', key, Number(value || 0));
}

function MediaState({ kind = 'loading', title, detail = '' }) {
  const Icon = kind === 'missing' ? File : kind === 'error' ? FileText : Presentation;
  return (
    <div className={`classmode-media-state ${kind === 'error' || kind === 'missing' ? 'error' : ''}`} role={kind === 'error' ? 'alert' : 'status'}>
      <Icon size={38}/>
      <strong>{title}</strong>
      {detail && <small>{detail}</small>}
    </div>
  );
}

function imageMime(resource = {}, blob = null) {
  const blobType = String(blob?.type || '').toLowerCase();
  if (blobType.startsWith('image/')) return blobType;
  const mime = String(resource.mimeType || '').toLowerCase();
  if (mime.startsWith('image/')) return mime;
  const name = String(resource.fileName || resource.title || '').toLowerCase();
  if (/\.png$/.test(name)) return 'image/png';
  if (/\.webp$/.test(name)) return 'image/webp';
  if (/\.gif$/.test(name)) return 'image/gif';
  if (/\.svg$/.test(name)) return 'image/svg+xml';
  return 'image/jpeg';
}

function RobustImage({ resource, source, zoom = 1, onZoomChange }) {
  const [fallbackUrl, setFallbackUrl] = useState('');
  const [failed, setFailed] = useState(false);
  const [fitMode, setFitMode] = useState('contain');
  const [fitPickerOpen, setFitPickerOpen] = useState(true);
  const normalizedBlob = useMemo(() => {
    if (!(source?.blob instanceof Blob) || source.blob.size <= 0) return null;
    const mime = imageMime(resource, source.blob);
    return source.blob.type === mime ? source.blob : source.blob.slice(0, source.blob.size, mime);
  }, [resource?.fileName, resource?.mimeType, resource?.title, source?.blob]);

  useEffect(() => {
    if (!normalizedBlob) {
      setFallbackUrl('');
      return undefined;
    }
    const url = URL.createObjectURL(normalizedBlob);
    setFallbackUrl(url);
    setFailed(false);
    return () => URL.revokeObjectURL(url);
  }, [normalizedBlob]);

  useEffect(() => {
    setFitMode('contain');
    setFitPickerOpen(true);
  }, [resource?.id]);

  const src = fallbackUrl || source?.url || resource?.url || '';
  if (!src || failed) return null;
  return (
    <div className={`classmode-image-stage fit-${fitMode}`}>
      <PanZoomSurface
        zoom={zoom}
        onZoomChange={onZoomChange}
        maxZoom={6}
        resetKey={resource?.id || src}
        className="classmode-image-panzoom"
        ariaLabel="الصورة — قرّب بإصبعين واسحب بعد التكبير"
      >
        <img
          key={`${resource.id}:${src}`}
          className="unified-media-image"
          src={src}
          alt={resource.title || resource.fileName || 'صورة الدرس'}
          decoding="async"
          onError={() => setFailed(true)}
        />
      </PanZoomSurface>
      {fitPickerOpen && (
        <div className="classmode-image-fit-controls" role="group" aria-label="طريقة عرض الصورة">
          <button type="button" className={fitMode === 'contain' ? 'active' : ''} onClick={() => { setFitMode('contain'); setFitPickerOpen(false); }}>احتواء</button>
          <button type="button" className={fitMode === 'width' ? 'active' : ''} onClick={() => { setFitMode('width'); setFitPickerOpen(false); }}>ملء العرض</button>
          <button type="button" className={fitMode === 'cover' ? 'active' : ''} onClick={() => { setFitMode('cover'); setFitPickerOpen(false); }}>ملء الشاشة</button>
        </div>
      )}
    </div>
  );
}

function useRememberedPlayback(resource, assetUrl, kind) {
  const ref = useRef(null);
  const memoryKey = `${kind}:${String(resource?.assetId || resource?.id || assetUrl || 'resource')}`;

  const restore = () => {
    const media = ref.current;
    if (!media) return;
    const remembered = Number(
      mediaPlaybackMemory.get(memoryKey)
      ?? readResourceState('playback', memoryKey, 0)
      ?? 0
    );
    if (remembered > 0) rememberPlaybackPosition(memoryKey, remembered);
    if (remembered > 0 && media?.readyState >= 1 && Number.isFinite(media.duration)) {
      media.currentTime = Math.min(remembered, Math.max(0, media.duration - 0.2));
    }
  };

  const remember = (event) => {
    const media = event?.currentTarget || ref.current;
    if (media?.ended) {
      rememberPlaybackPosition(memoryKey, 0);
      return;
    }
    const current = Number(media?.currentTime || 0);
    if (Number.isFinite(current) && current >= 0) rememberPlaybackPosition(memoryKey, current);
  };
  const ended = () => rememberPlaybackPosition(memoryKey, 0);

  useEffect(() => () => remember(), [memoryKey]);
  return { ref, restore, remember, ended };
}

function formatMediaTime(value) {
  const seconds = Math.max(0, Number(value) || 0);
  const minutes = Math.floor(seconds / 60);
  const rest = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${minutes}:${rest}`;
}

function CompactMediaControls({ playback, kind = 'video', currentTime, duration, playing, muted, onMutedChange, onSeek }) {
  const togglePlayback = async () => {
    const media = playback.ref.current;
    if (!media) return;
    if (media.paused) {
      try { await media.play(); } catch { /* browser/native gesture gate */ }
    } else media.pause();
  };
  const toggleMute = () => {
    const media = playback.ref.current;
    if (!media) return;
    media.muted = !media.muted;
    onMutedChange(media.muted);
  };
  return (
    <div className={`classmode-compact-media-controls ${kind}`} role="group" aria-label={kind === 'audio' ? 'التحكم في الصوت' : 'التحكم في الفيديو'}>
      <button type="button" onClick={togglePlayback} aria-label={playing ? 'إيقاف مؤقت' : 'تشغيل'} title={playing ? 'إيقاف مؤقت' : 'تشغيل'}>
        {playing ? <Pause size={17}/> : <Play size={17}/>}
      </button>
      <span className="classmode-media-time" dir="ltr">{formatMediaTime(currentTime)}</span>
      <input
        className="classmode-media-progress"
        type="range"
        min="0"
        max={Math.max(0.1, Number(duration) || 0.1)}
        step="0.1"
        value={Math.min(Number(currentTime) || 0, Math.max(0.1, Number(duration) || 0.1))}
        onChange={(event) => onSeek(Number(event.target.value || 0))}
        aria-label="موضع التشغيل"
      />
      <span className="classmode-media-time" dir="ltr">{formatMediaTime(duration)}</span>
      <button type="button" onClick={toggleMute} aria-label={muted ? 'تشغيل الصوت' : 'كتم الصوت'} title={muted ? 'تشغيل الصوت' : 'كتم الصوت'}>
        {muted ? <VolumeX size={17}/> : <Volume2 size={17}/>}
      </button>
    </div>
  );
}

function useCompactMediaState(playback) {
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const loaded = () => {
    playback.restore();
    const media = playback.ref.current;
    setDuration(Number(media?.duration || 0));
    setCurrentTime(Number(media?.currentTime || 0));
    setMuted(Boolean(media?.muted));
  };
  const progress = (event) => {
    const media = event.currentTarget;
    setCurrentTime(Number(media.currentTime || 0));
    setDuration(Number(media.duration || 0));
    playback.remember(event);
  };
  const seek = (next) => {
    const media = playback.ref.current;
    if (!media) return;
    media.currentTime = Math.max(0, Math.min(Number(next) || 0, Number(media.duration) || Number(next) || 0));
    setCurrentTime(Number(media.currentTime || 0));
    playback.remember({ currentTarget: media });
  };
  return { currentTime, duration, playing, muted, setPlaying, setMuted, loaded, progress, seek };
}

function MediaVideo({ resource, assetUrl }) {
  const playback = useRememberedPlayback(resource, assetUrl, 'video');
  const state = useCompactMediaState(playback);
  return (
    <div className="unified-media-video-shell">
      <video
        ref={playback.ref}
        key={resource.id}
        className="unified-media-video"
        playsInline
        preload="metadata"
        src={assetUrl}
        onLoadedMetadata={state.loaded}
        onTimeUpdate={state.progress}
        onPlay={() => state.setPlaying(true)}
        onPause={(event) => { state.setPlaying(false); playback.remember(event); }}
        onEnded={() => { playback.ended(); state.setPlaying(false); }}
        aria-label={resource.title || 'فيديو الدرس'}
      />
      <CompactMediaControls playback={playback} kind="video" {...state} onMutedChange={state.setMuted} onSeek={state.seek}/>
    </div>
  );
}

function MediaAudio({ resource, assetUrl }) {
  const playback = useRememberedPlayback(resource, assetUrl, 'audio');
  const state = useCompactMediaState(playback);
  return (
    <div className="unified-media-audio-shell">
      <audio
        ref={playback.ref}
        key={resource.id}
        className="unified-media-audio-element"
        preload="metadata"
        src={assetUrl}
        onLoadedMetadata={state.loaded}
        onTimeUpdate={state.progress}
        onPlay={() => state.setPlaying(true)}
        onPause={(event) => { state.setPlaying(false); playback.remember(event); }}
        onEnded={() => { playback.ended(); state.setPlaying(false); }}
        aria-label={resource.title || 'صوت الدرس'}
      />
      <CompactMediaControls playback={playback} kind="audio" {...state} onMutedChange={state.setMuted} onSeek={state.seek}/>
    </div>
  );
}

/**
 * The single display surface for every lesson asset shown inside Class Mode.
 * Asset loading remains keyed by assetId in useAssetSource; this component never
 * fetches a temporary remote URL when an Asset Store blob is available.
 */
function MediaRenderer({
  resource,
  source,
  pdfPage,
  page,
  annotations = [],
  onOpenExternal,
  onPdfStateChange,
  zoom = 1,
  onZoomChange,
  onPreviousPage,
  onNextPage,
}) {
  if (!resource) return null;

  const type = resource.type;
  const assetUrl = source?.url || '';
  const sourceError = source?.error || '';
  const nativeRuntime = Boolean(globalThis.Capacitor?.isNativePlatform?.());
  const pdfError = pdfPage?.error || '';
  const loading = Boolean(source?.loading || (nativeRuntime && ['pdf', 'textbook'].includes(type) && pdfPage?.loading));
  const imageAvailable = Boolean((source?.blob instanceof Blob && source.blob.size > 0) || assetUrl || resource?.url);

  return (
    <div className="resource-preview-body unified-media-renderer" data-media-type={type}>
      {type === 'image' && imageAvailable && (
        <RobustImage resource={resource} source={source} zoom={zoom} onZoomChange={onZoomChange} />
      )}
      {type === 'video' && assetUrl && (
        <MediaVideo resource={resource} assetUrl={assetUrl} />
      )}
      {type === 'audio' && assetUrl && (
        <MediaAudio resource={resource} assetUrl={assetUrl} />
      )}
      {type === 'slides' && (
        <Suspense fallback={<MediaState title="جارٍ تجهيز عارض PowerPoint عند الحاجة…"/>}>
          <PptxPreview
            url={assetUrl}
            blob={source?.blob}
            title={resource.title}
            resourceKey={resource.assetId || resource.id || assetUrl}
            onOpenExternal={onOpenExternal}
          />
        </Suspense>
      )}
      {['pdf', 'textbook'].includes(type) && nativeRuntime && pdfPage?.dataUrl && (
        <PanZoomSurface
          zoom={zoom}
          onZoomChange={onZoomChange}
          maxZoom={6}
          resetKey={`${resource?.id || ''}:${page || 1}`}
          className="classmode-pdf-panzoom classmode-native-pdf-panzoom"
          ariaLabel="صفحة PDF — قرّب بإصبعين واسحب بعد التكبير"
          onSwipeLeft={onNextPage}
          onSwipeRight={onPreviousPage}
        >
          <img
            className="classmode-pdf-page-image unified-media-pdf"
            src={pdfPage.dataUrl}
            alt={`${resource.title} — صفحة ${page || 1}`}
          />
        </PanZoomSurface>
      )}
      {['pdf', 'textbook'].includes(type) && !nativeRuntime && (source?.blob || assetUrl) && (
        <PdfCanvasPreview
          key={`${resource.assetId || resource.id || assetUrl}:${page || 1}`}
          source={source}
          resourceId={resource.assetId || resource.id || assetUrl}
          page={page || 1}
          title={resource.title}
          onStateChange={onPdfStateChange}
          zoom={zoom}
          onZoomChange={onZoomChange}
          onPreviousPage={onPreviousPage}
          onNextPage={onNextPage}
        />
      )}

      {loading && <MediaState title="جارٍ فتح الملف من ذاكرة المنصة…"/>}
      {sourceError && (
        <MediaState kind="error" title={sourceError} detail="أعد رفع الملف من المكتبة إذا استمرت المشكلة."/>
      )}
      {nativeRuntime && pdfError && (
        <MediaState kind="error" title={pdfError} detail="تعذر تجهيز صفحة PDF داخل وضع الحصة."/>
      )}
      {!source?.loading && !sourceError && type === 'image' && !imageAvailable && (
        <MediaState kind="missing" title="الصورة غير متاحة داخل ذاكرة المنصة." detail="أعد رفعها من المكتبة ثم افتح الحصة مرة أخرى."/>
      )}
      {!source?.loading && !sourceError && ['video', 'audio', 'slides'].includes(type) && !assetUrl && !(type === 'slides' && source?.blob) && (
        <MediaState kind="missing" title="الملف غير متاح داخل ذاكرة المنصة." detail="أعد رفعه من المكتبة ثم افتح الحصة مرة أخرى."/>
      )}
      {!INLINE_MEDIA_TYPES.has(type) && (
        <div className="resource-placeholder classmode-document-placeholder">
          <Presentation size={42}/>
          <strong>{resource.fileName || resource.title}</strong>
          <small>مستند مرتبط بالدرس</small>
          <button className="primary-btn" type="button" onClick={onOpenExternal}>فتح الملف على الجهاز</button>
        </div>
      )}
      {annotations.length > 0 && (
        <div className="resource-annotation-overlay">
          {annotations.map((note) => <span key={note.id} style={{ background: note.color }}>{note.text}</span>)}
        </div>
      )}
    </div>
  );
}

function sameMediaRendererProps(previous, next) {
  return (
    previous.resource?.id === next.resource?.id &&
    previous.resource?.assetId === next.resource?.assetId &&
    previous.resource?.type === next.resource?.type &&
    previous.source?.url === next.source?.url &&
    previous.source?.blob === next.source?.blob &&
    previous.source?.loading === next.source?.loading &&
    previous.source?.error === next.source?.error &&
    previous.pdfPage?.dataUrl === next.pdfPage?.dataUrl &&
    previous.pdfPage?.pageCount === next.pdfPage?.pageCount &&
    previous.pdfPage?.loading === next.pdfPage?.loading &&
    previous.pdfPage?.error === next.pdfPage?.error &&
    previous.page === next.page &&
    previous.annotations === next.annotations &&
    previous.zoom === next.zoom &&
    previous.resource?.url === next.resource?.url &&
    previous.resource?.fileName === next.resource?.fileName &&
    previous.resource?.title === next.resource?.title &&
    previous.resource?.mimeType === next.resource?.mimeType &&
    // A page/zoom change must use the latest handlers; a stale callback
    // silently saves navigation to a previous PDF resource.
    previous.onOpenExternal === next.onOpenExternal &&
    previous.onPdfStateChange === next.onPdfStateChange &&
    previous.onZoomChange === next.onZoomChange &&
    previous.onPreviousPage === next.onPreviousPage &&
    previous.onNextPage === next.onNextPage
  );
}

export default memo(MediaRenderer, sameMediaRendererProps);
