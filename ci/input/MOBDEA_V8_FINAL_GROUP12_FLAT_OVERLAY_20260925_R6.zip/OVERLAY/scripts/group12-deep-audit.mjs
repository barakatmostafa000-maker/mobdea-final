/** Source-provenance and dependency audit. Does not claim browser/native runtime validation. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const ROOT = process.cwd();
const file = (relative) => path.join(ROOT, relative);
const exists = (relative) => fs.existsSync(file(relative)) && fs.statSync(file(relative)).isFile();
const read = (relative) => exists(relative) ? fs.readFileSync(file(relative), 'utf8') : '';
const sha = (relative) => exists(relative) ? crypto.createHash('sha256').update(fs.readFileSync(file(relative))).digest('hex') : null;
const results = [];
const add = (id, ok, detail, evidence = []) => results.push({ id, status: ok ? 'PASS' : 'BLOCKED', detail, evidence });
const baseline = read('src/main.jsx');
add('V8_BASELINE_MARKER', baseline.includes('__MOBDEA_V8_FINAL_REAL_REVIEWED__'),
  'Approved V8 source marker is present in src/main.jsx.', ['src/main.jsx']);
const core = ['src/App.jsx','src/pages/ClassMode.jsx','src/pages/MapChallenge.jsx',
  'src/components/maps/LessonMapStudio.jsx','src/components/maps/ProfessionalMap.jsx',
  'src/services/studentPortalCloud.js','cloud-worker/group11Portal.js','cloud-worker/worker.group11.js',
  'cloud-worker/worker.js','cloud-worker/wrangler.jsonc','package.json','package-lock.json'];
add('ESSENTIAL_SOURCE_FILES', core.every(exists),
  core.filter(item => !exists(item)).length ? 'Required source files are absent.' : 'Essential application and worker sources are present.',
  core.filter(item => !exists(item)));
const native = ['android/app/build.gradle','android/app/src/main/AndroidManifest.xml',
  'android/app/src/main/java/com/mobdea/education/MainActivity.java',
  'android/app/src/main/java/com/mobdea/education/voice/MobdeaTextToSpeechPlugin.java',
  'android/app/src/main/java/com/mobdea/education/pdf/MobdeaPdfRendererPlugin.java',
  'android/app/src/main/java/com/mobdea/education/ocr/MobdeaPdfOcrPlugin.java'];
const missingNative = native.filter(item => !exists(item));
add('NATIVE_ANDROID_FILES', missingNative.length === 0,
  missingNative.length ? `Missing ${missingNative.length} native source/config file(s). Android/version/prebuild checks cannot pass on this source snapshot.` : 'Required native source/config files found.', missingNative);
const nativeOcrCandidates = [
  ['android/app/src/main/assets/tessdata/ara.traineddata.gz','android/app/src/main/assets/tessdata/eng.traineddata.gz'],
  ['android/app/src/main/assets/ara.traineddata.gz','android/app/src/main/assets/eng.traineddata.gz'],
];
const nativeOcr = nativeOcrCandidates.find(pair => pair.every(exists));
add('NATIVE_OCR_MODELS', Boolean(nativeOcr),
  nativeOcr
    ? `Bundled Android OCR training data found at ${nativeOcr.map(item=>path.dirname(item)).join(' / ')}.`
    : 'Bundled Android OCR training data required for offline native recognition.',
  nativeOcr ? nativeOcr : nativeOcrCandidates.flat().filter(item => !exists(item)));
const worker = read('cloud-worker/worker.group11.js');
const origin = read('cloud-worker/worker.js');
const wrangler = read('cloud-worker/wrangler.jsonc');
add('WORKER_ENTRY_PRESERVATION', worker.includes("import legacyWorker from './worker.js'") && wrangler.includes('worker.group11.js'),
  'Group 11 wrapper remains an additive entry point and imports the unmodified legacy worker.',
  ['cloud-worker/worker.group11.js','cloud-worker/wrangler.jsonc']);
add('ORIGINAL_WORKER_PROVENANCE', origin.includes('MOBDEA_WORKSPACE_TOKENS') && origin.includes('handleJoinGameRoom'),
  'Original worker must be the actual V8 backend; mock or missing server files cannot establish endpoint compatibility.',
  ['cloud-worker/worker.js']);
add('BACKEND_DATABASE_CONFIG', wrangler.includes('MOBDEA_TRIAL_DB'),
  'D1 needs a valid binding and applied migrations for trials and portal sessions.',
  ['cloud-worker/wrangler.jsonc','cloud-worker/migrations/0001_visitor_trials.sql','cloud-worker/migrations/0002_portal_auth.sql']);
const depPaths = ['node_modules/vite/bin/vite.js','node_modules/react/package.json','node_modules/react-dom/package.json'];
add('BUILD_DEPENDENCIES', depPaths.every(exists),
  'Production build dependencies must be installed and nonempty; directory placeholders do not count.',
  depPaths.filter(item => !exists(item)));
const importErrors = [];
let checked = 0;
const walk = (base) => {
  if (!fs.existsSync(base)) return;
  for (const ent of fs.readdirSync(base, { withFileTypes: true })) {
    const f = path.join(base, ent.name);
    if (ent.isDirectory()) { walk(f); continue; }
    if (!/\.(js|jsx|mjs)$/.test(ent.name)) continue;
    checked++;
    const content = fs.readFileSync(f, 'utf8');
    for (const match of content.matchAll(/(?:from\s*|import\s*\(|import\s*|require\s*\()\s*['"](\.{1,2}\/[^'"]+)['"]/g)) {
      const target = path.resolve(path.dirname(f), match[1]);
      const candidates = [target, `${target}.js`,`${target}.jsx`,`${target}.mjs`, `${target}.json`,
        `${target}.css`, path.join(target, 'index.js'),path.join(target, 'index.jsx')];
      if (!candidates.some(fs.existsSync)) importErrors.push({from:path.relative(ROOT,f),spec:match[1]});
    }
  }
};
for (const src of ['src','cloud-worker']) walk(file(src));
add('RELATIVE_IMPORTS', importErrors.length === 0,
  `Checked ${checked} JavaScript/JSX/MJS files; found ${importErrors.length} unresolved literal relative imports.`, importErrors);
const symbolManifest = read('public/map-symbols/manifest.json');
let images = [];
try {const obj = JSON.parse(symbolManifest); images = JSON.stringify(obj).match(/[\w-]+\.png/g) || [];} catch { /* missing manifest */ }
const uniqueImages = [...new Set(images)];
const missingSymbols = uniqueImages.filter(name=>!exists(`public/map-symbols/${name}`));
add('MAP_SYMBOL_IMAGE_FILES', exists('public/map-symbols/manifest.json') && uniqueImages.length > 0 && missingSymbols.length===0,
  `Map symbol manifest references ${uniqueImages.length} unique PNG names; ${missingSymbols.length} are absent.`,
  missingSymbols.slice(0,40));
const countryCards = read('src/data/countryCards.js');
const cardFiles = [...new Set(countryCards.match(/v8-verified-\d+\.png/g) || [])];
const expectedCards = Array.from({length:36}, (_,i)=>`v8-verified-${String(i).padStart(2,'0')}.png`);
const missingCards = expectedCards.filter(name=>!exists(`public/whiteboard/country-cards/${name}`));
add('COUNTRY_CARD_IMAGE_FILES', cardFiles.length>0 && !missingCards.length,
  `Country card library contains ${expectedCards.length-missingCards.length}/${expectedCards.length} verified card images.`,
  missingCards.slice(0,40));
const outcomes = {generatedAt:new Date().toISOString(),reference:'V8_FINAL_MASTER_REAL_REVIEWED',
  sourceRoot:ROOT, results,summary:{checks:results.length,passed:results.filter(x=>x.status==='PASS').length,
    blocked:results.filter(x=>x.status==='BLOCKED').length},
  IMPORTANT:'These are source/asset existence checks, not proof of UI behavior or a substitute for the full test suite and production build.'};
const text = JSON.stringify(outcomes,null,2)+'\n';
if (process.argv.includes('--write')) fs.writeFileSync(file('GROUP12_DEEP_AUDIT.json'), text);
console.log(text);
if (process.argv.includes('--strict') && outcomes.summary.blocked) process.exitCode=1;
