# R11 Deep Review — V8_FINAL_MASTER_REAL_REVIEWED

Baseline: `V8_FINAL_MASTER_REAL_REVIEWED`
Pinned native/assets parent: `3598945d2cd4d91bf4e78cf48214515fc32fd713`
Release: `10.14.3 / versionCode 120 / V8-G12-R11`

## Real regressions found during the R10 re-audit and fixed in R11
1. Existing hashed old-default student PINs with `studentPinMustChange=true` and an old policy version were skipped by the unified PIN migration. R11 rotates only those still-default credentials to `12345678`, while preserving credentials already changed by pupils.
2. `Project14YouTubeGradeFeed` still existed but was no longer mounted in `ContentLibrary`. R11 restores the student grade feed without exposing teacher-only content.

## Current acceptance evidence
- Current high-value/source acceptance gate: 126/126 PASS.
- Dedicated R11 PIN/current-runtime tests: PASS.
- V8 original final-reviewed gate: PASS.
- Lint: PASS.
- Format: PASS.
- Base commit verified through GitHub for Native Arabic TTS, Google Code Scanner registration/dependency, and Project14 YouTube worker routes.
- Historical implementation-shape tests remain diagnostic only when they conflict with the approved final V8 architecture (for example old `123456`, old header tabs instead of requirement-52 menu, or `onlineClass: ClassMode` instead of the dedicated OnlineClass route).

## Runtime-only acceptance
See `RUNTIME_VERIFICATION_REQUIRED_AR.txt`. Fullscreen, Touch/Pinch/Pan, Native TTS, real PDF, OCR/Tesseract, Maps, Media and WebRTC still require a real Android tablet after CI builds the APK.
