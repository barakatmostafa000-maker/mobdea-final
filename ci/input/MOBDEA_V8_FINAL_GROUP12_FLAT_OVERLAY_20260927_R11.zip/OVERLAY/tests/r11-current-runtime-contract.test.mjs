import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');
const json = (rel) => JSON.parse(read(rel));

test('R11 release identity is unique and newer than the R10 build identity', () => {
  const pkg = json('package.json');
  const version = read('src/config/version.js');
  assert.equal(pkg.version, '10.14.3');
  assert.equal(Number(pkg.mobdea?.versionCode), 120);
  assert.match(version, /APP_VERSION = "10\.14\.3"/);
  assert.match(version, /APP_VERSION_CODE = 120/);
  assert.match(version, /RELEASE_TAG = "V8-G12-R11"/);
});

test('ClassMode keeps the final navigation, two rails, plus/minus and bottom save contract', () => {
  const src = read('src/pages/ClassMode.jsx');
  for (const mode of ['pdf','board','maps','images','videos','audio','slides','games']) {
    assert.match(src, new RegExp(`key: ["']${mode}["']`), mode);
  }
  assert.match(src, /classmode-user-navigation/);
  assert.match(src, /const \[managementOpen, setManagementOpen\] = useState\(true\)/);
  assert.match(src, /splitStudentRails\(displayedStudents\)/);
  assert.match(src, /adjustPoints\(student, -1\)/);
  assert.match(src, /adjustPoints\(student, 1\)/);
  assert.match(src, /className="secondary-btn classmode-bottom-save"/);
  assert.match(src, /onClick=\{saveLessonState\}/);
});

test('Arabic speech remains native-first and Arabic correction is live in both boards', () => {
  const voice = read('src/services/voice.js');
  const klass = read('src/pages/ClassMode.jsx');
  const board = read('src/pages/Whiteboard.jsx');
  assert.ok(voice.indexOf('const nativeSpoken = await speakWithAndroid') < voice.indexOf('return speakWithBrowser'));
  assert.match(voice, /DEFAULT_LANGUAGE = 'ar-EG'/);
  assert.match(klass, /correctArabicSentence\(current\.value, \{ finish: false \}\)/);
  assert.match(klass, /correctTextEditorNow\(\{ finish: true \}\)/);
  assert.match(board, /correctArabicSentence\(current\.value, \{ finish: false \}\)/);
  assert.match(board, /correctArabicSentence\(textEditor\.value, \{ finish: true \}\)/);
});

test('student access stays private-by-default with explicit publishing and finite visitor trials', () => {
  const access = read('src/services/rolePortalAccess.js');
  const portal = read('src/services/studentPortalCloud.js');
  assert.match(access, /filterContentLibraryForRole/);
  assert.match(access, /roleSupportOnly/);
  assert.match(access, /VISITOR_TRIAL_LIMITS/);
  assert.match(portal, /studentId/);
  assert.match(portal, /identity/i);
});

test('student PIN and improvement policies remain on the repaired R9+ contract', () => {
  const pin = read('src/services/studentPinPolicy.js');
  const improvement = read('src/services/classPointImprovement.js');
  assert.match(pin, /DEFAULT_STUDENT_PIN = '12345678'/);
  assert.match(pin, /verifyLocalStudentPin/);
  assert.match(pin, /studentPinDefaultVersion/);
  assert.match(improvement, /buildClassPointProgress/);
  assert.match(improvement, /rankByClassImprovement/);
  assert.match(improvement, /wantedGroup/);
  assert.match(improvement, /wantedGrade/);
});

test('maps keep silent-label isolation, durable Nile IDs and independent region behavior', () => {
  const map = read('src/components/maps/ProfessionalMap.jsx');
  const nile = read('src/data/project06TeachingMaps.js');
  const geography = read('src/data/geography.js');
  assert.match(map, /const effectiveDisplayMode = silent \? 'blank' : displayMode/);
  assert.match(map, /!silent && \(placement\.showLabel \|\| placement\.type === "custom-label"\) && \(/);
  for (const id of ['kagera','victoria-nile','albert-nile','bahr-jebel','bahr-ghazal','sobat','white-nile','blue-nile','atbara','main-nile','delta-west','delta-east']) {
    assert.match(nile, new RegExp(`id: '${id}'`), id);
  }
  assert.match(geography, /asia:\s*\{/);
  assert.match(geography, /europe:\s*\{/);
  assert.match(geography, /eurasia:\s*\{/);
});

test('OCR manual path, bounded resource state and worker repair stay wired', () => {
  const q = read('src/pages/QuestionBankManager.jsx');
  const media = read('src/components/classmode/MediaRenderer.jsx');
  const pan = read('src/components/classmode/PanZoomSurface.jsx');
  const workerPatch = read('scripts/patch-pinned-base-r11.py');
  assert.match(q, /data-testid="manual-question-add"/);
  assert.match(q, /Project08ExamOcrImport/);
  assert.match(media, /MAX_PLAYBACK_MEMORY/);
  assert.match(pan, /MAX_PAN_MEMORY/);
  assert.match(workerPatch, /12345678/);
  assert.match(workerPatch, /project12StudentContentLibrary/);
});

test('R11 keeps the student YouTube grade feed mounted and the unified PIN migration safe', () => {
  const library = read('src/pages/ContentLibrary.jsx');
  const pin = read('src/services/studentPinPolicy.js');
  assert.match(library, /Project14YouTubeGradeFeed/);
  assert.match(library, /<Project14YouTubeGradeFeed[^>]*grade=\{studentRecord\?\.grade \|\| selectedGrade\}/);
  assert.match(pin, /legacyDefaultCredential/);
  assert.match(pin, /student\.studentPinMustChange === true/);
  assert.match(pin, /Number\(student\.studentPinDefaultVersion \|\| 0\) < STUDENT_PIN_POLICY_VERSION/);
  assert.match(pin, /if \(hasSecret && !legacyDefaultCredential\)/);
});

test('R11 preserves separate online class, WebRTC screen/audio, multiplayer and device-verification contract', () => {
  const online = read('src/pages/OnlineClass.jsx');
  const klass = read('src/pages/ClassMode.jsx');
  const teacherLive = read('src/components/live/TeacherLivePanel.jsx');
  const studentLive = read('src/components/live/StudentLiveRoom.jsx');
  const gameRooms = read('src/services/gameRooms.js');
  const runtime = read('RUNTIME_VERIFICATION_REQUIRED_AR.txt');
  assert.match(online, /<ClassMode \{\.\.\.props\} onlineEntry/);
  assert.match(klass, /TeacherLivePanel/);
  assert.match(teacherLive, /RTCPeerConnection/);
  assert.match(teacherLive, /getDisplayMedia/);
  assert.match(teacherLive, /getUserMedia/);
  assert.match(studentLive, /RTCPeerConnection/);
  assert.match(gameRooms, /createGameRoom/);
  assert.match(gameRooms, /joinGameRoom/);
  assert.match(gameRooms, /\/game\/rooms/);
  for (const token of ['Tablet', 'Touch', 'TTS', 'Fullscreen', 'OCR', 'PDF', 'Map', 'WebRTC']) assert.match(runtime, new RegExp(token, 'i'));
});
