export const APP_VERSION = "10.14.3";
export const APP_VERSION_CODE = 120;
export const DATA_SCHEMA_VERSION = 13;
export const RELEASE_CHANNEL = "stable";
export const RELEASE_TAG = "V8-G12-R11";
