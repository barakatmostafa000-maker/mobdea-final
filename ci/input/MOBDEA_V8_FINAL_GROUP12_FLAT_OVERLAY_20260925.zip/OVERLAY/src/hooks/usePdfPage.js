import { useEffect, useState } from "react";
import { isSamePdfPreview } from "../services/v8PdfSourceIdentity.js";

const initialState = { dataUrl: "", pageCount: 0, loading: false, error: "" };

export function usePdfPage(source, page = 1, maxWidth = 1600) {
  const url = typeof source === "string" ? source : source?.url || "";
  const blob = typeof source === "object" ? source?.blob || null : null;
  const cacheKey = typeof source === "object" ? source?.cacheKey || "" : url;
  const identity = { url, blob, cacheKey, page, maxWidth };
  const [state, setState] = useState(() => ({ ...initialState, identity }));

  useEffect(() => {
    let cancelled = false;
    let cancelPreload = null;
    const requestIdentity = { url, blob, cacheKey, page, maxWidth };

    if (!blob && !url) {
      setState({ ...initialState, identity: requestIdentity });
      return () => { cancelled = true; };
    }

    // A new book/page must never display the previous book/page while loading.
    // The original hook retained old dataUrl across resource changes.
    setState({ ...initialState, identity: requestIdentity, loading: true });

    const isNative = Boolean(globalThis.Capacitor?.isNativePlatform?.());
    const task = (isNative
      ? import('../services/pdfRenderer')
      : import('../services/webPdfRenderer')
    ).then((renderer) => {
      if (cancelled) return null;
      return isNative
        ? blob
          ? renderer.renderNativePdfBlob(blob, page, maxWidth, cacheKey)
          : renderer.renderNativePdfPage(url, page, maxWidth)
        : blob
          ? renderer.renderWebPdfBlob(blob, page, maxWidth, cacheKey)
          : renderer.renderWebPdfPage(url, page, maxWidth, cacheKey || url);
    });

    task.then((result) => {
      if (cancelled) return;
      setState({
        dataUrl: result?.dataUrl || "",
        pageCount: Number(result?.pageCount || 0),
        loading: false,
        error: "",
        identity: requestIdentity,
      });
      // Schedule adjacent pages only after this exact source/page completed;
      // cancel pending idle work immediately when the teacher switches books.
      if (!isNative && Number(result?.pageCount || 0) > 1) {
        const prefetch = () => {
          if (!cancelled) void import('../services/webPdfRenderer')
            .then(({ preloadWebPdfNeighbors }) => preloadWebPdfNeighbors(
              { blob, url, cacheKey }, page, result.pageCount, maxWidth,
            )).catch(() => {});
        };
        if (typeof globalThis.requestIdleCallback === 'function') {
          const idleId = globalThis.requestIdleCallback(prefetch, { timeout: 1800 });
          cancelPreload = () => globalThis.cancelIdleCallback?.(idleId);
        } else {
          const timer = globalThis.setTimeout(prefetch, 240);
          cancelPreload = () => globalThis.clearTimeout(timer);
        }
      }
    }).catch((error) => {
      if (cancelled) return;
      setState({
        dataUrl: "",
        pageCount: 0,
        loading: false,
        error: error?.message || "تعذر عرض صفحة PDF.",
        identity: requestIdentity,
      });
    });

    return () => {
      cancelled = true;
      cancelPreload?.();
    };
  }, [blob, cacheKey, maxWidth, page, url]);

  // useEffect runs after a render. Reject a stale preview synchronously even
  // during that first frame, including when the same URL points to a new Blob.
  if (!isSamePdfPreview(state.identity, identity)) {
    return { ...initialState, loading: Boolean(blob || url) };
  }
  return state;
}
