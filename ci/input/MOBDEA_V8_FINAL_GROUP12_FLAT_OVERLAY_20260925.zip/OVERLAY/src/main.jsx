import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import AppErrorBoundary from "./components/AppErrorBoundary";
import "./styles/app.css";
import "./styles/v103.css";
import "./styles/v104.css";
import "./styles/v105.css";
import "./styles/v106.css";
import "./styles/v107.css";
import "./styles/v109.css";
import "./styles/v110.css";
import "./styles/v111.css";
import "./styles/r18-classmode-viewport-fix.css";
import "./styles/r19-classmode-phase1.css";
import "./styles/r19-master-repairs.css";
import "./styles/r19-targeted-fixes.css";
import "./styles/student-cards-print.css";
import "./styles/r19-user-fix7.css";
import "./styles/r19-fix8-native.css";
import { installViewportMetrics } from "./services/viewport";
import { installTabletRuntime } from "./services/v8TabletRuntime";

import './styles/project01-whiteboard.css';
import './styles/project02-pdf-image-viewer.css';
import './styles/project04-card-layout.css';
import './styles/project05-student-card-duplex.css';
import './styles/project06-teaching-maps.css';
import './styles/project07-map-challenge-engine.css';
import './styles/project08-ocr-question-import.css';
import './styles/project09-dashboard-responsive.css';
import './styles/project10-online-class.css';
import './styles/project11-student-sync.css';
import './styles/project12-classmode-cloud-voice.css';
import './styles/project13-pdf-focus-attendance-links-exams.css';
import './styles/project14-youtube-auto-sync.css';
import './styles/r19-final-runtime-fixes.css';
import './styles/r20-fix01-core-runtime.css';
import './services/r20RuntimeCore.js';
import './services/r20PortalAccountRuntime.js';
import './styles/r20-fix04-accounts.css';
import './services/r20PortalDashboard.js';
import './styles/r20-fix05-role-dashboard.css';
import './services/r20TeacherTabletDashboard.js';
import './styles/r20-fix06-teacher-tablet-dashboard.css';
import './styles/r20-fix08-ocr-page-questions.css';
import './styles/r20-fix09-whiteboard.css';
import './styles/r20-fix10-educational-cards.css';
import './styles/r20-fix11-country-cards.css';
import './styles/r20-fix16-image-mode.css';
import './styles/r20-fix17-media.css';
import './styles/r20-fix18-games.css';
import './styles/r20-fix21-reports-whatsapp.css';
import './styles/r20-fix22-remedial-assistant.css';
import './styles/r20-fix23-duplex-print.css';
import './styles/r20-fix24-mobdea-online.css';
import './services/r20MonthlyEvaluation.js';
import './styles/r20-fix25-monthly-evaluation.css';
import './services/r20CriticalViewGuard.js';
import './services/r20PortalLoginBridge.js';
import './services/r20PortalScopeGuard.js';
import './styles/r20-audit-phase01-08.css';
import './styles/r20-classmode-final-rebuild.css';
import './styles/r20-classmode-pdf-v6.css';
import './styles/r20-classmode-geometry-v7.css';
import './styles/r20-classmode-v9-structural.css';
import './styles/r20-master-repair-pack-v1.css';
import './styles/r20-master-repair-pack-v4.css';
import './styles/r20-master-repair-pack-v5-1.css';
import './styles/r20-master-repair-pack-v6.css';
import './styles/v7-final.css';
import './styles/v8-final-real.css';
// Keep layout fixes after all V8/R20 overrides.
import './styles/v8-all-pages-layout.css';
import './styles/v8-section-07-12-whiteboard.css';
import "./styles/v8-section-13-18-media.css";
import './styles/v8-dashboard-hero-online-brand.css';
import './styles/v8-section-52-navigation.css';
import './styles/v8-phase1-route-layout.css';
import './styles/v8-group1-student-dock.css';
import './styles/v8-layout-actual-rebuild.css';
import './styles/v8-group2-voice-whiteboard.css';
globalThis["__MOBDEA_R20_MASTER_V4_2__"] = Object.freeze({
  dashboardApprovedHero: true,
  whiteboardNativeTools: true,
  mediaAnnotationMinimalTools: true,
  movableStudentSaveDock: true,
  balancedStudentColumns: true,
});
globalThis["__MOBDEA_R20_MASTER_V5_1__"] = Object.freeze({
  keepProject06TeachingMaps: true,
  keepProject07MapChallenge: true,
  disableR20MapMutators: true,
  disableR19StudentMirrors: true,
  fullClassModeViewport: true,
  boardArtworkNoCrop: true,
  boardNameRibbonVisible: true,
  bottomBoardTools: true,
  mediaToolsPenHighlighterEraserOnly: true,
  compactTwoColumnStudents: true,
  pdfPinchPanSwipe: true,
  dashboardHitTargets: true,
  mobdeaOnlineCompactIcon: true,
  countryCardsVisible: true,
  libraryVerticalResponsive: true,
});
globalThis["__MOBDEA_R20_MASTER_V6__"] = Object.freeze({
  pdfFastChunkRead: true,
  libraryEditorStickySave: true,
  mobdeaOnlineNativeDashboardIcon: true,
  boardFullscreenToolsVisible: true,
  countryCardsVisible: true,
  studentsAllVisibleWithPoints: true,
  mapPinchZoom: true,
  mapAtlasNamedAndUnnamed: true,
  nileFocusedMap: true,
  mapChallengeNoDrawingTools: true,
  termDefinitionInPlaceText: true,
  deepReviewedCardAutoFit: true,
});
globalThis["__MOBDEA_V7_FINAL_DEEP_REVIEWED__"] = true;
globalThis["__MOBDEA_V7_FINAL__"] = Object.freeze({
  globalResponsiveLayout: true,
  classModeFullStage: true,
  fastPdfCacheAndPrefetch: true,
  focalPinchZoomAndPan: true,
  compactMediaControls: true,
  resourceSwitcher: true,
  dualStudentRails: true,
  smoothSharedDrawing: true,
  realFontChoices: true,
  mapGeometryPreserved: true,
  eurasiaRegion: true,
  riversAndReferenceLinesVisible: true,
  mapChallengeMapFirst: true,
  dashboardActionsRestored: true,
  mobdeaOnlineVisible: true,
  countryCardsVisible: true,
  responsiveCountryAndDefinitionCards: true,
  automaticArabicSentenceCorrection: true,
  equalAreaMapProjection: true,
  bundledArabicFonts: true,
  powerpointSlideStateMemory: true,
  mapChallengeNoDrawingTools: true,
});
globalThis["__MOBDEA_V8_FINAL_REAL_REVIEWED__"] = Object.freeze({
  globalLayoutPageByPage: true,
  fullscreenTopOnly: true,
  sameTypeCompactResourceSwitching: true,
  pdfLosslessAdaptiveQuality: true,
  sharedMediaDrawingControls: true,
  studentRailsOnly: true,
  mapControlsDraggable: true,
  mapChallengeDraggableSelectors: true,
  continuousReferenceLines: true,
  refinedRiverRendering: true,
  ocrParserImportPipelineValidated: true,
  ocrDeviceRuntimeRequiresCodespace: true,
  runtimeQaManifest: true,
  classModeLazyRuntimeUsesMountedScene: true,
  unifiedBoardCoordinateSpace1536x864: true,
  nativeFirstArabicTtsWithBrowserFallback: true,
});
installViewportMetrics();
installTabletRuntime();

const rootElement = document.getElementById("root");
let bootCompleted = false;

// Heavy feature runtimes are activated only when their page is mounted. This
// keeps the initial tablet boot focused on the shell/dashboard instead of
// eagerly parsing OCR, maps, games, cards and media enhancements.
const lazyRuntimeRules = [
  {
    selector: '.question-bank-page-v8, .grade-scanner-page-v8, .project08-ocr-import-panel',
    loaders: [
      () => import('./services/r20PageOcrPipeline.js'),
      () => import('./services/r20OcrUiGuard.js'),
      () => import('./services/r20QuestionBankPipeline.js'),
    ],
  },
  {
    selector: '.classmode-scene, .standalone-whiteboard-page-v8',
    loaders: [() => import('./services/r20WhiteboardRuntime.js')],
  },
  {
    selector: '.classmode-scene, .student-cards-page-v8, .content-library-page-v8',
    loaders: [
      () => import('./services/project04CardLayout.js'),
      () => import('./services/r20EducationalCards.js'),
      () => import('./services/r20CountryCards.js'),
    ],
  },
  {
    selector: '.classmode-map-embed, .map-challenge-pro',
    loaders: [() => import('./services/r20GeographyTruth.js')],
  },
  {
    selector: '.classmode-scene',
    loaders: [
      () => import('./services/r20ImageMode.js'),
      () => import('./services/r20MediaControls.js'),
      () => import('./services/r20PowerPointMode.js'),
    ],
  },
  {
    selector: '.games-page-v8, .classmode-games-stage',
    loaders: [() => import('./services/r20GamesRuntime.js')],
  },
  {
    selector: '.grades-page-v8, .result-details-page-v8',
    loaders: [() => import('./services/r20ExamTracking.js')],
  },
  {
    selector: '.reports-page-v8',
    loaders: [() => import('./services/r20ReportsWhatsApp.js')],
  },
  {
    selector: '.smart-assistant-page-v8',
    loaders: [() => import('./services/r20RemedialAssistant.js')],
  },
  {
    selector: '.student-cards-page-v8',
    loaders: [() => import('./services/r20DuplexPrinting.js')],
  },
];

function installLazyFeatureRuntimes() {
  if (!rootElement || typeof MutationObserver === 'undefined') return;
  const pending = new Set(lazyRuntimeRules.map((_, index) => index));
  let observer = null;
  const scheduleLoad = (rule) => {
    const run = () => Promise.allSettled(rule.loaders.map((load) => load())).then((results) => {
      const failure = results.find((result) => result.status === 'rejected');
      if (failure) console.error('[Mobdea lazy runtime]', failure.reason);
    });
    if ('requestIdleCallback' in window) window.requestIdleCallback(run, { timeout: 700 });
    else window.setTimeout(run, 0);
  };
  const activateRule = (index) => {
    if (!pending.has(index)) return;
    pending.delete(index);
    scheduleLoad(lazyRuntimeRules[index]);
    if (!pending.size) observer?.disconnect();
  };
  const nodeMatchesRule = (node, selector) => {
    if (!(node instanceof Element)) return false;
    try {
      return node.matches(selector) || Boolean(node.querySelector(selector));
    } catch {
      return false;
    }
  };
  const scanNode = (node) => {
    for (const index of [...pending]) {
      if (nodeMatchesRule(node, lazyRuntimeRules[index].selector)) activateRule(index);
    }
  };

  // One complete scan at boot; after that inspect only newly mounted route nodes.
  for (const index of [...pending]) {
    if (rootElement.querySelector(lazyRuntimeRules[index].selector)) activateRule(index);
  }
  if (!pending.size) return;

  observer = new MutationObserver((mutations) => {
    if (!pending.size) return;
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes || []) {
        scanNode(node);
        if (!pending.size) return;
      }
    }
  });
  observer.observe(rootElement, { childList: true, subtree: true });
}


installLazyFeatureRuntimes();

function showFatalBootMessage(error) {
  if (!rootElement || bootCompleted) return;
  rootElement.innerHTML = `<div class="fatal-screen" dir="rtl"><div class="fatal-card"><h1>تعذر بدء المنصة</h1><p>تم منع الشاشة البيضاء. أعد تشغيل التطبيق.</p><code>${String(error?.message || error || "خطأ غير معروف").replace(/[<&]/g, "")}</code><button type="button" onclick="location.reload()">إعادة تشغيل التطبيق</button></div></div>`;
}

window.addEventListener("error", (event) =>
  showFatalBootMessage(event.error || event.message),
);
window.addEventListener("unhandledrejection", (event) =>
  showFatalBootMessage(event.reason),
);

setTimeout(() => {
  if (
    !bootCompleted &&
    rootElement &&
    !rootElement.querySelector(".fatal-screen")
  ) {
    showFatalBootMessage(
      new Error("لم تكتمل تهيئة واجهة المنصة خلال الوقت المتوقع."),
    );
  }
}, 12000);

try {
  if (!rootElement) throw new Error("عنصر تشغيل المنصة غير موجود.");
  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
      <AppErrorBoundary>
        <App />
      </AppErrorBoundary>
    </React.StrictMode>,
  );
  requestAnimationFrame(() => {
    bootCompleted = true;
    document.documentElement.dataset.mobdeaBooted = "true";
  });
} catch (error) {
  showFatalBootMessage(error);
}

import "./styles/v8-country-cards-verified.css";

import './styles/v8-section-19-30-maps.css';

import "./styles/v8-section-31-40-map-challenge.css";
