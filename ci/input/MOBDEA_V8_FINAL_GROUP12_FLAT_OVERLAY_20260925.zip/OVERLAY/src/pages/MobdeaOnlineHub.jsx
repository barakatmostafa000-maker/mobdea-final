import { ExternalLink, Sparkles } from 'lucide-react';
import { identity } from '../config/identity';

const socialPages = [
  {
    id: 'facebook',
    title: 'Facebook',
    subtitle: 'صفحة المُبدع مصطفى بركات على فيسبوك',
    url: 'https://www.facebook.com/share/1AyBatYgJv/',
    icon: 'f',
  },
  {
    id: 'youtube',
    title: 'YouTube',
    subtitle: 'قناة المُبدع مصطفى بركات على يوتيوب',
    url: 'https://youtube.com/@mostafabarakat21?si=FczgywNrmc9FTBsl',
    icon: '▶',
  },
  {
    id: 'tiktok',
    title: 'TikTok',
    subtitle: 'حساب المُبدع مصطفى بركات على تيك توك',
    url: 'https://www.tiktok.com/@mostafabarakat210?_r=1&_t=ZS-996NuPuPOy1',
    icon: '♪',
  },
];

export default function MobdeaOnlineHub() {
  return (
    <section className="page mobdea-online-page-v8 mobdea-social-hub-v8">
      <header className="mobdea-online-hero-v8 panel">
        <div className="mobdea-online-brand-v8">
          <img src={identity.logo || identity.icon} alt={identity.schoolName} />
          <div>
            <span className="eyebrow">صفحات المُبدع الرسمية</span>
            <h2>المُبدع أونلاين</h2>
            <strong>{identity.teacherName}</strong>
            <p>{identity.teacherTitle} • {identity.schoolName}</p>
          </div>
        </div>
      </header>

      <div className="mobdea-social-grid-v8" aria-label="صفحات المُبدع على السوشيال ميديا">
        {socialPages.map((page) => (
          <a
            key={page.id}
            className={`mobdea-social-card-v8 ${page.id}`}
            href={page.url}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`فتح ${page.title}`}
          >
            <span className="mobdea-social-icon-v8" aria-hidden="true">{page.icon}</span>
            <div><strong>{page.title}</strong><small>{page.subtitle}</small></div>
            <ExternalLink size={18} />
          </a>
        ))}
      </div>

      <footer className="mobdea-online-footer-v8">
        <Sparkles size={16} /> ثلاث أيقونات مستقلة؛ كل أيقونة تفتح الصفحة الرسمية الخاصة بها مباشرة.
      </footer>
    </section>
  );
}
