import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Circle,
  Diamond,
  Download,
  Eraser,
  FileImage,
  Highlighter,
  ImagePlus,
  Maximize2,
  MousePointer2,
  Move,
  PenLine,
  Plus,
  Redo2,
  RotateCcw,
  Save,
  Shapes,
  Square,
  Trash2,
  Triangle,
  Type,
  Undo2,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { identity } from '../config/identity';
import { useAssetUrl } from '../hooks/useAssetUrl';
import { usePdfPage } from '../hooks/usePdfPage';
import { importLegacyDataUrl, storeAsset } from '../services/assetStore';
import { formatDateAr, todayISO } from '../utils/time';
import { boardPointFromClient } from '../utils/boardPoint.js';
import { isArabicBoardFontAvailable } from '../services/v8BoardFontAvailability.js';

const BOARD_WIDTH = 1536;
const BOARD_HEIGHT = 864;
const colors = ['#111827', '#ffffff', '#2563eb', '#06b6d4', '#16a34a', '#facc15', '#f97316', '#dc2626', '#ec4899', '#7c3aed'];
const lineStyles = [
  { value: 'solid', label: 'خط متصل' },
  { value: 'dashed', label: 'خط متقطع' },
  { value: 'dotted', label: 'خط منقّط' },
  { value: 'calligraphy', label: 'لمسة خطاط' },
];
const boardFonts = [
  { value: "'Noto Naskh Arabic', 'Amiri', serif", probe: 'Noto Naskh Arabic', label: 'نسخ — نصوص ودروس' },
  { value: "'Aref Ruqaa', 'Amiri', serif", probe: 'Aref Ruqaa', label: 'رقعة — عناوين سريعة' },
  { value: "'Noto Kufi Arabic', 'Reem Kufi', sans-serif", probe: 'Noto Kufi Arabic', label: 'كوفي — عناوين قوية' },
  { value: "'Amiri', 'Noto Naskh Arabic', serif", probe: 'Amiri', label: 'أميري — نص رسمي' },
  { value: "'Reem Kufi', 'Noto Kufi Arabic', sans-serif", probe: 'Reem Kufi', label: 'ريم كوفي — عناوين حديثة' },
];
const WHITEBOARD_TOOL_SIZES = Object.freeze({
  pen: [2, 3, 4, 5, 8, 12, 16, 20],
  highlighter: [10, 12, 18, 24, 32, 40, 52],
  eraser: [16, 24, 32, 48, 64, 80, 104],
});

function actionBounds(action) {
  if (action.kind === 'stroke') {
    const xs = action.points.map((point) => point.x);
    const ys = action.points.map((point) => point.y);
    return { x: Math.min(...xs) - 14, y: Math.min(...ys) - 14, width: Math.max(...xs) - Math.min(...xs) + 28, height: Math.max(...ys) - Math.min(...ys) + 28 };
  }
  if (action.kind === 'text') {
    const lines = String(action.text || '').split('\n');
    const size = Number(action.fontSize || 34);
    return { x: action.x - Math.max(120, ...lines.map((line) => line.length * size * 0.75)), y: action.y - size, width: Math.max(120, ...lines.map((line) => line.length * size * 0.75)), height: Math.max(54, lines.length * size * 1.35) };
  }
  return { x: Math.min(action.x, action.x2), y: Math.min(action.y, action.y2), width: Math.abs(action.x2 - action.x), height: Math.abs(action.y2 - action.y) };
}

function drawAction(ctx, action, selected = false) {
  ctx.save();
  ctx.lineCap = action.lineStyle === 'calligraphy' ? 'square' : 'round';
  ctx.lineJoin = 'round';
  ctx.strokeStyle = action.color || '#111827';
  ctx.fillStyle = action.color || '#111827';
  ctx.lineWidth = action.width || 5;
  if (action.lineStyle === 'dashed') ctx.setLineDash([18, 12]);
  else if (action.lineStyle === 'dotted') ctx.setLineDash([2, 12]);
  else ctx.setLineDash([]);

  if (action.kind === 'stroke') {
    ctx.globalAlpha = action.tool === 'highlighter' ? 0.28 : 1;
    ctx.globalCompositeOperation = action.tool === 'eraser' ? 'destination-out' : 'source-over';
    ctx.lineWidth = action.tool === 'eraser'
      ? Math.max(26, action.width || 26)
      : action.tool === 'highlighter'
        ? Math.max(10, action.width || 18)
        : action.lineStyle === 'calligraphy'
          ? Math.max(7, (action.width || 5) * 1.35)
          : action.width || 5;
    const points = action.points || [];
    if (points.length === 1) {
      ctx.beginPath();
      ctx.arc(points[0].x, points[0].y, Math.max(1.5, ctx.lineWidth / 2), 0, Math.PI * 2);
      ctx.fillStyle = action.tool === 'eraser' ? '#000000' : (action.color || '#111827');
      ctx.fill();
    } else if (points.length > 1) {
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      for (let index = 1; index < points.length - 1; index += 1) {
        const current = points[index];
        const next = points[index + 1];
        const midX = (current.x + next.x) / 2;
        const midY = (current.y + next.y) / 2;
        ctx.quadraticCurveTo(current.x, current.y, midX, midY);
      }
      const last = points[points.length - 1];
      ctx.lineTo(last.x, last.y);
      ctx.stroke();
    }
  } else if (action.kind === 'text') {
    ctx.setLineDash([]);
    ctx.font = `${action.fontWeight || 700} ${action.fontSize || 34}px ${action.fontFamily || 'Tahoma, Arial, sans-serif'}`;
    String(action.text || '').split('\n').forEach((line, index) => {
      // Keep this renderer self-contained for standalone canvas export and isolation tests.
      const firstStrong = String(line).match(/[\p{Script=Arabic}\p{Script=Latin}]/u)?.[0];
      const leftToRight = Boolean(firstStrong && /\p{Script=Latin}/u.test(firstStrong));
      ctx.direction = leftToRight ? 'ltr' : 'rtl';
      ctx.textAlign = action.textAlign === 'center' ? 'center' : action.textAlign === 'left' ? 'left' : action.textAlign === 'right' ? 'right' : leftToRight ? 'left' : 'right';
      ctx.fillText(line, action.x, action.y + index * Number(action.fontSize || 34) * 1.35);
    });
  } else {
    const x = action.x;
    const y = action.y;
    const width = action.x2 - action.x;
    const height = action.y2 - action.y;
    if (action.kind === 'rect') ctx.strokeRect(x, y, width, height);
    if (action.kind === 'circle') {
      ctx.beginPath();
      ctx.ellipse(x + width / 2, y + height / 2, Math.abs(width / 2), Math.abs(height / 2), 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    if (action.kind === 'triangle') {
      ctx.beginPath();
      ctx.moveTo(x + width / 2, y);
      ctx.lineTo(action.x2, action.y2);
      ctx.lineTo(x, action.y2);
      ctx.closePath();
      ctx.stroke();
    }
    if (action.kind === 'diamond') {
      ctx.beginPath();
      ctx.moveTo(x + width / 2, y);
      ctx.lineTo(action.x2, y + height / 2);
      ctx.lineTo(x + width / 2, action.y2);
      ctx.lineTo(x, y + height / 2);
      ctx.closePath();
      ctx.stroke();
    }
    if (action.kind === 'line' || action.kind === 'arrow') {
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(action.x2, action.y2);
      ctx.stroke();
      if (action.kind === 'arrow') {
        const angle = Math.atan2(action.y2 - y, action.x2 - x);
        const size = 22;
        ctx.beginPath();
        ctx.moveTo(action.x2, action.y2);
        ctx.lineTo(action.x2 - size * Math.cos(angle - Math.PI / 6), action.y2 - size * Math.sin(angle - Math.PI / 6));
        ctx.moveTo(action.x2, action.y2);
        ctx.lineTo(action.x2 - size * Math.cos(angle + Math.PI / 6), action.y2 - size * Math.sin(angle + Math.PI / 6));
        ctx.stroke();
      }
    }
  }

  ctx.restore();
  if (selected) {
    const bounds = actionBounds(action);
    ctx.save();
    ctx.strokeStyle = '#d7ad35';
    ctx.lineWidth = 2;
    ctx.setLineDash([10, 7]);
    ctx.strokeRect(bounds.x, bounds.y, Math.max(12, bounds.width), Math.max(12, bounds.height));
    ctx.restore();
  }
}

function moveAction(action, dx, dy) {
  if (action.kind === 'stroke') return { ...action, points: action.points.map((point) => ({ x: point.x + dx, y: point.y + dy })) };
  if (action.kind === 'text') return { ...action, x: action.x + dx, y: action.y + dy };
  return { ...action, x: action.x + dx, y: action.y + dy, x2: action.x2 + dx, y2: action.y2 + dy };
}

function hitTest(actions, point) {
  for (let index = actions.length - 1; index >= 0; index -= 1) {
    const bounds = actionBounds(actions[index]);
    if (point.x >= bounds.x && point.x <= bounds.x + Math.max(14, bounds.width) && point.y >= bounds.y && point.y <= bounds.y + Math.max(14, bounds.height)) return actions[index].id;
  }
  return null;
}

export default function Whiteboard({ data, updateData, navigate }) {
  const currentSession = data.sessions.find((session) => session.current) || data.sessions[0] || null;
  const students = currentSession ? data.students.filter((student) => student.group === currentSession.group) : data.students;
  const resources = (data.contentLibrary || []).filter((resource) => ['image', 'pdf', 'textbook'].includes(resource.type));
  const [resourceId, setResourceId] = useState(resources[0]?.id || '');
  const resource = resources.find((item) => String(item.id) === String(resourceId)) || null;
  const savedLocalImageRecords = (data.whiteboardRecords || []).filter((record) =>
    String(record.sessionId ?? '') === String(currentSession?.id ?? '') && record.localAssetId);
  const savedLocalImages = [...new Map(savedLocalImageRecords.map((record) => [record.localAssetId, record])).values()];
  const resourceUrl = useAssetUrl(resource?.assetId, resource?.url);
  const [localImage, setLocalImage] = useState('');
  const [localImageKey, setLocalImageKey] = useState('');
  const [localAssetId, setLocalAssetId] = useState('');
  const localAssetUrl = useAssetUrl(localAssetId);
  const [resourcePage, setResourcePage] = useState(1);
  const pdfPage = usePdfPage(['pdf', 'textbook'].includes(resource?.type) ? resourceUrl : '', resourcePage);
  const [pages, setPages] = useState(() => {
    // Previously only page 1 was hydrated; saved pages and their PDF annotations vanished
    // after navigating away from the whiteboard. Scope hydration to this exact session.
    const restored = new Map();
    const sessionId = String(currentSession?.id ?? '');
    for (const record of [...(data.whiteboardRecords || [])].reverse()) {
      if (!record?.layerKey || !Array.isArray(record.actions)) continue;
      if (String(record.sessionId ?? '') !== sessionId) continue;
      const page = Math.min(40, Math.max(1, Number(record.page) || 1));
      if (!restored.has(page)) restored.set(page, {});
      restored.get(page)[record.layerKey] = record.actions;
    }
    const lastPage = Math.max(1, ...restored.keys());
    return Array.from({ length: lastPage }, (_, index) => ({
      id: `board-page-${index + 1}`, layers: restored.get(index + 1) || {},
    }));
  });
  const [pageIndex, setPageIndex] = useState(0);
  const [tool, setTool] = useState('pen');
  const [shape, setShape] = useState('rect');
  const [color, setColor] = useState('#2563eb');
  const [toolWidths, setToolWidths] = useState({ pen: 5, highlighter: 24, eraser: 32 });
  const [lineStyle, setLineStyle] = useState('solid');
  const [fontFamily, setFontFamily] = useState(boardFonts[0].value);
  const [fontSize, setFontSize] = useState(34);
  const [textAlign, setTextAlign] = useState('auto');
  const [fontAvailability, setFontAvailability] = useState(() =>
    Object.fromEntries(boardFonts.map((item) => [item.probe, null])),
  );
  const [zoom, setZoom] = useState(1);
  const [selectedId, setSelectedId] = useState(null);
  const [redo, setRedo] = useState([]);
  const [points, setPoints] = useState({});
  const [notice, setNotice] = useState('');
  const [textEditor, setTextEditor] = useState(null);
  const [boardArtworkFailed, setBoardArtworkFailed] = useState(false);
  const canvasRef = useRef(null);
  const shellRef = useRef(null);
  const drawing = useRef(false);
  const draft = useRef(null);
  const dragStart = useRef(null);
  const fileRef = useRef(null);
  const layerKey = localImage || localAssetId
    ? `local:${localImageKey || localAssetId || 'image'}`
    : resource
      ? `resource:${resource.id}:${['pdf', 'textbook'].includes(resource.type) ? resourcePage : 1}`
      : 'blank';
  const actions = pages[pageIndex]?.layers?.[layerKey] || pages[pageIndex]?.actions || [];
  const backgroundUrl = localImage || localAssetUrl || pdfPage.dataUrl || resourceUrl;
  const activeStrokeTool = ['pen', 'highlighter', 'eraser'].includes(tool) ? tool : 'pen';
  const activeStrokeWidth = Number(toolWidths[activeStrokeTool] || toolWidths.pen || 5);
  const activeStrokeSizes = WHITEBOARD_TOOL_SIZES[activeStrokeTool] || WHITEBOARD_TOOL_SIZES.pen;
  const visibleBoardFonts = boardFonts.filter((item) => fontAvailability[item.probe] !== false);
  const fontChoices = visibleBoardFonts.length ? visibleBoardFonts : [{ value: 'Tahoma, Arial, sans-serif', probe: 'System', label: 'خط الجهاز العربي — بديل' }];

  useEffect(() => {
    let cancelled = false;
    const fonts = globalThis.document?.fonts;
    if (!fonts?.load) {
      setFontAvailability(Object.fromEntries(boardFonts.map((item, index) => [item.probe, index === 0])));
      return undefined;
    }
    Promise.all(boardFonts.map(async (item) => {
      const spec = `700 34px "${item.probe}"`;
      const loaded = await isArabicBoardFontAvailable(item.probe);
      return [item.probe, loaded];
    })).then((entries) => {
      if (cancelled) return;
      const next = Object.fromEntries(entries);
      setFontAvailability(next);
      const selected = boardFonts.find((item) => item.value === fontFamily);
      if (selected && next[selected.probe] === false) {
        const replacement = boardFonts.find((item) => next[item.probe] === true);
        setFontFamily(replacement?.value || 'Tahoma, Arial, sans-serif');
      }
    });
    return () => { cancelled = true; };
  }, []);


  const ranked = useMemo(() => students.map((student) => ({ ...student, points: points[student.id] || 0 })).sort((a, b) => b.points - a.points), [students, points]);

  const commitActions = (nextActions) => {
    setPages((current) => current.map((page, index) => index === pageIndex
      ? { ...page, layers: { ...(page.layers || {}), [layerKey]: nextActions } }
      : page));
  };

  const render = (preview = null) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, BOARD_WIDTH, BOARD_HEIGHT);
    actions.forEach((action) => drawAction(ctx, action, action.id === selectedId));
    if (preview) drawAction(ctx, preview, false);
  };

  useEffect(() => { render(); }, [actions, selectedId]);

  useEffect(() => {
    setSelectedId(null);
    setRedo([]);
  }, [layerKey, pageIndex]);

  useEffect(() => () => {
    if (localImage) URL.revokeObjectURL(localImage);
  }, [localImage]);

  useEffect(() => {
    const onKey = (event) => {
      if ((event.key === 'Delete' || event.key === 'Backspace') && selectedId && !['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)) {
        commitActions(actions.filter((action) => action.id !== selectedId));
        setSelectedId(null);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selectedId, actions]);

  const pointFromEvent = (event) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const source = event.touches?.[0] || event;
    return boardPointFromClient(source.clientX, source.clientY, rect, BOARD_WIDTH, BOARD_HEIGHT);
  };

  const onPointerDown = (event) => {
    event.preventDefault();
    event.currentTarget?.setPointerCapture?.(event.pointerId);
    const point = pointFromEvent(event);
    if (!point) return;
    if (tool === 'select' || tool === 'move') {
      const id = hitTest(actions, point);
      setSelectedId(id);
      if (id && tool === 'move') dragStart.current = { point, actions };
      return;
    }
    setSelectedId(null);
    if (tool === 'text') {
      setTextEditor({ x: point.x, y: point.y, value: '' });
      return;
    }
    drawing.current = true;
    if (tool === 'pen' || tool === 'highlighter' || tool === 'eraser') {
      draft.current = { id: Date.now(), kind: 'stroke', tool, points: [point], color, width: activeStrokeWidth, lineStyle };
    } else {
      draft.current = {
        id: Date.now(), kind: shape === 'arrow' ? 'arrow' : shape,
        x: point.x, y: point.y, x2: point.x, y2: point.y,
        color, width: Number(toolWidths.pen || 5), lineStyle,
      };
    }
  };

  const onPointerMove = (event) => {
    if (dragStart.current && selectedId && tool === 'move') {
      event.preventDefault();
      const point = pointFromEvent(event);
      if (!point) return;
      const dx = point.x - dragStart.current.point.x;
      const dy = point.y - dragStart.current.point.y;
      const next = dragStart.current.actions.map((action) => action.id === selectedId ? moveAction(action, dx, dy) : action);
      commitActions(next);
      return;
    }
    if (!drawing.current || !draft.current) return;
    event.preventDefault();
    const nativeEvent = event.nativeEvent || event;
    const samples = nativeEvent.getCoalescedEvents?.() || [nativeEvent];
    if (draft.current.kind === 'stroke') {
      samples.forEach((sample) => { const point = pointFromEvent(sample); if (point) draft.current.points.push(point); });
    } else {
      const point = pointFromEvent(samples[samples.length - 1]);
      if (!point) return;
      draft.current.x2 = point.x;
      draft.current.y2 = point.y;
    }
    render(draft.current);
  };

  const onPointerUp = (event) => {
    try { event?.currentTarget?.releasePointerCapture?.(event.pointerId); } catch { /* pointer capture already released */ }
    if (dragStart.current) {
      dragStart.current = null;
      setRedo([]);
      return;
    }
    if (!drawing.current || !draft.current) return;
    commitActions([...actions, draft.current]);
    // لا نحدد الخط تلقائيًا بعد الكتابة؛ التحديد يظهر فقط عند اختيار أداة التحديد.
    setSelectedId(null);
    setRedo([]);
    draft.current = null;
    drawing.current = false;
  };

  const commitTextEditor = () => {
    if (!textEditor || !textEditor.value.trim()) { setTextEditor(null); return; }
    // Preserve mixed Arabic/English, diacritics, spaces and the teacher's original punctuation.
    const enteredText = textEditor.value;
    commitActions([...actions, {
      id: globalThis.crypto?.randomUUID?.() || `text-${Date.now()}-${Math.random()}`,
      kind: 'text', text: enteredText, x: textEditor.x, y: textEditor.y,
      color, fontSize, fontFamily, fontWeight: 700, textAlign,
    }]);
    setRedo([]);
    setTextEditor(null);
  };

  const undo = () => {
    if (!actions.length && redo[0]?.kind === 'cleared-layer') {
      commitActions(redo[0].actions);
      setRedo([{ kind: 'clear-again' }]);
      return;
    }
    if (!actions.length) return;
    const last = actions[actions.length - 1];
    commitActions(actions.slice(0, -1));
    setRedo((current) => [last, ...current]);
    setSelectedId(null);
  };

  const redoAction = () => {
    if (!redo.length) return;
    const [next, ...rest] = redo;
    commitActions(next?.kind === 'clear-again' ? [] : [...actions, next]);
    setRedo(rest);
  };

  const addPage = () => {
    setPages((current) => [...current, { id: Date.now(), layers: {} }]);
    setPageIndex(pages.length);
    setRedo([]);
    setSelectedId(null);
  };

  const drawBackground = async (ctx) => {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, BOARD_WIDTH, BOARD_HEIGHT);
    if (!backgroundUrl) {
      try {
        const board = new Image();
        await new Promise((resolve, reject) => { board.onload = resolve; board.onerror = reject; board.src = '/identity/class-board-history-v14.jpg?art=050a3927a7ba'; });
        const scale = Math.min(BOARD_WIDTH / board.naturalWidth, BOARD_HEIGHT / board.naturalHeight);
        const width = board.naturalWidth * scale;
        const height = board.naturalHeight * scale;
        ctx.drawImage(board, (BOARD_WIDTH - width) / 2, (BOARD_HEIGHT - height) / 2, width, height);
      } catch { /* Approved image unavailable: the board stays white. */ }
      return;
    }
    if (['pdf', 'textbook'].includes(resource?.type) && !pdfPage.dataUrl) return;
    try {
      const image = new Image();
      image.crossOrigin = 'anonymous';
      await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = reject; image.src = backgroundUrl; });
      const ratio = Math.min(BOARD_WIDTH / image.width, BOARD_HEIGHT / image.height);
      const drawWidth = image.width * ratio;
      const drawHeight = image.height * ratio;
      ctx.drawImage(image, (BOARD_WIDTH - drawWidth) / 2, (BOARD_HEIGHT - drawHeight) / 2, drawWidth, drawHeight);
    } catch {
      // The drawing layer remains exportable even if a remote image blocks canvas export.
    }
  };

  const makeBoardImage = async () => {
    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = BOARD_WIDTH;
    exportCanvas.height = BOARD_HEIGHT;
    const ctx = exportCanvas.getContext('2d');
    await drawBackground(ctx);
    const ink = document.createElement('canvas');
    ink.width = BOARD_WIDTH; ink.height = BOARD_HEIGHT;
    const inkCtx = ink.getContext('2d');
    actions.forEach((action) => drawAction(inkCtx, action, false));
    ctx.drawImage(ink, 0, 0);
    return exportCanvas.toDataURL('image/png');
  };

  const downloadBoard = async () => {
    const dataUrl = await makeBoardImage();
    const link = document.createElement('a');
    link.download = `سبورة-${currentSession?.title || 'الدرس'}-${todayISO()}-${pageIndex + 1}.png`;
    link.href = dataUrl;
    link.click();
    setNotice('تم حفظ صورة السبورة على الجهاز.');
  };

  const saveToPlatform = async () => {
    try {
      const dataUrl = await makeBoardImage();
      const asset = await importLegacyDataUrl(dataUrl, { name: `whiteboard-${Date.now()}.png`, kind: 'whiteboard' });
      const now = new Date().toISOString();
      const stamp = Date.now();
      const records = pages.flatMap((page, index) => {
        const layers = { ...(page.layers || {}) };
        if (index === pageIndex && !Object.prototype.hasOwnProperty.call(layers, layerKey)) layers[layerKey] = actions;
        return Object.entries(layers).map(([key, layer]) => ({
        id: `whiteboard-${stamp}-${index + 1}-${key}`,
        title: resource?.title || currentSession?.title || 'شرح على السبورة',
        sessionId: currentSession?.id || null,
        group: currentSession?.group || '',
        resourceId: key.startsWith('resource:') ? key.split(':')[1] : null,
        localAssetId: key.startsWith('local:') ? key.slice(6) : '',
        localAssetName: key === layerKey ? 'صورة الشرح المحفوظة' : '',
        page: index + 1,
        resourcePage: key.startsWith('resource:') ? Number(key.split(':')[2]) || 1 : 1,
        layerKey: key,
        boardAssetId: index === pageIndex && key === layerKey ? asset?.id || '' : '',
        actions: layer,
        points,
        createdAt: now,
      }));
      });
      // Write all pages and all PDF/image layers in one atomic data transaction;
      // do not replace other sessions' annotation records.
      await updateData((latest) => {
        const owned = new Set(records.map((record) => `${record.sessionId ?? ''}/${record.page}/${record.layerKey}`));
        const old = (latest.whiteboardRecords || []).filter((record) =>
          !owned.has(`${record.sessionId ?? ''}/${record.page}/${record.layerKey}`));
        return { ...latest, whiteboardRecords: [...records, ...old].slice(0, 500) };
      });
      setNotice(`تم حفظ ${records.length} طبقة شرح مع صفحاتها ومواردها.`);
    } catch (error) {
      setNotice(`تعذر حفظ طبقات السبورة: ${error?.message || 'خطأ غير معروف'}`);
    }
  };

  const toggleFullscreen = async () => {
    const node = shellRef.current;
    if (!node) return;
    const activeElement = document.fullscreenElement || document.webkitFullscreenElement;
    try {
      if (!activeElement) {
        const request = node.requestFullscreen || node.webkitRequestFullscreen;
        if (!request) throw new Error('fullscreen-unavailable');
        await request.call(node);
      } else {
        const exit = document.exitFullscreen || document.webkitExitFullscreen;
        if (!exit) throw new Error('fullscreen-exit-unavailable');
        await exit.call(document);
      }
    } catch {
      node.classList.toggle('css-fullscreen');
    }
  };

  const openLocalImage = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    event.target.value = '';
    try {
      // A blob: URL stops existing after closing the tab. Keep the image in the
      // existing encrypted asset store so its ink/background can both be restored.
      const asset = await storeAsset(file, { name: file.name, kind: 'whiteboard-image' });
      setLocalAssetId(asset.id);
      setLocalImage('');
      setLocalImageKey(asset.id);
      setResourceId('');
      setNotice(`تم حفظ الصورة للشرح: ${file.name}`);
    } catch (error) {
      setNotice(`تعذر حفظ الصورة محليًا: ${error?.message || 'خطأ غير معروف'}`);
    }
  };

  return (
    <section className="page whiteboard-page standalone-whiteboard-page-v8" ref={shellRef}>
      <header className="whiteboard-reference-header">
        <div className="whiteboard-brand-flag">
          <img src={identity.logo || identity.icon} alt={identity.schoolName} />
          <div><strong>المُبدع</strong><small>لتعليم ممتع</small></div>
        </div>
        <div className="whiteboard-title-plaque"><span>شرح الدرس</span><small>{resource?.title || currentSession?.title || 'السبورة التفاعلية'}</small></div>
        <div className="whiteboard-teacher-card">
          <img src={identity.portrait} alt={identity.teacherName} />
          <div><strong>{identity.teacherName}</strong><small>{identity.teacherTitle}</small></div>
        </div>
      </header>

      <div className="whiteboard-reference-layout">
        <aside className="whiteboard-tool-rail">
          <button type="button" className={tool === 'pen' ? 'active' : ''} onClick={() => setTool('pen')}><PenLine /><span>قلم حر</span></button>
          <button type="button" className={tool === 'select' ? 'active' : ''} onClick={() => setTool('select')}><MousePointer2 /><span>تحديد دقيق</span></button>
          <button type="button" className={tool === 'highlighter' ? 'active' : ''} onClick={() => setTool('highlighter')}><Highlighter /><span>قلم تمييز</span></button>
          <button type="button" className={tool === 'shape' ? 'active' : ''} onClick={() => setTool('shape')}><Shapes /><span>مكتبة الأشكال</span></button>
          <button type="button" className={tool === 'text' ? 'active' : ''} onClick={() => setTool('text')}><Type /><span>نص توضيحي</span></button>
          <button type="button" className={tool === 'move' ? 'active' : ''} onClick={() => setTool('move')}><Move /><span>تحريك العناصر</span></button>
          <button type="button" className={tool === 'eraser' ? 'active' : ''} onClick={() => setTool('eraser')}><Eraser /><span>الممحاة الذكية</span></button>
          <button type="button" onClick={() => fileRef.current?.click()}><ImagePlus /><span>إدراج صورة</span></button>
          <input ref={fileRef} type="file" accept="image/*" hidden onChange={openLocalImage} />
          <div className="whiteboard-rail-divider" />
          <button type="button" onClick={() => setZoom((value) => Math.min(2, value + 0.1))}><ZoomIn /><span>تكبير اللوحة</span></button>
          <button type="button" onClick={() => setZoom((value) => Math.max(0.6, value - 0.1))}><ZoomOut /><span>تصغير اللوحة</span></button>
          <button type="button" onClick={undo} disabled={!actions.length && redo[0]?.kind !== 'cleared-layer'}><Undo2 /><span>تراجع خطوة</span></button>
          <button type="button" onClick={redoAction} disabled={!redo.length || redo[0]?.kind === 'cleared-layer'}><Redo2 /><span>إعادة خطوة</span></button>
          <button type="button" onClick={saveToPlatform}><Save /><span>حفظ اللوحة</span></button>
          <button type="button" onClick={() => { if (!actions.length) return; commitActions([]); setRedo([{ kind: 'cleared-layer', actions }]); setSelectedId(null); }}><RotateCcw /><span>تنظيف اللوحة</span></button>
        </aside>

        <main className="whiteboard-paper-stage">
          <div className="whiteboard-resource-strip">
            <label><FileImage size={16} /><select value={localAssetId ? `saved-image:${localAssetId}` : resourceId} onChange={(event) => {
              const value = event.target.value;
              if (value.startsWith('saved-image:')) {
                const assetId = value.slice('saved-image:'.length);
                setLocalAssetId(assetId); setLocalImageKey(assetId); setResourceId('');
              } else { setLocalAssetId(''); setLocalImageKey(''); setResourceId(value); }
              setLocalImage(''); setResourcePage(1);
            }}><option value="">سبورة فارغة</option>{resources.map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}
              {savedLocalImages.map((record) => <option key={record.localAssetId} value={`saved-image:${record.localAssetId}`}>{record.localAssetName || 'صورة محفوظة للشرح'}</option>)}
            </select></label>
            {['pdf', 'textbook'].includes(resource?.type) && <div className="whiteboard-pdf-nav"><button type="button" onClick={() => setResourcePage((value) => Math.max(1, value - 1))} disabled={resourcePage <= 1}>‹</button><span>صفحة {resourcePage}{pdfPage.pageCount ? ` / ${pdfPage.pageCount}` : ''}</span><button type="button" onClick={() => setResourcePage((value) => pdfPage.pageCount ? Math.min(pdfPage.pageCount, value + 1) : value + 1)} disabled={Boolean(pdfPage.pageCount && resourcePage >= pdfPage.pageCount)}>›</button></div>}
            <div className="whiteboard-shape-picker" aria-label="مكتبة الأشكال التعليمية">
              <button type="button" className={shape === 'rect' ? 'active' : ''} onClick={() => { setShape('rect'); setTool('shape'); }} title="إطار توضيحي"><Square size={16} /></button>
              <button type="button" className={shape === 'circle' ? 'active' : ''} onClick={() => { setShape('circle'); setTool('shape'); }} title="دائرة مفاهيم"><Circle size={16} /></button>
              <button type="button" className={shape === 'triangle' ? 'active' : ''} onClick={() => { setShape('triangle'); setTool('shape'); }} title="هرم معرفي"><Triangle size={16} /></button>
              <button type="button" className={shape === 'diamond' ? 'active' : ''} onClick={() => { setShape('diamond'); setTool('shape'); }} title="معيّن تصنيفي"><Diamond size={16} /></button>
              <button type="button" className={shape === 'line' ? 'active' : ''} onClick={() => { setShape('line'); setTool('shape'); }} title="خط رابط"><PenLine size={16} /></button>
              <button type="button" className={shape === 'arrow' ? 'active' : ''} onClick={() => { setShape('arrow'); setTool('shape'); }} title="سهم توجيهي"><ArrowLeft size={16} /></button>
            </div>
            <div className="whiteboard-style-pickers">
              <label title="طراز الخط"><span>الخط</span><select value={lineStyle} onChange={(event) => setLineStyle(event.target.value)}>{lineStyles.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label>
              <label title="نوع الخط العربي"><span>الكتابة</span><select value={fontFamily} onChange={(event) => setFontFamily(event.target.value)}>{fontChoices.map((item) => <option key={item.value} value={item.value} style={{ fontFamily: item.value }}>{item.label}{fontAvailability[item.probe] === null ? ' — جارٍ التحقق' : ''}</option>)}</select></label>
              <label title="حجم النص"><span>الحجم</span><select value={fontSize} onChange={(event) => setFontSize(Number(event.target.value))}><option value="24">24</option><option value="28">28</option><option value="34">34</option><option value="42">42</option><option value="52">52</option><option value="68">68</option><option value="84">84</option></select></label>
              <label title="محاذاة الكتابة"><span>المحاذاة</span><select aria-label="محاذاة النص العربي" value={textAlign} onChange={(event) => setTextAlign(event.target.value)}><option value="auto">تلقائية حسب السطر</option><option value="right">يمين</option><option value="center">وسط</option><option value="left">يسار</option></select></label>
            </div>
          </div>
          {textEditor && (
            <div className="whiteboard-v8-text-editor" role="dialog" aria-label="إضافة نص عربي إلى السبورة">
              <label htmlFor="v8-board-text-input">اكتب النص كما تريد ظهوره (دون تصحيح تلقائي)</label>
              <textarea id="v8-board-text-input" autoFocus dir="auto" rows={3} value={textEditor.value}
                onChange={(event) => setTextEditor((current) => ({ ...current, value: event.target.value }))}
                onKeyDown={(event) => { if (event.key === 'Escape') setTextEditor(null); if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) commitTextEditor(); }} />
              <div><button type="button" onClick={commitTextEditor} disabled={!textEditor.value.trim()}>إضافة النص</button>
              <button type="button" onClick={() => setTextEditor(null)}>إلغاء</button></div>
            </div>
          )}
          <div className="whiteboard-canvas-viewport">
            <div className="whiteboard-canvas-stack" style={{ transform: `scale(${zoom})` }}>
              {!backgroundUrl && !boardArtworkFailed && <img src="/identity/class-board-history-v14.jpg?art=050a3927a7ba" alt="" aria-hidden="true" onError={() => setBoardArtworkFailed(true)} className="whiteboard-approved-history-background" />}
              {backgroundUrl && (localImage || resource?.type === 'image' || pdfPage.dataUrl) && <img src={backgroundUrl} alt={resource?.title || 'صورة الشرح'} className="whiteboard-background-media" />}
              {resourceUrl && ['pdf', 'textbook'].includes(resource?.type) && !pdfPage.dataUrl && <iframe src={`${resourceUrl}#page=${resourcePage}&toolbar=0&navpanes=0`} title={resource.title} className="whiteboard-background-media" />}
              {pdfPage.loading && <div className="whiteboard-pdf-loading">جارٍ تجهيز صفحة PDF للكتابة...</div>}
              <canvas
                ref={canvasRef}
                width={BOARD_WIDTH}
                height={BOARD_HEIGHT}
                className="whiteboard-drawing-canvas"
                onPointerDown={onPointerDown}
                onPointerMove={onPointerMove}
                onPointerUp={onPointerUp}
                onPointerCancel={onPointerUp}
                onPointerLeave={(event) => { if (drawing.current) onPointerUp(event); }}
              />
            </div>
          </div>
          <div className="whiteboard-bottom-toolbar">
            <div className="whiteboard-stroke-controls">
              {colors.map((item) => <button key={item} type="button" className={color === item ? 'active' : ''} style={{ background: item }} onClick={() => setColor(item)} aria-label={`اختيار اللون ${item}`} />)}
              <label className="whiteboard-tool-size"><span>{activeStrokeTool === 'highlighter' ? 'سمك الهايلايتر' : activeStrokeTool === 'eraser' ? 'حجم الممحاة' : 'سمك القلم'}</span><select value={activeStrokeWidth} onChange={(event) => setToolWidths((current) => ({ ...current, [activeStrokeTool]: Number(event.target.value) }))}>{activeStrokeSizes.map((size) => <option key={`${activeStrokeTool}-${size}`} value={size}>{size}px</option>)}</select></label>
            </div>
            <div className="whiteboard-page-controls">
              <button type="button" disabled={pageIndex === 0} onClick={() => { setPageIndex((value) => Math.max(0, value - 1)); setSelectedId(null); }}><ArrowRight size={18} /></button>
              <span>{pageIndex + 1} / {pages.length}</span>
              <button type="button" disabled={pageIndex >= pages.length - 1} onClick={() => { setPageIndex((value) => Math.min(pages.length - 1, value + 1)); setSelectedId(null); }}><ArrowLeft size={18} /></button>
              <button type="button" onClick={addPage}><Plus size={17} /> صفحة جديدة</button>
            </div>
            <div className="whiteboard-view-controls">
              <button type="button" onClick={() => setZoom(1)}>100%</button>
              <button type="button" onClick={downloadBoard}><Download size={18} /></button>
              <button type="button" onClick={toggleFullscreen}><Maximize2 size={18} /></button>
              {selectedId && <button type="button" className="danger" onClick={() => { commitActions(actions.filter((action) => action.id !== selectedId)); setSelectedId(null); }}><Trash2 size={17} /></button>}
            </div>
          </div>
          {notice && <button type="button" className="whiteboard-notice" onClick={() => setNotice('')}>{notice}</button>}
        </main>

        <aside className="whiteboard-students-panel">
          <div className="whiteboard-students-head"><strong>الطلاب والنقاط</strong><small>{students.length} طالبًا</small></div>
          <div className="whiteboard-students-list">
            {ranked.map((student, index) => (
              <div key={student.id}>
                <span>{index + 1}</span>
                <strong>{student.name}</strong>
                <b>{student.points}</b>
                <button type="button" onClick={() => setPoints((current) => ({ ...current, [student.id]: (current[student.id] || 0) + 1 }))}><Plus size={15} /></button>
              </div>
            ))}
          </div>
          <div className="whiteboard-motto"><BookOpenIcon /><strong>التعليم اليوم</strong><span>يصنع مستقبلًا أفضل</span></div>
        </aside>
      </div>

      <footer className="whiteboard-reference-footer">
        <button type="button" onClick={() => navigate('dashboard')}><ArrowRight size={17} /> خروج من السبورة</button>
        <span>{formatDateAr(todayISO())}</span>
        <button type="button" onClick={saveToPlatform}><Save size={17} /> حفظ وربط بالحصة</button>
      </footer>
    </section>
  );
}

function BookOpenIcon() {
  return <span className="whiteboard-book-mark">✦</span>;
}
