import { lazy, Suspense, useEffect, useMemo, useRef, useState } from "react";
import worldCountries from "../data/world-countries.json";
import {
  BrainCircuit,
  ChevronLeft,
  Compass,
  EyeOff,
  Flag,
  Gamepad2,
  Gem,
  GraduationCap,
  Layers3,
  Lightbulb,
  MapPin,
  Maximize2,
  Minimize2,
  Mountain,
  RotateCcw,
  Settings,
  SkipForward,
  Sparkles,
  Target,
  TimerReset,
  Trophy,
  Type,
  Users,
  Waves,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { identity } from "../config/identity";
import { encourageStudent } from "../services/voice";
import { subscriptionMessage } from "../services/rolePortalAccess";
import { claimVisitorTrial } from "../services/visitorTrialClient";
import {
  calculateMapReward,
  normalizeMapAnswer,
  shuffleMapItems,
} from "../utils/mapChallenge";
import { MAP_RIVER_LINES, countryInfo, featureInfo } from "../data/mapEnrichment";
import { percentWithinMapViewport } from "../services/mapSvgViewport.js";
import { filterChallengeSymbols, mapChallengeFeatureInfo, canAnswerMapTap } from "../services/v8MapChallengeFeatures.js";
import {
  GEOGRAPHY_REGIONS,
  GEOGRAPHY_LAYERS,
  GEOGRAPHY_TEACHING_CATEGORIES,
  getTeachingCategoryLayers,
  GEOGRAPHY_SYMBOLS,
  createMapProjector,
  getRegionCountries,
  getRegionLayerItems,
} from "../data/geography";

const ProfessionalMap = lazy(() => import("../components/maps/ProfessionalMap"));
const GeographyGlyph = lazy(() =>
  import("../components/maps/ProfessionalMap").then((module) => ({ default: module.GeographyGlyph })),
);

const regions = GEOGRAPHY_REGIONS;
const coreRegionKeys = [
  "egypt",
  "arab",
  "africa",
  "nile",
  "asia",
  "europe",
  "eurasia",
  "northAmerica",
  "southAmerica",
  "australia",
  "world",
];

const layers = {
  countries: { ...GEOGRAPHY_LAYERS.countries, icon: Flag },
  borders: { ...GEOGRAPHY_LAYERS.borders, icon: Layers3 },
  capitals: { ...GEOGRAPHY_LAYERS.capitals, icon: MapPin },
  cities: { ...GEOGRAPHY_LAYERS.cities, icon: MapPin },
  mountains: { ...GEOGRAPHY_LAYERS.mountains, icon: Mountain },
  plateaus: { ...GEOGRAPHY_LAYERS.plateaus, icon: Mountain },
  plains: { ...GEOGRAPHY_LAYERS.plains, icon: Layers3 },
  deserts: { ...GEOGRAPHY_LAYERS.deserts, icon: Layers3 },
  rivers: { ...GEOGRAPHY_LAYERS.rivers, icon: Waves },
  lakes: { ...GEOGRAPHY_LAYERS.lakes, icon: Waves },
  seas: { ...GEOGRAPHY_LAYERS.seas, icon: Waves },
  oceans: { ...GEOGRAPHY_LAYERS.oceans, icon: Waves },
  gulfs: { ...GEOGRAPHY_LAYERS.gulfs, icon: Waves },
  straits: { ...GEOGRAPHY_LAYERS.straits, icon: Waves },
  canals: { ...GEOGRAPHY_LAYERS.canals, icon: Waves },
  minerals: { ...GEOGRAPHY_LAYERS.minerals, icon: Gem },
  energy: { ...GEOGRAPHY_LAYERS.energy, icon: Gem },
  agriculture: { ...GEOGRAPHY_LAYERS.agriculture, icon: Layers3 },
  industry: { ...GEOGRAPHY_LAYERS.industry, icon: Layers3 },
  ports: { ...GEOGRAPHY_LAYERS.ports, icon: MapPin },
  landmarks: { ...GEOGRAPHY_LAYERS.landmarks, icon: MapPin },
  latitude: { ...GEOGRAPHY_LAYERS.latitude, icon: Compass },
  longitude: { ...GEOGRAPHY_LAYERS.longitude, icon: Compass },
  directions: { ...GEOGRAPHY_LAYERS.directions, icon: Compass },
  population: { ...GEOGRAPHY_LAYERS.population, icon: Users },
};

const modeConfig = {
  challenge: {
    label: "وضع التحدي",
    icon: Target,
    seconds: 35,
    lives: 3,
    multiplier: 1,
    description: "أسئلة متتابعة ونقاط حسب السرعة",
  },
  explore: {
    label: "وضع الاستكشاف",
    icon: Compass,
    seconds: 0,
    lives: 99,
    multiplier: 0,
    description: "استكشف الدول والظاهرات بحرية",
  },
  training: {
    label: "وضع التدريب",
    icon: GraduationCap,
    seconds: 60,
    lives: 8,
    multiplier: 0.65,
    description: "وقت أطول وتلميحات تعليمية",
  },
  naming: {
    label: "اكتب الاسم",
    icon: Type,
    seconds: 45,
    lives: 5,
    multiplier: 0.85,
    description: "اكتب اسم الموقع المحدد على الخريطة",
  },
  build: {
    label: "وضع البناء",
    icon: Layers3,
    seconds: 0,
    lives: 99,
    multiplier: 0.45,
    description: "ضع عناصر الجغرافيا على الخريطة",
  },
  contest: {
    label: "البطولات",
    icon: Trophy,
    seconds: 20,
    lives: 2,
    multiplier: 1.5,
    description: "أقصى سرعة ومكافآت أعلى",
  },
};

const allBuildPalette = GEOGRAPHY_SYMBOLS;
const economicSymbolPriority = (item) => {
  const semanticKey = `${item.id} ${item.groupId} ${item.label || ''} ${item.groupLabel || ''}`.toLowerCase();
  return /mineral|iron|gold|phosphate|petroleum|oil|gas|port|agric|industry|factory/u.test(semanticKey);
};

const buildSymbolCategories = [
  { key: 'resources', label: 'الثروات' },
  { key: 'water', label: 'المياه' },
  { key: 'terrain', label: 'التضاريس' },
  { key: 'human', label: 'البشرية' },
  { key: 'all', label: 'كل الرموز' },
];
const PROJECT07_MAP_CHALLENGE_SHARED_ENGINE_V1 = true;

export default function MapChallenge({ data, updateData, navigate, auth }) {
  const [geo] = useState(worldCountries);
  const [regionKey, setRegionKey] = useState("africa");
  const [teachingCategoryKey, setTeachingCategoryKey] = useState("terrain");
  const [layerKey, setLayerKey] = useState("mountains");
  const [mode, setMode] = useState("challenge");
  const [started, setStarted] = useState(false);
  const [order, setOrder] = useState([]);
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [message, setMessage] = useState("");
  const [labels, setLabels] = useState(false);
  const [mapStyle, setMapStyle] = useState("relief");
  const [silentMap, setSilentMap] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [seconds, setSeconds] = useState(modeConfig.challenge.seconds);
  const [lives, setLives] = useState(modeConfig.challenge.lives);
  const [placements, setPlacements] = useState([]);
  const [hintId, setHintId] = useState("");
  const [selectedId, setSelectedId] = useState("");
  const [selectedBuildItem, setSelectedBuildItem] = useState(null);
  const [selectedBuildPlacementId, setSelectedBuildPlacementId] = useState("");
  const [nameAnswer, setNameAnswer] = useState("");
  const [regionPickerOpen, setRegionPickerOpen] = useState(false);
  const [modePickerOpen, setModePickerOpen] = useState(false);
  const [categoryPickerOpen, setCategoryPickerOpen] = useState(false);
  const [layerPickerOpen, setLayerPickerOpen] = useState(false);
  const [detailItem, setDetailItem] = useState(null);
  const [buildCategory, setBuildCategory] = useState('resources');
  const [buildSearch, setBuildSearch] = useState('');
  const [awaitingNext, setAwaitingNext] = useState(false);
  const advanceTimerRef = useRef(null);
  const paletteRef = useRef(null);
  const [fullscreen, setFullscreen] = useState(false);
  const shellRef = useRef(null);
  const answerLockRef = useRef(false);
  const timerHandledRef = useRef("");
  const palettePointerRef = useRef(null);
  const settings = data?.settings || {};
  useEffect(() => () => clearTimeout(advanceTimerRef.current), []);
  const buildPalette = useMemo(() => {
    const filtered = filterChallengeSymbols(allBuildPalette, buildCategory, buildSearch);
    return buildCategory === 'resources'
      ? filtered.sort((a, b) => Number(economicSymbolPriority(b)) - Number(economicSymbolPriority(a)))
      : filtered;
  }, [buildCategory, buildSearch]);
  const selectQuestionLayer = (key) => {
    if (!layers[key]) return;
    setLayerKey(key);
    resetChallengeSelection();
    closeFloatingPickers();
  };
  useEffect(() => {
    function escape(event) { if (event.key === 'Escape') closeFloatingPickers(); }
    document.addEventListener('keydown', escape);
    return () => document.removeEventListener('keydown', escape);
  }, []);
  const toggleMapFullscreen = async () => {
    const node = shellRef.current;
    if (!node) return;
    const activeElement = document.fullscreenElement || document.webkitFullscreenElement;
    try {
      if (activeElement === node) {
        const exit = document.exitFullscreen || document.webkitExitFullscreen;
        if (!exit) throw new Error('fullscreen-exit-unavailable');
        await exit.call(document);
      } else {
        if (activeElement) {
          const exit = document.exitFullscreen || document.webkitExitFullscreen;
          if (exit) await exit.call(document);
        }
        const request = node.requestFullscreen || node.webkitRequestFullscreen;
        if (!request) throw new Error('fullscreen-unavailable');
        await request.call(node);
      }
    } catch {
      setMessage('لم يسمح المتصفح بملء الشاشة؛ جرّب زر ملء الشاشة بعد لمس الصفحة، أو افتح التطبيق على التابلت.');
      setFullscreen(document.fullscreenElement === node || document.webkitFullscreenElement === node);
    }
  };
  useEffect(() => {
    const onFullscreenChange = () => {
      const activeElement = document.fullscreenElement || document.webkitFullscreenElement;
      setFullscreen(activeElement === shellRef.current);
    };
    document.addEventListener('fullscreenchange', onFullscreenChange);
    document.addEventListener?.('webkitfullscreenchange', onFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', onFullscreenChange);
      document.removeEventListener?.('webkitfullscreenchange', onFullscreenChange);
    };
  }, []);
  const activeCategoryLayers = useMemo(
    () => getTeachingCategoryLayers(teachingCategoryKey).filter((key) => layers[key]),
    [teachingCategoryKey],
  );
  const resetChallengeSelection = () => {
    clearTimeout(advanceTimerRef.current);
    answerLockRef.current = false;
    setAwaitingNext(false);
    setStarted(false);
    setSelectedBuildItem(null);
    setSelectedBuildPlacementId("");
    setMessage("");
    setDetailItem(null);
  };
  const closeFloatingPickers = () => {
    setRegionPickerOpen(false);
    setModePickerOpen(false);
    setCategoryPickerOpen(false);
    setLayerPickerOpen(false);
  };
  const chooseRegion = (nextRegionKey) => {
    const candidates = getTeachingCategoryLayers(teachingCategoryKey).filter((key) => layers[key]);
    const nextLayer =
      candidates.find((key) => getRegionLayerItems(geo, nextRegionKey, key).length) ||
      candidates[0] ||
      "countries";
    setRegionKey(nextRegionKey);
    setZoom(1);
    setLayerKey(nextLayer);
    resetChallengeSelection();
    closeFloatingPickers();
  };
  const chooseMode = (nextMode) => {
    setMode(nextMode);
    resetChallengeSelection();
    closeFloatingPickers();
  };
  const chooseTeachingCategory = (categoryKey) => {
    const candidates = getTeachingCategoryLayers(categoryKey).filter((key) => layers[key]);
    const nextLayer = candidates.find((key) => getRegionLayerItems(geo, regionKey, key).length) || candidates[0] || 'countries';
    setTeachingCategoryKey(categoryKey);
    setLayerKey(nextLayer);
    resetChallengeSelection();
    closeFloatingPickers();
  };

  const region = regions[regionKey] || regions.world;
  const project = useMemo(() => createMapProjector(regionKey), [regionKey]);
  const countries = useMemo(
    () => getRegionCountries(geo, regionKey),
    [geo, regionKey],
  );
  const items = useMemo(() => {
    const rawItems = getRegionLayerItems(geo, regionKey, layerKey);
    if (!["countries", "borders", "population"].includes(layerKey)) return rawItems;
    return rawItems.map((item) => {
      if (!item.feature) return item;
      const shared = countryInfo(item.feature);
      return {
        ...item,
        countryInfo: shared,
        name: layerKey === "countries"
          ? shared.name
          : layerKey === "borders"
            ? `حدود ${shared.name}`
            : `سكان ${shared.name}`,
      };
    });
  }, [geo, countries, layerKey, regionKey]);
  const riverLines = useMemo(
    () => MAP_RIVER_LINES[regionKey] || [],
    [regionKey],
  );
  const activeConfig = modeConfig[mode];
  const target = order[index] || null;
  const progress =
    mode === "build"
      ? (placements.length ? 100 : 0)
      : order.length
        ? Math.round((index / order.length) * 100)
        : 0;

  const saveResult = async (status, finalScore = score) => {
    if (auth?.role === 'visitor') return;
    const result = {
      id: Date.now(),
      region: regionKey,
      layer: layerKey,
      mode,
      score: finalScore,
      streak,
      placements,
      status,
      answered:
        mode === "build"
          ? placements.length
          : Math.min(index + 1, order.length),
      total: mode === "build" ? placements.length : order.length,
      createdAt: new Date().toISOString(),
    };
    await updateData((latest) => ({
      ...latest,
      mapResults: [result, ...(latest.mapResults || [])].slice(0, 250),
    }));
  };

  const finish = async (status = "completed", finalScore = score) => {
    clearTimeout(advanceTimerRef.current);
    answerLockRef.current = true;
    setAwaitingNext(false);
    setStarted(false);
    setScore(finalScore);
    setMessage(
      status === "completed"
        ? "أحسنت! اكتملت الجولة وتم حفظ النتيجة."
        : "انتهت الجولة وتم حفظ النتيجة.",
    );
    await saveResult(status, finalScore);
  };

  const resetTimer = () => setSeconds(activeConfig.seconds || 0);
  const advance = async (finalScore = score) => {
    answerLockRef.current = false;
    timerHandledRef.current = "";
    setHintId("");
    setNameAnswer("");
    setSelectedId("");
    setDetailItem(null);
    setAwaitingNext(false);
    if (index + 1 >= order.length) await finish("completed", finalScore);
    else {
      setIndex((value) => value + 1);
      resetTimer();
    }
  };

  const wrongAnswer = async (reason = "إجابة غير صحيحة") => {
    setMessage(reason);
    setStreak(0);
    const nextLives = Math.max(0, lives - 1);
    setLives(nextLives);
    if (nextLives <= 0) await finish("out-of-lives");
  };

  useEffect(() => {
    if (
      !started ||
      !activeConfig.seconds ||
      ["build", "explore"].includes(mode)
    )
      return undefined;
    const id = setInterval(
      () => setSeconds((value) => answerLockRef.current ? value : Math.max(0, value - 1)),
      1000,
    );
    return () => clearInterval(id);
  }, [started, mode, index, activeConfig.seconds]);

  useEffect(() => {
    if (
      !started ||
      !activeConfig.seconds ||
      seconds !== 0 ||
      ["build", "explore"].includes(mode) || awaitingNext || answerLockRef.current
    )
      return;
    const timeoutKey = `${mode}:${regionKey}:${layerKey}:${index}`;
    if (timerHandledRef.current === timeoutKey) return;
    timerHandledRef.current = timeoutKey;
    answerLockRef.current = true;
    wrongAnswer("انتهى الوقت — حاول في السؤال التالي").then(() => {
      if (lives > 1) advance();
      else answerLockRef.current = false;
    });
  }, [
    seconds,
    started,
    mode,
    regionKey,
    layerKey,
    index,
    lives,
    awaitingNext,
    activeConfig.seconds,
  ]);



  const trialPendingRef = useRef(false);
  const startGame = async () => {
    if (!geo) {
      setMessage("انتظر لحظات حتى يكتمل تحميل الخريطة.");
      return;
    }
    if (mode !== "build" && items.length === 0) {
      setMessage("لا توجد عناصر متاحة في هذه الطبقة حاليًا. اختر طبقة أخرى.");
      return;
    }
    // Visitor attempts are counted on the server only after a usable map loads.
    if (auth?.role === 'visitor') {
      if (trialPendingRef.current) return;
      trialPendingRef.current = true;
      try {
        const trial = await claimVisitorTrial(data.settings, 'maps');
        if (!trial.allowed) {
          setMessage(subscriptionMessage());
          return;
        }
      } catch (error) {
        setMessage(error?.message || 'تعذر التحقق من التجربة المجانية.');
        return;
      } finally {
        trialPendingRef.current = false;
      }
    }
    answerLockRef.current = false;
    timerHandledRef.current = "";
    setOrder(shuffleMapItems(items));
    setIndex(0);
    setScore(0);
    setStreak(0);
    setLives(activeConfig.lives);
    setSeconds(activeConfig.seconds || 0);
    setMessage(
      mode === "explore"
        ? "اضغط على أي دولة أو ظاهرة لمعرفة اسمها."
        : mode === "build"
          ? "اختر عنصرًا ثم اضغط على موضعه، أو اسحبه إلى الخريطة."
          : "ابدأ الآن وحدد الإجابة على الخريطة.",
    );
    setPlacements([]);
    setSelectedBuildItem(null);
    setHintId("");
    setSelectedId("");
    setNameAnswer("");
    setDetailItem(null);
    setAwaitingNext(false);
    setStarted(true);
    if (mode === "explore") setLabels(true);
  };

  useEffect(() => {
    if (!started || mode !== "naming" || !target) return;
    setHintId(target.id);
    setLabels(false);
  }, [started, mode, target?.id]);

  const answer = async (id, name = "", feature = null) => {
    if (!canAnswerMapTap(started, mode)) return;
    const chosen = items.find((item) => item.id === id) ||
      (feature ? { id, name, feature } : null);
    if (mode === "explore") {
      setSelectedId(id);
      setDetailItem(chosen);
      setMessage(`📍 ${chosen?.name || name || "موقع على الخريطة"}`);
      return;
    }
    if (!target || answerLockRef.current) return;
    answerLockRef.current = true;
    if (id === target.id) {
      setSelectedId(id);
      setDetailItem(chosen || target);
      const reward = calculateMapReward({
        seconds,
        multiplier: activeConfig.multiplier,
        streak,
      });
      const nextScore = score + reward;
      setScore(nextScore);
      setStreak((value) => value + 1);
      setMessage(`إجابة صحيحة +${reward} نقطة`);
      encourageStudent("excellent", "", settings);
      // The next question is explicit: the info card stays visible until read.
      setAwaitingNext(true);
    } else {
      await wrongAnswer("ليست الإجابة المطلوبة — جرّب مرة أخرى");
      answerLockRef.current = false;
    }
  };

  const submitNameAnswer = async () => {
    if (!started || mode !== "naming" || !target || answerLockRef.current)
      return;
    const supplied = normalizeMapAnswer(nameAnswer);
    if (!supplied) {
      setMessage("اكتب اسم الموقع أولًا.");
      return;
    }
    answerLockRef.current = true;
    if (supplied === normalizeMapAnswer(target.name)) {
      const reward = calculateMapReward({
        seconds,
        multiplier: activeConfig.multiplier,
        streak,
      });
      const nextScore = score + reward;
      setScore(nextScore);
      setStreak((value) => value + 1);
      setMessage(`إجابة صحيحة +${reward} نقطة`);
      setSelectedId(target.id);
      setDetailItem(target);
      setAwaitingNext(true);
      return;
    }
    await wrongAnswer(`إجابة غير صحيحة — الموقع هو: ${target.name}`);
    answerLockRef.current = false;
  };

  const useHint = () => {
    if (!target || mode === "build" || awaitingNext) return;
    setHintId(target.id);
    setLabels(true);
    setScore((value) => Math.max(0, value - 30));
    setMessage("تم إظهار مكان الإجابة، وخصم 30 نقطة.");
    setTimeout(() => setHintId(""), 3000);
  };

  const skipQuestion = async () => {
    if (!target || awaitingNext) return;
    setScore((value) => Math.max(0, value - 20));
    setMessage(`تم تخطي: ${target.name}`);
    await advance();
  };

  const addBuildPlacement = (item, x, y) => {
    if (!item) return;
    const placement = {
      ...item,
      id: `${item.id}-${Date.now()}`,
      showLabel: false,
      x: Math.max(0, Math.min(100, x)),
      y: Math.max(0, Math.min(100, y)),
      size: 1,
    };
    setPlacements((current) => [...current, placement]);
    setSelectedBuildPlacementId(placement.id);
    setSelectedBuildItem(null);
    setScore((value) => value + 25);
    setMessage(`تم وضع ${item.label} على الخريطة`);
  };
  const clientPointToChallengeMapPercent = (stage, clientX, clientY) => {
    // HTML placements cover the SVG's *visible* 1000×620 viewport only.
    // Its transformed rectangle accounts for zoom, pan and letterboxing.
    const layer = stage?.querySelector?.('.map-pro-placement-layer');
    const transformed = stage?.querySelector?.(".map-pro-transform");
    return percentWithinMapViewport(clientX, clientY,
      layer?.getBoundingClientRect?.() || transformed?.getBoundingClientRect?.());
  };

  const handlePaletteDrag = (event, item) => {
    setSelectedBuildItem(item);
    event.dataTransfer.setData("application/json", JSON.stringify(item));
  };
  const handleDropPlacement = (event) => {
    if (mode !== "build" || !started) return;
    event.preventDefault();
    event.stopPropagation();
    try {
      const item = JSON.parse(event.dataTransfer.getData("application/json"));
      const point = clientPointToChallengeMapPercent(
        event.currentTarget,
        event.clientX,
        event.clientY,
      );
      if (!point) throw new Error("map-transform-unavailable");
      addBuildPlacement(item, point.x, point.y);
    } catch {
      setMessage("تعذر وضع العنصر هنا.");
    }
  };
  const handleMapStageClick = (event) => {
    if (mode !== "build" || !started || !selectedBuildItem || event.target.closest?.('.map-pro-placement')) return;
    const point = clientPointToChallengeMapPercent(
      event.currentTarget,
      event.clientX,
      event.clientY,
    );
    if (!point) return;
    addBuildPlacement(selectedBuildItem, point.x, point.y);
  };
  const startPalettePointer = (event, item) => {
    if (!started || mode !== 'build') return;
    setSelectedBuildItem(item);
    if (event.pointerType === "mouse") return;
    palettePointerRef.current = {
      item,
      startX: event.clientX,
      startY: event.clientY,
    };
    event.currentTarget.setPointerCapture?.(event.pointerId);
  };
  const finishPalettePointer = (event) => {
    const pending = palettePointerRef.current;
    palettePointerRef.current = null;
    if (!pending || event.pointerType === "mouse") return;
    const moved = Math.hypot(
      event.clientX - pending.startX,
      event.clientY - pending.startY,
    );
    if (moved < 12) return;
    const stage = document
      .elementFromPoint(event.clientX, event.clientY)
      ?.closest?.(".map-pro-stage");
    if (!stage) return;
    const point = clientPointToChallengeMapPercent(
      stage,
      event.clientX,
      event.clientY,
    );
    if (!point) return;
    if (!started || mode !== 'build') return;
    addBuildPlacement(pending.item, point.x, point.y);
  };



  const modeNav = Object.entries(modeConfig);
  return (
    <section ref={shellRef} className={`page map-challenge-pro map-game-v103 map-game-v11 ${fullscreen ? "map-challenge-fullscreen" : ""} ${!started ? "is-setup" : ""}`}>
      <header className="map-game-topbar">
        <div className="map-player-profile">
          <img src={identity.portrait} alt={identity.teacherName} />
          <div><strong>{identity.teacherName}</strong><small>تحدي الخرائط</small></div>
        </div>
        <div className="map-game-counters">
          <span>
            🪙 <b>{score}</b>
          </span>
          <span>
            ⭐ <b>{streak * 5}</b>
          </span>
          <span>
            ⚡{" "}
            <b>
              {Math.max(0, Math.round((lives / activeConfig.lives) * 100))}/100
            </b>
          </span>
        </div>
        <div className="map-game-title">
          <Trophy size={22} />
          <div>
            <strong>{modeConfig[mode].label}</strong>
            <small>{regions[regionKey].title}</small>
          </div>
        </div>
        <button type="button" className="map-game-fullscreen-btn" onClick={toggleMapFullscreen} aria-label={fullscreen ? "الخروج من ملء الشاشة" : "ملء الشاشة"} title={fullscreen ? "الخروج من ملء الشاشة" : "ملء الشاشة"}>
          {fullscreen ? <Minimize2 size={20} /> : <Maximize2 size={20} />}
        </button>
      </header>

      <div className="map-game-floating-selectors" aria-label="اختصارات تحدي الخرائط">
        <div
          className="map-game-floating-selector region-selector"
        >
          <button type="button" className={regionPickerOpen ? "active" : ""} onClick={() => { closeFloatingPickers(); setRegionPickerOpen(!regionPickerOpen); }} aria-expanded={regionPickerOpen} aria-label="اختيار الخريطة" title="اختيار الخريطة">
            <MapPin size={19}/>
          </button>
          {regionPickerOpen && (
            <div className="map-game-floating-menu region-menu">
              {coreRegionKeys.map((key) => (
                <button key={`float-region:${key}`} type="button" className={regionKey === key ? "active" : ""} onClick={() => chooseRegion(key)}>
                  {regions[key].title}
                </button>
              ))}
            </div>
          )}
        </div>
        <div
          className="map-game-floating-selector mode-selector"
        >
          <button type="button" className={modePickerOpen ? "active" : ""} onClick={() => { closeFloatingPickers(); setModePickerOpen(!modePickerOpen); }} aria-expanded={modePickerOpen} aria-label="اختيار وضع التحدي" title="اختيار وضع التحدي">
            <Settings size={19}/>
          </button>
          {modePickerOpen && (
            <div className="map-game-floating-menu mode-menu">
              {modeNav.map(([key, item]) => (
                <button key={`float-mode:${key}`} type="button" className={mode === key ? "active" : ""} onClick={() => chooseMode(key)}>
                  {item.label}
                </button>
              ))}
            </div>
          )}
        </div>
        <div
          className="map-game-floating-selector category-selector"
        >
          <button type="button" className={categoryPickerOpen ? "active" : ""} onClick={() => { closeFloatingPickers(); setCategoryPickerOpen(!categoryPickerOpen); }} aria-expanded={categoryPickerOpen} aria-label="اختيار تصنيف المنهج" title="اختيار تصنيف المنهج">
            <Layers3 size={19}/>
          </button>
          {categoryPickerOpen && (
            <div className="map-game-floating-menu category-menu">
              {Object.entries(GEOGRAPHY_TEACHING_CATEGORIES).map(([key, item]) => (
                <button key={`float-category:${key}`} type="button" className={teachingCategoryKey === key ? "active" : ""} onClick={() => chooseTeachingCategory(key)}>
                  {item.title}
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="map-game-floating-selector layer-selector">
          <button type="button" className={layerPickerOpen ? "active" : ""}
            onClick={() => { closeFloatingPickers(); setLayerPickerOpen(!layerPickerOpen); }}
            aria-expanded={layerPickerOpen} aria-label="اختيار نوع أسئلة الخريطة" title="نوع أسئلة الخريطة">
            <Layers3 size={19} />
          </button>
          {layerPickerOpen && (
            <div className="map-game-floating-menu layer-menu" role="group" aria-label="طبقات الأسئلة">
              {activeCategoryLayers.map((key) => {
                const Icon = layers[key].icon;
                return <button key={key} type="button" className={layerKey === key ? "active" : ""}
                  onClick={() => selectQuestionLayer(key)}>
                  <Icon size={17} /> {layers[key].title}
                </button>;
              })}
            </div>
          )}
        </div>
      </div>

      <div className="map-game-layout">
        <main className="map-game-main">
          <div className="map-challenge-view-controls" aria-label="أدوات عرض الخريطة والتكبير">
            <button
              type="button"
              className={silentMap ? "active" : ""}
              onClick={() => { setSilentMap(true); setLabels(false); }}
              title="خريطة صماء — إخفاء كل الكتابات"
              aria-label="خريطة صماء"
            >
              <EyeOff size={18} />
            </button>
            <button
              type="button"
              className={!silentMap && mapStyle === "relief" ? "active" : ""}
              onClick={() => { setSilentMap(false); setMapStyle("relief"); }}
              title="خريطة طبيعية"
              aria-label="خريطة طبيعية"
            >
              <Mountain size={18} />
            </button>
            <button
              type="button"
              className={!silentMap && mapStyle === "atlas" ? "active" : ""}
              onClick={() => { setSilentMap(false); setMapStyle("atlas"); }}
              title="أطلس تعليمي"
              aria-label="أطلس تعليمي"
            >
              <Compass size={18} />
            </button>
            <button type="button" onClick={() => setZoom((value) => Math.min(3.2, Number((value + 0.2).toFixed(2))))} title="تكبير" aria-label="تكبير">
              <ZoomIn size={18} />
            </button>
            <button type="button" onClick={() => setZoom((value) => Math.max(1, Number((value - 0.2).toFixed(2))))} title="تصغير" aria-label="تصغير">
              <ZoomOut size={18} />
            </button>
            <button type="button" onClick={() => setZoom(1)} title="إعادة ضبط التكبير" aria-label="إعادة ضبط التكبير">
              <RotateCcw size={18} />
            </button>
          </div>

          <div className="map-game-canvas-shell">
            {!geo && (
              <div className="map-game-loading">
                جارٍ تحميل حدود الخريطة الاحترافية…
              </div>
            )}
            <Suspense fallback={<div className="map-challenge-lazy-loading">جار تحميل الخريطة…</div>}>
              <ProfessionalMap
              region={region}
              countries={countries}
              items={items}
              layerKey={layerKey}
              labels={labels}
              showActiveLabel={mode !== "naming" || labels}
              highlightedId={hintId}
              selectedId={selectedId}
              project={project} regionKey={regionKey} teachingMode
              zoom={zoom}
              onZoomChange={setZoom}
              placements={placements}
              selectedPlacementId={selectedBuildPlacementId}
              onSelectPlacement={setSelectedBuildPlacementId}
              onCountryClick={(id, name, feature) => {
                if (['countries', 'borders', 'population'].includes(layerKey) && canAnswerMapTap(started, mode)) void answer(id, name, feature);
              }}
              onFeatureClick={(id, name, feature) => {
                if (canAnswerMapTap(started, mode) && items.some((item) => item.id === id)) void answer(id, name, feature);
              }}
              onDropPlacement={handleDropPlacement}
              onMovePlacement={(id, x, y) => {
                setPlacements((current) =>
                  current.map((item) =>
                    item.id === id ? { ...item, x, y } : item,
                  ),
                );
                setSelectedBuildPlacementId(id);
              }}
              onResizePlacement={(id, delta) => {
                setPlacements((current) =>
                  current.map((item) =>
                    item.id === id
                      ? {
                          ...item,
                          size: Math.max(
                            0.5,
                            Math.min(
                              2.5,
                              Number(((item.size || 1) + delta).toFixed(2)),
                            ),
                          ),
                        }
                      : item,
                  ),
                );
                setSelectedBuildPlacementId(id);
              }}
              onDuplicatePlacement={(id) => {
                const source = placements.find((item) => item.id === id);
                if (!source) return;
                const duplicate = {
                  ...source,
                  id: `${source.id}-copy-${Date.now()}`,
                  x: Math.max(0, Math.min(100, Number(source.x || 0) + 3)),
                  y: Math.max(0, Math.min(100, Number(source.y || 0) + 3)),
                };
                setPlacements((current) => [...current, duplicate]);
                setSelectedBuildPlacementId(duplicate.id);
              }}
              onRemovePlacement={(id) => {
                setPlacements((current) =>
                  current.filter((item) => item.id !== id),
                );
                setSelectedBuildPlacementId((current) =>
                  current === id ? "" : current,
                );
              }}
              onStageClick={handleMapStageClick}
              mapStyle={mapStyle}
              silent={silentMap}
              lineFeatures={riverLines}
              challengeTouchTargets
              challengeResourceSymbols={started && ['minerals', 'energy', 'agriculture', 'industry', 'ports'].includes(layerKey)}
            />
            </Suspense>
          </div>

          {detailItem && started && mode !== "build" && (() => {
            const info = mapChallengeFeatureInfo(detailItem, layerKey) || featureInfo(detailItem, layerKey);
            return (
              <aside className="map-challenge-info-card" dir="rtl" aria-live="polite" aria-label="بطاقة معلومات جغرافية">
                <button type="button" aria-label="إغلاق بطاقة المعلومات" onClick={() => setDetailItem(null)}>×</button>
                <strong>{info.flag ? `${info.flag} ` : ""}{info.name || detailItem.name}</strong>
                {info.capital && <span>العاصمة: {info.capital}</span>}
                {info.region && <span>الإقليم: {info.region}</span>}
                {info.continent && <span>القارة: {info.continent}</span>}
                {info.kind && !info.capital && <span>التصنيف: {layers[layerKey]?.title || "ظاهرة جغرافية"}</span>}
                <p>{info.fact}</p>
              </aside>
            );
          })()}
        </main>

        <aside className={`map-game-question-panel ${!started ? "is-setup" : ""}`}>
          {started && !['build', 'explore'].includes(mode) && <div className="map-question-progress">
            <span>
              السؤال {started ? Math.min(index + 1, order.length) : 0}/
              {order.length || items.length}
            </span>
            <b>{progress}%</b>
            <i>
              <em style={{ width: `${progress}%` }} />
            </i>
          </div>}
          <div className="map-question-copy">
            <BrainCircuit size={34} />
            <small>{region.subtitle}</small>
            <h3>
              {mode === "build"
                ? "اسحب عناصر الجغرافيا إلى الخريطة"
                : mode === "explore"
                  ? "اضغط على أي موضع لاستكشافه"
                  : mode === "naming"
                    ? "اكتب اسم الموقع المضيء على الخريطة"
                    : target
                      ? `حدد: ${target.name}`
                      : "اختر الإعدادات وابدأ الجولة"}
            </h3>
            {target && ["training", "explore"].includes(mode) && (() => {
              const info = mapChallengeFeatureInfo(target, layerKey);
              if (!info) return null;
              return (
                <p className="map-country-shared-fact map-feature-definition-card">
                  {target.countryInfo?.capital ? `العاصمة: ${target.countryInfo.capital} — ` : ""}
                  {target.countryInfo?.region ? `${target.countryInfo.region} — ` : ""}
                  {info.fact || "عنصر جغرافي مهم داخل الدرس."}
                </p>
              );
            })()}
          </div>
          {started && <div className="map-question-stats">
            <div>
              <span>الوقت</span>
              <strong>
                {activeConfig.seconds
                  ? `00:${String(seconds).padStart(2, "0")}`
                  : "∞"}
              </strong>
            </div>
            <div>
              <span>النقاط</span>
              <strong>{score.toLocaleString("ar-EG")}</strong>
            </div>
            <div>
              <span>المضاعف</span>
              <strong>×{activeConfig.multiplier}</strong>
            </div>
            <div>
              <span>الدقة</span>
              <strong>
                {index ? Math.round((streak / Math.max(index, 1)) * 100) : 100}%
              </strong>
            </div>
          </div>}
          {started && !['build', 'explore'].includes(mode) && <div className="map-lives">
            {Array.from(
              { length: Math.min(5, activeConfig.lives) },
              (_, lifeIndex) => (
                <span
                  key={lifeIndex}
                  className={lifeIndex < lives ? "alive" : ""}
                >
                  ♥
                </span>
              ),
            )}
          </div>}
          {mode === "build" && started && (
            <div className="map-build-toolbox">
              <div className="map-build-categories" role="group" aria-label="تصنيفات الرموز">
                {buildSymbolCategories.map((category) => (
                  <button key={category.key} type="button" className={buildCategory === category.key ? 'active' : ''}
                    aria-pressed={buildCategory === category.key} onClick={() => setBuildCategory(category.key)}>{category.label}</button>
                ))}
              </div>
              <input className="map-build-search" type="search" value={buildSearch}
                placeholder="ابحث عن معدن أو بترول أو ميناء..." aria-label="البحث عن رمز جغرافي"
                onChange={(event) => setBuildSearch(event.target.value)} />
              <div ref={paletteRef} className="map-build-palette">
              {buildPalette.map((item) => (
                <button
                  key={item.id}
                  draggable={started}
                  aria-pressed={selectedBuildItem?.id === item.id}
                  className={selectedBuildItem?.id === item.id ? "active" : ""}
                  onPointerDown={(event) => startPalettePointer(event, item)}
                  onPointerUp={finishPalettePointer}
                  onPointerCancel={() => {
                    palettePointerRef.current = null;
                  }}
                  onClick={() => {
                    setSelectedBuildItem(item);
                    setMessage(
                      `تم اختيار ${item.label} — اضغط على مكانه أو اسحب الشكل إلى الخريطة.`,
                    );
                  }}
                  onDragStart={(event) => handlePaletteDrag(event, item)}
                  type="button"
                  style={{ "--palette-color": item.color }}
                >
                  <b className="map-palette-glyph">
                    {item.asset ? <img src={item.asset} alt="" loading="lazy" /> : <Suspense fallback={<span aria-hidden="true">{item.symbol || "•"}</span>}><GeographyGlyph type={item.id} symbol={item.symbol} /></Suspense>}
                  </b>
                  <strong>{item.label}</strong>
                  <small>{item.hint}</small>
                </button>
              ))}
                {!buildPalette.length && <p>لا توجد رموز تطابق البحث.</p>}
              </div>
            </div>
          )}
          {message && (
            <div
              className={`map-game-message ${message.includes("صحيحة") || message.includes("تم وضع") || message.includes("📍") ? "good" : ""}`}
            >
              {message}
            </div>
          )}
          <div className="map-question-actions">
            {!started ? (
              <button
                type="button"
                className="map-start-button"
                onClick={startGame}
              >
                <Gamepad2 size={18} />
                ابدأ الجولة
              </button>
            ) : (
              <>
                {mode === "naming" && (
                  <div className="map-name-answer">
                    <input
                      value={nameAnswer}
                      onChange={(event) => setNameAnswer(event.target.value)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter") void submitNameAnswer();
                      }}
                      placeholder="اكتب اسم الدولة أو الظاهرة"
                      autoComplete="off"
                    />
                    <button
                      type="button"
                      onClick={() => void submitNameAnswer()}
                    >
                      تحقق
                    </button>
                  </div>
                )}
                {awaitingNext && (
                  <button type="button" className="map-next-question" onClick={() => void advance()}>
                    <ChevronLeft size={18} /> {index + 1 >= order.length ? 'عرض النتيجة' : 'السؤال التالي'}
                  </button>
                )}
                {!["build", "explore"].includes(mode) && !awaitingNext && (
                  <button type="button" onClick={useHint}>
                    <Lightbulb size={18} />
                    تلميح
                  </button>
                )}
                {!["build", "explore"].includes(mode) && !awaitingNext && (
                  <button type="button" onClick={skipQuestion}>
                    <SkipForward size={18} />
                    تخطي
                  </button>
                )}
                {mode === "build" && (
                  <button
                    type="button"
                    onClick={() => {
                      setPlacements([]);
                      setSelectedBuildItem(null);
                      setSelectedBuildPlacementId("");
                      setMessage("تم مسح عناصر البناء.");
                    }}
                  >
                    <RotateCcw size={18} />
                    مسح البناء
                  </button>
                )}
                <button
                  type="button"
                  onClick={() =>
                    finish(
                      mode === "build"
                        ? "completed"
                        : mode === "explore"
                          ? "explored"
                          : "stopped",
                    )
                  }
                >
                  <TimerReset size={18} />
                  {mode === "build"
                    ? "حفظ البناء"
                    : mode === "explore"
                      ? "إنهاء الاستكشاف"
                      : "إنهاء الجولة"}
                </button>
              </>
            )}
          </div>
          <div className="map-xp-reward">
            <Sparkles size={20} />
            <div>
              <strong>+{Math.round(score / 10)} XP</strong>
              <small>المكافأة الحالية</small>
            </div>
            <ChevronLeft size={18} />
          </div>
        </aside>
      </div>
    </section>
  );
}
