import { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft,
  Bell,
  BookOpen,
  BookOpenCheck,
  CalendarDays,
  CalendarClock,
  CheckCircle2,
  FolderOpen,
  Gamepad2,
  GraduationCap,
  LayoutDashboard,
  LibraryBig,
  MapPinned,
  MessageCircle,
  Presentation,
  QrCode,
  Radio,
  Search,
  Sparkles,
  Trophy,
  Users,
  WalletCards,
  X,
} from 'lucide-react';
import { identity } from '../config/identity';
import { formatDateAr, formatTime12, todayISO } from '../utils/time';
import { sessionsForToday } from '../services/dashboardSchedule';
import { roleGreeting, getRoleModules } from '../utils/auth';
import { filterContentLibraryForRole, roleDashboardProfile, scopeReadOnlyDataForRole, subscriptionMessage } from '../services/rolePortalAccess';
import { fetchVisitorTrialStatus } from '../services/visitorTrialClient';

const PROJECT10_ONLINE_CLASS_V1 = true;

const mainActions = [
  { id: 'mobdeaOnline', title: 'المبدع أونلاين', hint: 'فيسبوك ويوتيوب وتيك توك — صفحات المُبدع الرسمية', icon: Radio, tone: 'amber' },
  { id: 'onlineClass', title: 'الحصة الأونلاين', hint: 'إنشاء غرفة مباشرة ومشاركة الشرح والصوت والميكروفون', icon: Radio, tone: 'green' },
  { id: 'students', title: 'إدارة الطلاب', hint: 'إضافة وتعديل بيانات الطلاب ومتابعة ملفاتهم', icon: Users, tone: 'violet' },
  { id: 'attendance', title: 'الحضور والغياب', hint: 'تسجيل الحضور يدويًا أو باستخدام QR', icon: CheckCircle2, tone: 'green' },
  { id: 'reports', title: 'الدرجات والتقارير', hint: 'إدخال الدرجات واستعراض النتائج والتحليلات', icon: Trophy, tone: 'blue' },
  { id: 'contentLibrary', title: 'الدروس والمحتوى', hint: 'إدارة الدروس والملفات والشرح والوسائط', icon: BookOpen, tone: 'red' },
  { id: 'games', title: 'الألعاب التعليمية', hint: 'ألعاب تفاعلية لتعزيز الفهم والمراجعة', icon: Gamepad2, tone: 'amber' },
  { id: 'contentLibrary', title: 'المكتبة', hint: 'ملفات تعليمية وكتب وفيديوهات وخرائط', icon: FolderOpen, tone: 'orange' },
];

const studentActions = [
  { id: 'mobdeaOnline', title: 'المبدع أونلاين', hint: 'فيسبوك ويوتيوب وتيك توك', icon: Radio, tone: 'amber' },
  { id: 'onlineClass', title: 'الحصة الأونلاين', hint: 'دخول الحصة المباشرة عند تفعيلها', icon: Radio, tone: 'green' },
  { id: 'portalPreview', title: 'درجاتي', hint: 'نتائجي ومتوسط مستواي', icon: Trophy, tone: 'blue' },
  { id: 'portalPreview', title: 'الحضور والغياب', hint: 'سجل حضوري وتأخري وغيابي', icon: CheckCircle2, tone: 'green' },
  { id: 'portalPreview', title: 'المصروفات', hint: 'المدفوع والمتبقي في حسابي', icon: WalletCards, tone: 'orange' },
  { id: 'contentLibrary', title: 'محتواي', hint: 'فقط الدروس والكتب التي أتاحها المعلم لي', icon: BookOpen, tone: 'red' },
  { id: 'games', title: 'الألعاب التعليمية', hint: 'الألعاب والتحديات المتاحة لي', icon: Gamepad2, tone: 'amber' },
  { id: 'mapChallenge', title: 'تحدي الخرائط', hint: 'تدريب الخرائط والجغرافيا', icon: MapPinned, tone: 'violet' },
  { id: 'achievements', title: 'إنجازاتي', hint: 'النقاط والمستويات والجوائز', icon: Trophy, tone: 'blue' },
];

const guardianActions = [
  { id: 'mobdeaOnline', title: 'المبدع أونلاين', hint: 'فيسبوك ويوتيوب وتيك توك', icon: Radio, tone: 'amber' },
  { id: 'onlineClass', title: 'الحصة الأونلاين', hint: 'رابط الحصة المباشرة للطالب', icon: Radio, tone: 'green' },
  { id: 'portalPreview', title: 'درجات الطالب', hint: 'النتائج والمتوسط والتحسن', icon: Trophy, tone: 'blue' },
  { id: 'portalPreview', title: 'الحضور والغياب', hint: 'الحضور والتأخير والغياب', icon: CheckCircle2, tone: 'green' },
  { id: 'portalPreview', title: 'المصروفات', hint: 'المدفوع والمستحق والمتبقي', icon: WalletCards, tone: 'orange' },
  { id: 'portalPreview', title: 'التنبيهات والمتابعة', hint: 'رسائل ومتابعة مستوى الطالب', icon: MessageCircle, tone: 'red' },
  { id: 'contentLibrary', title: 'محتوى الطالب', hint: 'المحتوى الذي أتاحه المعلم للطالب', icon: BookOpen, tone: 'violet' },
];

const visitorActions = [
  { id: 'mobdeaOnline', title: 'المبدع أونلاين', hint: 'فيسبوك ويوتيوب وتيك توك', icon: Radio, tone: 'amber' },
  { id: 'games', title: 'تجربة ألعاب مجانية', hint: 'عدد محدود من الجولات قبل الاشتراك', icon: Gamepad2, tone: 'green' },
  { id: 'mapChallenge', title: 'تجربة تحدي الخرائط', hint: 'جولات مجانية محدودة', icon: MapPinned, tone: 'violet' },
  { id: 'contentLibrary', title: 'محتوى مجاني', hint: 'فقط المحتوى المنشور للعامة', icon: BookOpen, tone: 'red' },
];

// ROLE_MOBDEA_ONLINE_VISIBLE_V1 — visible inside student/guardian/visitor dashboards, not only as a route card.
const roleSocialLinks = [
  { id: 'facebook', title: 'Facebook', icon: 'f', url: 'https://www.facebook.com/share/1AyBatYgJv/' },
  { id: 'youtube', title: 'YouTube', icon: '▶', url: 'https://youtube.com/@mostafabarakat21?si=FczgywNrmc9FTBsl' },
  { id: 'tiktok', title: 'TikTok', icon: '♪', url: 'https://www.tiktok.com/@mostafabarakat210?_r=1&_t=ZS-996NuPuPOy1' },
];

function RoleMobdeaOnlineLinks() {
  return (
    <article className="panel role-mobdea-online-panel-v8" aria-label="المبدع أونلاين">
      <div className="role-mobdea-online-title-v8">
        <Radio size={21} />
        <span><strong>المبدع أونلاين</strong><small>تابع صفحات المُبدع مصطفى بركات الرسمية</small></span>
      </div>
      <div className="role-mobdea-online-links-v8">
        {roleSocialLinks.map((page) => (
          <a key={page.id} className={`role-social-link-v8 ${page.id}`} href={page.url} target="_blank" rel="noopener noreferrer" aria-label={`فتح ${page.title}`}>
            <span className="role-social-icon-v8" aria-hidden="true">{page.icon}</span>
            <strong>{page.title}</strong>
          </a>
        ))}
      </div>
    </article>
  );
}

const searchableModules = [
  ['dashboard', 'الرئيسية', 'لوحة التحكم واليوم'],
  ['classMode', 'وضع الحصة', 'السبورة والطلاب والتفاعل'],
  ['mobdeaOnline', 'المبدع أونلاين', 'فيسبوك ويوتيوب وتيك توك — الصفحات الرسمية'],
  ['onlineClass', 'الحصة الأونلاين', 'رابط مباشر وبث شاشة وصوت وميكروفون'],
  ['whiteboard', 'السبورة', 'شرح وكتابة ورسم'],
  ['students', 'الطلاب', 'إدارة بيانات الطلاب'],
  ['studentCards', 'كروت الطلاب', 'الطباعة وQR'],
  ['sessions', 'الجدول والحصص', 'المجموعات والمواعيد'],
  ['attendance', 'الحضور والغياب', 'التسجيل والمتابعة'],
  ['grades', 'الدرجات', 'الامتحانات والنتائج'],
  ['reports', 'التقارير', 'تحليل الأداء'],
  ['contentLibrary', 'المكتبة والمحتوى', 'PDF وصور وفيديو'],
  ['games', 'الألعاب التعليمية', 'تحديات ومراجعة'],
  ['mapChallenge', 'تحدي الخرائط', 'الدول والتضاريس'],
  ['messages', 'أولياء الأمور', 'التنبيهات والرسائل'],
  ['payments', 'الحسابات', 'المستحقات والمدفوعات'],
];

function ActionCard({ action, onClick }) {
  const Icon = action.icon;
  return (
    <button className={`dashboard-feature-card ${action.tone}`} onClick={onClick} type="button">
      <span className="dashboard-feature-icon"><Icon size={30} /></span>
      <strong>{action.title}</strong>
      <small>{action.hint}</small>
      <span className="dashboard-feature-link">فتح القسم <ArrowLeft size={15} /></span>
    </button>
  );
}

function SearchResults({ query, results, onOpen, onClose }) {
  if (!query.trim()) return null;
  return (
    <div className="dashboard-search-results">
      <div className="dashboard-search-results-head">
        <strong>نتائج البحث</strong>
        <button type="button" onClick={onClose} aria-label="إغلاق نتائج البحث"><X size={16} /></button>
      </div>
      {results.length ? results.map((result) => (
        <button key={result.key} type="button" onClick={() => onOpen(result)}>
          <span className="dashboard-search-result-icon">{result.icon}</span>
          <span><strong>{result.title}</strong><small>{result.subtitle}</small></span>
          <ArrowLeft size={15} />
        </button>
      )) : <div className="dashboard-search-empty">لا توجد نتيجة مطابقة.</div>}
    </div>
  );
}

export default function Dashboard({ data, navigate, auth }) {
  const [query, setQuery] = useState('');
  const isStaff = ['teacher', 'admin'].includes(auth?.role);
  // The original dashboard artwork is optional in source-only exports.
  // If absent on this deployment, keep working buttons INSIDE the branded hero.
  const [heroArtworkLoaded, setHeroArtworkLoaded] = useState(false);
  useEffect(() => {
    let active = true;
    const image = new Image();
    image.onload = () => { if (active) setHeroArtworkLoaded(true); };
    image.onerror = () => { if (active) setHeroArtworkLoaded(false); };
    image.src = '/identity/dashboard-hero-v2.jpg';
    return () => { active = false; image.onload = null; image.onerror = null; };
  }, []);
  // The teacher sees the full schedule. Other roles may only see sessions
  // scoped to their authenticated student / explicitly linked children.
  // A group name by itself is not sufficient: it can exist in several grades.
  const scopedDashboardData = useMemo(
    () => isStaff ? data : scopeReadOnlyDataForRole(data, auth),
    [data, auth, isStaff],
  );
  const sessions = Array.isArray(scopedDashboardData.sessions) ? scopedDashboardData.sessions : [];
  const currentSession = sessions.find((session) => session.current) || sessions[0] || null;
  const currentGroup = currentSession?.group || '';
  const dashboardProfile = useMemo(() => roleDashboardProfile(data, auth), [data, auth]);
  const focusStudents = !isStaff
    ? dashboardProfile.students
    : currentGroup
      ? (data.students || []).filter((student) => student.group === currentGroup)
      : (data.students || []);
  const visibleContent = useMemo(() => filterContentLibraryForRole(data, auth), [data, auth]);
  const [visitorTrial, setVisitorTrial] = useState(null);
  useEffect(() => {
    if (auth?.role !== 'visitor') { setVisitorTrial(null); return; }
    let active = true;
    fetchVisitorTrialStatus(data.settings).then((status) => {
      if (active) setVisitorTrial(status);
    }).catch(() => { if (active) setVisitorTrial(null); });
    return () => { active = false; };
  }, [auth?.role, data.settings?.cloudSync?.endpoint, data.settings?.cloudSync?.workspaceId]);
  const today = todayISO();
  const attendance = (data.attendance || []).filter((item) => item.date === today && focusStudents.some((student) => student.id === item.studentId));
  const present = attendance.filter((item) => ['present', 'late'].includes(item.status)).length;
  const absent = attendance.filter((item) => item.status === 'absent').length;
  const readyNotifications = (data.notifications || []).filter((item) => item.status === 'ready' && (isStaff || focusStudents.some((student) => String(student.id) === String(item.studentId))));
  const due = (data.payments || []).filter((item) => item.type === 'due' && focusStudents.some((student) => student.id === item.studentId)).reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const greeting = roleGreeting(auth?.role);
  const roleModules = getRoleModules(auth?.role);
  const canOpen = (id) => {
    if (!roleModules) return true;
    if (roleModules.has(id)) return true;
    // Backward-compatible permission alias only; navigation remains a distinct
    // route and never redirects Mobdea Online into Online Class.
    return id === 'mobdeaOnline' && roleModules.has('onlineClass');
  };

  const dashboardActions = auth?.role === 'student'
    ? studentActions
    : auth?.role === 'guardian'
      ? guardianActions
      : auth?.role === 'visitor'
        ? visitorActions
        : mainActions;

  const ranked = useMemo(() => focusStudents
    .map((student) => {
      const grades = (data.grades || []).filter((grade) => grade.studentId === student.id);
      const average = grades.length ? Math.round(grades.reduce((sum, grade) => sum + (grade.score / Math.max(1, grade.total)) * 100, 0) / grades.length) : 0;
      return { ...student, average };
    })
    .sort((a, b) => b.average - a.average)
    .slice(0, 10), [focusStudents, data.grades]);

  const todaysPlan = useMemo(() => {
    const scheduledToday = sessionsForToday(sessions, today, new Date(`${today}T12:00:00`).getDay());
    if (isStaff || ['student', 'guardian'].includes(auth?.role)) return scheduledToday.slice(0, 4);
    return [];
  }, [sessions, auth?.role, isStaff, today]);
  const upcomingExams = useMemo(() => (data.exams || []).slice(0, 3), [data.exams]);
  const announcements = useMemo(() => {
    const fromNotifications = readyNotifications.slice(0, 3).map((item) => ({
      id: item.id,
      title: item.type === 'absence' ? 'تنبيه غياب يحتاج إرسالًا' : item.type === 'low-grade' ? 'نتيجة تحتاج متابعة' : 'تنبيه جديد',
      subtitle: item.date || today,
      tone: item.type === 'absence' ? 'red' : 'orange',
    }));
    return fromNotifications.length ? fromNotifications : [
      { id: 'welcome', title: 'ابدأ الحصة من لوحة التحكم', subtitle: 'كل الأدوات متصلة ببيانات المنصة', tone: 'gold' },
    ];
  }, [readyNotifications, today]);

  const searchResults = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return [];
    const modules = searchableModules
      .filter(([id]) => canOpen(id))
      .filter(([, title, subtitle]) => `${title} ${subtitle}`.toLowerCase().includes(needle))
      .map(([id, title, subtitle]) => ({ key: `module-${id}`, type: 'module', id, title, subtitle, icon: <LayoutDashboard size={17} /> }));
    const students = (isStaff ? (data.students || []) : focusStudents)
      .filter((student) => `${student.name} ${student.code} ${student.grade} ${student.group}`.toLowerCase().includes(needle))
      .slice(0, 5)
      .map((student) => ({ key: `student-${student.id}`, type: 'student', id: student.id, title: student.name, subtitle: `${student.code} — ${student.grade}`, icon: <GraduationCap size={17} /> }));
    const resources = visibleContent
      .filter((resource) => `${resource.title} ${resource.unit} ${resource.lesson} ${resource.grade}`.toLowerCase().includes(needle))
      .slice(0, 5)
      .map((resource) => ({ key: `resource-${resource.id}`, type: 'resource', id: resource.id, title: resource.title, subtitle: `${resource.grade || ''} — ${resource.lesson || resource.type}`, icon: <LibraryBig size={17} /> }));
    return [...modules, ...students, ...resources].slice(0, 10);
  }, [query, data.students, visibleContent, roleModules, auth?.role, focusStudents]);

  const openSearchResult = (result) => {
    setQuery('');
    if (result.type === 'student') navigate(isStaff ? 'students' : 'portalPreview');
    else if (result.type === 'resource') navigate('contentLibrary');
    else navigate(result.id);
  };

  // POST52_DASHBOARD_REAL_ACTIONS_V2 — real navigation handlers, shared by
  // visible CTA buttons and the approved-hero hit targets.
  const startClassNow = () => navigate('classMode');
  const openFullSchedule = () => navigate('sessions');

  return (
    <section className="page dashboard-page dashboard-reference-layout dashboard-v103 dashboard-page-v8">
      <div className="dashboard-desktop-topbar">
        <div className="dashboard-search-wrap">
          <Search size={21} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ابحث هنا..." aria-label="البحث داخل المنصة" />
          {query && <button type="button" onClick={() => setQuery('')} aria-label="مسح البحث"><X size={17} /></button>}
          <SearchResults query={query} results={searchResults} onOpen={openSearchResult} onClose={() => setQuery('')} />
        </div>
        <div className="dashboard-account-strip">
          {canOpen('mobdeaOnline') && <button type="button" className="dashboard-mobdea-online-btn" onClick={() => navigate('mobdeaOnline')} aria-label="المبدع أونلاين" title="المبدع أونلاين">
            <Radio size={20} /><span>المبدع أونلاين</span>
          </button>}
          {auth?.role !== 'visitor' && <button type="button" className="dashboard-bell" onClick={() => navigate(isStaff ? 'messages' : 'portalPreview')} aria-label="فتح التنبيهات">
            <Bell size={22} />
            {readyNotifications.length > 0 && <b>{readyNotifications.length}</b>}
          </button>}
          <button type="button" className="dashboard-account" onClick={() => navigate(isStaff ? 'settings' : auth?.role === 'visitor' ? 'mobdeaOnline' : 'portalPreview')}>
            <span><strong>{greeting}</strong><small>{auth?.role === 'teacher' ? 'معلم دراسات' : auth?.displayName || identity.teacherTitle}</small></span>
            <img src={identity.portrait} alt={identity.teacherName} />
          </button>
        </div>
      </div>

      {isStaff && <div className="dashboard-direct-actions-v8" role="group" aria-label="اختصارات المعلم الأساسية">
        <button type="button" className="primary-btn" onClick={startClassNow} data-testid="dashboard-direct-start-class"><Presentation size={19} /> ابدأ الحصة</button>
        <button type="button" className="secondary-btn" onClick={openFullSchedule} data-testid="dashboard-direct-open-schedule"><CalendarDays size={19} /> عرض الجدول</button>
      </div>}
      <article className={`dashboard-reference-hero dashboard-image-hero ${heroArtworkLoaded ? "dashboard-hero-has-artwork-v8" : "dashboard-hero-fallback-v8"}`}>
        <div className="dashboard-reference-copy">
          <span className="dashboard-reference-kicker">منصة</span>
          <h2>المُبدع</h2>
          <h3>لتعليم ممتع</h3>
          <p>{auth?.role === 'student' ? 'لوحتك الشخصية للدرجات والحضور والمصروفات والمحتوى الذي أتاحه لك المعلم.' : auth?.role === 'guardian' ? 'متابعة الطالب من مكان واحد: درجات وحضور ومصروفات وتنبيهات ومحتوى متاح.' : auth?.role === 'visitor' ? 'جرّب منصة المُبدع مجانًا في الألعاب وتحديات الخرائط ثم اشترك للحصول على التجربة الكاملة.' : 'منصة متكاملة لإدارة التعليم والحضور والدرجات والمدفوعات والاختبارات في مكان واحد.'}</p>
          <div className="dashboard-reference-cta">
            {isStaff && canOpen('classMode') && <button type="button" className="hero-primary" onClick={startClassNow} data-testid="dashboard-start-class"><Presentation size={20} /> ابدأ الحصة الآن</button>}
            {isStaff && canOpen('sessions') && <button type="button" className="hero-secondary" onClick={openFullSchedule} data-testid="dashboard-open-schedule"><CalendarDays size={19} /> عرض الجدول</button>}
            {auth?.role === 'student' && <button type="button" className="hero-primary" onClick={() => navigate('portalPreview')}><GraduationCap size={20} /> بياناتي ونتائجي</button>}
            {auth?.role === 'guardian' && <button type="button" className="hero-primary" onClick={() => navigate('portalPreview')}><Users size={20} /> متابعة الطالب</button>}
            {auth?.role === 'visitor' && <button type="button" className="hero-primary" onClick={() => navigate('games')}><Gamepad2 size={20} /> ابدأ التجربة المجانية</button>}
            {auth?.role === 'visitor' && <button type="button" className="hero-secondary" onClick={() => navigate('mobdeaOnline')}><Sparkles size={19} /> الاشتراك الكامل</button>}
          </div>
        </div>

        <div className="dashboard-reference-portrait">
          <div className="dashboard-map-paper" aria-hidden="true">
            <span>خريطة العالم</span>
            <small>في العصور الوسطى</small>
          </div>
          <div className="dashboard-banner" aria-hidden="true"><BookOpen size={38} /><span>العلم نور الحياة</span></div>
          <img src={identity.portrait} alt={identity.teacherName} />
          <div className="dashboard-history-books" aria-hidden="true"><span>الحضارات القديمة</span><span>الجغرافيا التاريخية</span><span>دراسات اجتماعية</span></div>
        </div>

        <aside className="dashboard-today-panel">
          <div className="dashboard-today-head"><CalendarClock size={22} /><div><strong>جدول اليوم</strong><small>{formatDateAr(today)}</small></div></div>
          <div className="dashboard-today-list">
            {todaysPlan.length ? todaysPlan.map((session, index) => (
              <button type="button" key={session.id || index} onClick={() => navigate(isStaff ? 'sessions' : 'portalPreview')}>
                <span className={`schedule-dot tone-${index + 1}`}><Users size={15} /></span>
                <strong>{session.title || session.group}</strong>
                <small>{formatTime12(session.time)}</small>
              </button>
            )) : <div className="dashboard-today-empty">لا توجد حصص مسجلة اليوم.</div>}
          </div>
          {isStaff && <button type="button" className="dashboard-full-schedule" onClick={openFullSchedule}>عرض الجدول الكامل <ArrowLeft size={16} /></button>}
        </aside>
        {heroArtworkLoaded && <div className="dashboard-image-hotspots dashboard-artwork-actions-v8" aria-label="اختصارات لوحة المُبدع">
          {isStaff && canOpen('sessions') && <button type="button" className="dashboard-image-hotspot dashboard-hotspot-schedule" onClick={openFullSchedule} aria-label="عرض الجدول" title="عرض الجدول" data-testid="dashboard-hotspot-schedule" />}
          {isStaff && canOpen('classMode') && <button type="button" className="dashboard-image-hotspot dashboard-hotspot-class" onClick={startClassNow} aria-label="ابدأ الحصة الآن" title="ابدأ الحصة الآن" data-testid="dashboard-hotspot-class" />}
        </div>}
      </article>

      {isStaff && <RoleMobdeaOnlineLinks />}

      {['student', 'guardian', 'visitor'].includes(auth?.role) && <RoleMobdeaOnlineLinks />}

      {auth?.role === 'visitor' && !visitorTrial && <div className="panel">عداد التجارب المجانية غير متاح؛ يجب إعداد خادم التجارب قبل البدء.</div>}
      {auth?.role === 'visitor' && visitorTrial && (
        <article className="panel dashboard-visitor-trial-v8">
          <div><Sparkles size={20}/><span><strong>التجربة المجانية</strong><small>ألعاب {visitorTrial.remaining.games}/{visitorTrial.limits.games} • خرائط {visitorTrial.remaining.maps}/{visitorTrial.limits.maps} • لعب جماعي {visitorTrial.remaining.multiplayer}/{visitorTrial.limits.multiplayer}</small></span></div>
          <button type="button" className="primary-btn" onClick={() => navigate('mobdeaOnline')}>اشترك للحصول على كل المميزات</button>
          <p>{subscriptionMessage()}</p>
        </article>
      )}

      <div className="dashboard-feature-grid">
        {dashboardActions.filter((action) => canOpen(action.id)).map((action, index) => (
          <ActionCard key={`${action.id}-${index}`} action={action} onClick={() => {
            if (action.id === 'mobdeaOnline') navigate('mobdeaOnline');
            else if (action.id === 'onlineClass') navigate('onlineClass');
            else navigate(action.id);
          }} />
        ))}
      </div>

      {isStaff ? (
        <div className="dashboard-reference-bottom">
        <article className="dashboard-current-class-card">
          <div className="dashboard-current-art" aria-hidden="true"><MapPinned size={45} /><BookOpen size={35} /></div>
          <div>
            <span>الحصة الحالية</span>
            <h3>{currentSession?.title || 'لا توجد حصة حالية'}</h3>
            <p>{currentSession ? `${currentSession.group} — ${formatTime12(currentSession.time)}` : 'اختر الحصة الحالية من الجدول'}</p>
            <strong>{currentSession?.time ? formatTime12(currentSession.time) : "—"}</strong>
          </div>
          <button type="button" onClick={() => navigate('classMode')} disabled={!currentSession}>فتح الحصة</button>
        </article>

        <article className="dashboard-lower-panel">
          <div className="dashboard-lower-title"><MessageCircle size={19} /><strong>آخر الإعلانات</strong></div>
          <div className="dashboard-announcement-list">
            {announcements.map((item) => <button type="button" key={item.id} onClick={() => navigate('messages')}><i className={item.tone} /><span><strong>{item.title}</strong><small>{item.subtitle}</small></span></button>)}
          </div>
          <button type="button" className="dashboard-lower-link" onClick={() => navigate('messages')}>عرض جميع الإعلانات</button>
        </article>

        <article className="dashboard-lower-panel">
          <div className="dashboard-lower-title"><CalendarDays size={19} /><strong>الاختبارات القادمة</strong></div>
          <div className="dashboard-announcement-list">
            {upcomingExams.length ? upcomingExams.map((exam, index) => (
              <button type="button" key={exam.id || index} onClick={() => navigate('grades')}><i className={index === 0 ? 'red' : 'orange'} /><span><strong>{exam.title || exam.name || 'اختبار'}</strong><small>{exam.date || exam.grade || 'جميع المراحل'}</small></span></button>
            )) : <div className="dashboard-today-empty">لا توجد اختبارات قادمة.</div>}
          </div>
          <button type="button" className="dashboard-lower-link" onClick={() => navigate('grades')}>عرض جميع الاختبارات</button>
        </article>
      </div>
      ) : (
        <div className="dashboard-reference-bottom role-dashboard-summary-v8">
          <article className="dashboard-lower-panel"><div className="dashboard-lower-title"><GraduationCap size={19}/><strong>{auth?.role === 'guardian' ? 'متابعة الطالب' : auth?.role === 'student' ? 'ملخص حسابي' : 'تجربة المُبدع'}</strong></div><p>{auth?.role === 'visitor' ? subscriptionMessage() : `الدرجات والحضور والمصروفات تخص ${dashboardProfile.student?.name || 'الحساب المرتبط'} فقط.`}</p>{auth?.role !== 'visitor' && <button type="button" className="dashboard-lower-link" onClick={() => navigate('portalPreview')}>فتح التفاصيل</button>}</article>
          {auth?.role !== 'visitor' && <article className="dashboard-lower-panel"><div className="dashboard-lower-title"><BookOpen size={19}/><strong>المحتوى المتاح</strong></div><p>{visibleContent.filter((item) => item.type === 'lesson').length} درس متاح حسب الصلاحيات التي حددها المعلم.</p><button type="button" className="dashboard-lower-link" onClick={() => navigate('contentLibrary')}>فتح المحتوى</button></article>}
          {auth?.role === 'visitor' && <article className="dashboard-lower-panel"><div className="dashboard-lower-title"><Gamepad2 size={19}/><strong>تجارب مجانية</strong></div><p>يمكنك تجربة الألعاب وتحدي الخرائط واللعب الجماعي بعدد محدود.</p><button type="button" className="dashboard-lower-link" onClick={() => navigate('games')}>ابدأ اللعب</button></article>}
        </div>
      )}

      <div className="dashboard-hidden-live-metrics" aria-label="ملخص مباشر">
        <span><Users size={16} /> {focusStudents.length} طالب</span>
        <span><CheckCircle2 size={16} /> {present} حاضر</span>
        <span><QrCode size={16} /> {absent} غائب</span>
        <span><WalletCards size={16} /> {due} ج مستحقات</span>
      </div>
    </section>
  );
}
