import { useMemo, useState } from 'react';
import {
  buildEvaluationRanking,
  buildExamGroupMessage,
  evaluationExams,
  evaluationGroups,
  getExamGroupResults,
} from '../services/studentEvaluation';

async function copyText(text) {
  if (!text) return false;
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
    const area = document.createElement('textarea');
    area.value = text;
    area.setAttribute('readonly', 'true');
    area.style.position = 'fixed';
    area.style.opacity = '0';
    document.body.appendChild(area);
    area.select();
    const ok = document.execCommand('copy');
    area.remove();
    return ok;
  } catch {
    return false;
  }
}

export default function Grades({ data, updateData }) {
  const [form, setForm] = useState(null);
  const [rankingGroup, setRankingGroup] = useState('');
  const groups = useMemo(() => evaluationGroups(data), [data.students]);
  const exams = useMemo(() => evaluationExams(data), [data.grades]);
  const [messageExam, setMessageExam] = useState('');
  const [messageGroup, setMessageGroup] = useState('');
  const [messageNotice, setMessageNotice] = useState('');

  const rows = useMemo(() => [...data.grades].sort((a,b) => String(b.date || '').localeCompare(String(a.date || ''))), [data.grades]);
  const ranking = useMemo(() => buildEvaluationRanking(data, rankingGroup), [data.students, data.grades, rankingGroup]);
  const activeExam = messageExam || exams[0] || '';
  const activeGroup = messageGroup || groups[0] || '';
  const examSummary = useMemo(
    () => getExamGroupResults(data, { exam: activeExam, group: activeGroup }),
    [data.students, data.grades, activeExam, activeGroup],
  );
  const groupMessage = useMemo(
    () => buildExamGroupMessage(data, { exam: activeExam, group: activeGroup, date: examSummary.date }),
    [data.students, data.grades, activeExam, activeGroup, examSummary.date],
  );

  const save = async () => {
    if (!form?.studentId || !form?.exam?.trim() || !form?.total) return;
    const student = data.students.find((item) => String(item.id) === String(form.studentId));
    const nextRow = { ...form, exam: form.exam.trim(), id: Date.now() };
    const next = { ...data, grades: [...data.grades, nextRow] };
    await updateData(next);
    setMessageExam(nextRow.exam);
    setMessageGroup(student?.group || '');
    setMessageNotice('تم حفظ الدرجة وتجهيز رسالة مجموعة أولياء الأمور تلقائيًا.');
    setForm(null);
  };

  const avg = data.grades.length ? Math.round(data.grades.reduce((n,g)=>n+(Number(g.score || 0)/Math.max(1, Number(g.total || 1)))*100,0)/data.grades.length) : 0;
  const needs = new Set(data.grades.filter((g)=>(Number(g.score || 0)/Math.max(1, Number(g.total || 1)))*100 < 60).map((g)=>g.studentId)).size;

  const copyGroupMessage = async () => {
    const ok = await copyText(groupMessage);
    setMessageNotice(ok ? 'تم نسخ رسالة النتائج؛ الصقها مباشرة في جروب أولياء الأمور.' : 'تعذر النسخ التلقائي. ظلّل الرسالة وانسخها يدويًا.');
  };

  return <section className="page grades-page-v8">
    <div className="page-heading">
      <div><span className="eyebrow">التقييم والتحليل</span><h2>الدرجات والامتحانات</h2><p>ترتيب عام لكل الطلاب، ترتيب مستقل لكل مجموعة، ورسالة نتائج جاهزة لجروب أولياء الأمور.</p></div>
      <button className="primary-btn" onClick={() => setForm({ studentId: data.students[0]?.id || '', exam: '', score: 0, total: 20, date: new Date().toISOString().slice(0,10), strength: '', weakness: '' })}>+ تسجيل نتيجة</button>
    </div>

    <div className="stats-grid compact">
      <div className="stat-card"><div><span>عدد النتائج</span><strong>{data.grades.length}</strong><small>كل الاختبارات</small></div></div>
      <div className="stat-card"><div><span>المتوسط العام</span><strong>{avg}%</strong><small>جميع النتائج</small></div></div>
      <div className="stat-card"><div><span>يحتاجون متابعة</span><strong>{needs}</strong><small>أقل من 60%</small></div></div>
    </div>

    <div className="panel evaluation-ranking-panel-v8">
      <div className="panel-title evaluation-ranking-head-v8">
        <div><span className="eyebrow">نظام التقييم</span><h3>{rankingGroup ? `ترتيب ${rankingGroup}` : 'الترتيب العام لكل المجموعات'}</h3></div>
        <select value={rankingGroup} onChange={(event) => setRankingGroup(event.target.value)} aria-label="اختيار نطاق الترتيب">
          <option value="">كل المجموعات</option>
          {groups.map((group) => <option value={group} key={group}>{group}</option>)}
        </select>
      </div>
      <div className="evaluation-ranking-list-v8">
        {ranking.length ? ranking.slice(0, 20).map((entry) => (
          <article className={`evaluation-rank-row-v8 rank-${entry.rank}`} key={entry.student.id}>
            <b className="evaluation-rank-number-v8">#{entry.rank}</b>
            <div><strong>{entry.student.name}</strong><small>{entry.student.group || 'بدون مجموعة'} • {entry.resultCount} نتيجة</small></div>
            <span><strong>{entry.percentage}%</strong><small>{entry.score}/{entry.total}</small></span>
          </article>
        )) : <div className="empty-state">لا توجد درجات كافية لعمل ترتيب حتى الآن.</div>}
      </div>
    </div>

    <div className="panel exam-group-message-panel-v8">
      <div className="panel-title evaluation-ranking-head-v8">
        <div><span className="eyebrow">رسالة أولياء الأمور</span><h3>رسالة نتائج الامتحان للمجموعة</h3></div>
        <div className="exam-message-selectors-v8">
          <select value={activeExam} onChange={(event) => setMessageExam(event.target.value)} aria-label="اختيار الامتحان">
            {!exams.length && <option value="">لا توجد امتحانات</option>}
            {exams.map((exam) => <option value={exam} key={exam}>{exam}</option>)}
          </select>
          <select value={activeGroup} onChange={(event) => setMessageGroup(event.target.value)} aria-label="اختيار المجموعة">
            {!groups.length && <option value="">لا توجد مجموعات</option>}
            {groups.map((group) => <option value={group} key={group}>{group}</option>)}
          </select>
          <button type="button" className="primary-btn" disabled={!groupMessage} onClick={copyGroupMessage}>نسخ رسالة الجروب</button>
        </div>
      </div>
      {messageNotice && <div className="settings-notice">{messageNotice}</div>}
      <textarea className="exam-group-message-preview-v8" readOnly value={groupMessage} rows={Math.min(18, Math.max(8, examSummary.results.length + 9))} aria-label="معاينة رسالة نتائج المجموعة" />
    </div>

    <div className="panel responsive-table"><table><thead><tr><th>الطالب</th><th>الاختبار</th><th>الدرجة</th><th>النسبة</th><th>القوة</th><th>يحتاج مراجعة</th><th>التاريخ</th></tr></thead>
      <tbody>{rows.map((g)=><tr key={g.id}><td>{data.students.find((s)=>String(s.id)===String(g.studentId))?.name || '—'}</td><td>{g.exam}</td><td>{g.score}/{g.total}</td><td>{Math.round(Number(g.score || 0)/Math.max(1, Number(g.total || 1))*100)}%</td><td>{g.strength || '—'}</td><td>{g.weakness || '—'}</td><td>{g.date}</td></tr>)}</tbody></table></div>

    {form && <div className="modal-backdrop"><div className="modal-card"><h3>تسجيل نتيجة</h3><div className="form-grid">
      <select value={form.studentId} onChange={(e)=>setForm({...form,studentId:Number(e.target.value)})}>{data.students.map((s)=><option value={s.id} key={s.id}>{s.name} — {s.group || 'بدون مجموعة'}</option>)}</select>
      <input placeholder="اسم الاختبار" value={form.exam} onChange={(e)=>setForm({...form,exam:e.target.value})}/>
      <input type="number" min="0" max={Math.max(1, Number(form.total || 20))} placeholder="درجة الطالب" value={form.score} onChange={(e)=>setForm({...form,score:Number(e.target.value)})}/>
      <input type="number" min="1" placeholder="الدرجة النهائية" value={form.total} onChange={(e)=>setForm({...form,total:Number(e.target.value)})}/>
      <input placeholder="نقطة القوة" value={form.strength} onChange={(e)=>setForm({...form,strength:e.target.value})}/>
      <input placeholder="الجزئية التي تحتاج مراجعة" value={form.weakness} onChange={(e)=>setForm({...form,weakness:e.target.value})}/>
      <input type="date" value={form.date} onChange={(e)=>setForm({...form,date:e.target.value})}/>
    </div><div className="modal-actions"><button className="primary-btn" onClick={save}>حفظ وتجهيز الرسالة</button><button className="secondary-btn" onClick={()=>setForm(null)}>إلغاء</button></div></div></div>}
  </section>;
}
