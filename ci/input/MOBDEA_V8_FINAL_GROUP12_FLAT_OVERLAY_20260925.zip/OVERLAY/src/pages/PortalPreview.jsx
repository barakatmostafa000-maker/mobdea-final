import { findStudentForAuth, linkedStudentsForGuardian, canStudentAccessResource, filterContentLibraryForRole } from '../services/rolePortalAccess.js';
import { useEffect, useMemo, useState } from 'react';
import {
  UserRound,
  UsersRound,
  ShieldCheck,
  MessageCircle,
  WalletCards,
  GraduationCap,
  BookOpen,
  MapPinned,
  Gamepad2,
  Video,
  Cloud,
  CloudOff,
} from 'lucide-react';
import LessonRecordingItem from '../components/classmode/LessonRecordingItem';

const messageStatusLabel = { ready: 'جديدة', sent: 'تم الإرسال', postponed: 'مؤجلة', failed: 'فشل', cancelled: 'ألغيت' };
const messageTypeLabel = { absence: 'تنبيه غياب', late: 'تنبيه تأخر', due: 'تذكير مستحقات', praise: 'تميز', followup: 'متابعة مستوى' };


export default function PortalPreview({ data, auth, navigate }) {
  const isRealUser = auth?.role === 'student' || auth?.role === 'guardian';
  const [simRole, setSimRole] = useState('student');
  const students = Array.isArray(data.students) ? data.students : [];
  const [simStudentId, setSimStudentId] = useState(students[0]?.id || '');

  const role = isRealUser ? (auth.role === 'guardian' ? 'parent' : 'student') : simRole;

  // Only the authenticated guardian-to-child links can authorize a child.
  // A matching phone number or a duplicate student code is NOT an access grant.
  const linkedStudents = useMemo(() => isRealUser && role === 'parent'
    ? linkedStudentsForGuardian(data, auth)
    : students, [isRealUser, role, data, auth, students]);
  useEffect(() => {
    if (role !== 'parent' || !linkedStudents.length) return;
    if (!linkedStudents.some((item) => String(item.id) === String(simStudentId))) {
      setSimStudentId(linkedStudents[0].id);
    }
  }, [linkedStudents, role, simStudentId]);
  const student = isRealUser
    ? role === 'student'
      ? findStudentForAuth(data, auth)
      : linkedStudents.find((item) => String(item.id) === String(simStudentId)) || linkedStudents[0] || null
    : students.find((item) => String(item.id) === String(simStudentId)) || students[0] || null;
  const studentId = student?.id;

  const stats = useMemo(() => {
    const attendance = (data.attendance || []).filter((item) => Number(item.studentId) === Number(student?.id));
    const present = attendance.filter((item) => ['present', 'late'].includes(item.status)).length;
    const attendanceRate = attendance.length ? Math.round((present / attendance.length) * 100) : 0;
    const grades = (data.grades || []).filter((item) => Number(item.studentId) === Number(student?.id));
    const validGrades = grades.filter((item) => Number(item.total) > 0);
    const average = validGrades.length
      ? Math.round(validGrades.reduce((sum, item) => sum + (Number(item.score) / Number(item.total)) * 100, 0) / validGrades.length)
      : 0;

    const payments = (data.payments || []).filter((item) => Number(item.studentId) === Number(student?.id));
    const totalDue = payments.filter((item) => item.type === 'due').reduce((sum, item) => sum + Number(item.amount || 0), 0);
    const totalPaid = payments.filter((item) => item.type === 'paid').reduce((sum, item) => sum + Number(item.amount || 0), 0);
    const adjustments = payments.filter((item) => ['discount', 'exempt'].includes(item.type)).reduce((sum, item) => sum + Number(item.amount || 0), 0);
    const remaining = Math.max(0, totalDue - totalPaid - adjustments);

    return {
      attendanceRate,
      average,
      gradeCount: grades.length,
      totalDue,
      totalPaid,
      adjustments,
      remaining,
      paymentStatus: remaining <= 0 ? 'تم السداد' : totalPaid > 0 ? 'سداد جزئي' : 'مستحق',
    };
  }, [data.attendance, data.grades, data.payments, student?.id]);

  const messages = useMemo(() => {
    if (role !== 'parent' || !student) return [];
    return (data.notifications || [])
      .filter((item) => Number(item.studentId) === Number(student.id))
      .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''))
      .slice(0, 20);
  }, [data.notifications, role, student]);

  const visibleRecordings = useMemo(() => {
    if (!student) return [];
    const assignedLessons = new Set(filterContentLibraryForRole(data, {
      role: 'student', studentId: student.id, studentCode: student.code,
    }).filter((resource) => resource?.type === 'lesson').map((resource) => String(resource.id)));
    return (data.lessonRecordings || [])
      .filter((recording) => recording?.published !== false &&
        (canStudentAccessResource(recording, student) ||
          (recording?.inheritLessonAccess === true &&
            assignedLessons.has(String(recording.lessonId || recording.parentLessonId || '')))))
      .sort((left, right) => String(right.publishedAt || right.createdAt || '')
        .localeCompare(String(left.publishedAt || left.createdAt || '')))
      .slice(0, 30);
  }, [data, student]);

  const studentSession = data.settings?.studentPortalSession || null;
  const studentSyncLabel = studentSession?.lastError
    ? studentSession.lastError
    : studentSession?.lastPullAt
      ? `آخر تحديث ناجح: ${new Date(studentSession.lastPullAt).toLocaleString('ar-EG')}`
      : 'سيتم تحديث بيانات الحساب تلقائيًا عند الاتصال بالإنترنت.';

  if (!student) return <section className="page portal-page-v103 portal-page-v8"><div className="panel empty-state">{isRealUser ? 'تعذر العثور على بيانات الحساب المرتبط، تواصل مع المعلم.' : 'أضف طالبًا أولًا.'}</div></section>;

  const studentPermissions = student.permissions || {};
  const parentPermissions = student.parentPermissions || {};
  const canSee = (key) => role === 'student' ? studentPermissions[key] !== false : parentPermissions[key] !== false;

  return <section className="page portal-page-v103 portal-page-v8">
    {!isRealUser && <div className="page-heading"><div><span className="eyebrow">معاينة الصلاحيات</span><h2>ما يراه الطالب وولي الأمر</h2><p>راجع الواجهة قبل إتاحتها للمستخدمين.</p></div></div>}
    {isRealUser && <div className="page-heading"><div><span className="eyebrow">{role === 'parent' ? 'بوابة ولي الأمر' : 'بوابة الطالب'}</span><h2>مرحبًا، {role === 'parent' ? 'ولي الأمر' : student.name}</h2><p>{role === 'parent' ? 'اختر أحد الأبناء المرتبطين بحسابك للتحقق من بياناته.' : 'هذه بياناتك فقط، ولا تظهر لك بيانات أي طالب آخر.'}</p></div></div>}

    {isRealUser && role === 'student' && <div className={`portal-sync-status panel ${studentSession?.lastError ? 'has-error' : 'is-synced'}`}>
      {studentSession?.lastError ? <CloudOff size={18}/> : <Cloud size={18}/>}<span>{studentSyncLabel}</span>
    </div>}

    {!isRealUser && <div className="portal-toolbar panel">
      <div className="portal-role-tabs">
        <button className={simRole === 'student' ? 'active' : ''} onClick={() => setSimRole('student')}><UserRound size={18}/> الطالب</button>
        <button className={simRole === 'parent' ? 'active' : ''} onClick={() => setSimRole('parent')}><UsersRound size={18}/> ولي الأمر</button>
      </div>
      <select value={simStudentId} onChange={(event) => setSimStudentId(event.target.value)}>{students.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select>
    </div>}

    {isRealUser && role === 'parent' && <div className="portal-toolbar panel portal-child-switcher">
      <div><UsersRound size={19}/><strong>حسابات الأبناء المرتبطة</strong><small>{linkedStudents.length} حساب</small></div>
      <select value={studentId || ''} onChange={(event) => setSimStudentId(event.target.value)} aria-label="اختيار الابن">
        {linkedStudents.map((item) => <option key={item.id} value={item.id}>{item.name} — كود {item.code || item.id}</option>)}
      </select>
    </div>}

    {/* ROLE_MOBDEA_ONLINE_PORTAL_VISIBLE_V1 */}
    <article className="panel role-mobdea-online-panel-v8 role-mobdea-online-portal-v8" aria-label="المبدع أونلاين">
      <div className="role-mobdea-online-title-v8"><span><strong>المبدع أونلاين</strong><small>صفحات المُبدع مصطفى بركات الرسمية</small></span></div>
      <div className="role-mobdea-online-links-v8">
        <a className="role-social-link-v8 facebook" href="https://www.facebook.com/share/1AyBatYgJv/" target="_blank" rel="noopener noreferrer"><span className="role-social-icon-v8">f</span><strong>Facebook</strong></a>
        <a className="role-social-link-v8 youtube" href="https://youtube.com/@mostafabarakat21?si=FczgywNrmc9FTBsl" target="_blank" rel="noopener noreferrer"><span className="role-social-icon-v8">▶</span><strong>YouTube</strong></a>
        <a className="role-social-link-v8 tiktok" href="https://www.tiktok.com/@mostafabarakat210?_r=1&_t=ZS-996NuPuPOy1" target="_blank" rel="noopener noreferrer"><span className="role-social-icon-v8">♪</span><strong>TikTok</strong></a>
      </div>
    </article>

    <div className="portal-preview-shell">
      <header><div className="portal-avatar">{student.name.charAt(0)}</div><div><strong>مرحبًا، {student.name}</strong><span>{role === 'student' ? 'بوابة الطالب' : `${student.grade || 'الصف غير محدد'} • ${student.group || 'المجموعة غير محددة'}`}</span></div><ShieldCheck size={24}/></header>

      {role === 'parent' && <div className="portal-account-strip">
        <span><UserRound size={15}/> كود الطالب: <strong>{student.code || student.id}</strong></span>
        <span><GraduationCap size={15}/> {student.grade || 'الصف غير محدد'}</span>
      </div>}

      {role === 'student' && (
        <div className="portal-quick-actions">
          <button type="button" onClick={() => navigate?.('contentLibrary')}><BookOpen size={19}/><span><strong>محتوى الدروس</strong><small>الكتب والصور والفيديوهات</small></span></button>
          <button type="button" onClick={() => navigate?.('mapChallenge')}><MapPinned size={19}/><span><strong>تحدي الخرائط</strong><small>التدريب والألعاب الجغرافية</small></span></button>
          <button type="button" onClick={() => navigate?.('games')}><Gamepad2 size={19}/><span><strong>الألعاب التعليمية</strong><small>الجولات والتحديات المتاحة</small></span></button>
        </div>
      )}

      <div className="portal-cards">
        {canSee('attendance') && <article><span>نسبة الحضور</span><strong>{stats.attendanceRate}%</strong><small>السجلات المسجلة</small></article>}
        {canSee('grades') && <article><span>متوسط الدرجات</span><strong>{stats.average}%</strong><small>{stats.gradeCount} اختبار/نتيجة</small></article>}
        {role === 'parent' && canSee('dues') && <article><span>المتبقي</span><strong>{stats.remaining} ج</strong><small>{stats.paymentStatus}</small></article>}
        {role === 'student' && canSee('games') && <article><span>الألعاب</span><strong>مفتوحة</strong><small>الألعاب المسموح بها</small></article>}
        {role === 'student' && canSee('content') && <article><span>المحتوى</span><strong>متاح</strong><small>الفيديوهات والوسائل</small></article>}
      </div>

      {role === 'parent' && canSee('dues') && <div className="portal-finance-summary">
        <h4><WalletCards size={17}/> الحساب والمستحقات</h4>
        <div className="portal-cards">
          <article><span>إجمالي المستحق</span><strong>{stats.totalDue} ج</strong></article>
          <article><span>إجمالي المدفوع</span><strong>{stats.totalPaid} ج</strong></article>
          <article><span>خصم/إعفاء</span><strong>{stats.adjustments} ج</strong></article>
          <article><span>المتبقي</span><strong>{stats.remaining} ج</strong><small>{stats.paymentStatus}</small></article>
        </div>
      </div>}

      {role === 'student' && canSee('content') && <div className="portal-recordings">
        <h4><Video size={17}/> تسجيلات الحصص</h4>
        {visibleRecordings.length ? <div className="portal-recordings-list">{visibleRecordings.map((recording) => (
          <LessonRecordingItem key={recording.id} recording={recording} studentSession={studentSession} hideShareActions />
        ))}</div> : <div className="empty-state">لا توجد تسجيلات منشورة لهذا الصف بعد.</div>}
      </div>}

      {role === 'parent' && <div className="portal-messages">
        <h4><MessageCircle size={17}/> الرسائل من المعلم</h4>
        {messages.length ? messages.map((item) => (
          <div className="portal-message-row" key={item.id}>
            <div><strong>{messageTypeLabel[item.type] || item.type}</strong><small>{item.date || ''}</small></div>
            <span className={`notification-status ${item.status}`}>{messageStatusLabel[item.status] || item.status}</span>
          </div>
        )) : <div className="empty-state">لا توجد رسائل بعد.</div>}
      </div>}
      <div className="portal-private-note">تظهر بيانات الأبناء المرتبطين بحساب ولي الأمر بعد التحقق من صلاحياته فقط؛ تشابه أرقام الهاتف لا يمنح حق الوصول.</div>
    </div>
  </section>;
}
