import { buildCloudUrl, cloudHeaders, timeoutFetch, validateCloudConfig } from './cloudSync';
export async function provisionCloudPortalAccount(settings, account) {
  const config = validateCloudConfig(settings);
  const response = await timeoutFetch(buildCloudUrl(config.endpoint, '/portal/accounts'), {
    method: 'PUT', headers: { ...cloudHeaders(config), 'Content-Type': 'application/json' },
    body: JSON.stringify(account),
  }, 40000);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.ok !== true) throw new Error(payload.error || 'تعذر إنشاء الحساب على الخادم.');
  return payload;
}
