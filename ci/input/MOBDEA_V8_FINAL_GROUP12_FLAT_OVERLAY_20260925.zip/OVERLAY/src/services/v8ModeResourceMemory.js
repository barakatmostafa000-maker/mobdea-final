import { MODE_TYPES } from './mediaNavigation.js';

export function rememberModeResource(memory, mode, resource) {
  const expectedTypes = MODE_TYPES[mode] || [];
  if (!resource?.id || !expectedTypes.includes(resource.type)) return memory;
  memory.set(mode, String(resource.id));
  return memory;
}

export function preferredResourceForMode(resources, mode, memory, currentResource = null) {
  const types = MODE_TYPES[mode] || [];
  if (!types.length) return null;
  const candidates = (Array.isArray(resources) ? resources : []).filter((item) =>
    types.includes(item?.type),
  );
  const wanted = memory?.get(mode);
  return candidates.find((item) => String(item.id) === String(wanted))
    || candidates.find((item) => String(item.id) === String(currentResource?.id))
    || candidates[0] || null;
}
