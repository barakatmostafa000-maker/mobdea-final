/** Preserve every character entered by the teacher; set canvas direction from first strong letter. */
export function boardTextDirection(text) {
  const match = String(text ?? '').match(/[\p{Script=Arabic}\p{Script=Latin}]/u);
  return match && /\p{Script=Latin}/u.test(match[0]) ? 'ltr' : 'rtl';
}
export function boardTextAlignment(text) {
  return boardTextDirection(text) === 'ltr' ? 'left' : 'right';
}
