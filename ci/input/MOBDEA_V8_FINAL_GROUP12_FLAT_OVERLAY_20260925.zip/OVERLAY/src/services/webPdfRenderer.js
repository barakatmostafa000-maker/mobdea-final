import * as pdfjs from 'pdfjs-dist/build/pdf.mjs';
import PdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?worker';
import { createBoundedAsyncCache } from './boundedAsyncCache';
import { pdfNeighborPages } from './v8PdfPreloadPlan.js';

if (!pdfjs.GlobalWorkerOptions.workerPort) {
  pdfjs.GlobalWorkerOptions.workerPort = new PdfWorker();
}

// A Blob identity is not its file size/type: two different books may have identical sizes.
const blobIds = new WeakMap();
let nextBlobId = 0;
const documents = new Map();
const pages = createBoundedAsyncCache({ maxEntries: 4, maxCharacters: 32_000_000 });
const MAX_DOCUMENTS = 3;

function sourceKey({ blob, url, cacheKey }) {
  if (blob) {
    if (!blobIds.has(blob)) blobIds.set(blob, ++nextBlobId);
    return `${String(cacheKey || 'blob')}:blob:${blobIds.get(blob)}`;
  }
  return `url:${String(url || cacheKey || '')}`;
}

function openDocument(source) {
  const key = sourceKey(source);
  if (documents.has(key)) {
    const item = documents.get(key);
    documents.delete(key);
    documents.set(key, item);
    return item;
  }
  const item = { active: 0, retired: false, document: null, promise: null };
  // Register the in-flight PDF load before awaiting it: rapid page changes reuse it.
  item.promise = (async () => {
    const input = source.blob
      ? { data: new Uint8Array(await source.blob.arrayBuffer()) }
      : { url: source.url, withCredentials: false };
    const task = pdfjs.getDocument(input);
    item.document = await task.promise;
    if (item.retired && item.active === 0) await item.document.destroy();
    return item.document;
  })().catch((error) => {
    if (documents.get(key) === item) documents.delete(key);
    throw error;
  });
  documents.set(key, item);
  if (documents.size > MAX_DOCUMENTS) {
    const oldest = documents.keys().next().value;
    const old = documents.get(oldest);
    documents.delete(oldest);
    old.retired = true;
    if (old.document && old.active === 0) void old.document.destroy().catch(() => {});
  }
  return item;
}

async function renderDocumentPage(source, page = 1, targetWidth = 1800) {
  const docKey = sourceKey(source);
  const safeWidth = Math.max(500, Math.min(3000, Math.round(Number(targetWidth) || 1800)));
  const safePage = Math.max(1, Math.round(Number(page) || 1));
  return pages.get(`${docKey}:p${safePage}:w${safeWidth}`, async () => {
    const item = openDocument(source);
    item.active += 1;
    try {
      const doc = await item.promise;
      const pdfPage = await doc.getPage(Math.min(safePage, Number(doc.numPages || 1)));
      const base = pdfPage.getViewport({ scale: 1 });
      const scale = Math.max(0.5, Math.min(4, safeWidth / Math.max(1, base.width)));
      const viewport = pdfPage.getViewport({ scale });
      const canvas = document.createElement('canvas');
      canvas.width = Math.ceil(viewport.width);
      canvas.height = Math.ceil(viewport.height);
      const context = canvas.getContext('2d', { alpha: false });
      if (!context) throw new Error('تعذر إنشاء مساحة رسم صفحة PDF.');
      context.fillStyle = '#fff';
      context.fillRect(0, 0, canvas.width, canvas.height);
      await pdfPage.render({ canvasContext: context, viewport }).promise;
      const dataUrl = canvas.toDataURL('image/jpeg', 0.94);
      canvas.width = 0;
      canvas.height = 0;
      return { dataUrl, pageCount: Number(doc.numPages || 0) };
    } finally {
      item.active -= 1;
      if (item.retired && item.active === 0 && item.document) {
        void item.document.destroy().catch(() => {});
      }
    }
  });
}

/** Read the real page count once, before OCR requests its default page range. */
export async function getWebPdfPageCount(blob, cacheKey = '') {
  if (!(blob instanceof Blob) || !blob.size) throw new Error('ملف PDF فارغ.');
  const item = openDocument({ blob, cacheKey });
  item.active += 1;
  try {
    const doc = await item.promise;
    return Math.max(0, Number(doc.numPages || 0));
  } finally {
    item.active -= 1;
    if (item.retired && item.active === 0 && item.document) {
      void item.document.destroy().catch(() => {});
    }
  }
}

export function renderWebPdfBlob(blob, page = 1, targetWidth = 1800, cacheKey = '') {
  return renderDocumentPage({ blob, cacheKey }, page, targetWidth);
}

export function renderWebPdfPage(url, page = 1, targetWidth = 1800, cacheKey = '') {
  return renderDocumentPage({ url, cacheKey: cacheKey || url }, page, targetWidth);
}

/** Preload only adjacent pages at a reduced width, using the SAME bounded document/page cache. */
export async function preloadWebPdfNeighbors(source, page, totalPages, maxWidth = 1600) {
  const neighbors = pdfNeighborPages(page, totalPages);
  if (!neighbors.length || (!source?.blob && !source?.url)) return [];
  // A lower resolution avoids allocating two additional 3000px canvases while
  // the teacher pinches the current page. Full resolution still renders on demand.
  const preloadWidth = Math.min(1200, Math.max(500, Number(maxWidth) || 1200));
  return Promise.allSettled(neighbors.map((neighbor) =>
    renderDocumentPage(source, neighbor, preloadWidth),
  ));
}

export function clearWebPdfPageCache() {
  pages.clear();
  for (const item of documents.values()) {
    item.retired = true;
    if (item.document && item.active === 0) void item.document.destroy().catch(() => {});
  }
  documents.clear();
}
