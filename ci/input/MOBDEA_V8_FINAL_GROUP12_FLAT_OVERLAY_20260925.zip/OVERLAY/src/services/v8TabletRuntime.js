let installed = false;
let wakeLock = null;
let classModeUsers = 0;
let visibilityHandler = null;
let audioContext = null;

async function requestWakeLock() {
  if (document.visibilityState !== 'visible' || !navigator.wakeLock?.request || classModeUsers <= 0) return;
  try {
    wakeLock = await navigator.wakeLock.request('screen');
    wakeLock.addEventListener?.('release', () => { wakeLock = null; }, { once: true });
  } catch {
    wakeLock = null;
  }
}

export async function activateTabletAudio() {
  try { globalThis.speechSynthesis?.resume?.(); } catch { /* no-op */ }
  try {
    const AudioContextCtor = globalThis.AudioContext || globalThis.webkitAudioContext;
    if (AudioContextCtor) {
      if (!audioContext || audioContext.state === 'closed') audioContext = new AudioContextCtor();
      if (audioContext.state === 'suspended') await audioContext.resume();
    }
  } catch {
    // AudioContext is only a best-effort Android/WebView activation path.
  }
}

export function installTabletRuntime() {
  if (installed || typeof document === 'undefined') return;
  installed = true;
  const activate = () => { void activateTabletAudio(); };
  document.addEventListener('pointerdown', activate, { passive: true, capture: true });
  document.addEventListener('touchend', activate, { passive: true, capture: true });
  document.addEventListener('keydown', activate, { capture: true });
  visibilityHandler = () => {
    if (document.visibilityState === 'visible' && classModeUsers > 0) {
      void requestWakeLock();
      void activateTabletAudio();
    }
  };
  document.addEventListener('visibilitychange', visibilityHandler);
}

export async function activateClassModeTabletRuntime() {
  classModeUsers += 1;
  document.documentElement.classList.add('mobdea-tablet-classmode-runtime');
  document.body.classList.add('mobdea-tablet-classmode-runtime');
  await activateTabletAudio();
  await requestWakeLock();
  try { await globalThis.screen?.orientation?.lock?.('landscape'); } catch { /* device policy may block */ }
}

export async function reinforceClassModeFullscreen() {
  await activateTabletAudio();
  await requestWakeLock();
  try { await globalThis.screen?.orientation?.lock?.('landscape'); } catch { /* device policy may block */ }
}

export function deactivateClassModeTabletRuntime() {
  classModeUsers = Math.max(0, classModeUsers - 1);
  if (classModeUsers > 0) return;
  document.documentElement.classList.remove('mobdea-tablet-classmode-runtime');
  document.body.classList.remove('mobdea-tablet-classmode-runtime');
  try { wakeLock?.release?.(); } catch { /* no-op */ }
  wakeLock = null;
  try { globalThis.screen?.orientation?.unlock?.(); } catch { /* no-op */ }
}
