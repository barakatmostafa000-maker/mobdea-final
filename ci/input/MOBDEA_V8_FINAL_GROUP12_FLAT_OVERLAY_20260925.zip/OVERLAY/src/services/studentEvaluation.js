/* POST52_STUDENT_EVALUATION_RANKING_AND_GROUP_MESSAGE_V1 */

const numeric = (value) => Number.isFinite(Number(value)) ? Number(value) : 0;
const clean = (value) => String(value ?? '').trim();

export function evaluationGroups(data = {}) {
  return [...new Set((data.students || []).map((student) => clean(student.group)).filter(Boolean))]
    .sort((left, right) => left.localeCompare(right, 'ar'));
}

export function evaluationExams(data = {}) {
  return [...new Set((data.grades || []).map((row) => clean(row.exam)).filter(Boolean))]
    .sort((left, right) => left.localeCompare(right, 'ar'));
}

export function buildEvaluationRanking(data = {}, group = '') {
  const students = Array.isArray(data.students) ? data.students : [];
  const grades = Array.isArray(data.grades) ? data.grades : [];
  const studentById = new Map(students.map((student) => [String(student.id), student]));
  const wantedGroup = clean(group);
  const totals = new Map();

  for (const row of grades) {
    const student = studentById.get(String(row.studentId));
    if (!student) continue;
    if (wantedGroup && clean(student.group) !== wantedGroup) continue;
    const max = numeric(row.total);
    if (!(max > 0)) continue;
    const score = Math.max(0, Math.min(max, numeric(row.score)));
    const key = String(student.id);
    const current = totals.get(key) || {
      student,
      score: 0,
      total: 0,
      resultCount: 0,
      exams: new Set(),
    };
    current.score += score;
    current.total += max;
    current.resultCount += 1;
    if (row.exam) current.exams.add(clean(row.exam));
    totals.set(key, current);
  }

  const ranked = [...totals.values()].map((entry) => ({
    student: entry.student,
    score: entry.score,
    total: entry.total,
    resultCount: entry.resultCount,
    examCount: entry.exams.size,
    percentage: entry.total > 0 ? Math.round((entry.score / entry.total) * 1000) / 10 : 0,
  })).sort((left, right) =>
    right.percentage - left.percentage ||
    right.resultCount - left.resultCount ||
    right.score - left.score ||
    clean(left.student?.name).localeCompare(clean(right.student?.name), 'ar')
  );

  return ranked.map((entry, index) => ({ ...entry, rank: index + 1 }));
}

export function buildAllGroupRankings(data = {}) {
  return Object.fromEntries(evaluationGroups(data).map((group) => [group, buildEvaluationRanking(data, group)]));
}

function mostRecentExamDate(data, exam, group) {
  const students = new Map((data.students || []).map((student) => [String(student.id), student]));
  return (data.grades || [])
    .filter((row) => clean(row.exam) === clean(exam))
    .filter((row) => !group || clean(students.get(String(row.studentId))?.group) === clean(group))
    .map((row) => clean(row.date))
    .filter(Boolean)
    .sort()
    .at(-1) || '';
}

export function getExamGroupResults(data = {}, { exam = '', group = '', date = '' } = {}) {
  const students = new Map((data.students || []).map((student) => [String(student.id), student]));
  const examName = clean(exam);
  const groupName = clean(group);
  const selectedDate = clean(date) || mostRecentExamDate(data, examName, groupName);
  const latestByStudent = new Map();

  for (const row of data.grades || []) {
    if (!examName || clean(row.exam) !== examName) continue;
    const student = students.get(String(row.studentId));
    if (!student) continue;
    if (groupName && clean(student.group) !== groupName) continue;
    if (selectedDate && clean(row.date) !== selectedDate) continue;
    const total = numeric(row.total);
    if (!(total > 0)) continue;
    const score = Math.max(0, Math.min(total, numeric(row.score)));
    const candidate = {
      ...row,
      student,
      score,
      total,
      percentage: Math.round((score / total) * 100),
    };
    const previous = latestByStudent.get(String(student.id));
    if (!previous || numeric(candidate.id) >= numeric(previous.id)) latestByStudent.set(String(student.id), candidate);
  }

  const results = [...latestByStudent.values()].sort((left, right) =>
    right.percentage - left.percentage ||
    right.score - left.score ||
    clean(left.student?.name).localeCompare(clean(right.student?.name), 'ar')
  ).map((row, index) => ({ ...row, rank: index + 1 }));

  return { exam: examName, group: groupName, date: selectedDate, results };
}

const arNumber = (value) => Number(value || 0).toLocaleString('ar-EG', { maximumFractionDigits: 1 });

export function buildExamGroupMessage(data = {}, options = {}) {
  const summary = getExamGroupResults(data, options);
  if (!summary.exam) return '';
  const rows = summary.results;
  const average = rows.length
    ? Math.round(rows.reduce((sum, row) => sum + row.percentage, 0) / rows.length)
    : 0;
  const groupLabel = summary.group || 'كل المجموعات';
  const dateLabel = summary.date || '—';
  const resultsText = rows.length
    ? rows.map((row) => `${arNumber(row.rank)}) ${row.student.name} — ${arNumber(row.score)}/${arNumber(row.total)} (${arNumber(row.percentage)}%)`).join('\n')
    : 'لا توجد درجات مسجلة لهذه المجموعة حتى الآن.';

  return [
    'السلام عليكم ورحمة الله وبركاته',
    '',
    `📊 نتيجة امتحان: ${summary.exam}`,
    `👥 المجموعة: ${groupLabel}`,
    `📅 التاريخ: ${dateLabel}`,
    '',
    resultsText,
    '',
    `متوسط المجموعة: ${arNumber(average)}%`,
    rows[0] ? `الأعلى في المجموعة: ${rows[0].student.name} — ${arNumber(rows[0].percentage)}%` : '',
    '',
    'المُبدع مصطفى بركات',
    'معلم تاريخ ودراسات',
    'المُبدع لتعليم ممتع',
  ].filter((line, index, all) => line !== '' || all[index - 1] !== '').join('\n').trim();
}

/** Improvement in percentage points between the earliest and latest recorded
 * exam for each student. A single exam, missing date, or invalid total is not
 * evidence of improvement. For same-day exams, insertion order is stable. */
export function buildMostImprovedRanking(data = {}, group = '') {
  const wanted = clean(group);
  const students = new Map((data.students || []).filter((student) =>
    !wanted || clean(student.group) === wanted).map((student) => [String(student.id), student]));
  const history = new Map();
  for (const [index, row] of (data.grades || []).entries()) {
    const id = String(row.studentId);
    if (!students.has(id) || !clean(row.date) || !(numeric(row.total) > 0)) continue;
    const max = numeric(row.total);
    const percent = Math.round(1000 * Math.max(0, Math.min(max, numeric(row.score))) / max) / 10;
    const exams = history.get(id) || [];
    exams.push({ date: clean(row.date), index, percent });
    history.set(id, exams);
  }
  const ranking = [];
  for (const [id, exams] of history) {
    exams.sort((a, b) => a.date.localeCompare(b.date) || a.index - b.index);
    if (exams.length < 2) continue;
    const first = exams[0].percent;
    const latest = exams[exams.length - 1].percent;
    ranking.push({ student: students.get(id), first, latest,
      change: Math.round((latest - first) * 10) / 10, resultCount: exams.length });
  }
  return ranking.sort((a, b) => b.change - a.change || b.latest - a.latest ||
    clean(a.student.name).localeCompare(clean(b.student.name), 'ar'))
    .map((entry, index) => ({ ...entry, rank: index + 1 }));
}

/** Points ranking independent from percentages/grades. */
export function buildPointsRanking(data = {}, group = '') {
  const wanted = clean(group);
  return (data.students || []).filter((student) => !wanted || clean(student.group) === wanted)
    .map((student) => ({ student, points: Math.max(0, numeric(student.points)) }))
    .sort((a, b) => b.points - a.points || clean(a.student.name).localeCompare(clean(b.student.name), 'ar'))
    .map((entry, index) => ({ ...entry, rank: index + 1 }));
}

/** Most-improved CLASSROOM points: compare points earned in the last two
 * recorded lessons, never differences between cumulative account balances.
 * Students without two comparable lesson snapshots are not ranked. */
export function buildClassPointImprovementRanking(data = {}, group = '') {
  const wanted = clean(group);
  const sessions = (data.classPointSessions || []).slice().sort((left, right) =>
    clean(left.date || left.updatedAt).localeCompare(clean(right.date || right.updatedAt)) ||
    clean(left.updatedAt).localeCompare(clean(right.updatedAt)));
  const earned = (item, id, previous) => {
    if (!item) return null;
    if (item.earned && Object.prototype.hasOwnProperty.call(item.earned, id)) {
      return numeric(item.earned[id]);
    }
    if (item.startPoints && item.points &&
        Object.prototype.hasOwnProperty.call(item.startPoints, id) &&
        Object.prototype.hasOwnProperty.call(item.points, id)) {
      return numeric(item.points[id]) - numeric(item.startPoints[id]);
    }
    if (previous?.points && item.points &&
        Object.prototype.hasOwnProperty.call(previous.points, id) &&
        Object.prototype.hasOwnProperty.call(item.points, id)) {
      return numeric(item.points[id]) - numeric(previous.points[id]);
    }
    return null;
  };
  const ranking = [];
  for (const student of data.students || []) {
    if (wanted && clean(student.group) !== wanted) continue;
    const id = String(student.id);
    const ownSessions = sessions.filter((item) =>
      (!item.group || clean(item.group) === clean(student.group)) &&
      (!item.grade || clean(item.grade) === clean(student.grade)) &&
      ((item.earned && Object.prototype.hasOwnProperty.call(item.earned,id)) ||
       (item.points && Object.prototype.hasOwnProperty.call(item.points,id))));
    if (ownSessions.length < 2) continue;
    const last = ownSessions.at(-1);
    const prior = ownSessions.at(-2);
    const previousEarned = earned(prior, id, ownSessions.at(-3));
    const latestEarned = earned(last, id, prior);
    if (previousEarned === null || latestEarned === null) continue;
    ranking.push({ student, previousEarned, latestEarned,
      change: Math.round((latestEarned - previousEarned) * 10) / 10,
      points: Math.max(0, numeric(student.points)), resultCount: ownSessions.length });
  }
  return ranking.sort((a, b) => b.change - a.change || b.points - a.points ||
    clean(a.student.name).localeCompare(clean(b.student.name), 'ar'))
    .map((entry, index) => ({ ...entry, rank: index + 1 }));
}
