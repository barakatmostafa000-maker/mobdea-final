import { buildCloudUrl, timeoutFetch } from './cloudTransport.js';
function config(settings) {
  const cloud=settings?.cloudSync||settings||{};
  const endpoint=String(cloud.endpoint||'').replace(/\/+$/,'');
  const workspaceId=String(cloud.workspaceId||'');
  if(!/^https:\/\//i.test(endpoint)||! /^[a-zA-Z0-9_-]{3,80}$/.test(workspaceId))throw new Error('إعداد البوابة السحابية غير مكتمل.');
  return {endpoint,workspaceId};
}
export async function loginGuardianCloud(settings,accountId,pin){
  const c=config(settings);
  const response=await timeoutFetch(buildCloudUrl(c.endpoint,'/guardian/login'),{method:'POST',
    headers:{'Content-Type':'application/json','X-Mobdea-Workspace':c.workspaceId},
    body:JSON.stringify({accountId,pin})},25000);
  const result=await response.json();
  if(!response.ok||!result.roleToken)throw new Error(result.error||'تعذر دخول ولي الأمر.');
  return {...result,endpoint:c.endpoint,workspaceId:c.workspaceId};
}
export async function fetchGuardianCloudSnapshot(session){
  const c=config(session);
  const response=await timeoutFetch(buildCloudUrl(c.endpoint,'/guardian/snapshot'),{method:'GET',
    headers:{'X-Mobdea-Workspace':c.workspaceId,'X-Mobdea-Role-Token':session.roleToken}},25000);
  const result=await response.json();
  if(!response.ok)throw new Error(result.error||'تعذر تحديث بيانات ولي الأمر.');
  return result;
}
