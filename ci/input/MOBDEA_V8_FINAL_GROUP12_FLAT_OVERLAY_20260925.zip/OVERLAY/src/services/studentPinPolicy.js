import { createCredentialSecret, normalizePin } from '../utils/security';
import { cloudConfigured, pushCloudData } from './cloudSync';

export const DEFAULT_STUDENT_PIN = '12345678';
export const STUDENT_PIN_POLICY_VERSION = 2;

function pinPolicySettings(settings = {}) {
  return {
    ...settings,
    studentPinDefaultVersion: STUDENT_PIN_POLICY_VERSION,
    studentPinDefaultLength: DEFAULT_STUDENT_PIN.length,
  };
}

async function persistAndSync(nextData, updateData) {
  const saved = await updateData(nextData);
  const current = saved || nextData;
  if (!cloudConfigured(current.settings)) return { data: current, synced: false, syncError: '' };
  try {
    const remote = await pushCloudData(current);
    const syncedAt = new Date().toISOString();
    const withSync = {
      ...current,
      settings: {
        ...current.settings,
        cloudSync: {
          ...current.settings.cloudSync,
          revision: remote.revision || current.settings.cloudSync?.revision || '',
          lastPushAt: syncedAt,
          lastAutoSyncAt: syncedAt,
          localChangedAt: '',
          autoSyncError: '',
        },
      },
    };
    const synced = await updateData(withSync);
    return { data: synced || withSync, synced: true, syncError: '' };
  } catch (error) {
    return {
      data: current,
      synced: false,
      syncError: error?.message || 'تعذر مزامنة PIN مع الخادم.',
    };
  }
}

export function needsUnifiedStudentPinMigration(data = {}) {
  return Number(data?.settings?.studentPinDefaultVersion || 0) < STUDENT_PIN_POLICY_VERSION;
}

export async function migrateAllStudentsToUnifiedDefaultPin(data, updateData) {
  if (!data || typeof updateData !== 'function' || !needsUnifiedStudentPinMigration(data)) {
    return { changed: false, synced: false, syncError: '' };
  }
  const secret = await createCredentialSecret(DEFAULT_STUDENT_PIN, 'student');
  const now = new Date().toISOString();
  const nextData = {
    ...data,
    students: (data.students || []).map((student) => ({
      ...student,
      ...secret,
      studentPinMustChange: true,
      studentPinDefaultVersion: STUDENT_PIN_POLICY_VERSION,
      studentPinChangedByStudentAt: '',
      studentPinResetAt: now,
      updatedAt: now,
    })),
    settings: pinPolicySettings(data.settings),
  };
  const result = await persistAndSync(nextData, updateData);
  return { changed: true, ...result };
}

export async function resetStudentPinToDefault(data, studentId, updateData) {
  const secret = await createCredentialSecret(DEFAULT_STUDENT_PIN, 'student');
  const now = new Date().toISOString();
  const nextData = {
    ...data,
    students: (data.students || []).map((student) => String(student.id) === String(studentId)
      ? {
          ...student,
          ...secret,
          studentPinMustChange: true,
          studentPinDefaultVersion: STUDENT_PIN_POLICY_VERSION,
          studentPinChangedByStudentAt: '',
          studentPinResetAt: now,
          updatedAt: now,
        }
      : student),
    settings: pinPolicySettings(data.settings),
  };
  return persistAndSync(nextData, updateData);
}

export async function changeStudentPinAfterLogin(data, studentId, newPin, updateData) {
  const normalized = normalizePin(newPin);
  if (!/^\d{6,10}$/.test(normalized)) throw new Error('PIN الجديد يجب أن يكون من 6 إلى 10 أرقام.');
  if (normalized === DEFAULT_STUDENT_PIN) throw new Error('اختر PIN مختلفًا عن الرمز الأساسي 12345678.');
  const target = (data.students || []).find((student) => String(student.id) === String(studentId));
  if (!target) throw new Error('تعذر العثور على حساب الطالب الحالي.');
  const secret = await createCredentialSecret(normalized, 'student');
  const now = new Date().toISOString();
  const nextData = {
    ...data,
    students: (data.students || []).map((student) => String(student.id) === String(studentId)
      ? {
          ...student,
          ...secret,
          studentPinMustChange: false,
          studentPinDefaultVersion: STUDENT_PIN_POLICY_VERSION,
          studentPinChangedByStudentAt: now,
          updatedAt: now,
        }
      : student),
    settings: pinPolicySettings(data.settings),
  };
  return persistAndSync(nextData, updateData);
}
