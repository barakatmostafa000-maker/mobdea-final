// Browser OCR for real uploaded images and PDF pages; this does not claim that
// a particular file contains recognized questions until the worker returns text.
import { structureOcrQuestions } from './ocrQuestionParser';

const MAX_BROWSER_OCR_PAGES = 20;
const MAX_BROWSER_PDF_BYTES = 100 * 1024 * 1024;

function checkAbort(signal) {
  if (signal?.aborted) throw new DOMException('تم إلغاء عملية OCR.', 'AbortError');
}

function validBlob(blob) {
  if (!(blob instanceof Blob) || !blob.size) throw new Error('اختر ملفًا غير فارغ لعملية OCR.');
  if (blob.size > MAX_BROWSER_PDF_BYTES) throw new Error('ملف OCR أكبر من الحد الآمن للمتصفح (100 ميجابايت).');
}

async function withArabicWorker(operation, { signal, onProgress } = {}) {
  checkAbort(signal);
  // Lazy import keeps the expensive OCR worker out of normal page startup.
  const { createWorker } = await import('tesseract.js');
  let worker;
  let cancelled = false;
  const abort = () => {
    cancelled = true;
    void worker?.terminate?.().catch(() => {});
  };
  signal?.addEventListener('abort', abort, { once: true });
  try {
    checkAbort(signal);
    worker = await createWorker(['ara', 'eng'], 1, {
      logger: (event) => {
        if (!cancelled) onProgress?.({ stage: 'recognizing', progress: Number(event?.progress || 0) });
      },
    });
    checkAbort(signal);
    await worker.setParameters?.({ preserve_interword_spaces: '1' });
    return await operation(worker, checkAbort, signal);
  } finally {
    signal?.removeEventListener('abort', abort);
    try { await worker?.terminate?.(); } catch { /* cancelled or already terminated */ }
  }
}

export async function recognizeBrowserExamImage(image, options = {}) {
  if (!image) throw new Error('اختر صورة واضحة لاستخراج الأسئلة.');
  const text = await withArabicWorker(async (worker, assertNotCancelled, signal) => {
    assertNotCancelled(signal);
    const result = await worker.recognize(image);
    assertNotCancelled(signal);
    return String(result?.data?.text || '').trim();
  }, options);
  if (!text) throw new Error('لم يتمكن OCR من قراءة نص من الصورة. جرّب صورة أوضح.');
  return { text, ...structureOcrQuestions(text), engine: 'tesseract-browser' };
}

export async function extractBrowserExamPdf({ blob, startPage = 1, endPage = 1, cacheKey = '', signal, onProgress } = {}) {
  validBlob(blob);
  const first = Math.max(1, Number(startPage || 1));
  const last = Math.max(first, Number(endPage || first));
  if (!Number.isInteger(first) || !Number.isInteger(last) || last - first + 1 > MAX_BROWSER_OCR_PAGES) {
    throw new Error(`الحد الأقصى لاستخراج PDF على المتصفح هو ${MAX_BROWSER_OCR_PAGES} صفحة في المرة الواحدة.`);
  }
  const { renderWebPdfBlob, getWebPdfPageCount } = await import('./webPdfRenderer');
  const pageCount = await getWebPdfPageCount(blob, cacheKey);
  if (first > pageCount) throw new Error(`ملف PDF يحتوي على ${pageCount} صفحة؛ اختر صفحة ضمن الملف.`);
  // Default form range (1–4) should still work with one-page PDFs.
  const actualLast = Math.min(last, pageCount);
  const pages = [];
  const textParts = [];
  const result = await withArabicWorker(async (worker, assertNotCancelled, abortSignal) => {
    for (let page = first; page <= actualLast; page += 1) {
      assertNotCancelled(abortSignal);
      onProgress?.({ stage: 'rendering', page, totalPages: actualLast - first + 1 });
      const rendered = await renderWebPdfBlob(blob, page, 1800, cacheKey);
      assertNotCancelled(abortSignal);
      onProgress?.({ stage: 'recognizing', page, totalPages: actualLast - first + 1 });
      const ocr = await worker.recognize(rendered.dataUrl);
      assertNotCancelled(abortSignal);
      const text = String(ocr?.data?.text || '').trim();
      pages.push({ pageNumber: page, text });
      if (text) textParts.push(text);
    }
    return structureOcrQuestions(textParts.join('\n\n'));
  }, { signal, onProgress });
  return { ...result, pages, pageCount, processedPages: pages.length, startPage: first, endPage: actualLast, engine: 'tesseract-browser' };
}
