/** Review state is independent of the OCR engine. Never infer an answer. */
import { isQuestionReadyForGame } from './project08QuestionImport.js';

export function patchOcrReviewQuestion(question, patch) {
  const next = { ...question, ...patch };
  if ('answer' in patch || 'options' in patch || 'text' in patch) {
    const options = Array.isArray(next.options) ? next.options : [];
    const answer = String(next.answer || '').trim();
    next.answerIndex = next.type === 'mcq'
      ? options.findIndex((choice) => String(choice).trim() === answer)
      : next.type === 'tf' ? (answer === 'صح' ? 0 : answer === 'خطأ' ? 1 : -1)
        : -1;
    next.needsAnswer = !isQuestionReadyForGame(next);
    // A changed question must be approved anew; untouched answers can be
    // approved explicitly via the checkbox below.
    next.approved = false;
  } else if ('approved' in patch) {
    next.approved = Boolean(patch.approved) && isQuestionReadyForGame(next);
  }
  return next;
}

export function approvedOcrQuestions(questions = [], existing = []) {
  const unique = new Set(existing.map((item) => item.id));
  return questions.filter((item) => {
    if (!item?.approved || !isQuestionReadyForGame(item) || unique.has(item.id)) return false;
    unique.add(item.id);
    return true;
  });
}

/** Only clear the review queue AFTER durable persistence completes. */
export async function persistApprovedOcrQuestions(questions, existing, save) {
  const ready = approvedOcrQuestions(questions, existing);
  if (!ready.length) return [];
  await save(ready.map((question) => ({ ...question, needsAnswer: false })));
  return ready.map((question) => question.id);
}
