const STORAGE_KEY = "mobdea:v8:resource-state:v1";
const MAX_STATE_ENTRIES = 120;
const memory = new Map();

function storage() {
  try {
    return globalThis.sessionStorage || null;
  } catch {
    return null;
  }
}

function loadOnce() {
  if (memory.__loaded) return;
  memory.__loaded = true;
  const store = storage();
  if (!store) return;
  try {
    const parsed = JSON.parse(store.getItem(STORAGE_KEY) || "[]");
    if (!Array.isArray(parsed)) return;
    for (const row of parsed.slice(-MAX_STATE_ENTRIES)) {
      if (!row || typeof row.key !== "string") continue;
      memory.set(row.key, { value: row.value, at: Number(row.at || 0) });
    }
  } catch {
    // Corrupted session state must never block ClassMode.
  }
}

function persist() {
  const store = storage();
  if (!store) return;
  try {
    const rows = [...memory.entries()]
      .filter(([key]) => key !== "__loaded")
      .map(([key, item]) => ({ key, value: item?.value, at: Number(item?.at || 0) }))
      .sort((a, b) => a.at - b.at)
      .slice(-MAX_STATE_ENTRIES);
    store.setItem(STORAGE_KEY, JSON.stringify(rows));
  } catch {
    // Storage quotas/private modes are best-effort only.
  }
}

function fullKey(scope, key) {
  return `${String(scope || "view")}:${String(key || "default")}`;
}

export function readResourceState(scope, key, fallback = null) {
  loadOnce();
  const item = memory.get(fullKey(scope, key));
  return item ? item.value : fallback;
}

export function writeResourceState(scope, key, value) {
  loadOnce();
  const k = fullKey(scope, key);
  if (memory.has(k)) memory.delete(k);
  memory.set(k, { value, at: Date.now() });
  while ([...memory.keys()].filter((keyName) => keyName !== "__loaded").length > MAX_STATE_ENTRIES) {
    const stale = [...memory.keys()].find((keyName) => keyName !== "__loaded");
    if (!stale) break;
    memory.delete(stale);
  }
  persist();
  return value;
}

export function removeResourceState(scope, key) {
  loadOnce();
  memory.delete(fullKey(scope, key));
  persist();
}

export function clearV8ResourceSessionState() {
  memory.clear();
  memory.__loaded = true;
  try { storage()?.removeItem(STORAGE_KEY); } catch { /* best effort */ }
}

export const V8_RESOURCE_STATE_LIMIT = MAX_STATE_ENTRIES;
