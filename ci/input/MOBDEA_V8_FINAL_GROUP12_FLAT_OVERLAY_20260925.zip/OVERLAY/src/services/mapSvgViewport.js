// Shared coordinate model for SVG viewBox 0 0 1000 620 and its HTML marker overlay.
export const MAP_SVG_WIDTH = 1000;
export const MAP_SVG_HEIGHT = 620;

export function fitMapSvgViewport(width, height) {
  const w = Number(width);
  const h = Number(height);
  if (!Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) return null;
  const ratio = Math.min(w / MAP_SVG_WIDTH, h / MAP_SVG_HEIGHT);
  const fittedWidth = MAP_SVG_WIDTH * ratio;
  const fittedHeight = MAP_SVG_HEIGHT * ratio;
  return { left: (w - fittedWidth) / 2, top: (h - fittedHeight) / 2,
    width: fittedWidth, height: fittedHeight };
}

export function percentWithinMapViewport(clientX, clientY, rect) {
  if (!rect || !Number.isFinite(rect.width) || !Number.isFinite(rect.height)
      || rect.width <= 0 || rect.height <= 0) return null;
  const x = (Number(clientX) - rect.left) / rect.width;
  const y = (Number(clientY) - rect.top) / rect.height;
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || x > 1 || y < 0 || y > 1) return null;
  return { x: x * 100, y: y * 100 };
}
