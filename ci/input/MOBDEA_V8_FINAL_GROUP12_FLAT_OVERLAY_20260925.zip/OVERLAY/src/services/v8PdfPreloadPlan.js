/** Bounded, distinct neighbors for a real PDF. Never request page 0 or a page beyond the book. */
export function pdfNeighborPages(page, totalPages) {
  const current = Math.floor(Number(page));
  const total = Math.floor(Number(totalPages));
  if (!Number.isFinite(current) || !Number.isFinite(total) || current < 1 || total < 1 || current > total) return [];
  return [current + 1, current - 1].filter((candidate) => candidate >= 1 && candidate <= total);
}
