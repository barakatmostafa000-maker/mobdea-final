import {
  COUNTRY_AR_NAMES,
  COUNTRY_CAPITALS_AR,
  COUNTRY_FACTS_AR,
} from "../data/mapEnrichment.js";
import {
  COUNTRY_CARD_CATEGORIES,
  COUNTRY_CARD_MAP,
  countryCardsForCategory as rawCountryCardsForCategory,
} from "../data/countryCards.js";

const CATEGORY_LABELS = Object.freeze(
  Object.fromEntries(COUNTRY_CARD_CATEGORIES.map(({ key, label }) => [key, label])),
);

export function normalizeCountryCardName(value = "") {
  return String(value)
    .trim()
    .normalize("NFKD")
    .replace(/[\u064B-\u065F\u0670]/g, "")
    .replace(/[إأآ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/\s+/g, " ");
}

const ISO_BY_ARABIC_NAME = Object.freeze(
  Object.fromEntries(Object.entries(COUNTRY_AR_NAMES).map(
    ([iso, name]) => [normalizeCountryCardName(name), iso],
  )),
);

export function enrichCountryCard(card, categoryKey = "") {
  if (!card || card.isDefault) return card;
  const explicitIso = String(card.iso || card.iso3 || card.countryCode || "").toUpperCase();
  const iso = COUNTRY_AR_NAMES[explicitIso]
    ? explicitIso
    : ISO_BY_ARABIC_NAME[normalizeCountryCardName(card.name)] || "";
  const capital = card.capital || COUNTRY_CAPITALS_AR[iso] || "";
  const region = card.region || card.subregion || card.continent || CATEGORY_LABELS[categoryKey] || "";
  const educationalFact = card.fact || COUNTRY_FACTS_AR[iso] || "";
  return { ...card, iso, capital, region, educationalFact };
}

export function getCountryCard(cardKey, categoryKey = "") {
  const card = COUNTRY_CARD_MAP[String(cardKey)];
  return enrichCountryCard(card, card?.category || categoryKey);
}

export function countryCardsForCategory(categoryKey, search = "") {
  const query = normalizeCountryCardName(search).replace(/\s+/g, "");
  const cards = query
    ? COUNTRY_CARD_CATEGORIES.flatMap(({ key }) => rawCountryCardsForCategory(key))
    : rawCountryCardsForCategory(categoryKey);
  return cards
    .map((card) => enrichCountryCard(card, card.category))
    .filter((card) => !query || normalizeCountryCardName(
      [card.name, card.capital, card.region, card.iso].join(" "),
    ).replace(/\s+/g, "").includes(query));
}
