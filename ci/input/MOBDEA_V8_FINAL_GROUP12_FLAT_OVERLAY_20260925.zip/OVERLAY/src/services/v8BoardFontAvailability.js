/** A @font-face rule alone is not proof that the font file loads on the device. */
const FONT_ASSET_PATHS = Object.freeze({
  'Noto Naskh Arabic': '/fonts/NotoNaskhArabic-Variable.ttf',
  'Noto Kufi Arabic': '/fonts/NotoKufiArabic-Variable.ttf',
  'Aref Ruqaa': '/fonts/ArefRuqaa-Regular.ttf',
  'Amiri': '/fonts/Amiri-Regular.ttf',
  'Reem Kufi': '/fonts/ReemKufi-Variable.ttf',
});
const fontAssetChecks = new Map();

/** Inspect the binary signature to distinguish real installed fonts from a Vite fallback page. */
export async function isArabicBoardFontAvailable(family, documentObject = globalThis.document) {
  const url = FONT_ASSET_PATHS[family];
  if (!url) return false;
  if (!fontAssetChecks.has(family)) {
    fontAssetChecks.set(family, (async () => {
      try {
        const response = await fetch(url, { cache: 'no-cache' });
        if (!response.ok) return false;
        const contentType = String(response.headers.get('content-type') || '').toLowerCase();
        if (contentType.includes('text/html')) return false;
        const header = new Uint8Array(await response.arrayBuffer());
        if (header.byteLength < 50_000) return false;
        const signature = Array.from(header.slice(0, 4)).map((byte) => byte.toString(16).padStart(2, '0')).join('');
        return ['00010000', '4f54544f', '74727565', '74746366'].includes(signature);
      } catch { return false; }
    })());
  }
  if (!await fontAssetChecks.get(family)) return false;
  try {
    const spec = `700 34px "${family}"`;
    const faces = await documentObject?.fonts?.load(spec, 'المُبدع');
    return Boolean(faces?.length) && Boolean(documentObject?.fonts?.check(spec));
  } catch { return false; }
}

export function clearArabicBoardFontProbeCache() { fontAssetChecks.clear(); }
