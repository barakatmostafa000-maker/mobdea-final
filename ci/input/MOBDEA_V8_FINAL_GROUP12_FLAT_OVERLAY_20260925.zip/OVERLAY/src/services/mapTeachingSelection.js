import worldCountries from '../data/world-countries.json' with { type: 'json' };
import { COUNTRY_CARDS } from '../data/countryCards.js';
import { COUNTRY_AR_NAMES } from '../data/mapEnrichment.js';
import { countryInfo, featureInfo } from '../data/mapEnrichment.js';
import { GEOGRAPHY_TEACHING_CATEGORIES, getRegionLayerItems } from '../data/geography.js';
import { NILE_LANDMARKS, TEACHING_WATER_BODIES, getTeachingRiverPaths } from '../data/project06TeachingMaps.js';
import { NILE_POINTS } from '../data/mapEnrichment.js';

/** Keep the 35 verified illustrated country templates intact, and provide a
 * factual text/flag card for every other country present in the map dataset.
 * Never claim that a generated text card has a verified illustration. */
export function allMapCountryCards() {
  const byIso = new Map(COUNTRY_CARDS.map(card => [card.iso, card]));
  for (const feature of worldCountries.features || []) {
    const details = countryInfo(feature);
    if (!/^[A-Z]{3}$/.test(details.iso) || details.iso === 'ATA' || byIso.has(details.iso)) continue;
    byIso.set(details.iso, {
      key: `geo-${details.iso}`,
      iso: details.iso,
      name: COUNTRY_AR_NAMES[details.iso] || details.name,
      capital: details.capital,
      region: details.region,
      fact: details.fact,
      flag: details.flag,
      asset: null,
      illustrated: false,
    });
  }
  return [...byIso.values()].sort((a, b) => a.name.localeCompare(b.name, 'ar'));
}

export function teachingCategoryForLayer(layerKey = '') {
  return Object.entries(GEOGRAPHY_TEACHING_CATEGORIES).find(([, group]) => group.layers.includes(layerKey))?.[0] || 'political';
}

/** Restore a selected object as useful information, not just a highlighted ID. */
export function resolveMapSelection(geo, regionKey, layerKey, selectedId) {
  const id = String(selectedId || '');
  if (!id) return null;
  const countries = getRegionLayerItems(geo, regionKey, 'countries');
  const country = countries.find(item => item.id === id);
  if (country) return { type: 'country', ...countryInfo(country.feature) };
  // The Egypt view only renders these seven landmarks. Do not restore an
  // off-map source (such as Lake Victoria) from another region's snapshot.
  const egyptLandmarkIds = new Set(['lake-nasser', 'aswan', 'cairo', 'delta', 'rosetta-mouth', 'damietta-mouth', 'mediterranean']);
  const landmark = regionKey === 'nile'
    ? NILE_LANDMARKS.find(entry => entry.id === id)
    : regionKey === 'egypt'
      ? NILE_LANDMARKS.find(entry => entry.id === id && egyptLandmarkIds.has(entry.id))
      : null;
  if (landmark) return { type: 'feature', ...featureInfo(landmark, 'water'), raw: landmark };
  const extra = regionKey === 'nile' ? NILE_POINTS.find(entry => entry.id === id) : null;
  if (extra) return { type: 'feature', ...featureInfo(extra, 'water'), raw: extra };
  const body = (TEACHING_WATER_BODIES[regionKey] || []).find(entry => entry.id === id);
  if (body) return { type: 'feature', ...featureInfo(body, 'water'), raw: body };
  const river = getTeachingRiverPaths(regionKey).find(entry => entry.id === id);
  if (river) return { type: 'feature', ...featureInfo(river, 'rivers'), raw: river };
  const item = getRegionLayerItems(geo, regionKey, layerKey).find(entry => entry.id === id);
  return item ? { type: 'feature', ...featureInfo(item, layerKey), raw: item } : null;
}
