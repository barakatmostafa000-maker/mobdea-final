import { COUNTRY_CARDS } from '../data/countryCards.js';
const BY_ISO = new Map(COUNTRY_CARDS.map((card) => [card.iso, card]));
export function countryCardByIso(iso) { return BY_ISO.get(String(iso || '').toUpperCase()) || null; }
