import { GEOGRAPHY_SYMBOLS } from '../data/geography.js';
import { countryInfo, featureInfo } from '../data/mapEnrichment.js';
import { countryCardByIso } from './mapCountryCard.js';

// The actual artwork catalog is used for map questions AND for map-building.
const BY_ID = new Map(GEOGRAPHY_SYMBOLS.map((symbol) => [symbol.id, symbol]));
const RESOURCE_GROUPS = new Set(['minerals', 'energy', 'industry', 'agriculture', 'crops', 'fisheries', 'human-economic', 'transport']);
const HUMAN_GROUPS = new Set(['human-economic', 'population', 'migration', 'transport', 'borders', 'tourism', 'fisheries']);

export function filterChallengeSymbols(symbols = GEOGRAPHY_SYMBOLS, category = 'all', search = '') {
  const query = String(search ?? '').trim().toLocaleLowerCase('ar');
  const groups = category === 'resources' ? RESOURCE_GROUPS
    : category === 'human' ? HUMAN_GROUPS
      : category === 'water' ? new Set(['water', 'nile'])
        : category === 'terrain' ? new Set(['terrain', 'vegetation', 'animals']) : null;
  return symbols.filter((item) => (!groups || groups.has(item.groupId)) &&
    (!query || [item.label, item.hint, item.id, item.groupLabel].some((value) => String(value || '').toLocaleLowerCase('ar').includes(query))));
}

const LAYER_ASSET_RULES = Object.freeze({
  minerals: [
    [/ذهب/, 'mineral-gold'], [/فوسفات/, 'human-mine'], [/حديد/, 'mineral-iron'],
    [/نحاس/, 'mineral-copper'], [/فحم/, 'energy-coal'], [/قصدير/, 'mineral-tin'],
    [/ماس/, 'mineral-diamond'], [/بوكسيت/, 'mineral-bauxite-aluminium'],
    [/بترول|نفط/, 'energy-petroleum'], [/غاز/, 'energy-natural-gas'],
  ],
  energy: [
    [/بترول|نفط/, 'energy-petroleum'], [/غاز/, 'energy-natural-gas'],
    [/شمس|شمسي/, 'energy-solar'], [/رياح/, 'energy-wind'],
    [/فحم/, 'energy-coal'], [/كهرومائ/, 'energy-hydropower'],
  ],
  agriculture: [[/واحة|نخيل/, 'crop-date-palm'], [/ري|زراع|دلتا|وادي/, 'agriculture-irrigated']],
  industry: [[/سيارات/, 'industry-cars'], [/ألومنيوم|ألمنيوم/, 'industry-aluminium']],
  ports: [[/ميناء|موانئ|مرفأ/, 'human-seaport']],
});
const FEATURE_DEFINITIONS = Object.freeze({
  mountains: 'جبل: مرتفع طبيعي عن سطح الأرض، وقد تمتد الجبال المتجاورة في سلسلة جبلية.',
  plateaus: 'هضبة: سطح مرتفع واسع نسبيًا، قد تحده حافات شديدة الانحدار.',
  plains: 'سهل: مساحة أرض منبسطة أو قليلة الانحدار تساعد على النقل والعمران.',
  deserts: 'صحراء: إقليم شديد الجفاف، تقل فيه الأمطار والغطاء النباتي.',
  terrain: 'ظاهرة تضاريسية: شكل من أشكال سطح الأرض يتغير بفعل عمليات جيولوجية ومناخية.',
  rivers: 'نهر: مجرى مائي يسير من منطقة المنبع إلى المصب، وقد تصب فيه روافد.',
  lakes: 'بحيرة: مسطح مائي تحيط به اليابسة من جوانبه، وقد يكون عذبًا أو مالحًا.',
  seas: 'بحر: جزء واسع من المياه المالحة يتصل عادة بالمحيط أو يفصله عن غيره مضيق.',
  oceans: 'محيط: مسطح مائي مالح شاسع يفصل بين قارات العالم.',
  gulfs: 'خليج: امتداد من البحر أو المحيط إلى داخل اليابسة.',
  straits: 'مضيق: ممر مائي طبيعي ضيق يصل بين مسطحين مائيين ويفصل بين منطقتين يابستين.',
  canals: 'قناة: مجرى مائي صناعي يُستخدم في الملاحة أو الري أو نقل المياه.',
  water: 'ظاهرة مائية: مسطح أو مجرى مائي يؤثر في الحياة البشرية والبيئة.',
  minerals: 'ثروة معدنية: مادة طبيعية تُستخرج من باطن الأرض وتُستخدم في الصناعة والاقتصاد.',
  energy: 'مصدر طاقة: مورد يُستخدم في إنتاج الكهرباء أو الحرارة أو تشغيل الآلات ووسائل النقل.',
  agriculture: 'نشاط زراعي: إنتاج محاصيل باستخدام الأرض والمياه والموارد الطبيعية.',
  industry: 'نشاط صناعي: تحويل المواد الخام إلى منتجات نافعة باستخدام العمل والتقنية.',
  ports: 'ميناء: موقع تُستقبل فيه السفن والبضائع والركاب وتنطلق منه الرحلات البحرية.',
  capitals: 'عاصمة: مدينة تضم مؤسسات الحكم الرئيسية في الدولة.',
  cities: 'مدينة: تجمع عمراني يضم سكانًا وأنشطة وخدمات متنوعة.',
  landmarks: 'معلم جغرافي أو موقع مهم يمكن تحديد موضعه وعلاقته بما حوله على الخريطة.',
  borders: 'حدود: خطوط تحدد نطاق سيادة الدول أو التقسيمات الإدارية على الخريطة.',
  population: 'توزيع السكان: طريقة انتشار السكان بين أجزاء الدولة أو الإقليم.',
  latitude: 'دوائر العرض: خطوط مرجعية تُقاس بها المسافة الزاوية شمال خط الاستواء أو جنوبه.',
  longitude: 'خطوط الطول: خطوط مرجعية تُقاس بها المسافة الزاوية شرق خط جرينتش أو غربه.',
  directions: 'الاتجاهات الأصلية: الشمال والجنوب والشرق والغرب لتحديد المواضع على الخريطة.',
});

const LAYER_DEFAULT_ICON = Object.freeze({
  minerals: 'human-mine', energy: 'energy-petroleum', agriculture: 'agriculture-irrigated',
  industry: 'human-industrial-area', ports: 'human-seaport',
});

export function challengeSymbolForFeature(item, layerKey) {
  const name = String(item?.name || '');
  const rules = LAYER_ASSET_RULES[layerKey] || [];
  const specific = rules.find(([regex]) => regex.test(name));
  const id = specific?.[1] || LAYER_DEFAULT_ICON[layerKey];
  return id ? BY_ID.get(id) || null : null;
}

export function mapChallengeFeatureInfo(item, layerKey) {
  if (item?.countryInfo) {
    const card = countryCardByIso(item.countryInfo.iso);
    return card ? {
      ...item.countryInfo,
      capital: card.capital || item.countryInfo.capital,
      region: card.region || item.countryInfo.region,
      fact: card.fact || item.countryInfo.fact,
    } : item.countryInfo;
  }
  if (item?.feature?.geometry && ['countries', 'borders', 'population'].includes(layerKey)) {
    const country = countryInfo(item.feature);
    const card = countryCardByIso(country.iso);
    return card ? { ...country, capital: card.capital || country.capital,
      region: card.region || country.region, fact: card.fact || country.fact } : country;
  }
  const info = featureInfo(item, layerKey);
  // Preserve named, source-backed facts; replace an otherwise generic placeholder
  // with the precise, layer-specific geographical definition.
  if (!item?.fact && !info.fact?.includes(item.name) &&
      /عنصر جغرافي مهم|يمكن ربطه بموقعه/.test(info.fact || '')) {
    return { ...info, fact: FEATURE_DEFINITIONS[layerKey] || info.fact };
  }
  return info;
}

export function canAnswerMapTap(started, mode) {
  return Boolean(started) && !['naming', 'build'].includes(mode);
}
