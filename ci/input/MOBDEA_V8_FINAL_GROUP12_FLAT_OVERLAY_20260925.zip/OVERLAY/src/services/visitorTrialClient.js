// Explicit server-side guest quota: no localStorage or unverified student codes.
const ALLOWED = new Set(['games', 'maps', 'multiplayer']);
export async function claimVisitorTrial(settings, kind, fetcher = globalThis.fetch) {
  if (!ALLOWED.has(kind)) throw new Error('نوع التجربة المجانية غير صالح.');
  const source = settings?.cloudSync || settings || {};
  const endpoint = String(source.endpoint || '').replace(/\/+$/, '');
  const workspaceId = String(source.workspaceId || '');
  if (!/^https:\/\/[^/]+/i.test(endpoint) || !/^[a-zA-Z0-9_-]{3,80}$/.test(workspaceId)) {
    throw new Error('يجب إعداد خادم التجارب المجانية قبل تفعيل دخول الزائر.');
  }
  let response;
  try {
    response = await fetcher(`${endpoint}/visitor/trials`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Mobdea-Workspace': workspaceId },
      body: JSON.stringify({kind}),
      cache: 'no-store',
    });
  } catch { throw new Error('تعذر الاتصال بخادم التجارب المجانية. لم تُخصم محاولة.'); }
  let result;
  try { result = await response.json(); } catch { throw new Error('استجابة خادم التجارب المجانية غير صالحة.'); }
  if (response.status === 403 && result?.allowed === false) {
    return { allowed: false, kind, status: result };
  }
  if (!response.ok || result?.allowed !== true || !Number.isInteger(result?.remaining?.[kind])) {
    throw new Error('تعذر التحقق من التجربة المجانية على الخادم.');
  }
  return { allowed: true, kind, status: result };
}

export async function fetchVisitorTrialStatus(settings, fetcher = globalThis.fetch) {
  const source = settings?.cloudSync || settings || {};
  const endpoint = String(source.endpoint || '').replace(/\/+$/, '');
  const workspaceId = String(source.workspaceId || '');
  if (!/^https:\/\/[^/]+/i.test(endpoint) || !/^[a-zA-Z0-9_-]{3,80}$/.test(workspaceId))
    throw new Error('يجب إعداد خادم التجارب المجانية لعرض المحاولات المتبقية.');
  const response = await fetcher(`${endpoint}/visitor/trials`, {
    method: 'GET', headers: { 'X-Mobdea-Workspace': workspaceId }, cache: 'no-store',
  });
  if (!response.ok) throw new Error('تعذر قراءة عداد التجارب المجانية من الخادم.');
  const status = await response.json();
  for (const kind of ALLOWED) {
    if (!Number.isInteger(status?.remaining?.[kind]) || !Number.isInteger(status?.limits?.[kind]))
      throw new Error('استجابة عداد التجارب المجانية غير صالحة.');
  }
  return status;
}
