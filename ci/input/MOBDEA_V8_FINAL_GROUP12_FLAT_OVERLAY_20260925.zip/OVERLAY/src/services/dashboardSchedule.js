/** Match lessons to today's local date without showing another weekday as "today". */
const WEEKDAYS_AR = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const WEEKDAYS_EN = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

export function sessionsForToday(sessions, localDate, weekdayIndex) {
  if (!Array.isArray(sessions)) return [];
  const today = String(localDate || '').slice(0, 10);
  if (!/^\d{4}-\d\d-\d\d$/.test(today) || !Number.isInteger(weekdayIndex) || weekdayIndex < 0 || weekdayIndex > 6) return [];
  return sessions.filter((session) => {
    if (!session || typeof session !== 'object') return false;
    const date = String(session.lessonDate || session.date || '').trim();
    if (date) return date.slice(0, 10) === today;
    const day = String(session.day || '').trim();
    if (day) return day === WEEKDAYS_AR[weekdayIndex] || day.toLowerCase() === WEEKDAYS_EN[weekdayIndex];
    return session.current === true;
  });
}
