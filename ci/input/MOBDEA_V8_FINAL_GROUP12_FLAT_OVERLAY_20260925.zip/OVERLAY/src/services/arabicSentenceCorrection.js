// V7_DEEP_ARABIC_SENTENCE_CORRECTION_V1
// Conservative offline Arabic text cleanup for the classroom whiteboard.
// It deliberately avoids aggressive grammatical rewrites that could change a
// teacher's intended meaning. The same function is used for typed text and OCR.

const SAFE_WORD_CORRECTIONS = Object.freeze(new Map([
  ['هاذا', 'هذا'],
  ['هاذه', 'هذه'],
  ['ذالك', 'ذلك'],
  ['لاكن', 'لكن'],
  ['اللذي', 'الذي'],
  ['اللتي', 'التي'],
  ['اولئك', 'أولئك'],
  ['الى', 'إلى'],
  ['لان', 'لأن'],
  ['اذا', 'إذا'],
]));

const ARABIC_QUESTION_OPENERS = /^(?:هل|كيف|لماذا|متى|أين|اين|من|ماذا|ما|كم|أي|اي)(?=\s|$)/u;
const TERMINAL_PUNCTUATION = /[.!؟?!…]$/u;

function replaceWholeWords(value) {
  return String(value || '').replace(/[\p{L}\p{M}]+/gu, (word) => {
    const corrected = SAFE_WORD_CORRECTIONS.get(word);
    return corrected || word;
  });
}

function normalizePunctuation(value) {
  return String(value || '')
    // Teachers frequently type punctuation from an English keyboard. Converting
    // only the punctuation glyphs is meaning-safe and keeps Arabic RTL text tidy.
    .replace(/,/g, '،')
    .replace(/;/g, '؛')
    .replace(/\?/g, '؟')
    .replace(/\s*([،؛:؟!.…])\s*/gu, '$1 ')
    .replace(/,{2,}/g, '،')
    .replace(/;{2,}/g, '؛')
    .replace(/\?{2,}/g, '؟')
    .replace(/!{3,}/g, '!!')
    .replace(/\.{3,}/g, '…')
    .replace(/\s+([،؛:؟!?.,…])/gu, '$1')
    .replace(/([،؛:؟!?.,…])\s+$/u, '$1')
    .trim();
}

function finishSentence(value) {
  const text = String(value || '').trim();
  if (!text || TERMINAL_PUNCTUATION.test(text)) return text;
  const words = text.split(/\s+/u).filter(Boolean);
  // Do not punctuate a heading, label, date, or isolated term automatically.
  if (words.length < 3 || text.length < 14) return text;
  return ARABIC_QUESTION_OPENERS.test(text) ? `${text}؟` : `${text}.`;
}

export function correctArabicSentence(value, { finish = true } = {}) {
  const original = String(value ?? '');
  let text = original
    .normalize('NFKC')
    .replace(/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/g, '')
    .replace(/ـ+/g, '')
    .replace(/\r\n?/g, '\n')
    .replace(/[\t ]+/g, ' ')
    .replace(/ *\n */g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  text = replaceWholeWords(text);
  text = normalizePunctuation(text);
  if (finish && !text.includes('\n')) text = finishSentence(text);

  return {
    text,
    changed: text !== original.trim(),
    original: original.trim(),
  };
}

export const V7_DEEP_ARABIC_SENTENCE_CORRECTION_V1 = true;
