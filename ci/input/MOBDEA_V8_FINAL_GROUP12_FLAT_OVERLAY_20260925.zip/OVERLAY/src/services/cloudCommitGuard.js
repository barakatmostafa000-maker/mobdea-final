/**
 * A cloud response acknowledges an older snapshot, not edits made locally while
 * the request was in flight. Preserve newer local records and leave them dirty
 * so the next sync uploads them. This never grants cloud reads or writes.
 */
export function commitCloudSnapshot(latest, proposed, { newerLocalEdits = false, uploadedDirtyAt = '', cloudPatch = {} } = {}) {
  if (!latest || typeof latest !== 'object' || !proposed || typeof proposed !== 'object') {
    throw new Error('Cloud synchronization data is unavailable.');
  }
  const latestCloud = latest.settings?.cloudSync || {};
  const currentDirtyAt = String(latestCloud.localChangedAt || '');
  const newer = newerLocalEdits || currentDirtyAt !== String(uploadedDirtyAt || '');
  const chosen = newer ? latest : proposed;
  const cloud = { ...latestCloud, ...(chosen.settings?.cloudSync || {}), ...cloudPatch };
  cloud.localChangedAt = newer ? currentDirtyAt : '';
  cloud.autoSyncError = newer ? String(latestCloud.autoSyncError || '') : '';
  return { ...chosen, settings: { ...(chosen.settings || {}), cloudSync: cloud } };
}
