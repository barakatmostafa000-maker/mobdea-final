/** Evenly divide the current class list, with right-hand list receiving the odd student. */
export function splitStudentRails(students = []) {
  const unique = [];
  const seen = new Set();
  for (const student of Array.isArray(students) ? students : []) {
    const id = String(student?.id ?? "");
    if (!id || seen.has(id)) continue;
    seen.add(id);
    unique.push(student);
  }
  const middle = Math.ceil(unique.length / 2);
  return [unique.slice(0, middle), unique.slice(middle)];
}
