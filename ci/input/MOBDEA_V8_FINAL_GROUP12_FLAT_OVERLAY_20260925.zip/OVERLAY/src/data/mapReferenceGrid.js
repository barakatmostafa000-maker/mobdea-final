import { REFERENCE_LATITUDES, REFERENCE_LONGITUDES } from './project06TeachingMaps.js';

function latitudeLabel(value) {
  if (!value) return 'خط الاستواء 0°';
  return `${Math.abs(value)}° ${value > 0 ? 'شمالًا' : 'جنوبًا'}`;
}
function longitudeLabel(value) {
  if (!value) return 'خط جرينتش 0°';
  return `${Math.abs(value)}° ${value > 0 ? 'شرقًا' : 'غربًا'}`;
}
function axisLines(min, max, fixed, step, axis) {
  const byPosition = new Map();
  for (let value = Math.ceil(min / step) * step; value <= max + 1e-7; value += step) {
    if (Math.abs(value) <= 180) {
      byPosition.set(value, {
        id: `${axis}-${value}`, value,
        label: axis === 'lat' ? latitudeLabel(value) : longitudeLabel(value),
        major: value === 0, prime: value === 0,
      });
    }
  }
  for (const item of fixed) {
    if (item.value >= min && item.value <= max) byPosition.set(item.value, item);
  }
  return [...byPosition.values()].sort((a, b) => a.value - b.value);
}
export function referenceLinesForBounds(bounds) {
  if (!Array.isArray(bounds) || bounds.length !== 4) return { latitudes: [], longitudes: [] };
  const [minLon, minLat, maxLon, maxLat] = bounds.map(Number);
  if (![minLon, minLat, maxLon, maxLat].every(Number.isFinite)
      || maxLon <= minLon || maxLat <= minLat) return { latitudes: [], longitudes: [] };
  const span = Math.max(maxLon - minLon, maxLat - minLat);
  const step = span > 100 ? 30 : span > 35 ? 15 : 5;
  return {
    latitudes: axisLines(minLat, maxLat, REFERENCE_LATITUDES, step, 'lat'),
    longitudes: axisLines(minLon, maxLon, REFERENCE_LONGITUDES, step, 'lon'),
  };
}
