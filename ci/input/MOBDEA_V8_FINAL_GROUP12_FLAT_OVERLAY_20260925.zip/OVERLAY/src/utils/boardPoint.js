/** Keep pointer and dragged teaching-card coordinates inside the visible board.
 * Off-canvas captured pointers must not store negative/out-of-range positions.
 */
export function boardPointFromClient(clientX, clientY, rect, width = 1536, height = 864) {
  const w = Number(rect?.width);
  const h = Number(rect?.height);
  const x = Number(clientX);
  const y = Number(clientY);
  if (!(w > 0 && h > 0 && width > 0 && height > 0) || ![x,y,rect?.left,rect?.top].every(Number.isFinite)) return null;
  return {
    x: Math.max(0, Math.min(width, ((x - rect.left) / w) * width)),
    y: Math.max(0, Math.min(height, ((y - rect.top) / h) * height)),
  };
}
