import { useMemo, useState } from 'react';
import { KeyRound, ShieldCheck } from 'lucide-react';
import { normalizePin } from '../utils/security';
import {
  DEFAULT_STUDENT_PIN,
  changeStudentPinAfterLogin,
} from '../services/studentPinPolicy';
import { identity } from '../config/identity';
import { findStudentForAuth } from '../services/rolePortalAccess.js';

export default function StudentPinChangeGate({ data, auth, updateData }) {
  const student = useMemo(() => findStudentForAuth(data, auth), [data, auth]);
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);

  if (auth?.role !== 'student' || !student?.studentPinMustChange) return null;

  const save = async (event) => {
    event?.preventDefault?.();
    const next = normalizePin(pin);
    const confirmation = normalizePin(confirmPin);
    if (!/^\d{6,10}$/.test(next)) {
      setNotice('اختر PIN جديدًا من 6 إلى 10 أرقام.');
      return;
    }
    if (next === DEFAULT_STUDENT_PIN) {
      setNotice('لا يمكن استخدام الرمز الأساسي 12345678 كـ PIN شخصي.');
      return;
    }
    if (next !== confirmation) {
      setNotice('تأكيد PIN غير مطابق.');
      return;
    }
    setBusy(true);
    setNotice('');
    try {
      const result = await changeStudentPinAfterLogin(data, student.id, next, updateData);
      setNotice(result.syncError
        ? `تم تغيير PIN على الجهاز. تنبيه المزامنة: ${result.syncError}`
        : 'تم تغيير PIN بنجاح. يمكنك الآن استخدام المنصة.');
    } catch (error) {
      setNotice(error?.message || 'تعذر تغيير PIN.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="student-pin-change-gate" role="dialog" aria-modal="true" aria-labelledby="student-pin-change-title">
      <div className="student-pin-change-card">
        <header>
          <img src={identity.logo || identity.icon} alt={identity.schoolName} />
          <div>
            <span>حماية حساب الطالب</span>
            <h1 id="student-pin-change-title">تغيير الرمز الأساسي إلزامي</h1>
            <p>{student.name} — دخلت بالرمز الموحد 12345678. اختر رمزك الشخصي قبل متابعة المنصة.</p>
          </div>
          <ShieldCheck size={34} />
        </header>
        <form onSubmit={save}>
          <label><span><KeyRound size={16} /> PIN جديد</span><input type="password" inputMode="numeric" maxLength={10} value={pin} onChange={(event) => setPin(normalizePin(event.target.value))} autoFocus /></label>
          <label><span><KeyRound size={16} /> تأكيد PIN</span><input type="password" inputMode="numeric" maxLength={10} value={confirmPin} onChange={(event) => setConfirmPin(normalizePin(event.target.value))} /></label>
          {notice && <div className="settings-notice">{notice}</div>}
          <button className="primary-btn" type="submit" disabled={busy}>{busy ? 'جارٍ الحفظ…' : 'حفظ PIN والدخول'}</button>
        </form>
      </div>
    </div>
  );
}
