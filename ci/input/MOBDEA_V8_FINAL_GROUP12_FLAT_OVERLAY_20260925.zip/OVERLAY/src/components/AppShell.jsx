import { lazy, Suspense, useEffect, useMemo, useState } from 'react';
import {
  Home, Users, CalendarDays, ClipboardCheck, GraduationCap, WalletCards,
  Gamepad2, MessageCircle, BarChart3, Settings, Menu, X, Presentation,
  IdCard, ScanLine, ListChecks, Eye, Stethoscope, ChevronLeft, Sparkles,
  ShieldCheck, Bell, BrainCircuit, MapPinned, BookOpen, DownloadCloud, LogOut, PenTool, Search, Trophy, Radio
} from 'lucide-react';
import { identity } from '../config/identity';
import { release } from '../config/release';
import { ROLE_LABELS, getRoleModules } from '../utils/auth';
import { scopeReadOnlyDataForRole } from '../services/rolePortalAccess';
const GlobalSearch = lazy(() => import('./GlobalSearch'));

const baseItems = [
  ['dashboard', 'الرئيسية', Home, 'اليوم والحصة الحالية'],
  ['mobdeaOnline', 'المبدع أونلاين', Sparkles, 'فيسبوك ويوتيوب وتيك توك — الصفحات الرسمية'],
  ['classMode', 'وضع الحصة', Presentation, 'الشرح والتفاعل والحضور'],
  ['onlineClass', 'الحصة الأونلاين', Radio, 'رابط مباشر وصوت وميكروفون'],
  ['whiteboard', 'السبورة', PenTool, 'الرسم والكتابة والشرح'],
  ['students', 'الطلاب', Users, 'البيانات والمجموعات'],
  ['studentCards', 'كروت الطلاب', IdCard, 'QR والطباعة'],
  ['sessions', 'الحصص والمجموعات', CalendarDays, 'الجدول والحصة الحالية'],
  ['attendance', 'الحضور والغياب', ClipboardCheck, 'سجل الحصص'],
  ['gradeScanner', 'رصد الدرجات بالكود', ScanLine, 'رصد سؤالًا بسؤال'],
  ['resultDetails', 'تحليل الأخطاء', ListChecks, 'الدروس والموضوعات الضعيفة'],
  ['grades', 'الدرجات والامتحانات', GraduationCap, 'النتائج والترتيب'],
  ['payments', 'الحسابات', WalletCards, 'الدفع بالحصة والمستحقات'],
  ['games', 'الألعاب التعليمية', Gamepad2, 'الجولات والتحديات'],
  ['achievements', 'الإنجازات والجوائز', Trophy, 'النقاط والمستويات والمتجر'],
  ['mapChallenge', 'تحدي الخرائط', MapPinned, 'الدول والمواقع والظاهرات'],
  ['messages', 'أولياء الأمور', MessageCircle, 'الرسائل والتنبيهات'],
  ['reports', 'التقارير', BarChart3, 'متابعة الأداء'],
  ['contentLibrary', 'الشرح والمحتوى', BookOpen, 'الدروس والملفات والخرائط'],
  ['smartAssistant', 'مساعد المُبدع', BrainCircuit, 'تحليل وتنبيهات ذكية'],
  ['updates', 'تحديث التطبيق', DownloadCloud, 'فحص وتنزيل آخر إصدار'],
  ['portalPreview', 'معاينة الصلاحيات', Eye, 'الطالب وولي الأمر'],
  ['diagnostics', 'تشخيص الجهاز', Stethoscope, 'الكاميرا والصوت والاتصال'],
  ['settings', 'الإعدادات', Settings, 'الحماية والتحكم']
];

const moduleMap = {
  grades: 'grades', payments: 'payments', games: 'games',
  messages: 'messages', reports: 'reports'
};

export default function AppShell({ active, onChange, children, settings, data, auth, onLogout }) {
  const [open, setOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const roleModules = useMemo(() => getRoleModules(auth?.role), [auth?.role]);
  const scopedShellData = useMemo(() => scopeReadOnlyDataForRole(data, auth), [data, auth]);
  const items = useMemo(() => baseItems.filter(([id]) => {
    const key = moduleMap[id];
    const moduleVisible = !key || settings?.visibleModules?.[key] !== false;
    const roleVisible = !roleModules || roleModules.has(id);
    return moduleVisible && roleVisible;
  }), [settings, roleModules]);

  useEffect(() => {
    const onKeyDown = (event) => {
      if (event.key === 'Escape') setOpen(false);
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const currentSession = scopedShellData?.sessions?.find((session) => session.current);
  const readyNotifications = (scopedShellData?.notifications || []).filter((item) => item.status === 'ready').length;

  const select = (id) => {
    // Match the router's role allowlist for sidebar, search and shortcuts.
    if (roleModules && !roleModules.has(id)) return;
    onChange(id);
    setOpen(false);
    requestAnimationFrame(() => {
      const content = document.querySelector('.app-shell-v103:not(.lesson-mode-shell) > .app-content');
      if (content?.scrollTo) content.scrollTo({ top: 0, behavior: 'auto' });
      else window.scrollTo({ top: 0, behavior: 'auto' });
    });
  };

  const roleLabel = ROLE_LABELS[auth?.role] || 'المستخدم';

  // PROJECT10_ONLINE_CLASS_V1
  if (active === 'classMode' || active === 'whiteboard') {
    return <div className="app-shell lesson-mode-shell">{children}</div>;
  }

  return (
    <div className={`app-shell app-shell-v103 ${collapsed ? 'sidebar-collapsed' : ''}`} data-layout-role={auth?.role || 'visitor'} data-layout-route={active}>
      <header className="mobile-header">
        <button className="mobile-menu-button" onClick={() => setOpen(true)} aria-label="فتح القائمة"><Menu size={23} /></button>
        <div className="mobile-brand-copy">
          <img src={identity.logo || identity.icon} alt={identity.schoolName} className="mobile-brand-avatar mobile-brand-logo" />
          <div>
            <strong>{identity.teacherName}</strong>
            <span>{currentSession ? currentSession.group : identity.teacherTitle}</span>
          </div>
        </div>
        <div className="mobile-header-actions">
          <span className="mobile-role-pill mobile-header-pill" aria-label={`الدور الحالي: ${roleLabel}`}>{roleLabel}</span>
          <button className="mobile-alert-button" onClick={() => setSearchOpen(true)} aria-label="البحث الشامل"><Search size={20} /></button>
          {auth?.role !== 'visitor' && <button
            className="mobile-alert-button"
            type="button"
            onClick={() => select(['teacher', 'admin'].includes(auth?.role) ? 'messages' : 'portalPreview')}
            aria-label="التنبيهات"
          >
            <Bell size={20} />
            {readyNotifications > 0 && <b>{readyNotifications}</b>}
          </button>}
        </div>
      </header>

      {open && <button className="drawer-overlay app-shell-backdrop" onClick={() => setOpen(false)} aria-label="إغلاق القائمة" />}

      <aside className={`sidebar sidebar-grid-area ${open ? 'open is-open' : ''} ${collapsed ? 'collapsed' : ''}`}>
        <div className="sidebar-top">
          <button
            className="sidebar-desktop-toggle"
            type="button"
            onClick={() => setCollapsed((value) => !value)}
            aria-label={collapsed ? 'توسيع القائمة الجانبية' : 'تصغير القائمة الجانبية'}
            title={collapsed ? 'توسيع القائمة' : 'تصغير القائمة'}
          ><Menu size={22} /></button>
          <button className="drawer-close" onClick={() => setOpen(false)} aria-label="إغلاق القائمة"><X size={21} /></button>
          <div className="brand-panel">
            <button className="brand-avatar brand-avatar-photo" type="button" onClick={() => select('dashboard')} aria-label="الانتقال إلى الرئيسية">
              <img src={identity.logo || identity.icon} alt={identity.schoolName} />
              <i><Sparkles size={13} /></i>
            </button>
            <div>
              <h1>المُبدع</h1>
              <p>{identity.teacherName.replace('المُبدع ', '')}</p>
              <small>{identity.teacherTitle}</small>
            </div>
          </div>

          <div className="sidebar-role-card">
            <ShieldCheck size={18} />
            <span>
              <strong>{roleLabel}</strong>
              <small>{auth?.displayName || auth?.studentId ? 'تم تسجيل الدخول بنجاح' : 'جلسة نشطة'}</small>
            </span>
          </div>

          <button className="sidebar-search-button" type="button" onClick={() => setSearchOpen(true)}>
            <Search size={17} />
            <span><strong>بحث شامل</strong><small>طالب، درس، امتحان أو تسجيل</small></span>
            <kbd>Ctrl K</kbd>
          </button>

          {['teacher', 'admin'].includes(auth?.role) && <button
            className="session-mini-card"
            type="button"
            onClick={() => select('classMode')}
          >
            <span className="session-mini-icon"><Presentation size={19} /></span>
            <span>
              <small>{currentSession ? 'الحصة الحالية' : 'لا توجد حصة حالية'}</small>
              <strong>{currentSession?.group || 'اختر حصة للبدء'}</strong>
            </span>
            <ChevronLeft size={17} />
          </button>}
        </div>

        <nav className="sidebar-nav" aria-label="القائمة الرئيسية">
          {items.map(([id, label, Icon, hint]) => (
            <button key={id} className={active === id ? 'active' : ''} onClick={() => select(id)}>
              <span className="nav-icon"><Icon size={19} /></span>
              <span className="nav-copy"><strong>{label}</strong><small>{hint}</small></span>
              <ChevronLeft className="nav-arrow" size={16} />
            </button>
          ))}
          <button className="sidebar-logout-nav" type="button" onClick={onLogout}>
            <span className="nav-icon"><LogOut size={19} /></span>
            <span className="nav-copy"><strong>تسجيل الخروج</strong><small>آخر عنصر في القائمة</small></span>
            <ChevronLeft className="nav-arrow" size={16} />
          </button>
        </nav>

        <div className="sidebar-footer">
          <div><ShieldCheck size={18} /><span><strong>الإدارة محمية</strong><small>PIN وقفل تلقائي</small></span></div>
          <b>{release.footerLabel}</b>
        </div>
      </aside>

      <main className="app-content">{children}</main>
      {searchOpen && <Suspense fallback={<div className="mobdea-search-loading" role="status">جارٍ فتح البحث…</div>}><GlobalSearch
        open={searchOpen}
        data={scopedShellData}
        auth={auth}
        onClose={() => setSearchOpen(false)}
        onNavigate={select}
      /></Suspense>}
    </div>
  );
}
