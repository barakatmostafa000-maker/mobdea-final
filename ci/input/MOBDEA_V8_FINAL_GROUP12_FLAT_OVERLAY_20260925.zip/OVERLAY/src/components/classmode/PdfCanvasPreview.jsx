import { useEffect, useRef, useState } from "react";
import * as pdfjs from "pdfjs-dist/legacy/build/pdf.mjs";
import PdfWorker from "pdfjs-dist/legacy/build/pdf.worker.min.mjs?worker";
import PanZoomSurface from "./PanZoomSurface";
import { pdfDocumentIdentity, pdfPageIdentity } from "../../services/pdfDocumentIdentity.js";

if (!pdfjs.GlobalWorkerOptions.workerPort) pdfjs.GlobalWorkerOptions.workerPort = new PdfWorker();

const pdfCache = new Map();
const pdfOpenPromises = new Map();
const pdfUseCount = new Map();
const retiredDocuments = new Set();
const rasterCache = new Map();
const rasterPromiseCache = new Map();
const MAX_PDF_CACHE = 5;
const MAX_RASTER_CACHE = 18;
const BASE_RASTER_PIXELS = 3_600_000;
const ENHANCED_RASTER_PIXELS = 7_500_000;
const BASE_RASTER_SIDE = 3200;
const ENHANCED_RASTER_SIDE = 4600;
const MAX_RENDER_DPR = 2;

function cacheKeyFor(source, resourceId = "") {
  return pdfDocumentIdentity(source, resourceId);
}

function touchLru(map, key, value) {
  if (map.has(key)) map.delete(key);
  map.set(key, value);
}

function retirePdfDocument(document) {
  if (!document) return;
  if ((pdfUseCount.get(document) || 0) > 0) {
    retiredDocuments.add(document);
    return;
  }
  retiredDocuments.delete(document);
  void Promise.resolve(document.destroy?.()).catch(() => {});
}

async function openPdf(source, resourceId) {
  const key = cacheKeyFor(source, resourceId);
  if (key && pdfCache.has(key)) {
    const cached = pdfCache.get(key);
    touchLru(pdfCache, key, cached);
    return cached;
  }
  if (key && pdfOpenPromises.has(key)) return pdfOpenPromises.get(key);
  if (!source?.blob && !source?.url) throw new Error("ملف PDF غير موجود في ذاكرة المنصة.");
  const load = (async () => {
    const input = source?.blob
      ? { data: new Uint8Array(await source.blob.arrayBuffer()), isEvalSupported: false }
      : { url: source.url, withCredentials: false, isEvalSupported: false };
    const document = await pdfjs.getDocument(input).promise;
    if (key) {
      touchLru(pdfCache, key, document);
      while (pdfCache.size > MAX_PDF_CACHE) {
        const staleKey = pdfCache.keys().next().value;
        const stale = pdfCache.get(staleKey);
        pdfCache.delete(staleKey);
        retirePdfDocument(stale);
      }
    }
    return document;
  })();
  if (key) pdfOpenPromises.set(key, load);
  try { return await load; }
  finally { if (key && pdfOpenPromises.get(key) === load) pdfOpenPromises.delete(key); }
}

function canvasBlob(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("تعذر تحويل صفحة PDF إلى صورة للعرض.")), "image/png");
  });
}

function sizeBucket(width, height) {
  const major = Math.max(Number(width || 0), Number(height || 0));
  return Math.max(480, Math.round(major / 160) * 160);
}

async function renderRaster({ source, resourceId, page, hostWidth, hostHeight, quality = 1 }) {
  const docKey = cacheKeyFor(source, resourceId);
  const bucket = sizeBucket(hostWidth, hostHeight);
  const qualityBucket = quality >= 1.8 ? 2 : quality >= 1.3 ? 1.5 : 1;
  const key = `${docKey}|p${page}|s${bucket}|q${qualityBucket}`;
  if (rasterCache.has(key)) {
    const cached = rasterCache.get(key);
    touchLru(rasterCache, key, cached);
    return cached;
  }
  if (rasterPromiseCache.has(key)) return rasterPromiseCache.get(key);

  const promise = (async () => {
    const pdfDocument = await openPdf(source, resourceId);
    pdfUseCount.set(pdfDocument, (pdfUseCount.get(pdfDocument) || 0) + 1);
    try {
    const safePage = Math.max(1, Math.min(Number(page || 1), Number(pdfDocument.numPages || 1)));
    const pdfPage = await pdfDocument.getPage(safePage);
    const base = pdfPage.getViewport({ scale: 1 });
    const fitScale = Math.max(0.15, Math.min(hostWidth / base.width, hostHeight / base.height));
    const cssWidth = Math.max(1, Math.floor(base.width * fitScale));
    const cssHeight = Math.max(1, Math.floor(base.height * fitScale));
    const deviceRatio = Math.max(1, Math.min(MAX_RENDER_DPR, Number(window.devicePixelRatio || 1)));
    const qualityMultiplier = qualityBucket === 2 ? 2.05 : qualityBucket === 1.5 ? 1.55 : 1.2;
    let renderScale = fitScale * Math.max(1.2, deviceRatio * qualityMultiplier);
    let viewport = pdfPage.getViewport({ scale: renderScale });
    const maxSide = qualityBucket > 1 ? ENHANCED_RASTER_SIDE : BASE_RASTER_SIDE;
    const maxPixels = qualityBucket > 1 ? ENHANCED_RASTER_PIXELS : BASE_RASTER_PIXELS;
    const sideLimiter = Math.min(1, maxSide / Math.max(1, viewport.width), maxSide / Math.max(1, viewport.height));
    const pixelLimiter = Math.min(1, Math.sqrt(maxPixels / Math.max(1, viewport.width * viewport.height)));
    const limiter = Math.min(sideLimiter, pixelLimiter);
    if (limiter < 1) {
      renderScale *= limiter;
      viewport = pdfPage.getViewport({ scale: renderScale });
    }
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.ceil(viewport.width));
    canvas.height = Math.max(1, Math.ceil(viewport.height));
    const context = canvas.getContext("2d", { alpha: false });
    if (!context) throw new Error("تعذر إنشاء مساحة عرض صفحة PDF.");
    context.fillStyle = "#fff";
    context.fillRect(0, 0, canvas.width, canvas.height);
    await pdfPage.render({ canvasContext: context, viewport }).promise;
    const blob = await canvasBlob(canvas);
    const result = { blob, cssWidth, cssHeight, pageCount: Number(pdfDocument.numPages || 0), page: safePage };
    touchLru(rasterCache, key, result);
    while (rasterCache.size > MAX_RASTER_CACHE) rasterCache.delete(rasterCache.keys().next().value);
    return result;
    } finally {
      const remaining = (pdfUseCount.get(pdfDocument) || 1) - 1;
      if (remaining > 0) pdfUseCount.set(pdfDocument, remaining);
      else {
        pdfUseCount.delete(pdfDocument);
        if (retiredDocuments.has(pdfDocument)) retirePdfDocument(pdfDocument);
      }
    }
  })().finally(() => rasterPromiseCache.delete(key));
  rasterPromiseCache.set(key, promise);
  return promise;
}

function idle(callback) {
  if (typeof requestIdleCallback === "function") return requestIdleCallback(callback, { timeout: 650 });
  return setTimeout(callback, 90);
}
function cancelIdle(handle) {
  if (typeof cancelIdleCallback === "function") cancelIdleCallback(handle);
  else clearTimeout(handle);
}

export default function PdfCanvasPreview({ source, page = 1, resourceId = "", title = "", onStateChange, zoom = 1, onZoomChange, onPreviousPage, onNextPage }) {
  const hostRef = useRef(null);
  const objectUrlRef = useRef("");
  const [renderedUrl, setRenderedUrl] = useState("");
  const [renderedIdentity, setRenderedIdentity] = useState("");
  const requestIdentity = pdfPageIdentity(source, resourceId, page);
  // Never show a page from another book while React waits for the next effect.
  const visibleRenderedUrl = renderedIdentity === requestIdentity ? renderedUrl : "";
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [resizeVersion, setResizeVersion] = useState(0);
  const [displaySize, setDisplaySize] = useState({ width: 0, height: 0 });
  const [qualityZoom, setQualityZoom] = useState(1);

  useEffect(() => {
    const timer = window.setTimeout(() => setQualityZoom(Math.max(1, Number(zoom || 1))), 260);
    return () => window.clearTimeout(timer);
  }, [zoom]);

  useEffect(() => () => {
    if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
    objectUrlRef.current = "";
  }, []);

  useEffect(() => {
    const host = hostRef.current;
    if (!host || typeof ResizeObserver === "undefined") return undefined;
    let frame = 0;
    const observer = new ResizeObserver(() => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => setResizeVersion((value) => value + 1));
    });
    observer.observe(host);
    return () => { cancelAnimationFrame(frame); observer.disconnect(); };
  }, []);

  useEffect(() => {
    let cancelled = false;
    let idleHandle = 0;
    const publish = async () => {
      const host = hostRef.current;
      if (!host || (!source?.blob && !source?.url)) {
        if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
        objectUrlRef.current = "";
        setRenderedUrl("");
        setRenderedIdentity("");
        const message = "ملف PDF غير متاح داخل مكتبة الدرس.";
        setError(message);
        onStateChange?.({ dataUrl: "", pageCount: 0, loading: false, error: message });
        return;
      }
      const hostWidth = Math.floor(host.clientWidth || host.getBoundingClientRect().width || 0);
      const hostHeight = Math.floor(host.clientHeight || host.getBoundingClientRect().height || 0);
      if (hostWidth < 80 || hostHeight < 80) return;

      setLoading(!visibleRenderedUrl);
      setError("");
      try {
        const result = await renderRaster({ source, resourceId, page, hostWidth, hostHeight, quality: Math.min(2, Math.sqrt(Math.max(1, qualityZoom))) });
        if (cancelled) return;
        const nextUrl = URL.createObjectURL(result.blob);
        if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
        objectUrlRef.current = nextUrl;
        setRenderedUrl(nextUrl);
        setRenderedIdentity(requestIdentity);
        setDisplaySize({ width: result.cssWidth, height: result.cssHeight });
        setLoading(false);
        onStateChange?.({ dataUrl: nextUrl, pageCount: result.pageCount, loading: false, error: "" });

        // Warm the adjacent pages while the teacher is reading the current one.
        idleHandle = idle(() => {
          if (cancelled) return;
          [result.page + 1, result.page - 1]
            .filter((target) => target >= 1 && target <= result.pageCount)
            .forEach((target) => void renderRaster({ source, resourceId, page: target, hostWidth, hostHeight, quality: 1 }).catch(() => {}));
        });
      } catch (reason) {
        if (cancelled) return;
        const message = reason?.message || "تعذر عرض صفحة PDF.";
        setLoading(false);
        setError(message);
        onStateChange?.({ dataUrl: visibleRenderedUrl, pageCount: 0, loading: false, error: message });
      }
    };
    void publish();
    return () => { cancelled = true; if (idleHandle) cancelIdle(idleHandle); };
  }, [source?.blob, source?.url, page, resourceId, resizeVersion, qualityZoom, onStateChange]);

  return (
    <div ref={hostRef} className="classmode-pdf-canvas-host" role="img" aria-label={`${title || "ملف PDF"} — صفحة ${page || 1}`}>
      {visibleRenderedUrl && (
        <PanZoomSurface
          zoom={zoom}
          onZoomChange={onZoomChange}
          maxZoom={6}
          resetKey={`${resourceId}:${page}`}
          className="classmode-pdf-panzoom"
          ariaLabel="صفحة PDF — قرّب حول موضع إصبعيك واسحب في كل الاتجاهات"
          onSwipeLeft={onNextPage}
          onSwipeRight={onPreviousPage}
        >
          <img className="classmode-pdf-rendered-image" src={visibleRenderedUrl} alt={`${title || "ملف PDF"} — صفحة ${page || 1}`} style={displaySize.width && displaySize.height ? { width: `${displaySize.width}px`, height: `${displaySize.height}px` } : undefined} />
        </PanZoomSurface>
      )}
      {loading && <div className="classmode-pdf-render-status">جارٍ تجهيز صفحة {page || 1}…</div>}
      {error && <div className="classmode-pdf-render-error"><strong>تعذر رسم صفحة PDF داخل مساحة الشرح</strong><small>{error}</small></div>}
    </div>
  );
}
