import { useEffect, useMemo, useRef, useState } from 'react';
import { readResourceState, removeResourceState, writeResourceState } from '../../services/v8ResourceState';

const panStateMemory = new Map();
const MAX_PAN_MEMORY = 48;

function rememberPan(key, value) {
  const memoryKey = String(key || 'default');
  if (panStateMemory.has(memoryKey)) panStateMemory.delete(memoryKey);
  panStateMemory.set(memoryKey, value);
  while (panStateMemory.size > MAX_PAN_MEMORY) {
    panStateMemory.delete(panStateMemory.keys().next().value);
  }
  writeResourceState('pan', memoryKey, value);
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function centroid(points = []) {
  if (!points.length) return { x: 0, y: 0 };
  return {
    x: points.reduce((sum, point) => sum + point.x, 0) / points.length,
    y: points.reduce((sum, point) => sum + point.y, 0) / points.length,
  };
}

export default function PanZoomSurface({
  zoom = 1,
  onZoomChange,
  onSwipeLeft,
  onSwipeRight,
  minZoom = 1,
  maxZoom = 4,
  className = '',
  children,
  ariaLabel = 'مساحة قابلة للتكبير والتحريك',
  resetKey = '',
}) {
  const hostRef = useRef(null);
  const contentRef = useRef(null);
  const pointersRef = useRef(new Map());
  const gestureRef = useRef(null);
  const swipeRef = useRef(null);
  const panRef = useRef({ x: 0, y: 0 });
  const [pan, setPanState] = useState({ x: 0, y: 0 });
  const [metrics, setMetrics] = useState({ hostWidth: 0, hostHeight: 0, contentWidth: 0, contentHeight: 0 });
  const safeZoom = clamp(Number(zoom || 1), minZoom, maxZoom);

  const setPan = (next, { remember = true } = {}) => {
    panRef.current = next;
    setPanState(next);
    if (remember) rememberPan(resetKey, next);
  };

  const measure = () => {
    const host = hostRef.current;
    const content = contentRef.current;
    if (!host || !content) return;
    const child = content.firstElementChild;
    const hostRect = host.getBoundingClientRect();
    const childWidth = Number(child?.offsetWidth || child?.clientWidth || hostRect.width || 0);
    const childHeight = Number(child?.offsetHeight || child?.clientHeight || hostRect.height || 0);
    setMetrics((current) => {
      const next = {
        hostWidth: Math.max(1, hostRect.width || 1),
        hostHeight: Math.max(1, hostRect.height || 1),
        contentWidth: Math.max(1, childWidth || hostRect.width || 1),
        contentHeight: Math.max(1, childHeight || hostRect.height || 1),
      };
      return Object.keys(next).every((key) => Math.abs(next[key] - current[key]) < 1) ? current : next;
    });
  };

  useEffect(() => {
    measure();
    const host = hostRef.current;
    const content = contentRef.current;
    if (!host || !content || typeof ResizeObserver === 'undefined') return undefined;
    const observer = new ResizeObserver(measure);
    observer.observe(host);
    observer.observe(content);
    if (content.firstElementChild) observer.observe(content.firstElementChild);
    const mutation = typeof MutationObserver !== 'undefined' ? new MutationObserver(() => {
      measure();
      if (content.firstElementChild) observer.observe(content.firstElementChild);
    }) : null;
    mutation?.observe(content, { childList: true, subtree: false });
    window.addEventListener('orientationchange', measure);
    window.addEventListener('resize', measure);
    return () => {
      observer.disconnect();
      mutation?.disconnect();
      window.removeEventListener('orientationchange', measure);
      window.removeEventListener('resize', measure);
    };
  }, []);

  const limitsForZoom = (targetZoom) => {
    const scaledWidth = metrics.contentWidth * targetZoom;
    const scaledHeight = metrics.contentHeight * targetZoom;
    // Keep every edge reachable. A small margin lets the teacher inspect the very
    // first/last line without the page snapping back toward its centre.
    return {
      x: Math.max(0, (scaledWidth - metrics.hostWidth) / 2) + 14,
      y: Math.max(0, (scaledHeight - metrics.hostHeight) / 2) + 18,
    };
  };

  const panLimits = useMemo(
    () => limitsForZoom(safeZoom),
    [metrics.contentHeight, metrics.contentWidth, metrics.hostHeight, metrics.hostWidth, safeZoom],
  );
  const canPan = safeZoom > minZoom + 0.015 && (panLimits.x > 1 || panLimits.y > 1);

  useEffect(() => {
    const current = panRef.current;
    const next = {
      x: clamp(current.x, -panLimits.x, panLimits.x),
      y: clamp(current.y, -panLimits.y, panLimits.y),
    };
    if (Math.abs(next.x - current.x) > 0.5 || Math.abs(next.y - current.y) > 0.5) setPan(next);
  }, [panLimits.x, panLimits.y]);

  useEffect(() => {
    const memoryKey = String(resetKey || 'default');
    const remembered = panStateMemory.get(memoryKey)
      || readResourceState('pan', memoryKey, null);
    if (remembered) rememberPan(memoryKey, remembered);
    setPan(remembered || { x: 0, y: 0 }, { remember: false });
    const frame = requestAnimationFrame(measure);
    return () => cancelAnimationFrame(frame);
    // Zoom is owned by the parent per resource; changing media must not force it back to 100%.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resetKey]);

  const pointerDistance = () => {
    const points = [...pointersRef.current.values()];
    if (points.length < 2) return 0;
    return Math.hypot(points[0].x - points[1].x, points[0].y - points[1].y);
  };

  const beginPinch = () => {
    const points = [...pointersRef.current.values()].slice(0, 2);
    const center = centroid(points);
    const hostRect = hostRef.current?.getBoundingClientRect();
    const hostCenter = {
      x: Number(hostRect?.left || 0) + Number(hostRect?.width || metrics.hostWidth) / 2,
      y: Number(hostRect?.top || 0) + Number(hostRect?.height || metrics.hostHeight) / 2,
    };
    const currentPan = panRef.current;
    const screenVector = { x: center.x - hostCenter.x, y: center.y - hostCenter.y };
    gestureRef.current = {
      kind: 'pinch',
      distance: Math.max(1, pointerDistance()),
      zoom: safeZoom,
      hostCenter,
      localX: (screenVector.x - currentPan.x) / Math.max(0.01, safeZoom),
      localY: (screenVector.y - currentPan.y) / Math.max(0.01, safeZoom),
    };
  };

  const handlePointerDown = (event) => {
    measure();
    event.currentTarget.setPointerCapture?.(event.pointerId);
    pointersRef.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (pointersRef.current.size === 1 && safeZoom <= minZoom + 0.02 && event.pointerType !== 'mouse') {
      swipeRef.current = { pointerId: event.pointerId, x: event.clientX, y: event.clientY, at: Number(event.timeStamp || performance.now()) };
    }
    if (pointersRef.current.size >= 2) {
      swipeRef.current = null;
      beginPinch();
      return;
    }
    if (canPan) {
      const currentPan = panRef.current;
      gestureRef.current = { kind: 'pan', x: event.clientX, y: event.clientY, panX: currentPan.x, panY: currentPan.y };
    }
  };

  const handlePointerMove = (event) => {
    if (!pointersRef.current.has(event.pointerId)) return;
    pointersRef.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
    const gesture = gestureRef.current;
    if (!gesture) return;

    if (pointersRef.current.size >= 2) {
      event.preventDefault();
      if (gesture.kind !== 'pinch') {
        beginPinch();
        return;
      }
      const points = [...pointersRef.current.values()].slice(0, 2);
      const center = centroid(points);
      const distance = pointerDistance();
      const nextZoom = clamp(gesture.zoom * (distance / Math.max(1, gesture.distance)), minZoom, maxZoom);
      const screenVector = { x: center.x - gesture.hostCenter.x, y: center.y - gesture.hostCenter.y };
      const nextLimits = limitsForZoom(nextZoom);
      const nextPan = {
        x: clamp(screenVector.x - nextZoom * gesture.localX, -nextLimits.x, nextLimits.x),
        y: clamp(screenVector.y - nextZoom * gesture.localY, -nextLimits.y, nextLimits.y),
      };
      setPan(nextPan);
      onZoomChange?.(Number(nextZoom.toFixed(3)));
      return;
    }

    if (gesture.kind === 'pan' && canPan) {
      event.preventDefault();
      const next = {
        x: clamp(gesture.panX + event.clientX - gesture.x, -panLimits.x, panLimits.x),
        y: clamp(gesture.panY + event.clientY - gesture.y, -panLimits.y, panLimits.y),
      };
      setPan(next);
    }
  };

  const finishPointer = (event) => {
    const swipe = swipeRef.current;
    if (event.type === 'pointerup' && swipe && swipe.pointerId === event.pointerId && safeZoom <= minZoom + 0.02) {
      const dx = Number(event.clientX) - swipe.x;
      const dy = Number(event.clientY) - swipe.y;
      const elapsed = Number(event.timeStamp || performance.now()) - swipe.at;
      if (elapsed <= 900 && Math.abs(dx) >= 64 && Math.abs(dx) > Math.abs(dy) * 1.25) {
        if (dx < 0) onSwipeLeft?.();
        else onSwipeRight?.();
      }
    }

    pointersRef.current.delete(event.pointerId);
    if (pointersRef.current.size >= 2) {
      beginPinch();
    } else if (pointersRef.current.size === 1 && canPan) {
      const point = [...pointersRef.current.values()][0];
      const currentPan = panRef.current;
      gestureRef.current = { kind: 'pan', x: point.x, y: point.y, panX: currentPan.x, panY: currentPan.y };
    } else {
      gestureRef.current = null;
      swipeRef.current = null;
    }
  };

  const reset = () => {
    const memoryKey = String(resetKey || 'default');
    panStateMemory.delete(memoryKey);
    removeResourceState('pan', memoryKey);
    setPan({ x: 0, y: 0 }, { remember: false });
    onZoomChange?.(minZoom);
  };

  return (
    <div
      ref={hostRef}
      className={`classmode-panzoom-viewport ${className}`}
      role="application"
      aria-label={ariaLabel}
      data-zoom={safeZoom.toFixed(2)}
      data-can-pan={canPan ? 'true' : 'false'}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={finishPointer}
      onPointerCancel={finishPointer}
      onDoubleClick={reset}
    >
      <div ref={contentRef} className="classmode-panzoom-content" style={{ transform: `translate3d(${pan.x}px, ${pan.y}px, 0) scale(${safeZoom})` }}>
        {children}
      </div>
    </div>
  );
}
