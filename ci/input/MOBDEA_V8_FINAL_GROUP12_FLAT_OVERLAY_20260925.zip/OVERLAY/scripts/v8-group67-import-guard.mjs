/** Resolve local imports for group 6/7 touched code, independent of npm packages. */
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const paths = [
  'src/components/questions/Project08ExamOcrImport.jsx',
  'src/pages/QuestionBankManager.jsx',
  'src/services/ocrReviewWorkflow.js',
  'src/services/browserExamOcr.js',
  'src/services/webPdfRenderer.js',
  'src/services/assessment.js',
];
const missing = [];
let checked = 0;
for (const relative of paths) {
  const full = path.resolve(root, relative);
  if (!fs.existsSync(full)) { missing.push(relative); continue; }
  const source = fs.readFileSync(full, 'utf8');
  for (const [, specifier] of source.matchAll(/(?:\bfrom\s*|\bimport\s*\(\s*|\bimport\s*)["'](\.[^"']+)["']/g)) {
    const clean = specifier.split('?')[0];
    const target = path.resolve(path.dirname(full), clean);
    const options = [target, ...['.js', '.jsx', '.mjs', '.json', '.css'].map((ext) => target + ext), path.join(target, 'index.js'), path.join(target, 'index.jsx')];
    checked++;
    if (!options.some((candidate) => fs.existsSync(candidate) && fs.statSync(candidate).isFile())) {
      missing.push(relative + ' -> ' + specifier);
    }
  }
}
if (missing.length) {
  process.stderr.write('Group6/7 relative imports unresolved:\n' + missing.join('\n') + '\n');
  process.exitCode = 1;
} else process.stdout.write(`Group6/7 local relative import paths PASS (${checked} imports).\n`);
