#!/usr/bin/env python3
"""Verify actual SQLite UPSERT/RETURNING semantics used by the D1 trial gate."""
import re,sqlite3
from pathlib import Path
root=Path(__file__).resolve().parent.parent
source=(root/'cloud-worker/visitorTrialEdge.js').read_text(encoding='utf8')
migration=(root/'cloud-worker/migrations/0001_visitor_trials.sql').read_text(encoding='utf8')
match=re.search(r'env\.MOBDEA_TRIAL_DB\.prepare\(`\s*(INSERT INTO mobdea_guest_trials.*?)`\)\.bind\(',source,re.S)
if not match:raise SystemExit('FAIL: atomic SQL missing from edge source')
con=sqlite3.connect(':memory:')
con.executescript(migration)
sql=match.group(1)
for index in range(5):
 row=con.execute(sql,('class_1','opaque-hashed-visitor','games',5)).fetchone()
 assert row==(index+1,), (index,row)
assert con.execute(sql,('class_1','opaque-hashed-visitor','games',5)).fetchone() is None
assert con.execute(sql,('class_1','opaque-hashed-visitor','maps',5)).fetchone()==(1,)
assert con.execute(sql,('class_2','opaque-hashed-visitor','games',5)).fetchone()==(1,)
assert con.execute('select count(*) from mobdea_guest_trials').fetchone()==(3,)
print('Group9 SQLite D1-equivalent atomic quota: PASS (cap 5, 6th blocked; kind/workspace separated)')
