/* Phase-one browser startup watchdog: no React, data or credentials are read. */
(function () {
  "use strict";
  if (typeof document === "undefined" || typeof window === "undefined") return;
  var loaded = false;
  var displayed = false;
  var deadline = 18000;
  var timer = 0;
  function markReady() {
    loaded = true;
    clearTimeout(timer);
    var alert = document.getElementById("mobdea-entry-recovery");
    if (alert) alert.remove();
  }
  function present(message) {
    if (loaded || displayed || !document.body) return;
    if (document.getElementById("root")?.querySelector(".runtime-error-screen,.fatal-screen")) return;
    displayed = true;
    var box = document.createElement("section");
    box.id = "mobdea-entry-recovery";
    box.setAttribute("role", "alert");
    box.setAttribute("dir", "rtl");
    box.style.cssText = "position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;padding:18px;background:#0b1019;color:#f7e3ae;font:18px system-ui;text-align:center";
    var content = document.createElement("div");
    content.style.cssText = "max-width:580px;line-height:1.75";
    var title = document.createElement("h1");
    title.textContent = "تعذر بدء واجهة المبدع";
    var detail = document.createElement("p");
    detail.textContent = message;
    var retry = document.createElement("button");
    retry.type = "button";
    retry.textContent = "إعادة محاولة التحميل";
    retry.style.cssText = "padding:12px 20px;border:0;border-radius:12px;cursor:pointer;font:inherit";
    retry.addEventListener("click", function () { window.location.reload(); });
    var note = document.createElement("p");
    note.textContent = "لن يحذف هذا الزر بيانات الطلاب. إذا استمرت المشكلة افتح تقرير تشغيل Vite.";
    note.style.fontSize = "14px";
    content.append(title, detail, retry, note);
    box.append(content);
    document.body.append(box);
  }
  window.addEventListener("mobdea:app-mounted", markReady, { once: true });
  window.addEventListener("error", function (event) {
    if (loaded) return;
    var target = event.target;
    if (target && (target.tagName === "SCRIPT" || target.tagName === "LINK")) {
      present("لم يتم تحميل أحد ملفات تشغيل المنصة. تأكد من أن Vite يعمل على المنفذ 5173، ثم حدّث الصفحة.");
    }
  }, true);
  function start() {
    timer = setTimeout(function () {
      if (!loaded) present("لم تكتمل تهيئة JavaScript. قد يكون السيرفر متوقفًا أو ملف بدء التطبيق غير متاح.");
    }, deadline);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start, { once: true });
  else start();
})();
