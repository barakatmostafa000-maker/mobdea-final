/* Group 11: server-authorized student/guardian portal. Keeps the teacher-only
 * legacy worker unchanged; all student reads derive from a *server-bound*
 * principal and the authoritative encrypted workspace snapshot. */
const ENCODER = new TextEncoder();
const DECODER = new TextDecoder();
const WS = /^[a-zA-Z0-9_-]{3,80}$/;
const ID = /^[a-zA-Z0-9._-]{1,100}$/;
const SESSION_SECONDS = 7 * 24 * 60 * 60;
const PIN_ITERATIONS = 150_000;
const PORTAL_FIELDS = ['attendance','grades','detailedResults','payments','notifications','achievements'];
const text = (value, max = 100) => String(value ?? '').trim().slice(0, max);
const bytesHex = (bytes) => Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
const bytes64 = (bytes) => btoa(String.fromCharCode(...bytes));
const from64 = (value) => Uint8Array.from(atob(value), (char) => char.charCodeAt(0));
const digest = async (value) => bytesHex(new Uint8Array(await crypto.subtle.digest('SHA-256', ENCODER.encode(value))));
const random = () => bytes64(crypto.getRandomValues(new Uint8Array(32))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/g,'');
const validWorkspace = (request) => WS.test(text(request.headers.get('X-Mobdea-Workspace'), 100))
  ? text(request.headers.get('X-Mobdea-Workspace'), 100) : '';
function reply(request, env, body, status = 200, headers = {}) {
  const origin = request.headers.get('Origin');
  const origins = String(env.MOBDEA_ALLOWED_ORIGINS || '').split(',').map(x => x.trim());
  return new Response(JSON.stringify(body), {status, headers:{
    'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',
    'X-Content-Type-Options':'nosniff','Vary':'Origin',
    ...(origin && origins.includes(origin) ? {'Access-Control-Allow-Origin':origin} : {}), ...headers,
  }});
}
async function secureKey(env) {
  const secret = String(env.MOBDEA_ENCRYPTION_KEY || '');
  if (secret.length < 32) throw new Error('missing_encryption_key');
  return crypto.subtle.importKey('raw', await crypto.subtle.digest('SHA-256',ENCODER.encode(secret)),
    {name:'AES-GCM'}, false, ['encrypt','decrypt']);
}
async function decodeEncrypted(raw, env, aad) {
  if (!raw) return null;
  const envelope = JSON.parse(raw);
  if (envelope.version !== 1 || !envelope.iv || !envelope.ciphertext) throw new Error('invalid_envelope');
  const plain = await crypto.subtle.decrypt({name:'AES-GCM',iv:from64(envelope.iv),
    additionalData:ENCODER.encode(aad),tagLength:128},await secureKey(env),from64(envelope.ciphertext));
  return JSON.parse(DECODER.decode(plain));
}
async function encodeEncrypted(value, env, aad) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:ENCODER.encode(aad),tagLength:128},
    await secureKey(env),ENCODER.encode(JSON.stringify(value)));
  return JSON.stringify({version:1,iv:bytes64(iv),ciphertext:bytes64(new Uint8Array(cipher))});
}
async function readPrivate(env,key) {return decodeEncrypted(await env.MOBDEA_DATA.get(key),env,key);}
async function writePrivate(env,key,value,options) {
  return env.MOBDEA_DATA.put(key,await encodeEncrypted(value,env,key),options);
}
async function loadSnapshot(env,workspace) {
  const raw = await env.MOBDEA_DATA.get(`workspace:${workspace}`);
  const envelope=await decodeEncrypted(raw,env,`sync:${workspace}`);
  if(!envelope?.data)return null;
  return {...envelope.data,assetManifest:envelope.assetManifest||envelope.data.assetManifest||[]};
}
async function teacherAuthorized(request,env,legacyWorker,context) {
  const check = new Request(new URL('/health',request.url),{method:'GET',headers:request.headers});
  const status = await legacyWorker.fetch(check,env,context);
  return status.status === 200 && (await status.json().catch(() => null))?.ok === true;
}
function studentPublic(student) {
  if (!student) return null;
  const fields = ['id','code','name','grade','group','className','image','avatar','status'];
  return Object.fromEntries(fields.filter(key => student[key] !== undefined).map(key => [key,student[key]]));
}
function roleStudents(data,principal) {
  const byId = new Map((data?.students || []).map(student=>[String(student.id),student]));
  return principal.studentIds.map(id=>byId.get(String(id))).filter(Boolean);
}
const entries = (value) => Array.isArray(value) ? value.map(x => String(x ?? '').trim()).filter(Boolean)
  : String(value ?? '').split(/[,،\n]/).map(x=>x.trim()).filter(Boolean);
function resourceAccess(resource,students,role, publicOnly = false) {
  if (!resource || resource.published === false || resource.archived === true) return false;
  const acl = resource.access && typeof resource.access === 'object' ? resource.access : {};
  const mode = text(acl.mode || resource.accessMode || (resource.isPublic === true || resource.publicVisible === true ? 'public' : 'private'),30);
  if (mode === 'public') return true;
  if (publicOnly || !['student','guardian'].includes(role)) return false;
  if (mode === 'allStudents') return students.length > 0;
  const grade = String(acl.grade || resource.grade || '');
  if (mode === 'grade') return !!grade && students.some(s=>String(s.grade || '') === grade);
  if (mode === 'group') {
    const groups = entries(acl.groups || resource.accessGroups || resource.groups);
    return groups.length > 0 && students.some(s=>(!grade || String(s.grade || '') === grade) && groups.includes(String(s.group || '')));
  }
  if (mode === 'students') {
    const ids = entries(acl.studentIds || resource.accessStudentIds || resource.studentIds);
    return ids.length > 0 && students.some(s=>ids.includes(String(s.id)) || (s.code != null && ids.includes(String(s.code))));
  }
  return false;
}
function allowedResources(data,principal) {
  const students = roleStudents(data,principal);
  const all = Array.isArray(data.contentLibrary) ? data.contentLibrary : [];
  const permittedLessons = new Set(all.filter(item=>item?.type==='lesson' && resourceAccess(item,students,principal.role))
    .map(item=>String(item.id)));
  return all.filter(item => {
    if (resourceAccess(item,students,principal.role)) return true;
    if (item?.published === false || item?.archived === true || item?.inheritLessonAccess !== true) return false;
    if (!['image','video','audio','ppt','pptx','pdf-page','lesson-attachment'].includes(String(item.type || '').toLowerCase())) return false;
    return permittedLessons.has(String(item.lessonId || item.parentLessonId || ''));
  });
}
function matchingAsset(resource,assetId) {
  const ids = [resource.assetId,resource.fileId,resource.asset?.id,resource.thumbnailAssetId,
    ...(Array.isArray(resource.assetIds) ? resource.assetIds : [])].map(String);
  // Legacy content sometimes uses the asset itself as its resource ID.
  if (resource.isAsset === true || resource.type === 'asset') ids.push(String(resource.id || ''));
  return ids.includes(assetId);
}
function sessionSettings(request,workspace,principal,token) {
  const endpoint=new URL(request.url).origin;
  const studentId=principal.role==='student'?principal.studentIds[0]:null;
  return {cloudSync:{endpoint,workspaceId:workspace,token:'',autoSync:false},
    studentPortalSession:{endpoint,workspaceId:workspace,studentToken:token,
      studentId,studentCode:principal.role==='student'?principal.accountId:'',lastPullAt:new Date().toISOString()}};
}
function projectedSessionData(data,principal,request,workspace,token) {
  return {...projection(data,principal),settings:sessionSettings(request,workspace,principal,token)};
}
function projection(data,principal) {
  const students = roleStudents(data,principal);
  const ids = new Set(students.map(s=>String(s.id)));
  // Never leak teacher notes, answer keys, secret links or nested private
  // attachments through a public/guardian/student resource's metadata.
  const resourceFields=['id','type','kind','title','name','description','grade','group','lessonId',
    'parentLessonId','unit','chapter','fileId','assetId','assetIds','thumbnailAssetId',
    'fileName','mimeType','size','duration','published','archived','access','accessMode',
    'publicVisible','isPublic','inheritLessonAccess','cover','category','tags','order'];
  const filtered = {students:students.map(studentPublic),contentLibrary:allowedResources(data,principal)
    .map(item=>({ ...Object.fromEntries(resourceFields.filter(key=>key!=='access' && key!== 'accessMode' && item[key]!==undefined).map(key=>[key,item[key]])),
      access:{mode:'students',studentIds:students.map(student=>String(student.id))}}))};
  for (const key of PORTAL_FIELDS) filtered[key] = (Array.isArray(data[key]) ? data[key] : [])
    .filter(row=>row && ids.has(String(row.studentId ?? '')));
  // Group schedules are shared by a class; remove any embedded private fields.
  filtered.sessions = (Array.isArray(data.sessions) ? data.sessions : []).filter(row=>
    students.some(student=>String(row.grade || '') === String(student.grade || '') &&
      String(row.group || '') === String(student.group || '') && !!String(row.group || '')))
    .map(row=>Object.fromEntries(['id','grade','group','date','time','topic','title','status']
      .filter(key=>row[key] !== undefined).map(key=>[key,row[key]])));
  const allowedAssets = new Set(filtered.contentLibrary.flatMap(item=>[
    item.assetId,item.fileId,item.asset?.id,item.thumbnailAssetId,...(Array.isArray(item.assetIds)?item.assetIds:[]),
    ...((item.isAsset === true || item.type === 'asset') ? [item.id] : []),
  ]).filter(Boolean).map(String));
  const safeAssetFields=['id','sha256','size','mimeType','type','name','kind'];
  filtered.assetManifest=(Array.isArray(data.assetManifest)?data.assetManifest:[])
    .filter(item=>item && allowedAssets.has(String(item.id)))
    .map(item=>Object.fromEntries(safeAssetFields.filter(key=>item[key]!==undefined)
      .map(key=>[key,item[key]])));
  return filtered;
}
function safeBody(request,limit=24_000) {return request.text().then(t=>{
  if (ENCODER.encode(t).length > limit) throw new Error('payload_too_large');
  return JSON.parse(t);
});}
async function pinHash(pin,salt) {
  const base=await crypto.subtle.importKey('raw',ENCODER.encode(pin),'PBKDF2',false,['deriveBits']);
  return bytesHex(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt:from64(salt),
    iterations:PIN_ITERATIONS,hash:'SHA-256'},base,256)));
}
function equals(a,b) {if(a.length!==b.length)return false;let d=0;for(let i=0;i<a.length;i++)d|=a.charCodeAt(i)^b.charCodeAt(i);return d===0;}
async function loginLimit(request,env,ws,accountId) {
  if (!env.MOBDEA_TRIAL_DB?.prepare) return false;
  const ip=request.headers.get('CF-Connecting-IP') || 'unverified';
  const id=await digest(`${ws}\u0000${accountId}\u0000${ip}`);
  const window=Math.floor(Date.now()/900_000);
  const row=await env.MOBDEA_TRIAL_DB.prepare(`INSERT INTO mobdea_portal_login_attempts (scope,window_id,attempts)
    VALUES(?1,?2,1) ON CONFLICT(scope,window_id) DO UPDATE SET attempts=attempts+1 RETURNING attempts`)
    .bind(id,window).first();
  return Number(row?.attempts || 999) <= 6;
}
const accountKey=(ws,role,id)=>`portal-account:${ws}:${role}:${id}`;
const sessionKey=async(ws,token)=>`portal-session:${ws}:${await digest(token)}`;
async function authenticated(request,env,ws,role='') {
  const token=text(request.headers.get('X-Mobdea-Student-Token')||request.headers.get('X-Mobdea-Role-Token'),260);
  if(!token || !ws)return null;
  const principal=await readPrivate(env,await sessionKey(ws,token));
  if(!principal || principal.expiresAt<=Date.now() || (role && principal.role!==role))return null;
  const account=await readPrivate(env,accountKey(ws,principal.role,principal.accountId));
  if(!account || account.revision!==principal.revision || account.active!==true)return null;
  return principal;
}
async function createAccount(request,env,ws) {
  const data=await loadSnapshot(env,ws);
  if(!data)return reply(request,env,{error:'workspace_not_ready'},409);
  const body=await safeBody(request);
  const role=text(body.role,20);
  const id=text(body.accountId || body.code,80);
  const pin=text(body.pin,32);
  const studentIds=[...new Set(entries(body.studentIds || [body.studentId]))];
  const registered=new Set((data.students || []).map(student=>String(student.id)));
  if(!['student','guardian'].includes(role)||!ID.test(id)||!/^\d{8,16}$/.test(pin)||
    !studentIds.length || (role==='student'&&studentIds.length!==1) ||
    studentIds.some(studentId=>!registered.has(studentId)))return reply(request,env,{error:'invalid_account'},400);
  if(role==='student') {
    const student=(data.students || []).find(item=>String(item.id)===studentIds[0]);
    if(String(student?.code ?? '') !== id)return reply(request,env,{error:'student_code_mismatch'},400);
    if((data.students||[]).filter(item=>String(item.code ?? '')===id).length!==1)
      return reply(request,env,{error:'ambiguous_student_code'},409);
  }
  const salt=bytes64(crypto.getRandomValues(new Uint8Array(16)));
  const account={role,accountId:id,studentIds,salt,pinHash:await pinHash(pin,salt),
    revision:random(),active:body.active!==false,mustChangePin:role==='student'&&pin==='12345678',updatedAt:new Date().toISOString()};
  await writePrivate(env,accountKey(ws,role,id),account);
  return reply(request,env,{ok:true,role,accountId:id,studentIds},201);
}
async function login(request,env,ws,role) {
  if(!env.MOBDEA_TRIAL_DB?.prepare)return reply(request,env,{error:'login_database_unavailable'},503);
  const body=await safeBody(request,5000);
  const id=text(body.code || body.studentCode || body.accountId,80);
  const pin=text(body.pin,32);
  if(!ID.test(id)||!/^\d{8,16}$/.test(pin))return reply(request,env,{error:'invalid_credentials'},401);
  if(!(await loginLimit(request,env,ws,`${role}:${id}`)))return reply(request,env,{error:'rate_limited'},429);
  const account=await readPrivate(env,accountKey(ws,role,id));
  // Constant-work on nonexistent accounts; never match a user-supplied phone to children.
  const salt=account?.salt || bytes64(new Uint8Array(16));
  const expected=account?.pinHash || '0'.repeat(64);
  const actual=await pinHash(pin,salt);
  if(!account || !account.active || !equals(expected,actual))return reply(request,env,{error:'invalid_credentials'},401);
  const data=await loadSnapshot(env,ws);
  if(!data)return reply(request,env,{error:'workspace_not_ready'},503);
  const students=roleStudents(data,account);
  if(students.length!==account.studentIds.length || (role==='student' && String(students[0]?.code ?? '')!==id))
    return reply(request,env,{error:'student_not_active'},403);
  const token=random();
  const expiresAt=Date.now()+SESSION_SECONDS*1000;
  await writePrivate(env,await sessionKey(ws,token),{role,accountId:id,studentIds:account.studentIds,
    revision:account.revision,expiresAt},{expirationTtl:SESSION_SECONDS});
  const snapshot=projectedSessionData(data,account,request,ws,token);
  // An initial shared PIN authenticates only the PIN rotation, NOT a normal
  // student session. Never deliver private data before the change succeeds.
  const initialData=role==='student' && account.mustChangePin===true
    ? {students:students.map(studentPublic),settings:snapshot.settings,contentLibrary:[],assetManifest:[]}
    : snapshot;
  return reply(request,env,{ok:true,role,student:role==='student'?studentPublic(students[0]):undefined,
    students:students.map(studentPublic),studentToken:token,roleToken:token,
    expiresAt:new Date(expiresAt).toISOString(),mustChangePin:account.mustChangePin===true,data:initialData},200);
}
async function downloadAsset(request,env,ws,principal,assetId) {
  if(!ID.test(assetId))return reply(request,env,{error:'not_found'},404);
  const data=await loadSnapshot(env,ws);
  if(!data)return reply(request,env,{error:'workspace_not_ready'},503);
  if(!allowedResources(data,principal).some(resource=>matchingAsset(resource,assetId)))
    return reply(request,env,{error:'not_found'},404);
  if(!env.MOBDEA_ASSETS?.get)return reply(request,env,{error:'asset_storage_unavailable'},503);
  const object=await env.MOBDEA_ASSETS.get(`workspace/${ws}/${assetId}`);
  if(!object)return reply(request,env,{error:'not_found'},404);
  const meta=object.customMetadata || {};
  if(!meta.iv || !/^[a-f0-9]{64}$/.test(String(meta.sha256||'')) || !(Number(meta.size)>0))
    return reply(request,env,{error:'invalid_asset_metadata'},503);
  const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:from64(meta.iv),
    additionalData:ENCODER.encode(`asset:${ws}:${assetId}`),tagLength:128},
    await secureKey(env),await object.arrayBuffer());
  if(plain.byteLength!==Number(meta.size) || await digestBuffer(plain)!==meta.sha256)
    return reply(request,env,{error:'asset_integrity_error'},503);
  const headers={'Cache-Control':'private, no-store','Content-Type':meta.type||'application/octet-stream',
    'X-Mobdea-Asset-Sha256':meta.sha256,'X-Mobdea-Asset-Size':String(plain.byteLength),
    'X-Mobdea-Asset-Name':encodeURIComponent(meta.name||'file'),
    'X-Mobdea-Asset-Kind':encodeURIComponent(meta.kind||'resource'),
    'Content-Disposition':`inline; filename*=UTF-8''${encodeURIComponent(meta.name||'file')}`,
    'X-Content-Type-Options':'nosniff','Vary':'Origin'};
  const origin=request.headers.get('Origin');
  if(String(env.MOBDEA_ALLOWED_ORIGINS||'').split(',').map(x=>x.trim()).includes(origin)){
    headers['Access-Control-Allow-Origin']=origin;
    headers['Access-Control-Expose-Headers']='X-Mobdea-Asset-Sha256,X-Mobdea-Asset-Size,X-Mobdea-Asset-Name,X-Mobdea-Asset-Kind';
  }
  return new Response(plain,{status:200,headers});
}
async function digestBuffer(buffer){return bytesHex(new Uint8Array(await crypto.subtle.digest('SHA-256',buffer)));}
export async function portalRoute(request,env,legacyWorker,context) {
  const path=new URL(request.url).pathname;
  if(!path.startsWith('/portal/')&&!/^\/(?:student|guardian)\//.test(path))return null;
  const ws=validWorkspace(request);
  if(!ws)return reply(request,env,{error:'invalid_workspace'},400);
  if(!env.MOBDEA_DATA?.get || !env.MOBDEA_DATA?.put)return reply(request,env,{error:'portal_store_unavailable'},503);
  const origin=request.headers.get('Origin');
  if(origin && !String(env.MOBDEA_ALLOWED_ORIGINS||'').split(',').map(x=>x.trim()).includes(origin))
    return reply(request,env,{error:'origin_not_allowed'},403);
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{
    'Access-Control-Allow-Origin':origin||'', 'Access-Control-Allow-Methods':'GET,POST,PUT,DELETE,OPTIONS',
    'Access-Control-Allow-Headers':'Content-Type,Authorization,X-Mobdea-Workspace,X-Mobdea-Student-Token,X-Mobdea-Role-Token',
    'Access-Control-Expose-Headers':'X-Mobdea-Asset-Sha256,X-Mobdea-Asset-Size,X-Mobdea-Asset-Name,X-Mobdea-Asset-Kind','Vary':'Origin',
  }});
  try {
    if(path==='/portal/accounts'&&request.method==='PUT') {
      if(!(await teacherAuthorized(request,env,legacyWorker,context)))return reply(request,env,{error:'teacher_required'},403);
      return createAccount(request,env,ws);
    }
    if((path==='/student/login'||path==='/guardian/login')&&request.method==='POST')
      return login(request,env,ws,path.startsWith('/student/')?'student':'guardian');
    const role=path.startsWith('/student/')?'student':path.startsWith('/guardian/')?'guardian':'';
    const principal=await authenticated(request,env,ws,role);
    if(!principal)return reply(request,env,{error:'unauthorized'},401);
    // A student who still uses the shared initial PIN may change that PIN,
    // but cannot obtain the snapshot, protected files, or multiplayer access.
    if(principal.role==='student' && path!=='/student/change-pin') {
      const account=await readPrivate(env,accountKey(ws,'student',principal.accountId));
      if(!account || account.mustChangePin===true)
        return reply(request,env,{error:'pin_change_required'},403);
    }
    if((path==='/student/snapshot'||path==='/student/refresh'||path==='/guardian/snapshot'||path==='/portal/snapshot')&&request.method==='GET') {
      const data=await loadSnapshot(env,ws);
      if(!data)return reply(request,env,{error:'workspace_not_ready'},503);
      const students=roleStudents(data,principal);
      return reply(request,env,{ok:true,student:principal.role==='student'?studentPublic(students[0]):undefined,
        students:students.map(studentPublic),mustChangePin:principal.role==='student' && (await readPrivate(env,accountKey(ws,principal.role,principal.accountId)))?.mustChangePin===true,
        data:projectedSessionData(data,principal,request,ws,
          text(request.headers.get('X-Mobdea-Student-Token')||request.headers.get('X-Mobdea-Role-Token'),260))});
    }
    if(path==='/student/change-pin'&&request.method==='POST'&&principal.role==='student') {
      const body=await safeBody(request,5000);
      const nextPin=text(body.newPin,32);
      if(!/^\d{8,16}$/.test(nextPin)||nextPin==='12345678')return reply(request,env,{error:'invalid_new_pin'},400);
      const key=accountKey(ws,'student',principal.accountId);
      const previous=await readPrivate(env,key);
      if(!previous || !previous.active || previous.revision!==principal.revision)
        return reply(request,env,{error:'unauthorized'},401);
      if(equals(await pinHash(nextPin,previous.salt),previous.pinHash))
        return reply(request,env,{error:'new_pin_must_differ'},400);
      const salt=bytes64(crypto.getRandomValues(new Uint8Array(16)));
      const hash=await pinHash(nextPin,salt);
      const account={...previous,salt,pinHash:hash,revision:random(),mustChangePin:false,
        updatedAt:new Date().toISOString()};
      await writePrivate(env,key,account);
      const token=random();const expiresAt=Date.now()+SESSION_SECONDS*1000;
      const nextPrincipal={...principal,revision:account.revision,expiresAt};
      await writePrivate(env,await sessionKey(ws,token),nextPrincipal,{expirationTtl:SESSION_SECONDS});
      const data=await loadSnapshot(env,ws);
      return reply(request,env,{ok:true,studentToken:token,changedAt:account.updatedAt,
        data:projectedSessionData(data,nextPrincipal,request,ws,token)});
    }
    const asset=/^\/(?:student|guardian|portal)\/assets\/([a-zA-Z0-9._-]{1,100})$/.exec(path);
    if(asset&&request.method==='GET')return downloadAsset(request,env,ws,principal,asset[1]);
    if(path==='/portal/logout'&&request.method==='POST') {
      const token=text(request.headers.get('X-Mobdea-Student-Token')||request.headers.get('X-Mobdea-Role-Token'),260);
      await env.MOBDEA_DATA.delete(await sessionKey(ws,token));
      return reply(request,env,{ok:true});
    }
    return reply(request,env,{error:'not_found'},404);
  } catch(error) {
    const known=error?.message==='payload_too_large'?413:error instanceof SyntaxError?400:500;
    return reply(request,env,{error:known===500?'portal_internal_error':known===413?'payload_too_large':'invalid_json'},known);
  }
}
export {authenticated as authenticatePortalPrincipal,loadSnapshot,decodeEncrypted,reply,roleStudents};
