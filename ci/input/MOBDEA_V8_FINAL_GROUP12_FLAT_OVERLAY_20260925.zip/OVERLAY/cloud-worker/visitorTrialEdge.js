/* Group 9: Cloudflare Worker D1-backed guest trial ledger.
 * This module does NOT grant teacher/student privileges.  It is only the
 * anonymous trial quota endpoint; role authorization for other routes must
 * remain in the existing Worker.  Deploy with the explicit D1 binding in
 * cloud-worker/migrations/0001_visitor_trials.sql.
 */
const LIMITS = Object.freeze({ games: 5, maps: 5, multiplayer: 3 });
const ENCODER = new TextEncoder();
const VALID_WORKSPACE = /^[a-zA-Z0-9_-]{3,80}$/;

function response(request, env, body, status = 200) {
  const origin = request.headers.get('Origin');
  const allowed = String(env.MOBDEA_ALLOWED_ORIGINS || '').split(',').map(x => x.trim());
  const originOk = origin && allowed.includes(origin);
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'Vary': 'Origin',
      ...(originOk ? { 'Access-Control-Allow-Origin': origin } : {}),
      'Access-Control-Allow-Headers': 'Content-Type,X-Mobdea-Workspace',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    },
  });
}

async function digestIdentity(workspace, request, env) {
  const pepper = String(env.MOBDEA_TRIAL_PEPPER || '');
  if (pepper.length < 32) throw new Error('visitor_trial_secret_missing');
  // Edge-owned client IP is not a user-supplied student code or localStorage.
  // IP quotas are deliberately conservative; shared-network users may share
  // one allocation. For account-specific subscriptions use verified logins.
  const ip = request.headers.get('CF-Connecting-IP');
  if (!ip || ip.length > 80 || !/^[0-9a-fA-F:.]+$/.test(ip))
    throw new Error('verified_client_address_required');
  const key = await crypto.subtle.importKey('raw', ENCODER.encode(pepper),
    { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const signed = new Uint8Array(await crypto.subtle.sign('HMAC', key, ENCODER.encode(`${workspace}\u0000${ip}`)));
  return Array.from(signed, byte => byte.toString(16).padStart(2, '0')).join('');
}

async function readStatus(database, workspace, subject) {
  const rows = await database.prepare(
    'SELECT kind, used FROM mobdea_guest_trials WHERE workspace = ?1 AND subject_hash = ?2'
  ).bind(workspace, subject).all();
  const used = { games: 0, maps: 0, multiplayer: 0 };
  for (const row of rows.results || []) if (Object.hasOwn(used, row.kind))
    used[row.kind] = Math.min(LIMITS[row.kind], Math.max(0, Number(row.used) || 0));
  const remaining = Object.fromEntries(Object.entries(LIMITS).map(([kind, limit]) => [kind, Math.max(0, limit - used[kind])]));
  return { used, limits: LIMITS, remaining };
}

export async function handleVisitorTrialRequest(request, env) {
  const path = new URL(request.url).pathname;
  if (path !== '/visitor/trials') return null;
  const origin = request.headers.get('Origin');
  const allow = String(env.MOBDEA_ALLOWED_ORIGINS || '').split(',').map(x => x.trim());
  if (origin && !allow.includes(origin)) return response(request, env, {error: 'origin_not_allowed'}, 403);
  if (request.method === 'OPTIONS') return new Response(null, {status: 204, headers: response(request, env, {}).headers});
  if (!['GET','POST'].includes(request.method)) return response(request, env, {error:'method_not_allowed'},405);
  const workspace = request.headers.get('X-Mobdea-Workspace') || '';
  if (!VALID_WORKSPACE.test(workspace)) return response(request, env, {error:'invalid_workspace'},400);
  if (!env.MOBDEA_TRIAL_DB?.prepare) return response(request, env, {error:'trial_database_unavailable'},503);
  let subject;
  try { subject = await digestIdentity(workspace, request, env); }
  catch { return response(request, env, {error:'trial_identity_unavailable'},503); }
  if (request.method === 'GET') return response(request, env, await readStatus(env.MOBDEA_TRIAL_DB, workspace, subject));
  const size = Number(request.headers.get('Content-Length') || '0');
  if (size > 2048) return response(request, env, {error:'payload_too_large'},413);
  let body;
  try { body = await request.json(); } catch { return response(request, env, {error:'invalid_json'},400); }
  const kind = String(body?.kind || '');
  if (!Object.hasOwn(LIMITS, kind)) return response(request, env, {error:'invalid_trial_kind'},400);
  // One D1 SQL statement atomically applies the quota even when requests race.
  // No success result is returned on a failed write; a missing binding fails closed.
  let row;
  try {
    row = await env.MOBDEA_TRIAL_DB.prepare(`
      INSERT INTO mobdea_guest_trials(workspace, subject_hash, kind, used, updated_at)
      VALUES(?1, ?2, ?3, 1, strftime('%s','now'))
      ON CONFLICT(workspace, subject_hash, kind)
      DO UPDATE SET used = used + 1, updated_at = strftime('%s','now')
      WHERE used < ?4
      RETURNING used
    `).bind(workspace, subject, kind, LIMITS[kind]).first();
  } catch { return response(request, env, {error:'trial_database_error'},503); }
  if (row) {
    // The atomic write has already succeeded. Do not introduce a second
    // fallible DB read that could turn a consumed attempt into a false error.
    return response(request, env, {allowed:true, kind, limits:LIMITS,
      used:{[kind]:Number(row.used)}, remaining:{[kind]:Math.max(0,LIMITS[kind]-Number(row.used))}});
  }
  const status = await readStatus(env.MOBDEA_TRIAL_DB, workspace, subject);
  return response(request, env, {allowed:false, kind, ...status}, 403);
}

export { LIMITS as VISITOR_LIMITS };
