/* Group 11: retain the original worker.js as the sole legacy backend.
 * This wrapper adds verified role portals, guards BOTH group-game and live
 * joins on the server, and binds the Group 9 quota endpoint to the same API. */
import legacyWorker from './worker.js';
import {handleVisitorTrialRequest} from './visitorTrialEdge.js';
import {portalRoute,authenticatePortalPrincipal,loadSnapshot,decodeEncrypted,reply,roleStudents} from './group11Portal.js';
const text=(value,max=100)=>String(value??'').trim().slice(0,max);
const WS=/^[a-zA-Z0-9_-]{3,80}$/;
async function joinGuard(request,env,context) {
  const path=new URL(request.url).pathname;
  const game=path==='/game/rooms/join';
  const live=/^\/live\/rooms\/([a-zA-Z0-9_-]{8,80})\/join$/.exec(path);
  if(request.method!=='POST'||(!game&&!live))return null;
  const ws=text(request.headers.get('X-Mobdea-Workspace'),80);
  if(!WS.test(ws))return reply(request,env,{error:'invalid_workspace'},400);
  const origin=request.headers.get('Origin');
  if(origin&&!String(env.MOBDEA_ALLOWED_ORIGINS||'').split(',').map(x=>x.trim()).includes(origin))
    return reply(request,env,{error:'origin_not_allowed'},403);
  let body;
  try {const raw=await request.text();if(raw.length>6000)return reply(request,env,{error:'payload_too_large'},413);body=JSON.parse(raw);}
  catch {return reply(request,env,{error:'invalid_json'},400);}
  const joinCode=text(body.joinCode,30);
  if(game && !/^\d{6}$/.test(joinCode))return reply(request,env,{error:'invalid_join_code'},400);
  if(live && !/^\d{6}$/.test(joinCode))return reply(request,env,{error:'invalid_join_code'},400);
  // Check the actual room BEFORE debiting a visitor trial. An arbitrary code
  // must never consume quota (or create an unverified participant).
  let room;
  if(game){
    const id=await env.MOBDEA_DATA.get(`game-code:${ws}:${joinCode}`);
    if(!id)return reply(request,env,{error:'game_room_not_found'},404);
    const key=`game-room:${ws}:${id}`;
    room=await decodeEncrypted(await env.MOBDEA_DATA.get(key),env,key);
    if(!room||['closed','finished'].includes(room.status)||Date.parse(room.expiresAt||'')<=Date.now())
      return reply(request,env,{error:'game_room_not_available'},404);
  }else{
    const key=`live-room:${ws}:${live[1]}`;
    room=await decodeEncrypted(await env.MOBDEA_DATA.get(key),env,key);
    if(!room||room.status!=='open'||room.joinCode!==joinCode||Date.parse(room.expiresAt||'')<=Date.now())
      return reply(request,env,{error:'live_room_not_available'},404);
  }
  if(game && !String(body.displayName||body.studentName||body.name||'').trim())
    return reply(request,env,{error:'display_name_required'},400);
  if(live && String(body.name||'').trim().length<2)return reply(request,env,{error:'invalid_name'},400);
  // Avoid charging an invalid/full game join. The legacy room still performs
  // its own occupancy check when committing a participant.
  if(game){
    const limit=Number(room.maxParticipants||40);
    if(!Number.isInteger(limit)||limit<1)return reply(request,env,{error:'invalid_room_limit'},409);
    let cursor;let count=0;
    do {
      const page=await env.MOBDEA_DATA.list({prefix:`game-participant:${ws}:${room.roomId}:`,limit:250,cursor});
      for(const entry of page.keys||[]){
        const participant=await decodeEncrypted(await env.MOBDEA_DATA.get(entry.name),env,entry.name);
        if(participant && participant.status!=='removed')count+=1;
      }
      cursor=page.list_complete===false?page.cursor:undefined;
    }while(cursor&&count<limit);
    if(count>=limit)return reply(request,env,{error:'game_room_full'},409);
  }
  const presentedToken=request.headers.get('X-Mobdea-Student-Token')||request.headers.get('X-Mobdea-Role-Token');
  const principal=await authenticatePortalPrincipal(request,env,ws,'student');
  if(presentedToken && !principal)return reply(request,env,{error:'student_session_invalid'},401);
  if(principal){
    const accountKey=`portal-account:${ws}:student:${principal.accountId}`;
    const account=await decodeEncrypted(await env.MOBDEA_DATA.get(accountKey),env,accountKey);
    if(!account || account.mustChangePin===true)
      return reply(request,env,{error:'pin_change_required'},403);
    const snapshot=await loadSnapshot(env,ws);
    const students=roleStudents(snapshot,principal);
    if(students.length!==1)return reply(request,env,{error:'student_not_active'},403);
    body.studentId=String(students[0].id);
    body.studentCode=String(students[0].code||'');
  }else{
    // A typed student code is NEVER verified identity. Null it before
    // forwarding to the legacy game/live room writer.
    body.studentId='';body.studentCode='';
    const quotaRequest=new Request(new URL('/visitor/trials',request.url),{
      method:'POST',headers:new Headers(request.headers),body:JSON.stringify({kind:'multiplayer'}),
    });
    const quota=await handleVisitorTrialRequest(quotaRequest,env);
    if(!quota || !quota.ok)return quota || reply(request,env,{error:'trial_unavailable'},503);
  }
  const headers=new Headers(request.headers);
  headers.delete('Content-Length');
  const downstream=new Request(request.url,{method:'POST',headers,body:JSON.stringify(body)});
  return legacyWorker.fetch(downstream,env,context);
}
export default {async fetch(request,env,context){
  try {
    const portal=await portalRoute(request,env,legacyWorker,context);
    if(portal)return portal;
    const joined=await joinGuard(request,env,context);
    if(joined)return joined;
    const trials=await handleVisitorTrialRequest(request,env);
    if(trials)return trials;
    return legacyWorker.fetch(request,env,context);
  }catch{return reply(request,env,{error:'backend_error'},503);}
}};
