/* Group 9 entry: preserves all legacy Worker routes and intercepts only the
 * guest trial endpoint. Set wrangler main = "worker.group9.js" AFTER adding the
 * MOBDEA_TRIAL_DB D1 binding and applying migration 0001_visitor_trials.sql.
 * Never replace an existing worker.js with a stale repository copy.
 */
import existingWorker from './worker.js';
import { handleVisitorTrialRequest } from './visitorTrialEdge.js';
export default {
  async fetch(request, env, context) {
    const handled = await handleVisitorTrialRequest(request, env);
    return handled ?? existingWorker.fetch(request, env, context);
  },
};
