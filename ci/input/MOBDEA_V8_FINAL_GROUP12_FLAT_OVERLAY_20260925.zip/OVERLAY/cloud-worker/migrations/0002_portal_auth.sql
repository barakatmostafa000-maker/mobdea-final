-- D1 backend requires migration 0001_visitor_trials.sql first.
-- Each account/IP has at most six login attempts in a 15-minute window.
CREATE TABLE IF NOT EXISTS mobdea_portal_login_attempts (
  scope TEXT NOT NULL,
  window_id INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(scope,window_id)
);
