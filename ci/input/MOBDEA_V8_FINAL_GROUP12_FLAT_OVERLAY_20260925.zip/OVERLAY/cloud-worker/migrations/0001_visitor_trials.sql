-- Apply to the D1 database bound to MOBDEA_TRIAL_DB before deploying the Group 9 edge entry.
CREATE TABLE IF NOT EXISTS mobdea_guest_trials (
 workspace TEXT NOT NULL,
 subject_hash TEXT NOT NULL,
 kind TEXT NOT NULL CHECK (kind IN ('games','maps','multiplayer')),
 used INTEGER NOT NULL DEFAULT 0 CHECK (used >= 0),
 updated_at INTEGER NOT NULL,
 PRIMARY KEY (workspace, subject_hash, kind)
);
