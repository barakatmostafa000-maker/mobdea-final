#!/usr/bin/env python3
"""Safely fix original Cloudflare Worker game-room rate limiting, preserving its routes."""
import re
from pathlib import Path


def patch_original_worker(source: str) -> tuple[str, list[str]]:
    updated = source
    changed = []
    for func, category in [('handleCreateGameRoom', 'game-create'), ('handleJoinGameRoom', 'game-join')]:
        begin = updated.find(f'async function {func}(')
        if begin < 0:
            raise ValueError(f'Missing original game handler {func}; refuse blind patch')
        end = updated.find('const body =', begin)
        if end < 0 or end - begin > 2400:
            raise ValueError(f'Unexpected {func} rate limiter body')
        section = updated[begin:end]
        if section.count(f"'{category}'") != 1:
            raise ValueError(f'Unexpected {func} rate limiter category')
        if re.search(r'if\s*\(\s*!\s*\(\s*await\s+rateLimit\(', section):
            continue
        found = re.search(r'if\s*\(\s*await\s+rateLimit\(\s*request,\s*env,\s*.*?'
                          + re.escape(f"'{category}'") + r',?\s*\)\s*\)\s*\{', section, re.S)
        if not found:
            raise ValueError(f'Unexpected {func} rate limiter; refuse blind patch')
        fixed = found.group(0).replace('await rateLimit(', '!(await rateLimit(', 1)
        # Append the new parenthesis immediately before the original if close.
        fixed = re.sub(r'\)\s*\{\s*$', ')) {', fixed, count=1)
        section = section[:found.start()] + fixed + section[found.end():]
        updated = updated[:begin] + section + updated[end:]
        changed.append(category)
    return updated, changed


def main():
    import argparse
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('worker_path', type=Path)
    cli.add_argument('--apply', action='store_true')
    args = cli.parse_args()
    path = args.worker_path
    if not path.is_file():
        raise SystemExit('Original worker.js missing. Cannot safely replace it with an earlier worker.')
    source = path.read_text(encoding='utf8')
    patched, changed = patch_original_worker(source)
    if args.apply and changed:
        path.write_text(patched, encoding='utf8')
    print({'status': 'already_patched' if not changed else 'apply' if args.apply else 'ready', 'changed': changed})


if __name__ == '__main__':
    main()
