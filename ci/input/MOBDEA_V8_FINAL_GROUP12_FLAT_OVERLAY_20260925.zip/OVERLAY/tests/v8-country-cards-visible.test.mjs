import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const component = fs.readFileSync(path.join(root, 'src/pages/ClassMode.jsx'), 'utf8');
const style = fs.readFileSync(path.join(root, 'src/styles/v8-country-cards-verified.css'), 'utf8');

test('country library entry is viewport sibling, not a clipped child of lesson stage', () => {
  const stage = component.indexOf('<ClassModeViewport.Stage>');
  const header = component.indexOf('<ClassModeViewport.Header>');
  const trigger = component.indexOf('data-testid="country-card-visible-entry"');
  const overlays = component.indexOf('<ClassModeViewport.Overlays>');
  const panel = component.indexOf('id="v8-country-card-library"');
  assert.ok(trigger !== -1 && trigger < header && header < stage, 'Entry must precede the viewport header and stage');
  assert.ok(overlays > stage && panel > overlays, 'Drawer must live in viewport overlays, not clipped stage');
  assert.equal(component.match(/id="v8-country-card-library"/g)?.length, 1);
  assert.doesNotMatch(component, /className="v8-country-card-direct-toggle"/, 'Remove stage-only duplicate');
  assert.match(component, /aria-expanded=\{cardsDrawerOpen && cardDrawerSection === "countries"\}/);
});

test('country entry works from unsupported media, then opens the actual catalogue', () => {
  assert.match(component, /const openCountryCardLibrary = \(\) => \{\s*if \(!canPlaceLessonCards\) \{\s*setContentMode\("board"\)/);
  assert.match(component, /setCardDrawerSection\("countries"\);\s*setCardsDrawerOpen\(true\);/);
  assert.match(component, /countryCardsForCategory\(countryCategory, countryCardSearch\)/);
  assert.match(component, /onClick=\{\(\) => addCountryCard\(card\.key\)\}/);
  assert.match(component, /data-testid=\{`country-card-template-\$\{card\.key\}`\}/);
});

test('drawer is touch scrollable and remains visible in fullscreen and stage focus', () => {
  assert.match(style, /presentation-fullscreen > \.v8-country-library-launcher/);
  assert.match(style, /stage-focus-mode > \.v8-country-library-launcher/);
  assert.match(style, /> #v8-country-card-library/);
  assert.match(style, /touch-action:pan-y!important/);
  assert.match(style, /pointer-events:auto!important/);
});

test('missing artwork uses a local fallback without losing card title/facts', () => {
  assert.match(component, /function showCountryCardFallback\(event\)/);
  assert.match(component, /if \(image\.dataset\.countryFallback === "1"\)/);
  assert.equal(component.match(/onError=\{showCountryCardFallback\}/g)?.length, 3);
  assert.match(component, /className="v8-country-card-title"/);
  assert.match(component, /className="country-card-facts-panel"/);
  const artwork = fs.readFileSync(path.join(root,'public/whiteboard/country-cards/v8-card-fallback.svg'), 'utf8');
  assert.match(artwork, /^<svg xmlns="http:\/\/www\.w3\.org\/2000\/svg"/);
});
