import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { MODE_TYPES } from '../src/services/mediaNavigation.js';
import { rememberModeResource, preferredResourceForMode } from '../src/services/v8ModeResourceMemory.js';
import {
  GEOGRAPHY_REGIONS, GEOGRAPHY_FEATURES, GEOGRAPHY_TEACHING_CATEGORIES,
  GEOGRAPHY_SYMBOLS, createMapProjector, getRegionCountries,
} from '../src/data/geography.js';
import { NILE_LANDMARKS, TEACHING_RIVER_PATHS, TEACHING_WATER_BODIES, REFERENCE_LATITUDES, REFERENCE_LONGITUDES } from '../src/data/project06TeachingMaps.js';
import { countryInfo, featureInfo } from '../src/data/mapEnrichment.js';
import countries from '../src/data/world-countries.json' with { type: 'json' };

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const source = (name) => fs.readFileSync(path.join(root, name), 'utf8');

const lesson = [
  { id: 'p1', type: 'pdf', title: 'الكتاب الأول' },
  { id: 'p2', type: 'pdf', title: 'الكتاب الثاني' },
  { id: 'i1', type: 'image', title: 'صورة' },
  { id: 'v1', type: 'video', title: 'فيديو' },
  { id: 'a1', type: 'audio', title: 'صوت' },
  { id: 's1', type: 'slides', title: 'عرض' },
  { id: 'e1', type: 'textbook', title: 'كتاب مدرسي' },
];

test('13: preserves last selected file per media mode, not first file of a different mode', () => {
  const remembered = new Map();
  rememberModeResource(remembered, 'pdf', lesson[1]);
  rememberModeResource(remembered, 'images', lesson[2]);
  assert.equal(preferredResourceForMode(lesson, 'images', remembered, lesson[1]).id, 'i1');
  assert.equal(preferredResourceForMode(lesson, 'pdf', remembered, lesson[2]).id, 'p2');
  assert.equal(preferredResourceForMode(lesson, 'slides', remembered, lesson[1]).id, 's1');
});

test('13: invalid remembered resource and cross-mode IDs cannot select wrong type', () => {
  const remembered = new Map([['pdf', 'v1']]);
  assert.equal(preferredResourceForMode(lesson, 'pdf', remembered, lesson[0]).id, 'p1');
  remembered.set('pdf', 'deleted');
  assert.equal(preferredResourceForMode(lesson, 'pdf', remembered, null).id, 'p1');
  rememberModeResource(remembered, 'pdf', lesson[3]);
  assert.equal(remembered.get('pdf'), 'deleted');
  assert.equal(preferredResourceForMode([], 'pdf', remembered), null);
  assert.equal(preferredResourceForMode(lesson, 'board', remembered), null);
  for (const mode of ['pdf', 'images', 'videos', 'audio', 'slides']) assert.ok(MODE_TYPES[mode]?.length);
});

test('14–16: resource-specific page/zoom/pan, media playback, PPT page, and bounded PDF cache are wired', () => {
  const viewer = source('src/pages/ClassMode.jsx');
  const preview = source('src/components/classmode/PdfCanvasPreview.jsx');
  const media = source('src/components/classmode/MediaRenderer.jsx');
  const pan = source('src/components/classmode/PanZoomSurface.jsx');
  const ppt = source('src/components/classmode/PptxPreview.jsx');
  assert.match(viewer, /rememberModeResource\(lastModeResourceRef\.current/);
  assert.match(viewer, /writeResourceState\('page', resourceKey/);
  assert.match(viewer, /writeResourceState\('zoom', resourceKey/);
  assert.match(preview, /pdfOpenPromises\.has\(key\)/);
  assert.match(preview, /\.finally\(\(\) => rasterPromiseCache\.delete\(key\)\)/);
  assert.match(preview, /result\.page \+ 1, result\.page - 1/);
  assert.match(media, /media\?\.readyState >= 1/);
  assert.match(media, /if \(media\?\.ended\)/);
  assert.match(media, /const ended = \(\) => rememberPlaybackPosition\(memoryKey, 0\)/);
  assert.match(media, /readResourceState\('playback', memoryKey/);
  assert.match(pan, /readResourceState\('pan', memoryKey/);
  assert.match(ppt, /writeResourceState\('pptx-slide', memoryKey/);
});

test('17–18: editable lesson and country cards are wired over annotated media pages', () => {
  const cm = source('src/pages/ClassMode.jsx');
  assert.match(cm, /const canPlaceLessonCards = contentMode === "board" \|\| Boolean/);
  assert.match(cm, /onAddCard=\{canPlaceLessonCards \? addBoardCard/);
  assert.match(cm, /onAddCountryCard=\{canPlaceLessonCards \? addCountryCard/);
  assert.match(cm, /actions=\{boardActions\}/);
  assert.match(cm, /countryMeta:/);
});

test('19–22: separates Europe, Asia, Eurasia, and supports silent atlas reference lines', () => {
  for (const key of ['europe', 'asia', 'eurasia']) assert.ok(GEOGRAPHY_REGIONS[key]);
  for (const key of ['equator', 'greenwich']) assert.ok(
    [...REFERENCE_LATITUDES, ...REFERENCE_LONGITUDES].some((item) => item.id === key && item.value === 0),
  );
  const ru = countries.features.find((feature) => feature.properties.iso_a3 === 'RUS');
  assert.ok(ru);
  assert.equal(GEOGRAPHY_REGIONS.europe.countryFilter(ru), true);
  assert.equal(GEOGRAPHY_REGIONS.asia.countryFilter(ru), true);
  assert.equal(GEOGRAPHY_REGIONS.eurasia.countryFilter(ru), true);
  const map = source('src/components/maps/ProfessionalMap.jsx');
  assert.match(map, /<TeachingRiverOverlay[^>]+labels=\{labels && !silent\}/);
  assert.match(map, /<TeachingWaterBodies[^>]+labels=\{labels && !silent\}/);
  assert.match(map, /<TeachingRiverOverlay[^>]+labels=\{labels && !silent\}/);
});

test('23–26: Nile network retains a joined main channel, two Delta mouths, named lakes and Sudd', () => {
  const waterways = TEACHING_RIVER_PATHS.nile;
  const byId = Object.fromEntries(waterways.map((item) => [item.id, item]));
  for (const id of ['kagera','victoria-nile','albert-nile','bahr-jebel','bahr-ghazal','sobat','white-nile','blue-nile','atbara','main-nile','delta-west','delta-east']) {
    assert.ok(byId[id]?.coords.length >= 3, id);
    for (const [lon, lat] of byId[id].coords) assert.ok(lon >= 20 && lon <= 43 && lat >= -5 && lat <= 34, id);
  }
  assert.deepEqual(byId['delta-west'].coords[0], byId['delta-east'].coords[0]);
  assert.ok(TEACHING_WATER_BODIES.nile.some((item) => item.id === 'sudd-wetlands'));
  for (const name of ['بحيرة ناصر', 'القاهرة', 'مستنقعات السد']) assert.ok(NILE_LANDMARKS.some((item) => item.name.includes(name)));
  assert.ok(TEACHING_RIVER_PATHS.egypt.some((item) => item.id === 'nile-egypt'));
});

test('27–30: all five Egypt map classifications include actual data and symbol catalog assets', () => {
  assert.deepEqual(Object.keys(GEOGRAPHY_TEACHING_CATEGORIES), ['terrain','water','resources','political','landmarks']);
  for (const id of ['terrain','water','minerals','energy','ports','landmarks','capitals']) assert.ok(GEOGRAPHY_FEATURES.egypt[id]?.length, id);
  assert.ok(GEOGRAPHY_SYMBOLS.length >= 100);
  const mediaFiles = GEOGRAPHY_SYMBOLS.filter((item) => item.asset);
  assert.ok(mediaFiles.length >= 100);
  for (const symbol of mediaFiles) assert.ok(fs.existsSync(path.join(root, 'public', symbol.asset.replace(/^\//, ''))), symbol.asset);
  const studio = source('src/components/maps/LessonMapStudio.jsx');
  for (const handler of ['onMovePlacement','onResizePlacement','onDuplicatePlacement','onRemovePlacement','onSaveState']) assert.ok(studio.includes(handler), handler);
  const project = createMapProjector('egypt');
  assert.ok(project(31.2357, 30.0444).every(Number.isFinite));
});

test('18, 39, 40: geography information resolves capitals/facts from real feature data', () => {
  const egypt = getRegionCountries(countries, 'egypt').find((item) => item.properties.iso_a3 === 'EGY');
  const info = countryInfo(egypt);
  assert.equal(info.capital, 'القاهرة');
  assert.ok(info.fact.length > 10);
  assert.ok(featureInfo({ name: 'جبال أطلس' }, 'mountains').fact.includes('شمال غرب إفريقيا'));
});
