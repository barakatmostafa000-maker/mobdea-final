import assert from 'node:assert/strict';
import fs from 'node:fs';
import test from 'node:test';

const source = (file) => fs.readFileSync(file, 'utf8');

test('dashboard keeps local class, schedule, Online Class and Mobdea Online distinct', () => {
  const dashboard = source('src/pages/Dashboard.jsx');
  for (const route of ['classMode','sessions','onlineClass','mobdeaOnline']) {
    assert.match(dashboard, new RegExp(`navigate\\('${route}'\\)`));
  }
  assert.doesNotMatch(dashboard, /action\.id === 'mobdeaOnline'\) navigate\('onlineClass'\)/);
});

test('ClassMode has one top fullscreen control and one same-type resource switcher', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const css = source('src/styles/v8-final-real.css');
  assert.equal((classMode.match(/className="classmode-user-fullscreen"/g) || []).length, 1);
  assert.equal((classMode.match(/className="classmode-media-edge-nav"/g) || []).length, 1);
  assert.match(css, /\.classmode-user-fullscreen\{[\s\S]*?top:/);
  assert.doesNotMatch(classMode, /classmode-inline-media-switcher|classmode-resource-switcher/);
});

test('independent pen/highlighter/eraser sizes replace legacy multiplier sizing', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  assert.match(classMode, /DRAW_TOOL_SIZE_OPTIONS/);
  assert.match(classMode, /pen:\s*\[2, 3, 4, 6, 10, 14, 20\]/);
  assert.match(classMode, /highlighter:\s*\[12, 18, 24, 32, 40, 52\]/);
  assert.match(classMode, /eraser:\s*\[24, 32, 40, 52, 64, 80\]/);
  assert.doesNotMatch(classMode, /\(strokeWidth \|\| 4\) \* 4\.5/);
});

test('PDF renderer is lossless, bounded and warms only adjacent pages', () => {
  const pdf = source('src/components/classmode/PdfCanvasPreview.jsx');
  assert.match(pdf, /image\/png/);
  assert.match(pdf, /MAX_PDF_CACHE/);
  assert.match(pdf, /result\.page - 1/);
  assert.match(pdf, /result\.page \+ 1/);
  assert.doesNotMatch(pdf, /image\/jpeg/);
});

test('Arabic correction is conservative and wired live/finish in ClassMode', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const correction = source('src/services/arabicSentenceCorrection.js');
  assert.match(classMode, /correctArabicSentence\(current\.value, \{ finish: false \}\)/);
  assert.match(classMode, /correctTextEditorNow\(\{ finish: true \}\)/);
  assert.match(correction, /SAFE_WORD_CORRECTIONS/);
  assert.match(correction, /normalizePunctuation/);
});

test('OCR interfaces are lazy/on-demand and manual question entry remains present', () => {
  const library = source('src/pages/ContentLibrary.jsx');
  const manager = source('src/pages/QuestionBankManager.jsx');
  assert.match(library, /import\("\.\.\/services\/pdfQuestionOcr"\)/);
  assert.match(library, /import\("\.\.\/services\/ocrQuestionParser"\)/);
  assert.match(manager, /lazy\(\(\) => import\('\.\.\/components\/questions\/Project08ExamOcrImport'\)\)/);
  assert.match(manager, /ocrPanelOpen/);
  assert.match(manager, /\+ سؤال جديد/);
  assert.match(manager, /customQuestionBank/);
});

test('Nile basin and Egypt river datasets contain the agreed sequence and mouths', () => {
  const maps = source('src/data/project06TeachingMaps.js');
  for (const id of ['kagera','victoria-nile','albert-nile','bahr-jebel','bahr-ghazal','sobat','white-nile','blue-nile','atbara','main-nile','delta-west','delta-east']) {
    assert.match(maps, new RegExp(`id: '${id}'`), id);
  }
  for (const id of ['victoria','albert','tana','lake-nasser','aswan','cairo','delta','rosetta-mouth','damietta-mouth']) {
    assert.match(maps, new RegExp(`id: '${id}'`), id);
  }
});

test('Asia Europe and Eurasia are distinct and Russia handling is explicit', () => {
  const geography = source('src/data/geography.js');
  assert.match(geography, /asia:\s*\{/);
  assert.match(geography, /europe:\s*\{/);
  assert.match(geography, /eurasia:\s*\{/);
  assert.match(geography, /iso_a3 === 'RUS'/);
  assert.match(geography, /'RUS'\]/);
});

test('silent maps hide reference labels but preserve continuous reference lines', () => {
  const map = source('src/components/maps/ProfessionalMap.jsx');
  const css = source('src/styles/v8-final-real.css');
  assert.match(map, /displayMode !== 'blank' && <text/);
  assert.match(map, /!silent && \(placement\.showLabel \|\| placement\.type === "custom-label"\) && \(/);
  assert.match(css, /stroke-dasharray:none!important/);
  assert.match(css, /project06-reference-line/);
});

test('map symbols support placement update duplicate delete and selected hint', () => {
  const studio = source('src/components/maps/LessonMapStudio.jsx');
  assert.match(studio, /onMovePlacement/);
  assert.match(studio, /onResizePlacement/);
  assert.match(studio, /onDuplicatePlacement/);
  assert.match(studio, /onRemovePlacement/);
  assert.match(studio, /lesson-map-selected-symbol-hint/);
  assert.match(studio, /onPointerMove/);
});

test('country and term cards use internal scrolling, in-card auto-fit and tap/drag insertion', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const css = source('src/styles/v8-final-real.css');
  assert.match(classMode, /data-v7-card-autofit="true"/);
  assert.match(classMode, /ResizeObserver/);
  assert.match(classMode, /onDragStart/);
  assert.match(css, /country-card-drawer-list[^}]*overflow-y:auto!important/);
});

test('all requested admin pages expose V8 structural root hooks', () => {
  const files = {
    Dashboard:'dashboard-page-v8', Students:'students-page-v8', Attendance:'attendance-page-v8', Grades:'grades-page-v8',
    GradeScanner:'grade-scanner-page-v8', Payments:'payments-page-v8', Reports:'reports-page-v8', Messages:'messages-page-v8',
    Achievements:'achievements-page-v8', StudentCards:'student-cards-page-v8', Games:'games-page-v8', QuestionBankManager:'question-bank-page-v8',
    ContentLibrary:'content-library-page-v8', Sessions:'sessions-page-v8', Settings:'settings-page-v8', ResultDetails:'result-details-page-v8',
    SmartAssistant:'smart-assistant-page-v8', Updates:'updates-page-v8', PortalPreview:'portal-page-v8', Whiteboard:'standalone-whiteboard-page-v8'
  };
  for (const [file, marker] of Object.entries(files)) assert.match(source(`src/pages/${file}.jsx`), new RegExp(marker), file);
});

test('resource state memories are bounded for pages zoom pan playback and slides', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const pan = source('src/components/classmode/PanZoomSurface.jsx');
  const media = source('src/components/classmode/MediaRenderer.jsx');
  const ppt = source('src/components/classmode/PptxPreview.jsx');
  assert.match(classMode, /MAX_RESOURCE_VIEW_MEMORY/);
  assert.match(classMode, /resourcePageMemoryRef/);
  assert.match(classMode, /resourceZoomMemoryRef/);
  assert.match(pan, /MAX_PAN_MEMORY/);
  assert.match(media, /MAX_PLAYBACK_MEMORY/);
  assert.match(ppt, /MAX_PPTX_SLIDE_MEMORY/);
});

test('ClassMode heavy map/game/live and OCR bridge code is dynamically loaded', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  assert.match(classMode, /lazy\(\(\) => import\("\.\.\/components\/maps\/LessonMapStudio"\)\)/);
  assert.match(classMode, /lazy\(\(\) => import\("\.\.\/components\/classmode\/ClassroomGamePanel"\)\)/);
  assert.match(classMode, /await import\('\.\.\/services\/r20PageOcrPipeline\.js'\)/);
  assert.doesNotMatch(classMode, /import \{ recognizePageForQuestions \} from/);
});

test('standalone whiteboard shares 1536x864 coordinates and verified Arabic font choices', () => {
  const board = source('src/pages/Whiteboard.jsx');
  assert.match(board, /const BOARD_WIDTH = 1536/);
  assert.match(board, /const BOARD_HEIGHT = 864/);
  for (const font of ['Noto Naskh Arabic','Aref Ruqaa','Noto Kufi Arabic','Amiri']) assert.match(board, new RegExp(font));
  assert.match(board, /globalThis\.document\?\.fonts/);
  assert.match(board, /correctArabicSentence/);
});
