import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { fitMapSvgViewport, percentWithinMapViewport } from '../src/services/mapSvgViewport.js';
import { referenceLinesForBounds } from '../src/data/mapReferenceGrid.js';
import { COUNTRY_CARDS } from '../src/data/countryCards.js';
import { countryCardByIso } from '../src/services/mapCountryCard.js';
import { normalizeLessonMapState, normalizeMapRegionSnapshot } from '../src/services/lessonMapState.js';

const src = (file) => readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

test('SVG marker overlay follows viewBox aspect-ratio and does not create off-map symbols', () => {
  assert.deepEqual(fitMapSvgViewport(1000, 800), {left:0, top:90, width:1000, height:620});
  const landscape = fitMapSvgViewport(1280, 620);
  assert.equal(landscape.width,1000);
  assert.equal(landscape.left,140);
  const rect={left:140,top:0,width:1000,height:620};
  assert.deepEqual(percentWithinMapViewport(640,310,rect),{x:50,y:50});
  assert.equal(percentWithinMapViewport(139,310,rect),null);
  assert.equal(percentWithinMapViewport(1141,310,rect),null);
  assert.equal(fitMapSvgViewport(0,620),null);
});

test('atlas references include only in-bounds geographic Greenwich and Equator', () => {
  const world=referenceLinesForBounds([-180,-80,180,85]);
  assert.equal(world.longitudes.filter((line)=>line.value===0).length,1);
  assert.equal(world.latitudes.filter((line)=>line.value===0).length,1);
  assert.equal(world.latitudes.some((line)=>line.value===90),false);
  const africa=referenceLinesForBounds([-20,-35,55,40]);
  assert.ok(africa.latitudes.some((line)=>line.value===0));
  assert.ok(africa.longitudes.some((line)=>line.value===0));
  assert.equal(referenceLinesForBounds([10,10,10,20]).latitudes.length,0);
});

test('all country cards have unique ISO identifiers, capitals, regions and real facts', () => {
  assert.equal(COUNTRY_CARDS.length,35);
  assert.equal(new Set(COUNTRY_CARDS.map((card)=>card.iso)).size,35);
  for(const card of COUNTRY_CARDS){
    assert.ok(card.capital?.trim(), card.name);
    assert.ok(card.region?.trim(),card.name);
    assert.ok(card.fact?.trim(),card.name);
    assert.equal(countryCardByIso(card.iso),card);
  }
  assert.equal(countryCardByIso('ZZZ'),null);
});

test('map card drawer is visible on the map surface and class resource drawer remains available', () => {
 const map=src('src/components/maps/LessonMapStudio.jsx');
 assert.match(map,/lesson-map-country-cards-toggle/);
 assert.match(map,/lesson-map-country-cards-drawer/);
 assert.match(map,/openCountryCard\(card\)/);
 assert.match(map,/selectedCountryCard\?\.region/);
 assert.match(map,/countryCardImageFailed/);
 assert.match(src('src/pages/ClassMode.jsx'),/country-card/);
});

test('switching and returning from Nile keeps each region map-layer and map resources isolated', () => {
 const initial=normalizeLessonMapState({regionKey:'nile',regions:{nile:{layerKey:'rivers',zoom:2,placements:[{id:'n1',x:30,y:40}]},egypt:{layerKey:'minerals',zoom:1.5,placements:[{id:'eg1',x:20,y:50}]}}});
 assert.equal(initial.layerKey,'rivers');
 assert.equal(initial.zoom,2);
 assert.equal(initial.regions.egypt.layerKey,'minerals');
 assert.deepEqual(initial.regions.egypt.placements,[{id:'eg1',x:20,y:50}]);
 const map=src('src/components/maps/LessonMapStudio.jsx');
 assert.match(map,/previousRegionBeforeNileRef/);
 assert.match(map,/nextStates\[returnRegion\]/);
 assert.match(map,/setLayerKey\(normalized.layerKey/);
});

test('PDF cache retains a live renderer and deduplicates same-document opens', () => {
 const code=src('src/components/classmode/PdfCanvasPreview.jsx');
 assert.match(code,/pdfOpenPromises\.has\(key\)/);
 assert.match(code,/pdfUseCount\.set/);
 assert.match(code,/retirePdfDocument/);
});

test('prior patch-required imports are included as actual files in cumulative payload', () => {
 for(const file of [
  'src/services/classStudentRails.js','src/services/v8BoardFontAvailability.js',
  'src/services/v8ModeResourceMemory.js','src/utils/boardPoint.js',
  'src/services/v8BoardTextDirection.js'
 ]) assert.ok(existsSync(new URL(`../${file}`,import.meta.url)),file);
});
