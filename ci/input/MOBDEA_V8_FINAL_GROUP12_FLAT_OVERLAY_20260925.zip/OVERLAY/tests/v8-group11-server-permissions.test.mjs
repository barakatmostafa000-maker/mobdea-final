import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,writeFileSync,copyFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';

const root=resolve(import.meta.dirname,'..');
const dir=mkdtempSync(join(tmpdir(),'mobdea-group11-'));
for (const name of ['worker.group11.js','group11Portal.js','visitorTrialEdge.js'])
  copyFileSync(join(root,'cloud-worker',name),join(dir,name));
writeFileSync(join(dir,'package.json'),' {"type":"module"}\n');
writeFileSync(join(dir,'worker.js'),`export default {async fetch(req,env){
  const path=new URL(req.url).pathname;
  if(path==='/health')return new Response(JSON.stringify({ok:req.headers.get('Authorization')==='Bearer teacher-secret'}),
    {status:req.headers.get('Authorization')==='Bearer teacher-secret'?200:401});
  if(path.endsWith('/join')){
    const body=await req.json();
    return Response.json({ok:true,received:{studentId:body.studentId,studentCode:body.studentCode}}, {status:201});
  }
  return new Response('LEGACY_OK');
}};`);
const {default:edge}=await import(pathToFileURL(join(dir,'worker.group11.js')).href);
class KV {
  #values=new Map();
  async get(k){return this.#values.get(k)??null;}
  async put(k,v){this.#values.set(k,v);}
  async delete(k){this.#values.delete(k);}
  async list({prefix}){return {keys:[...this.#values.keys()].filter(k=>k.startsWith(prefix)).map(name=>({name}))};}
}
class D1 {
  count=new Map();trials=new Map();
  prepare(sql){return {bind:(...args)=>({
    first:async()=>{
      if(sql.includes('mobdea_portal_login_attempts')){
        const k=args.join(':');const count=(this.count.get(k)||0)+1;this.count.set(k,count);return {attempts:count};
      }
      if(sql.includes('INSERT INTO mobdea_guest_trials')){
        const [ws,sub,kind,limit]=args;const key=`${ws}:${sub}:${kind}`;
        const count=this.trials.get(key)||0;if(count>=limit)return null;
        this.trials.set(key,count+1);return {used:count+1};
      }
      return null;
    },
    all:async()=>{const [ws,sub]=args;return {results:[...this.trials.entries()].filter(([key])=>key.startsWith(`${ws}:${sub}:`))
      .map(([key,used])=>({kind:key.split(':').at(-1),used}))};},
  })};}
}
const secret='e'.repeat(48);
const enc=new TextEncoder();
const b64=(bytes)=>btoa(String.fromCharCode(...bytes));
async function encrypt(value,aad){
  const key=await crypto.subtle.importKey('raw',await crypto.subtle.digest('SHA-256',enc.encode(secret)),{name:'AES-GCM'},false,['encrypt']);
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:enc.encode(aad),tagLength:128},key,enc.encode(JSON.stringify(value)));
  return JSON.stringify({version:1,iv:b64(iv),ciphertext:b64(new Uint8Array(cipher))});
}
const students=[{id:'s1',code:'4101',name:'أحمد',grade:'1',group:'A',studentPin:'DO_NOT_LEAK'},
  {id:'s2',code:'4202',name:'مريم',grade:'2',group:'B',guardianPhone:'fake-guardian'}];
const data={students,grades:[{studentId:'s1',score:20},{studentId:'s2',score:3}],
  payments:[{studentId:'s1',amount:20},{studentId:'s2',amount:300}],
  assetManifest:[{id:'book-a.pdf',sha256:'f'.repeat(64),size:15,teacherSecret:'NOT_FOR_STUDENTS',name:'Public book'}],
  contentLibrary:[
    {id:'book-a',assetId:'book-a.pdf',published:true,access:{mode:'students',studentIds:['s1','s2']}},
    {id:'book-b',assetId:'book-b.pdf',published:true,access:{mode:'students',studentIds:['s2']}},
    {id:'hidden',assetId:'hidden.pdf',published:false,access:{mode:'public'}},
  ], sessions:[],settings:{cloudSync:{token:'TEACHER_PRIVATE'}}};
const ws='school_1';
const env={MOBDEA_DATA:new KV(),MOBDEA_TRIAL_DB:new D1(),MOBDEA_ALLOWED_ORIGINS:'https://app.example',
  MOBDEA_ENCRYPTION_KEY:secret,MOBDEA_TRIAL_PEPPER:'p'.repeat(48)};
await env.MOBDEA_DATA.put(`workspace:${ws}`,await encrypt({data},`sync:${ws}`));
async function req(path,method='GET',body,opts={}) {
  const headers={'X-Mobdea-Workspace':opts.ws||ws,Origin:opts.origin||'https://app.example',
    'CF-Connecting-IP':opts.ip||'192.0.2.22',
    ...(opts.teacher?{Authorization:'Bearer teacher-secret'}:{}),
    ...(opts.token?{'X-Mobdea-Student-Token':opts.token}:{}),
    ...(body?{'Content-Type':'application/json'}:{})};
  return edge.fetch(new Request(`https://worker.example${path}`,{method,headers,...(body?{body:JSON.stringify(body)}:{})}),env,{});
}
let studentToken='',guardianToken='';
test('unverified teacher cannot provision accounts; teacher creates one exact student and linked guardian',async()=>{
  assert.equal((await req('/portal/accounts','PUT',{role:'student',accountId:'4101',studentIds:['s1'],pin:'12345678'})).status,403);
  assert.equal((await req('/portal/accounts','PUT',{role:'student',accountId:'4202',studentIds:['s1'],pin:'12345678'},{teacher:true})).status,400);
  assert.equal((await req('/portal/accounts','PUT',{role:'student',accountId:'4101',studentIds:['s1'],pin:'12345678'},{teacher:true})).status,201);
  assert.equal((await req('/portal/accounts','PUT',{role:'guardian',accountId:'parent01',studentIds:['s1'],pin:'98765432'},{teacher:true})).status,201);
});
test('student login checks hashed PIN, rejects guardian phone, enforces limited attempts',async()=>{
  assert.equal((await req('/student/login','POST',{code:'4101',pin:'00000000'})).status,401);
  assert.equal((await req('/guardian/login','POST',{accountId:'fake-guardian',pin:'98765432'})).status,401);
  const login=await req('/student/login','POST',{code:'4101',pin:'12345678'});
  assert.equal(login.status,200);
  const result=await login.json();studentToken=result.studentToken;
  assert.equal(result.student.id,'s1');assert.equal(result.data.students.length,1);
  assert.equal(result.mustChangePin,true);
  assert.equal(result.data.contentLibrary.length,0);
  assert.equal(result.data.grades,undefined);
  assert.equal((await req('/student/snapshot','GET',undefined,{token:studentToken})).status,403);
  assert.equal((await req('/student/assets/book-a.pdf','GET',undefined,{token:studentToken})).status,403);
  assert.doesNotMatch(JSON.stringify(result),/DO_NOT_LEAK|TEACHER_PRIVATE|4202|300/);
  const rotated=await req('/student/change-pin','POST',{newPin:'87654321'},{token:studentToken});
  assert.equal(rotated.status,200);
  const changed=await rotated.json();studentToken=changed.studentToken;
  assert.deepEqual(changed.data.grades.map(x=>x.studentId),['s1']);
  assert.equal(changed.data.contentLibrary.length,1);
  assert.deepEqual(changed.data.contentLibrary[0].access.studentIds,['s1']);
  assert.equal(changed.data.assetManifest.length,1);
  assert.equal(changed.data.assetManifest[0].teacherSecret,undefined);
  assert.doesNotMatch(JSON.stringify(changed.data),/NOT_FOR_STUDENTS/);
  const guardian=await req('/guardian/login','POST',{accountId:'parent01',pin:'98765432'});
  assert.equal(guardian.status,200);guardianToken=(await guardian.json()).roleToken;
});
test('role sessions are workspace-bound, guardian links are server-issued, and assets fail closed',async()=>{
  assert.equal((await req('/student/snapshot','GET',undefined,{token:studentToken,ws:'school_2'})).status,401);
  assert.equal((await req('/guardian/snapshot','GET',undefined,{token:studentToken})).status,401);
  const snapshot=await req('/guardian/snapshot','GET',undefined,{token:guardianToken});
  assert.equal(snapshot.status,200);assert.deepEqual((await snapshot.json()).students.map(s=>s.id),['s1']);
  assert.equal((await req('/student/assets/book-b.pdf','GET',undefined,{token:studentToken})).status,404);
  assert.equal((await req('/student/assets/hidden.pdf','GET',undefined,{token:studentToken})).status,404);
  assert.equal((await req('/student/assets/book-a.pdf','GET',undefined,{token:'invalid'})).status,401);
});
test('valid published asset decrypts and hashes on the server; unrelated resource cannot leak',async()=>{
  const content=enc.encode('AUTHORIZED_BOOK');
  const key=await crypto.subtle.importKey('raw',await crypto.subtle.digest('SHA-256',enc.encode(secret)),{name:'AES-GCM'},false,['encrypt']);
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:enc.encode(`asset:${ws}:book-a.pdf`),tagLength:128},key,content);
  const sha=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',content)),x=>x.toString(16).padStart(2,'0')).join('');
  env.MOBDEA_ASSETS={get:async path=>path===`workspace/${ws}/book-a.pdf`?{
    customMetadata:{iv:b64(iv),sha256:sha,size:content.length,name:'safe.pdf',type:'application/pdf'},arrayBuffer:async()=>cipher,
  }:null};
  const response=await req('/student/assets/book-a.pdf','GET',undefined,{token:studentToken});
  assert.equal(response.status,200);assert.equal(await response.text(),'AUTHORIZED_BOOK');
  assert.equal(response.headers.get('X-Mobdea-Asset-Sha256'),sha);
});
test('guest and student game-room joins are authorized by server, not a typed student ID',async()=>{
  const game={roomId:'room_1234567',workspace:ws,status:'waiting',expiresAt:new Date(Date.now()+3600_000).toISOString()};
  await env.MOBDEA_DATA.put('game-code:school_1:123456',game.roomId);
  await env.MOBDEA_DATA.put(`game-room:${ws}:${game.roomId}`,await encrypt(game,`game-room:${ws}:${game.roomId}`));
  const body={joinCode:'123456',displayName:'Guest',studentId:'s2',studentCode:'4202'};
  const before=env.MOBDEA_TRIAL_DB.trials.size;
  assert.equal((await req('/game/rooms/join','POST',{...body,joinCode:'999999'})).status,404);
  assert.equal(env.MOBDEA_TRIAL_DB.trials.size,before);
  const guest=await req('/game/rooms/join','POST',body);
  assert.equal(guest.status,201);assert.equal((await guest.json()).received.studentId,'');
  const pupil=await req('/game/rooms/join','POST',body,{token:studentToken});
  assert.equal(pupil.status,201);assert.equal((await pupil.json()).received.studentId,'s1');
  const status=await req('/visitor/trials');assert.equal((await status.json()).remaining.multiplayer,2);
});
test('guest live joins consume quota at room join; invalid join does not spend a trial',async()=>{
  const room={id:'live_room_12345',workspace:ws,joinCode:'345678',status:'open',expiresAt:new Date(Date.now()+3600_000).toISOString()};
  await env.MOBDEA_DATA.put(`live-room:${ws}:${room.id}`,await encrypt(room,`live-room:${ws}:${room.id}`));
  assert.equal((await req(`/live/rooms/${room.id}/join`,'POST',{joinCode:'345677',name:'Wrong'})).status,404);
  const response=await req(`/live/rooms/${room.id}/join`,'POST',{joinCode:room.joinCode,name:'Guest',studentCode:'s2'});
  assert.equal(response.status,201);assert.equal((await response.json()).received.studentCode,'');
  const status=await req('/visitor/trials');assert.equal((await status.json()).remaining.multiplayer,1);
});
test('full game room rejects guest BEFORE using a multiplayer attempt',async()=>{
  const game={roomId:'room_full_123',workspace:ws,status:'waiting',maxParticipants:1,
    expiresAt:new Date(Date.now()+3600_000).toISOString()};
  await env.MOBDEA_DATA.put(`game-code:${ws}:111222`,game.roomId);
  await env.MOBDEA_DATA.put(`game-room:${ws}:${game.roomId}`,await encrypt(game,`game-room:${ws}:${game.roomId}`));
  const key=`game-participant:${ws}:${game.roomId}:already-joined`;
  await env.MOBDEA_DATA.put(key,await encrypt({participantId:'already-joined',status:'waiting'},key));
  const before=await (await req('/visitor/trials')).json();
  const res=await req('/game/rooms/join','POST',{joinCode:'111222',displayName:'Another guest'});
  assert.equal(res.status,409);
  assert.equal((await res.json()).error,'game_room_full');
  const after=await (await req('/visitor/trials')).json();
  assert.deepEqual(after.remaining,before.remaining);
});
test('a one-letter live join is rejected without consuming a trial',async()=>{
  const room={id:'live_short_name_1',workspace:ws,joinCode:'616161',status:'open',
    expiresAt:new Date(Date.now()+3600_000).toISOString()};
  const key=`live-room:${ws}:${room.id}`;
  await env.MOBDEA_DATA.put(key,await encrypt(room,key));
  const before=await (await req('/visitor/trials')).json();
  const response=await req(`/live/rooms/${room.id}/join`,'POST',{joinCode:room.joinCode,name:'A'});
  assert.equal(response.status,400);
  assert.deepEqual((await (await req('/visitor/trials')).json()).remaining,before.remaining);
});
test('account PIN reset revokes older role sessions',async()=>{
  assert.equal((await req('/portal/accounts','PUT',{role:'student',accountId:'4101',studentIds:['s1'],pin:'55555555'},{teacher:true})).status,201);
  assert.equal((await req('/student/snapshot','GET',undefined,{token:studentToken})).status,401);
  assert.equal((await req('/student/login','POST',{code:'4101',pin:'55555555'})).status,200);
});
test('PIN rotation rejects same/default PIN and issues a new server-bound session',async()=>{
  const login=await req('/student/login','POST',{code:'4101',pin:'55555555'});
  assert.equal(login.status,200);
  const firstToken=(await login.json()).studentToken;
  assert.equal((await req('/student/change-pin','POST',{newPin:'55555555'},{token:firstToken})).status,400);
  assert.equal((await req('/student/change-pin','POST',{newPin:'12345678'},{token:firstToken})).status,400);
  const changed=await req('/student/change-pin','POST',{newPin:'66666666'},{token:firstToken});
  assert.equal(changed.status,200);
  const payload=await changed.json();
  assert.notEqual(payload.studentToken,firstToken);
  assert.equal(payload.data.settings.studentPortalSession.studentToken,payload.studentToken);
  assert.equal((await req('/student/snapshot','GET',undefined,{token:firstToken})).status,401);
  assert.equal((await req('/student/snapshot','GET',undefined,{token:payload.studentToken})).status,200);
});
test('legacy teacher endpoints and unknown routes remain owned by original worker',async()=>{
  assert.equal(await (await req('/some-old-route')).text(),'LEGACY_OK');
  assert.equal((await req('/health','GET',undefined,{teacher:true})).status,200);
});
test.after(()=>rmSync(dir,{recursive:true,force:true}));
