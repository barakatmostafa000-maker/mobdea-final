import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { splitStudentRails } from '../src/services/classStudentRails.js';
import { drawRandomStudents } from '../src/services/project11StudentSelection.js';
import { withClassPointAward } from '../src/services/classPointImprovement.js';

const read = (name) => fs.readFileSync(new URL(`../${name}`, import.meta.url), 'utf8');
const students = Array.from({ length: 14 }, (_, index) => ({id: String(index + 1), name: `طالب ${index + 1}`, points: 0}));

test('items 3: split is 5/5, 6/6, 7/7 and odd count differs by at most one', () => {
  for (const [n, expected] of [[0,[0,0]],[1,[1,0]],[7,[4,3]],[10,[5,5]],[12,[6,6]],[14,[7,7]]]) {
    const rails = splitStudentRails(students.slice(0,n));
    assert.deepEqual(rails.map((side) => side.length), expected);
    assert.equal(new Set(rails.flat().map((student) => student.id)).size, n);
  }
  assert.deepEqual(splitStudentRails([{id:'a'},{id:'a'},{id:'b'}]).map((part) => part.length), [1,1]);
});

test('item 3: a full random cycle on each rail never selects a student from the other rail', () => {
  const [right,left] = splitStudentRails(students.slice(0,12));
  const first = (list) => {
    let usedIds = [];
    const picked = [];
    for (let i=0;i<list.length;i++) {
      const step=drawRandomStudents(list,1,usedIds,()=>0);
      usedIds=step.usedIds;
      picked.push(step.selected[0].id);
    }
    assert.equal(new Set(picked).size,list.length);
    assert.deepEqual(new Set(picked),new Set(list.map((s)=>s.id)));
  };
  first(right);first(left);
  assert.equal(right.some((s) => left.includes(s)),false);
  const component=read('src/pages/ClassMode.jsx');
  assert.match(component,/onClick=\{\(\) => randomStudent\("left"\)\}/);
  assert.match(component,/randomUsedBySideRef\.current\[selectedSide\]/);
  assert.match(component,/randomPickedStudentId === String\(student\.id\)/);
});

test('item 4: fast consecutive awards and non-negative deductions use the latest snapshot', () => {
  const config = {sessionKey:'lesson:2026-09-22',session:{id:'lesson'},today:'2026-09-22',group:'أ',grade:'أولى'};
  let data={students:[{id:'1',name:'علي',points:4,group:'أ'}],classPointSessions:[]};
  const step = (change) => {data=withClassPointAward({latest:data,studentId:'1',change,...config});};
  step(1);step(1);step(-1);step(-50);step(1);
  assert.equal(data.students[0].points,1);
  assert.equal(data.classPointSessions.length,1);
  assert.equal(data.classPointSessions[0].points['1'],1);
  assert.equal(data.classPointSessions[0].earned['1'],-3);
});

test('item 4: remote presentation state never overwrites durable student balance', () => {
  const bridge=read('src/components/classmode/Project11ClassSyncBridge.jsx');
  assert.doesNotMatch(bridge,/setPoints\?\.\(remote\.points\)/);
  const cm=read('src/pages/ClassMode.jsx');
  assert.match(cm,/withClassPointAward\(/);
  assert.match(cm,/updateData\(\(latest\) =>/);
  assert.match(cm,/setPoints\(\(currentPoints\) =>/);
});

test('item 5: draggable bottom dock contains student controls and sole lesson save; no legacy drawer', () => {
  const cm=read('src/pages/ClassMode.jsx');
  const dock=cm.slice(cm.indexOf('className={`project12-classmode-dock classmode-user-bottom-dock'),cm.indexOf('<button\n        type="button"\n        className="classmode-user-fullscreen"'));
  assert.match(dock,/classmode-dock-drag-handle/);
  assert.match(dock,/classmode-students-dock-toggle/);
  assert.match(dock,/classmode-dock-point-plus/);
  assert.match(dock,/classmode-dock-point-minus/);
  assert.match(dock,/disabled=\{!selectedStudent \|\| !students\.some/);
  assert.match(dock,/className="secondary-btn classmode-bottom-save"/);
  assert.equal((dock.match(/onClick=\{saveLessonState\}/g)||[]).length,1);
  assert.match(cm,/if \(!event\.target\.closest\?\.\("\.classmode-dock-drag-handle"\)\) return/);
  assert.doesNotMatch(cm,/className="classmode-student-drawer-backdrop"/);
  const css=read('src/styles/v8-group1-student-dock.css');
  assert.doesNotMatch(cm,/حفظ طبقة السبورة<\/span>/);
  assert.match(css,/\.classmode-student-rail-list \{/);
});

test('items 1,2: layouts are mounted last and fullscreen fallback remains available', () => {
  const main=read('src/main.jsx');
  assert.ok(main.indexOf('v8-group1-student-dock.css')>main.indexOf('v8-final-real.css'));
  const cm=read('src/pages/ClassMode.jsx');
  assert.match(cm,/requestFullscreen/);
  assert.match(cm,/classmode-final-layout/);
  const css=read('src/styles/v8-all-pages-layout.css');
  assert.match(css,/data-layout-role/); // every role inherits same shell structure
});
