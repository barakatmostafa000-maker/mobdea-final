import assert from 'node:assert/strict';
import fs from 'node:fs';
import test from 'node:test';
import { COUNTRY_AR_NAMES, COUNTRY_CAPITALS_AR } from '../src/data/mapEnrichment.js';

const source = (file) => fs.readFileSync(file, 'utf8');
const classMode = () => source('src/pages/ClassMode.jsx');
const css = () => source('src/styles/v8-final-real.css');

const pageMarkers = {
  Dashboard:'dashboard-page-v8', Students:'students-page-v8', Attendance:'attendance-page-v8', Grades:'grades-page-v8',
  GradeScanner:'grade-scanner-page-v8', Payments:'payments-page-v8', Reports:'reports-page-v8', Messages:'messages-page-v8',
  Achievements:'achievements-page-v8', StudentCards:'student-cards-page-v8', Games:'games-page-v8', QuestionBankManager:'question-bank-page-v8',
  ContentLibrary:'content-library-page-v8', Sessions:'sessions-page-v8', Settings:'settings-page-v8', ResultDetails:'result-details-page-v8',
  SmartAssistant:'smart-assistant-page-v8', Updates:'updates-page-v8', PortalPreview:'portal-page-v8', Whiteboard:'standalone-whiteboard-page-v8'
};

test('01 layout: every requested page has a structural root hook and tablet-landscape ownership', () => {
  for (const [file, marker] of Object.entries(pageMarkers)) {
    assert.match(source(`src/pages/${file}.jsx`), new RegExp(marker), file);
    assert.match(css(), new RegExp(`\\.${marker}`), marker);
  }
  assert.match(css(), /orientation:landscape/);
  assert.match(css(), /writing-mode:horizontal-tb!important/);
  assert.match(css(), /overflow-x:clip!important/);
});

test('02 ClassMode: one top fullscreen control, stable touch toolbar and board-only save', () => {
  const s=classMode(), c=css();
  assert.equal((s.match(/className="classmode-user-fullscreen"/g)||[]).length,1);
  assert.match(c,/\.classmode-user-fullscreen\{[\s\S]*?top:/);
  assert.match(c,/classmode-header-tabs button\.active\{[^}]*transform:none!important/);
  assert.match(c,/classmode-toolbar\{[\s\S]*?overflow:auto!important/);
  assert.match(s,/contentMode === "board" && \(\s*<button onClick=\{persistCurrentBoardLayer\}/);
});

test('03 students: two rails, visible scrolling, +/- points, random choice and compact management entry', () => {
  const s=classMode(), c=css();
  assert.match(s,/classmode-student-rails/);
  assert.match(s,/classmode-student-rail-list/);
  assert.match(s,/adjustPoints\(student, 1\)/);
  assert.match(s,/adjustPoints\(student, -1\)/);
  assert.match(s,/classmode-rail-random/);
  assert.match(s,/classmode-rail-manage/);
  assert.match(c,/classmode-student-rail-list\{[^}]*overflow-y:auto!important/);
  assert.doesNotMatch(s,/classmode-students-panel/);
});

test('04 TTS: native/service speech is attempted first with Arabic browser fallback and praise/correction wiring', () => {
  const s=classMode();
  assert.match(s,/const nativeSpoken = await speakArabic/);
  assert.match(s,/globalThis\.speechSynthesis/);
  assert.match(s,/utterance\.lang = "ar-EG"/);
  assert.match(s,/speakClassroomArabic\(text, data\.settings, "excited"\)/);
  assert.match(s,/speakClassroomArabic\(text, data\.settings, "calm"\)/);
});

test('05 board: 1536x864 coordinate stage, contain background, export ratio and legacy migration', () => {
  const s=classMode(), c=css();
  assert.match(s,/BOARD_CANVAS_WIDTH = 1536/); assert.match(s,/BOARD_CANVAS_HEIGHT = 864/);
  assert.match(s,/LEGACY_BOARD_COORD_WIDTH = 1200/); assert.match(s,/LEGACY_BOARD_COORD_HEIGHT = 720/);
  assert.match(s,/canvas\.width = BOARD_CANVAS_WIDTH/); assert.match(s,/canvas\.height = BOARD_CANVAS_HEIGHT/);
  assert.match(c,/class-board-coordinate-stage\.is-board/); assert.match(c,/object-fit:contain!important/);
});

test('06 board tools: independent sizes, text/font/selection, undo redo clear and fullscreen reachability', () => {
  const s=classMode(), c=css();
  for (const token of ['pen','highlighter','eraser']) assert.match(s,new RegExp(`${token}:\\s*\\[`));
  assert.match(s,/normal-text/); assert.match(s,/fontFamily/); assert.match(s,/fontSize/); assert.match(s,/selectedBoardActionId/);
  assert.match(s,/<Undo2/); assert.match(s,/<Redo2/); assert.match(s,/clearBoard/);
  assert.match(c,/presentation-fullscreen \.classmode-toolbar/);
});

test('07 annotations: PDF/image/PPT use shared canvas tools and pointer preview avoids React updates per sample', () => {
  const s=classMode();
  assert.match(s,/MEDIA_ANNOTATION_TOOL_KEYS/);
  assert.match(s,/mediaAnnotationMode/);
  assert.match(s,/MemoCanvasOverlay/);
  assert.match(s,/preview/);
  assert.match(s,/requestAnimationFrame|draw/i);
});

test('08 fonts: real Arabic families are probed, previewed and stored/rendered on text objects', () => {
  const s=classMode();
  for (const font of ['Noto Naskh Arabic','Aref Ruqaa','Noto Kufi Arabic','Amiri']) assert.match(s,new RegExp(font));
  assert.match(s,/fonts\.load/); assert.match(s,/fonts\.check/);
  assert.match(s,/style=\{\{ fontFamily: item\.value \}\}/);
  assert.match(s,/stamp\.fontFamily/);
});

test('09 Arabic correction: conservative live/finish normalization is wired into class text and saved questions', () => {
  const corr=source('src/services/arabicSentenceCorrection.js'), s=classMode(), q=source('src/pages/QuestionBankManager.jsx');
  assert.match(corr,/SAFE_WORD_CORRECTIONS/); assert.match(corr,/normalizePunctuation/);
  assert.match(s,/finish: false/); assert.match(s,/finish: true/);
  assert.match(q,/correctArabicSentence/);
});

test('10 resources: exactly one compact same-type switcher and no dropdown switcher', () => {
  const s=classMode();
  assert.equal((s.match(/className="classmode-media-edge-nav"/g)||[]).length,1);
  assert.match(s,/modeResourceTypes/); assert.match(s,/wantedTypes\.includes\(resourceMediaType\(resource\)\)/);
  assert.doesNotMatch(s,/classmode-inline-media-switcher/);
});

test('11 resource state: page/zoom, playback, slide and pan memories are per resource and bounded', () => {
  const s=classMode(), media=source('src/components/classmode/MediaRenderer.jsx'), ppt=source('src/components/classmode/PptxPreview.jsx'), pan=source('src/components/classmode/PanZoomSurface.jsx');
  assert.match(s,/resourcePageMemoryRef/); assert.match(s,/resourceZoomMemoryRef/); assert.match(s,/MAX_RESOURCE_VIEW_MEMORY/);
  assert.match(media,/mediaPlaybackMemory/); assert.match(media,/MAX_PLAYBACK_MEMORY/);
  assert.match(ppt,/pptxSlideMemory/); assert.match(ppt,/MAX_PPTX_SLIDE_MEMORY/);
  assert.match(pan,/panStateMemory/); assert.match(pan,/MAX_PAN_MEMORY/);
});

test('12 PDF: bounded cache, adjacent preload, focal pinch/pan and lossless adaptive rendering', () => {
  const pdf=source('src/components/classmode/PdfCanvasPreview.jsx'), pan=source('src/components/classmode/PanZoomSurface.jsx');
  assert.match(pdf,/MAX_PDF_CACHE/); assert.match(pdf,/result\.page - 1/); assert.match(pdf,/result\.page \+ 1/); assert.match(pdf,/image\/png/); assert.match(pdf,/qualityZoom/);
  assert.match(pan,/beginPinch/); assert.match(pan,/centroid/); assert.match(pan,/screenVector/); assert.match(pan,/panLimits\.x/); assert.match(pan,/panLimits\.y/);
});

test('13 media: compact video/audio controls, lazy PPT, no duplicate fullscreen, annotation toolbar does not cover content', () => {
  const m=source('src/components/classmode/MediaRenderer.jsx'), c=css();
  assert.match(m,/lazy\(\(\) => import\('\.\/PptxPreview'\)\)/); assert.match(m,/classmode-compact-media-controls/);
  assert.doesNotMatch(m,/requestFullscreen|webkitRequestFullscreen/); assert.match(c,/classmode-compact-media-controls\{[^}]*height:40px!important/);
});

test('14 cards: country/term content is in-card, scrollable, auto-fit and tap/drag insertable', () => {
  const s=classMode(), c=css();
  assert.match(s,/data-v7-card-autofit="true"/); assert.match(s,/ResizeObserver/); assert.match(s,/onDragStart/); assert.match(s,/onClick/);
  assert.match(c,/country-card-drawer-list[^}]*overflow-y:auto!important/);
});

test('15 country data: every mapped country has a capital and maps/cards/challenge consume the shared enrichment source', () => {
  assert.deepEqual(Object.keys(COUNTRY_AR_NAMES).filter((iso)=>!COUNTRY_CAPITALS_AR[iso]),[]);
  const e=source('src/data/mapEnrichment.js'), cm=classMode(), challenge=source('src/pages/MapChallenge.jsx');
  assert.match(e,/continent:\s*continentArabic/); assert.match(e,/region:\s*regionArabic/); assert.match(e,/fallbackFact/);
  assert.match(cm,/COUNTRY_CAPITALS_AR/); assert.match(cm,/COUNTRY_FACTS_AR/); assert.match(cm,/enrichCountryCard/);
  assert.match(challenge,/countryInfo/); assert.match(challenge,/target\.countryInfo/);
});

test('16 maps: separate Asia/Europe/Eurasia, Russia handling, pan/zoom and relief rendering hooks exist', () => {
  const g=source('src/data/geography.js'), m=source('src/components/maps/ProfessionalMap.jsx');
  for (const key of ['asia','europe','eurasia']) assert.match(g,new RegExp(`${key}:\\s*\\{`));
  assert.match(g,/RUS/); assert.match(m,/zoom/); assert.match(m,/mapStyle/); assert.match(m,/relief/);
});

test('17 blank map: text labels disappear while continuous latitude/longitude lines remain', () => {
  const m=source('src/components/maps/ProfessionalMap.jsx'), c=css();
  assert.match(m,/displayMode !== 'blank' && <text/); assert.match(c,/stroke-dasharray:none!important/); assert.match(c,/project06-reference-line/);
  assert.match(m,/!silent && \(placement\.showLabel \|\| placement\.type === "custom-label"\) && \(/);
});

test('18 rivers: geographic paths use main/tributary/delta weights with no neon filter', () => {
  const c=css(), d=source('src/data/project06TeachingMaps.js');
  assert.match(c,/project06-river-group\.main[\s\S]*?stroke-width:2\.25px!important/); assert.match(c,/project06-river-group\.tributary[\s\S]*?1\.18px!important/);
  assert.match(c,/project06-river-line\{[^}]*filter:none!important/); assert.match(d,/kind: 'tributary'/); assert.match(d,/kind: 'main'/);
});

test('19 Nile/Egypt: southern border, Nasser, Aswan, Cairo, Delta, Rosetta and Damietta mouths are represented', () => {
  const d=source('src/data/project06TeachingMaps.js');
  for (const t of ['[32.90, 22.00]','lake-nasser','aswan','cairo','delta','rosetta-mouth','damietta-mouth']) assert.ok(d.includes(t),t);
});

test('20 Nile basin: full Kagera→Victoria→Albert→Jebel→White Nile plus Sobat/Ghazal/Blue Nile/Tana/Atbara sequence exists', () => {
  const d=source('src/data/project06TeachingMaps.js');
  for (const id of ['kagera','victoria-nile','albert-nile','bahr-jebel','bahr-ghazal','sobat','white-nile','blue-nile','atbara','main-nile','tana']) assert.match(d,new RegExp(`(?:id: '${id}'|id: \\"${id}\\")`),id);
});

test('21 curriculum maps: the five agreed teaching categories and physical/economic layers are defined centrally', () => {
  const g=source('src/data/geography.js');
  for (const key of ['terrain','water','resources','political','landmarks']) assert.match(g,new RegExp(`${key}:`));
  for (const layer of ['mountains','plateaus','plains','deserts','rivers','lakes','seas','oceans','gulfs','straits','canals','minerals','energy','ports']) assert.match(g,new RegExp(`${layer}`));
});

test('22 Egypt: deserts, Sinai, Red Sea mountains, St Catherine, depressions, resources, energy and ports exist', () => {
  const g=source('src/data/geography.js');
  for (const t of ['الصحراء الشرقية','الصحراء الغربية','شبه جزيرة سيناء','جبال البحر الأحمر','جبل سانت كاترين','منخفض القطارة','بترول خليج السويس','حقل ظهر','ميناء الإسكندرية']) assert.ok(g.includes(t),t);
});

test('23 map symbols: select/tap placement, move/resize/duplicate/delete, touch and selected hint are wired', () => {
  const s=source('src/components/maps/LessonMapStudio.jsx');
  assert.match(s,/selectedSymbol/); assert.match(s,/handleStageClick/); assert.match(s,/onMovePlacement/); assert.match(s,/onResizePlacement/); assert.match(s,/onDuplicatePlacement/); assert.match(s,/onRemovePlacement/); assert.match(s,/onPointerMove/); assert.match(s,/lesson-map-selected-symbol-hint/);
});

test('24 Map Challenge: real Fullscreen API, compact floating selectors, no drawing tools and full region set', () => {
  const s=source('src/pages/MapChallenge.jsx'), c=css();
  for (const key of ['egypt','arab','africa','nile','asia','europe','eurasia','northAmerica','southAmerica','australia']) assert.match(s,new RegExp(`\"${key}\"`));
  assert.match(s,/requestFullscreen/); assert.match(s,/exitFullscreen/); assert.match(s,/fullscreenchange/);
  assert.match(s,/map-game-floating-selectors/); assert.match(s,/closeFloatingPickers/); assert.match(c,/map-game-floating-menu/); assert.match(c,/map-challenge-fullscreen/);
  assert.doesNotMatch(s,/className="map-game-toolbar"/); assert.match(s,/map-challenge-view-controls/); assert.match(s,/map-game-question-panel \${!started \? "is-setup"/);
  assert.match(s,/Math\.min\(3\.2/); assert.match(source('src/components/maps/ProfessionalMap.jsx'),/onWheel=\{handleMapWheel\}/); assert.match(source('src/components/maps/ProfessionalMap.jsx'),/pinchRef/);
  assert.doesNotMatch(s,/drawTool|PenLine|Highlighter|classmode-toolbar/);
});
test('25 dashboard paths: class, schedule, Mobdea Online and Online Class have distinct navigate targets', () => {
  const d=source('src/pages/Dashboard.jsx');
  for (const route of ['classMode','sessions','mobdeaOnline','onlineClass']) assert.match(d,new RegExp(`navigate\\('${route}'\\)`));
  assert.doesNotMatch(d,/mobdeaOnline[\s\S]{0,120}navigate\('classMode'\)/);
  assert.doesNotMatch(d,/onlineClass[\s\S]{0,120}navigate\('classMode'\)/);
});

test('26 OCR/Question Bank: manual remains, OCR is on-demand, review/save targets shared customQuestionBank and ClassMode OCR bridge is dynamic', () => {
  const q=source('src/pages/QuestionBankManager.jsx'), l=source('src/pages/ContentLibrary.jsx'), s=classMode();
  assert.match(q,/\+ سؤال جديد/); assert.match(q,/ocrPanelOpen/); assert.match(q,/customQuestionBank/);
  assert.match(l,/OcrQuestionReview/); assert.match(l,/ocrReviewQuestions/); assert.match(l,/customQuestionBank/); assert.match(l,/import\("\.\.\/services\/pdfQuestionOcr"\)/);
  assert.match(s,/await import\('\.\.\/services\/r20PageOcrPipeline\.js'\)/);
});

test('27 performance: heavy features are lazy, caches bounded, offscreen list rendering contained and heavy views memoized', () => {
  const main=source('src/main.jsx'), s=classMode(), media=source('src/components/classmode/MediaRenderer.jsx'), map=source('src/components/maps/ProfessionalMap.jsx'), c=css();
  assert.match(main,/lazyRuntimeRules/); assert.match(main,/mutation\.addedNodes/);
  assert.match(s,/lazy\(\(\) => import\("\.\.\/components\/maps\/LessonMapStudio"\)\)/); assert.match(s,/MemoCanvasOverlay/);
  assert.match(media,/export default memo\(MediaRenderer/); assert.match(map,/export default memo\(ProfessionalMap/);
  assert.match(c,/content-visibility:auto!important/); assert.match(source('src/components/classmode/PdfCanvasPreview.jsx'),/MAX_PDF_CACHE/);
});

test('28 execution: final package marker exists; source/data validation is separate from device runtime verification', () => {
  const main=source('src/main.jsx'), c=css();
  assert.match(main,/__MOBDEA_V8_FINAL_REAL_REVIEWED__/); assert.match(c,/FINAL_DEEP_AUDIT_FULL_CUMULATIVE/);
  assert.match(main,/ocrDeviceRuntimeRequiresCodespace:\s*true/);
});
