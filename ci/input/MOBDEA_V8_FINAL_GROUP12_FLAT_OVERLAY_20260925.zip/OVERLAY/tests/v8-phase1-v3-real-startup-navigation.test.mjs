import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';
import vm from 'node:vm';
import { sessionsForToday } from '../src/services/dashboardSchedule.js';
const read = (path) => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');

test('pre-React recovery page does not erase data or local storage', () => {
  const text = read('public/mobdea-boot-guard.js');
  assert.doesNotMatch(text, /localStorage|indexedDB|caches\.delete|innerHTML|document\.write/);
  const listeners = {};
  const doc = { readyState: 'complete', body: { append: () => {} }, addEventListener: (key, fn) => { listeners[key] = fn; }, getElementById: () => null };
  const win = { addEventListener: (key, fn) => { listeners[key] = fn; }, location: { reload: () => {} } };
  let timeout;
  vm.runInNewContext(text, { document: doc, window: win, setTimeout: (fn) => { timeout = fn; return 1; }, clearTimeout: () => {} });
  assert.equal(typeof timeout, 'function');
  assert.equal(typeof listeners['mobdea:app-mounted'], 'function');
  listeners['mobdea:app-mounted']();
  timeout();
});

test('both teacher dashboard actions use dedicated route handlers and honest session time', () => {
  const dashboard = read('src/pages/Dashboard.jsx');
  assert.match(dashboard, /const startClassNow = \(\) => navigate\('classMode'\)/);
  assert.match(dashboard, /const openFullSchedule = \(\) => navigate\('sessions'\)/);
  assert.match(dashboard, /currentSession\?\.time \? formatTime12\(currentSession\.time\)/);
  assert.doesNotMatch(dashboard, /2120/);
});

test('route changes guard both valid ids and role allowlist', () => {
  const app = read('src/App.jsx');
  assert.match(app, /if \(!KNOWN_ROUTES\.has\(destination\)\) return false/);
  assert.match(app, /if \(allowed && !allowed\.has\(destination\)\) return false/);
  assert.match(app, /window\.dispatchEvent|globalThis\.dispatchEvent/);
});

test('global-search index and dashboard code are deferred until needed', () => {
  const shell = read('src/components/AppShell.jsx');
  const app = read('src/App.jsx');
  assert.match(shell, /searchOpen && <Suspense/);
  assert.match(shell, /lazy\(\(\) => import\('\.\/GlobalSearch'\)\)/);
  assert.match(app, /const Dashboard = lazy\(\(\) => import\("\.\/pages\/Dashboard"\)\)/);
});

test('browser boot diagnostics load before the app and layout overrides after V8', () => {
  const index = read('index.html');
  const main = read('src/main.jsx');
  assert.ok(index.indexOf('mobdea-boot-guard.js') < index.indexOf('src/main.jsx'));
  assert.ok(main.indexOf("v8-phase1-route-layout.css") > main.indexOf("v8-section-52-navigation.css"));
});

test('today schedule excludes wrong weekdays and keeps explicitly dated classes', () => {
  const sessions = [
    { id: 1, day: 'الاثنين' }, { id: 2, day: 'الأربعاء' },
    { id: 3, date: '2026-09-23' }, { id: 4, date: '2026-09-21', current: true },
    { id: 5, day: 'wednesday' }, { id: 6, current: true },
  ];
  assert.deepEqual(sessionsForToday(sessions, '2026-09-23', 3).map((row) => row.id), [2, 3, 5, 6]);
  assert.deepEqual(sessionsForToday(sessions, 'broken', 3), []);
});
