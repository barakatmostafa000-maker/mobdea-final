import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { test } from 'node:test';

// Evaluate the actual studentPinPolicy implementation while injecting only its
// native/security/cloud dependencies; no duplicate implementation or text-only
// assertion of feature names is involved in these tests.
const original = await readFile(new URL('../src/services/studentPinPolicy.js', import.meta.url), 'utf8');
const source = original
  .replace(/^import \{ createCredentialSecret, hasCredentialSecret, normalizePin, verifyCredentialSecret \} from '\.\.\/utils\/security';\s*/m, 'const { createCredentialSecret, hasCredentialSecret, normalizePin, verifyCredentialSecret } = globalThis.__pinTestDeps;\n')
  .replace(/^import \{ cloudConfigured, pushCloudData \} from '\.\/cloudSync';\s*/m, 'const { cloudConfigured, pushCloudData } = globalThis.__pinTestDeps;\n');
assert.notEqual(source, original, 'The real policy module must be loaded');
assert.ok(!/^import\s/m.test(source), 'Unexpected dependency left in isolated module');
let cloudPush;
let credentialCreates;
let cloudCalls;
globalThis.__pinTestDeps = {
  createCredentialSecret: async (pin) => { credentialCreates++; return { studentCredentialHash: `hashed:${pin}` }; },
  hasCredentialSecret: (student) => Boolean(student.studentCredentialHash),
  normalizePin: (value) => String(value ?? '').trim(),
  verifyCredentialSecret: async (pin, student) => student.studentCredentialHash === `hashed:${pin}`,
  cloudConfigured: (settings) => Boolean(settings.cloudSync?.enabled),
  pushCloudData: async (data) => { cloudCalls++; return cloudPush(data); },
};
const { migrateAllStudentsToUnifiedDefaultPin, STUDENT_PIN_POLICY_VERSION } =
  await import(`data:text/javascript,${encodeURIComponent(source)}`);
const oldData = () => ({
  settings: { studentPinDefaultVersion: 0, cloudSync: { enabled: true } },
  students: [
    { id: 'a', studentPin: '123456' },
    { id: 'b', studentCredentialHash: 'hashed:999999', studentPinChangedByStudentAt: '2026-06-01' },
  ],
});

test('persist new PIN locally before waiting for slow cloud and preserve changed pupil credentials', async () => {
  credentialCreates = 0;
  cloudCalls = 0;
  let finishCloud;
  cloudPush = () => new Promise((resolve) => { finishCloud = resolve; });
  let stored = null;
  let localCommitted = false;
  let migrateFinished = false;
  const progress = migrateAllStudentsToUnifiedDefaultPin(oldData(), async (next) => {
    stored = typeof next === 'function' ? next(stored) : next;
    return stored;
  }, {
    onLocalCommitted: (saved) => { localCommitted = true; assert.equal(saved, stored); },
  }).then((result) => { migrateFinished = true; return result; });
  for (let tick = 0; tick < 200 && !localCommitted; tick++) await new Promise((r) => setTimeout(r, 1));
  assert.equal(localCommitted, true, 'The UI should leave the splash after durable local save');
  assert.equal(migrateFinished, false, 'Cloud must still be pending when local UI unlocks');
  assert.equal(stored.settings.studentPinDefaultVersion, STUDENT_PIN_POLICY_VERSION);
  assert.equal(stored.students[0].studentCredentialHash, 'hashed:12345678');
  assert.equal(stored.students[0].studentPinMustChange, true);
  assert.equal(stored.students[1].studentCredentialHash, 'hashed:999999', 'Preserve an existing changed PIN');
  assert.equal(credentialCreates, 1);
  // The app is now usable. A teacher adds new grades while the previous
  // cloud upload is still pending; finishing it must not restore old data.
  stored = { ...stored, grades: [{ studentId: 'a', score: 20 }],
    settings: { ...stored.settings, cloudSync: { ...stored.settings.cloudSync, localChangedAt: 'new-edit' } } };
  finishCloud({ revision: 'remote-1' });
  const result = await progress;
  assert.equal(result.synced, true);
  assert.deepEqual(result.data.grades, [{ studentId: 'a', score: 20 }]);
  assert.equal(result.data.settings.cloudSync.localChangedAt, 'new-edit',
    'A subsequent unsynced edit must remain marked dirty');
  assert.equal(cloudCalls, 1);
});

test('a rejected local save never unlocks the interface or uploads an unapplied PIN change', async () => {
  credentialCreates = 0;
  cloudCalls = 0;
  cloudPush = async () => ({ revision: 'should-not-run' });
  let localCommitted = false;
  await assert.rejects(
    () => migrateAllStudentsToUnifiedDefaultPin(oldData(), async () => { throw new Error('disk full'); },
      { onLocalCommitted: () => { localCommitted = true; } }), /disk full/,
  );
  assert.equal(localCommitted, false);
  assert.equal(cloudCalls, 0);
});

test('failed cloud upload keeps the locally saved PIN and reports an unsynced state', async () => {
  credentialCreates = 0;
  cloudCalls = 0;
  cloudPush = async () => { throw new Error('offline'); };
  let saved;
  const outcome = await migrateAllStudentsToUnifiedDefaultPin(oldData(), async (next) => {
    saved = next;
    return next;
  }, { onLocalCommitted: () => { assert.equal(saved.students[0].studentPinMustChange, true); } });
  assert.equal(outcome.synced, false);
  assert.equal(outcome.syncError, 'offline');
  assert.equal(saved.settings.studentPinDefaultVersion, STUDENT_PIN_POLICY_VERSION);
});
