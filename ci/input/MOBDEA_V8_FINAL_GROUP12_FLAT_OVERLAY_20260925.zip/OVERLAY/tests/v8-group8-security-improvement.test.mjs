import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import {
  findStudentForAuth, linkedStudentsForGuardian, canStudentAccessResource,
  filterContentLibraryForRole, scopeReadOnlyDataForRole,
} from '../src/services/rolePortalAccess.js';
import { buildMostImprovedRanking, buildClassPointImprovementRanking, buildPointsRanking, buildEvaluationRanking,
  buildExamGroupMessage } from '../src/services/studentEvaluation.js';
import { buildGlobalSearchIndex } from '../src/services/globalSearch.js';

const pupils = [
  { id: 1, code: '111', name: 'ليلى', grade: 'الأول', group: 'مساء', points: 22, studentPinHash: 'SECRET', guardianPin: '222222' },
  { id: 2, code: '222', name: 'مريم', grade: 'الأول', group: 'مساء', points: 10, guardianPhone: '01000000000' },
  { id: 3, code: '333', name: 'عمر', grade: 'الثاني', group: 'مساء', points: 31, guardianPhone: '01000000000' },
];
const data = {
  students: pupils,
  sessions: [ { id: 'one', grade: 'الأول', group: 'مساء' }, { id: 'two', grade: 'الثاني', group: 'مساء' } ],
  grades: [
    { id: 1, studentId: 1, exam: 'الأول', score: 10, total: 20, date: '2026-09-01' },
    { id: 2, studentId: 1, exam: 'الثاني', score: 18, total: 20, date: '2026-09-10' },
    { id: 3, studentId: 2, exam: 'الأول', score: 16, total: 20, date: '2026-09-01' },
    { id: 4, studentId: 2, exam: 'الثاني', score: 18, total: 20, date: '2026-09-10' },
  ],
  contentLibrary: [
    { id: 'private', type: 'lesson', grade: 'الأول', studentVisible: true },
    { id: 'public', type: 'lesson', access: {mode:'public'} },
    { id: 'grade', type: 'lesson', access: {mode:'grade', grade:'الأول'} },
    { id: 'group', type: 'lesson', access: {mode:'group', grade:'الأول', groups:['مساء']} },
    { id: 'private-file', type: 'pdf', lessonId:'grade', assetId:'BOOK' },
    { id: 'inherited-file', type: 'image', lessonId:'grade', inheritLessonAccess:true },
    { id: 'hidden', type: 'lesson', access:{mode:'public'}, published:false },
  ],
};
const student = { role:'student', studentId:1, studentCode:'111' };
const guardian = { role:'guardian', studentIds:[1], guardianPhone:'01000000000' };

test('canonical student match cannot fallback from conflicting id to code', () => {
  assert.equal(findStudentForAuth(data, {role:'student',studentId:2,studentCode:'111'}), null);
  assert.equal(findStudentForAuth(data, student).id, 1);
});
test('ambiguous duplicated codes do not authenticate an arbitrary pupil', () => {
  assert.equal(findStudentForAuth({ students:[...pupils,{id:9,code:'111'}] }, {studentCode:'111'}), null);
});
test('guardian explicit links do not expand by phone matching', () => {
  assert.deepEqual(linkedStudentsForGuardian(data, guardian).map(x => x.id),[1]);
  assert.deepEqual(linkedStudentsForGuardian(data, {role:'guardian', guardianPhone:'01000000000'}),[]);
});
test('unpublished, legacy visible and private lesson attachments stay hidden', () => {
  assert.deepEqual(filterContentLibraryForRole(data,student).map(x=>x.id),['public','grade','group','inherited-file']);
  assert.deepEqual(filterContentLibraryForRole(data,{role:'visitor'}).map(x=>x.id),['public']);
});
test('matching group names in separate grades do not authorize a lesson', () => {
  assert.equal(canStudentAccessResource(data.contentLibrary[3],pupils[2]),false);
});
test('scoped dashboard redacts another child, credentials and unrelated sessions', () => {
  const limited = scopeReadOnlyDataForRole(data, student);
  assert.deepEqual(limited.students.map(x=>x.id),[1]);
  assert.equal(Object.hasOwn(limited.students[0], 'studentPinHash'),false);
  assert.equal(Object.hasOwn(limited.students[0], 'guardianPin'),false);
  assert.deepEqual(limited.sessions.map(x=>x.id),['one']);
});
test('visitor has no students, child sessions or private books', () => {
  const limited = scopeReadOnlyDataForRole(data, {role:'visitor'});
  assert.equal(limited.students.length,0);
  assert.equal(limited.sessions.length,0);
  assert.deepEqual(limited.contentLibrary.map(x=>x.id),['public']);
});
test('most improved is based on distinct chronological exams, not cumulative points', () => {
  const improved = buildMostImprovedRanking(data);
  assert.deepEqual(improved.map(x=>x.student.id),[1,2]);
  assert.equal(improved[0].change,40);
  assert.equal(improved[1].change,10);
  assert.equal(buildMostImprovedRanking(data, 'غائب').length,0);
});
test('only one exam or no valid date is not evidence of improvement', () => {
  assert.deepEqual(buildMostImprovedRanking({ students:pupils, grades:[data.grades[0]] }),[]);
});
test('most improved classroom points compares points earned per lesson, never cumulative balance', () => {
  const withLessons = { ...data, classPointSessions: [
    {id:'a',grade:'الأول',group:'مساء',date:'2026-09-01',earned:{1:1,2:8},points:{1:10,2:20}},
    {id:'b',grade:'الأول',group:'مساء',date:'2026-09-10',earned:{1:7,2:9},points:{1:17,2:29}},
    {id:'c',grade:'الثاني',group:'مساء',date:'2026-09-11',earned:{3:40},points:{3:100}},
  ]};
  const result = buildClassPointImprovementRanking(withLessons);
  assert.deepEqual(result.map((row) => row.student.id), [1,2]);
  assert.equal(result[0].change,6);
  assert.equal(result[1].change,1);
  assert.equal(buildClassPointImprovementRanking({...withLessons,classPointSessions:[withLessons.classPointSessions[0]]}).length,0);
});
test('points ordering differs from cumulative grade ranking', () => {
  assert.deepEqual(buildPointsRanking(data).map(x=>x.student.id),[3,1,2]);
  assert.deepEqual(buildEvaluationRanking(data).map(x=>x.student.id),[2,1]);
});
test('group exam message contains scores and percentages for its pupils only', () => {
  const msg = buildExamGroupMessage(data,{ exam:'الثاني', group:'مساء' });
  assert.match(msg,/ليلى/);assert.match(msg,/مريم/);assert.match(msg,/٩٠%/);
  assert.doesNotMatch(msg,/عمر/);
});
test('PIN gate and library use canonical role identity and never phone/code fallback', () => {
  const gate = readFileSync(new URL('../src/components/StudentPinChangeGate.jsx',import.meta.url),'utf8');
  const library = readFileSync(new URL('../src/pages/ContentLibrary.jsx',import.meta.url),'utf8');
  const preview = readFileSync(new URL('../src/pages/PortalPreview.jsx',import.meta.url),'utf8');
  assert.match(gate,/findStudentForAuth\(data, auth\)/);
  assert.match(library,/findStudentForAuth\(data, auth\)/);
  assert.match(preview,/linkedStudentsForGuardian\(data, auth\)/);
  assert.doesNotMatch(preview,/normalizePhone\(auth\?\.guardianPhone/);
});
test('map challenge does not charge visitor for a map that failed to load', () => {
  const page = readFileSync(new URL('../src/pages/MapChallenge.jsx',import.meta.url),'utf8');
  const portion = page.slice(page.indexOf('const startGame = async () =>'),page.indexOf('answerLockRef.current = false', page.indexOf('const startGame = async () =>')));
  assert.ok(portion.indexOf('if (!geo)') >= 0 && portion.indexOf('if (!geo)') < portion.indexOf("claimVisitorTrial(data.settings, 'maps')"));
  assert.ok(portion.indexOf('if (mode !== \"build\" && items.length === 0)') < portion.indexOf("claimVisitorTrial(data.settings, 'maps')"));
});

test('global search cannot leak private books, unrelated pupils or unpublished teacher exams', () => {
  const guest = buildGlobalSearchIndex(data, {role:'visitor'});
  assert.deepEqual(guest.filter((item) => item.type === 'resource').map((item) => item.title), []);
  const own = buildGlobalSearchIndex({ ...data,
    students: pupils, exams:[{id:1,title:'خطة امتحان سرية'}],
    contentLibrary: [{id:'private',type:'lesson',title:'ملف المعلم الخاص'},
      {id:'public',type:'lesson',title:'ملف عام',access:{mode:'public'}},
      {id:'grade',type:'lesson',title:'درس الأول',access:{mode:'grade',grade:'الأول'}}],
    lessonRecordings: [{id:'private-recording',title:'حصة خاصة',published:false},
      {id:'unlinked',title:'تسجيل غير منشور للطالب',grade:'الثاني'},
      {id:'public-recording',title:'تسجيل عام',access:{mode:'public'}}],
  }, student);
  const titles = own.map((item) => item.title);
  assert.ok(titles.includes('ليلى'));
  assert.ok(titles.includes('ملف عام'));
  assert.ok(titles.includes('درس الأول'));
  assert.ok(titles.includes('تسجيل عام'));
  for (const hidden of ['مريم','عمر','ملف المعلم الخاص','خطة امتحان سرية','حصة خاصة','تسجيل غير منشور للطالب']) {
    assert.ok(!titles.includes(hidden), `exposed ${hidden}`);
  }
});
test('achievements cannot link children by matching guardian phone or show other children reward requests', () => {
  const component = readFileSync(new URL('../src/pages/Achievements.jsx',import.meta.url),'utf8');
  assert.match(component,/linkedStudentsForGuardian\(data, auth\)/);
  assert.match(component,/findStudentForAuth\(data, auth\)/);
  assert.doesNotMatch(component,/guardianPhone === anchor.guardianPhone/);
  assert.match(component,/Boolean\(student\) && String\(item.studentId\) === String\(student.id\)/);
});
