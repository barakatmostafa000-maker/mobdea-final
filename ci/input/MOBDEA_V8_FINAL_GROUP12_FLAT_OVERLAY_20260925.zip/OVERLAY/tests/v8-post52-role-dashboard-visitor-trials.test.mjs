import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

const accessModuleUrl = pathToFileURL(path.join(root, 'src/services/rolePortalAccess.js')).href;
const access = await import(accessModuleUrl);

test('student content is explicit opt-in; private teacher content stays hidden', () => {
  const data = {
    students: [
      { id: 1, code: 1, name: 'أحمد', grade: 'سادس', group: '5 مساءً' },
      { id: 2, code: 2, name: 'نور', grade: 'سادس', group: '7 مساءً' },
    ],
    contentLibrary: [
      { id: 'private', type: 'lesson', grade: 'سادس', title: 'خاص', access: { mode: 'private' } },
      { id: 'grade', type: 'lesson', grade: 'سادس', title: 'للصف', access: { mode: 'grade', grade: 'سادس' } },
      { id: 'group', type: 'lesson', grade: 'سادس', title: 'للمجموعة', access: { mode: 'group', groups: ['5 مساءً'] } },
      { id: 'one', type: 'lesson', grade: 'سادس', title: 'لطالب', access: { mode: 'students', studentIds: ['1'] } },
      { id: 'public', type: 'lesson', grade: 'سادس', title: 'عام', access: { mode: 'public' } },
      { id: 'book', type: 'textbook', grade: 'سادس', title: 'كتاب الصف', access: { mode: 'private' } },
      { id: 'examfile', type: 'exams', grade: 'سادس', title: 'امتحانات خاصة', access: { mode: 'private' } },
    ],
  };
  const auth = { role: 'student', studentId: 1, studentCode: 1 };
  const ids = access.filterContentLibraryForRole(data, auth).map((item) => item.id);
  assert.ok(!ids.includes('private'));
  assert.ok(ids.includes('grade'));
  assert.ok(ids.includes('group'));
  assert.ok(ids.includes('one'));
  assert.ok(ids.includes('public'));
  assert.ok(ids.includes('book'), 'textbook may be retained only as an internal support source for an assigned lesson');
  assert.ok(!ids.includes('examfile'), 'private teacher exam files must never be exposed as lesson support');
  const book = access.filterContentLibraryForRole(data, auth).find((item) => item.id === 'book');
  assert.equal(book.roleSupportOnly, true);
});

test('visitor sees only public content and finite trials', () => {
  const data = { students: [], contentLibrary: [
    { id: 'x', type: 'lesson', access: { mode: 'private' } },
    { id: 'p', type: 'lesson', access: { mode: 'public' } },
  ] };
  assert.deepEqual(access.filterContentLibraryForRole(data, { role: 'visitor' }).map((x) => x.id), ['p']);
  assert.equal(access.VISITOR_TRIAL_LIMITS.games, 5);
  assert.equal(access.VISITOR_TRIAL_LIMITS.maps, 5);
  assert.equal(access.VISITOR_TRIAL_LIMITS.multiplayer, 3);
});

test('Dashboard keeps same branded shell but exposes role-specific cards', () => {
  const source = read('src/pages/Dashboard.jsx');
  for (const token of ['studentActions', 'guardianActions', 'visitorActions', 'dashboard-reference-hero', 'dashboard-visitor-trial-v8', 'filterContentLibraryForRole']) {
    assert.ok(source.includes(token), `missing ${token}`);
  }
  assert.match(source, /درجاتي/);
  assert.match(source, /المصروفات/);
  assert.match(source, /تجربة ألعاب مجانية/);
  assert.match(source, /الاشتراك الكامل/);
});

test('teacher controls publishing/assignment and non-teacher library is filtered', () => {
  const source = read('src/pages/ContentLibrary.jsx');
  for (const token of ['filterContentLibraryForRole', 'accessMode', 'library-access-control-v8', 'خاص بي فقط', 'كل طلاب هذا الصف', 'مجموعات محددة', 'طلاب محددون', 'عام — يظهر للزائر أيضًا']) {
    assert.ok(source.includes(token), `missing ${token}`);
  }
  assert.match(source, /access:\s*\{/);
  assert.match(source, /mode:\s*form\.accessMode/);
});

test('installer enforces Dashboard home and visitor game/map/multiplayer quotas', () => {
  const installer = process.env.V8_PATCH_INSTALLER ? fs.readFileSync(process.env.V8_PATCH_INSTALLER, 'utf8') : read('../apply_to_v8_codespace.py');
  for (const token of [
    "student: 'dashboard'",
    "guardian: 'dashboard'",
    "visitor: 'dashboard'",
    'POST52_VISITOR_GAME_TRIAL_V1',
    'POST52_VISITOR_MAP_TRIAL_V1',
    'POST52_VISITOR_MULTIPLAYER_TRIAL_V1',
    "consumeVisitorTrial('multiplayer')",
    'scopeReadOnlyDataForRole',
    'roleDashboardProfile',
    'gameStudents',
  ]) assert.ok(installer.includes(token), `installer missing ${token}`);
});


test('visible Mobdea Online links for student guardian visitor', () => {
  const dashboard = read('src/pages/Dashboard.jsx');
  const installer = process.env.V8_PATCH_INSTALLER ? fs.readFileSync(process.env.V8_PATCH_INSTALLER, 'utf8') : read('../apply_to_v8_codespace.py');
  assert.match(dashboard, /ROLE_MOBDEA_ONLINE_VISIBLE_V1/);
  assert.match(dashboard, /\['student', 'guardian', 'visitor'\]\.includes\(auth\?\.role\)/);
  for (const token of [
    'https://www.facebook.com/share/1AyBatYgJv/',
    'https://youtube.com/@mostafabarakat21',
    'https://www.tiktok.com/@mostafabarakat210',
    'role-mobdea-online-panel-v8',
    'role-social-link-v8',
  ]) assert.ok(dashboard.includes(token), `Dashboard social token missing: ${token}`);
  assert.match(installer, /ROLE_MOBDEA_ONLINE_PORTAL_VISIBLE_V1/);
  assert.match(installer, /PortalPreview\.jsx/);
});
