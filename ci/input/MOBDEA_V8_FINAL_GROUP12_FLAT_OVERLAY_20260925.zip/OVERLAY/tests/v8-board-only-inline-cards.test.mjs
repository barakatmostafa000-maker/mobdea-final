import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
const root = process.cwd();
const source = readFileSync(join(root,'src/pages/ClassMode.jsx'),'utf8');
const css = readFileSync(join(root,'src/styles/v8-country-cards-verified.css'),'utf8');
test('country and definition cards work on the whiteboard and on PDF/image/PPT annotation layers, never on video/audio/maps',()=>{
  // The previous board-only expectation contradicted checklist items 10 and 17.
  // Verify the *actual* content-mode guard and placement wiring, rather than
  // making the board-only implementation pass when media cards are missing.
  assert.match(source, /const canPlaceLessonCards = contentMode === "board" \|\| Boolean\(/);
  assert.match(source, /displayResource && \["pdf", "images", "slides"\]\.includes\(contentMode\)/);
  assert.match(source, /\{canPlaceLessonCards && \(\s*<button\s+type="button"\s+className="v8-country-card-direct-toggle"/);
  assert.match(source, /\{canPlaceLessonCards && cardsDrawerOpen && \(\s*<aside\s+className="classmode-card-drawer"/);
  assert.match(source, /if \(!canPlaceLessonCards\) return;\s*const card = getCountryCard/);
  assert.match(source, /if \(!canPlaceLessonCards\) return;\s*const template = BOARD_CARD_TEMPLATE_MAP/);
  assert.match(source, /onAddCountryCard=\{canPlaceLessonCards \? addCountryCard : undefined\}/);
  assert.match(source, /onAddCard=\{canPlaceLessonCards \? addBoardCard : undefined\}/);
  assert.match(source, /if \(canPlaceLessonCards\) \{\s*for \(const card of boardActions\.filter/);
  assert.match(source, /\["pdf", "images", "slides"\]\.includes\(contentMode\)\)\) && \(\s*<MemoCanvasOverlay/);
});

test('definition editing replaces text inside the template body area rather than prompting or creating an overlay textbox',()=>{
  const overlay=source.slice(source.indexOf('function BoardCardOverlay('),source.indexOf('async function drawBoardCardToCanvas('));
  assert.doesNotMatch(overlay,/window\.prompt/);
  assert.match(overlay,/className=\{`\$\{fieldClass\} board-card-field-editor`\}/);
  assert.match(overlay,/onChange=\{\(event\) => onChange\(\{/);
  assert.match(overlay,/fieldKey=\{field\.key\}/);
  assert.match(overlay,/event\.target\?\.closest\?\.\("textarea,input,button,\.board-card-resize-handle"\)/);
  assert.match(css,/data-card-template="geographical-term".*data-card-field="body"/);
  assert.match(css,/data-card-template="historical-term".*data-card-field="body"/);
  assert.match(css,/background:#fff4d5!important/);
  assert.match(css,/overflow-y:auto!important/);
});
test('country name/facts and definition fields use measured font fitting and their original in-card coordinates',()=>{
  assert.match(source,/function useAutoFitCardField/);
  assert.match(source,/node\.scrollWidth <= width \+ 1 && node\.scrollHeight <= height \+ 1/);
  assert.match(source,/className="v8-country-card-title"\s+style=\{\{ direction: "rtl" \}\}/);
  assert.match(source,/x: 44, y: 32\.5, w: 48, h: 8\.8/);
  assert.match(source,/key: "body",\s*label: "التعريف",[\s\S]*?replacePrintedLabel: true/);
  assert.match(css,/font-size:var\(--v7-card-field-font, 18px\)!important/);
});
test('when legacy term images are absent, fallback artwork exists and is used for screen and canvas export',()=>{
  for(const kind of ['geographical','historical']) {
    const path=join(root,`public/whiteboard/cards/v8-${kind}-term-fallback.svg`);
    assert.ok(existsSync(path),path);
    const asset=readFileSync(path,'utf8');
    assert.match(asset,/xmlns="http:\/\/www\.w3\.org\/2000\/svg"/);
    assert.match(source,new RegExp(`assetFallback: "/whiteboard/cards/v8-${kind}-term-fallback\\.svg"`));
  }
  assert.match(source,/frame = await dataUrlToImage\(template\.assetFallback\)/);
});
