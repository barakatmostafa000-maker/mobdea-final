import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');
const exists = (rel) => fs.existsSync(path.join(root, rel));

const layoutHooks = {
  'src/pages/Dashboard.jsx': 'dashboard-page-v8',
  'src/pages/Students.jsx': 'students-page-v8',
  'src/pages/Sessions.jsx': 'sessions-page-v8',
  'src/pages/Attendance.jsx': 'attendance-page-v8',
  'src/pages/GradeScanner.jsx': 'grade-scanner-page-v8',
  'src/pages/ResultDetails.jsx': 'result-details-page-v8',
  'src/pages/Grades.jsx': 'grades-page-v8',
  'src/pages/Payments.jsx': 'payments-page-v8',
  'src/pages/Games.jsx': 'games-page-v8',
  'src/pages/Achievements.jsx': 'achievements-page-v8',
  'src/pages/MapChallenge.jsx': 'map-challenge-pro',
  'src/pages/Messages.jsx': 'messages-page-v8',
  'src/pages/Reports.jsx': 'reports-page-v8',
  'src/pages/ContentLibrary.jsx': 'content-library-page-v8',
  'src/pages/SmartAssistant.jsx': 'smart-assistant-page-v8',
  'src/pages/Updates.jsx': 'updates-page-v8',
  'src/pages/PortalPreview.jsx': 'portal-page-v8',
  'src/pages/QuestionBankManager.jsx': 'question-bank-page-v8',
  'src/pages/StudentCards.jsx': 'student-cards-page-v8',
  'src/pages/Settings.jsx': 'settings-page-v8',
  'src/pages/Whiteboard.jsx': 'standalone-whiteboard-page-v8',
  'src/pages/ClassMode.jsx': 'classmode-scene',
  'src/pages/MobdeaOnlineHub.jsx': 'mobdea-online-page-v8',
  'src/pages/DeviceDiagnostics.jsx': 'diagnostics-page-v8',
};

test('post52-01: every working page has its tablet-layout hook', () => {
  for (const [rel, token] of Object.entries(layoutHooks)) {
    assert.ok(exists(rel), `missing ${rel}`);
    assert.match(read(rel), new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')), `${rel} missing ${token}`);
  }
  const css = read('src/styles/v8-final-real.css');
  for (const token of ['attendance-page-v8','mobdea-online-page-v8','diagnostics-page-v8','mobdea-tablet-classmode-runtime','classmode-user-fullscreen','classmode-board-tools-toggle']) {
    assert.ok(css.includes(token), `CSS missing ${token}`);
  }
});

test('post52-02: student default PIN is exactly 12345678 and reset re-forces change', () => {
  const policy = read('src/services/studentPinPolicy.js');
  const students = read('src/pages/Students.jsx');
  assert.ok(policy.includes("DEFAULT_STUDENT_PIN = '12345678'"));
  assert.ok(policy.includes('STUDENT_PIN_POLICY_VERSION = 2'));
  assert.ok(policy.includes('migrateAllStudentsToUnifiedDefaultPin'));
  assert.ok(policy.includes('resetStudentPinToDefault'));
  assert.ok(policy.includes('studentPinMustChange: true'));
  assert.ok(policy.includes('studentPinChangedByStudentAt'));
  assert.ok(students.includes('PIN 12345678'));
  assert.ok(!students.includes('PIN 123456</button>'));
});

test('post52-03: startup migration + first-login gate enforce personal PIN change', () => {
  const app = read('src/App.jsx');
  const gate = read('src/components/StudentPinChangeGate.jsx');
  assert.ok(app.includes('POST52_UNIFIED_STUDENT_PIN_STARTUP_MIGRATION_V2'));
  assert.ok(app.includes('migrateAllStudentsToUnifiedDefaultPin'));
  assert.ok(app.includes('needsUnifiedStudentPinMigration'));
  assert.ok(app.includes('studentPinPolicyBusy'));
  assert.ok(app.includes('POST52_STUDENT_PIN_CHANGE_GATE_V1'));
  assert.ok(app.includes('pinGateStudent?.studentPinMustChange'));
  assert.ok(app.includes('<StudentPinChangeGate'));
  assert.ok(gate.includes('changeStudentPinAfterLogin'));
  assert.ok(gate.includes('لا يمكن استخدام الرمز الأساسي 12345678'));
});

test('post52-04: Mobdea Online is a branded three-social-page hub', () => {
  const app = read('src/App.jsx');
  const hub = read('src/pages/MobdeaOnlineHub.jsx');
  const shell = read('src/components/AppShell.jsx');
  assert.match(app, /mobdeaOnline:\s*MobdeaOnlineHub/);
  assert.ok(hub.includes("import { identity }"));
  for (const social of ['facebook','youtube','tiktok']) assert.ok(hub.includes(`id: '${social}'`));
  assert.ok(hub.includes('https://www.facebook.com/share/1AyBatYgJv/'));
  assert.ok(hub.includes('https://youtube.com/@mostafabarakat21'));
  assert.ok(hub.includes('https://www.tiktok.com/@mostafabarakat210'));
  assert.ok(hub.includes('المُبدع أونلاين'));
  assert.ok(shell.includes("['mobdeaOnline', 'المبدع أونلاين'"));
});

test('post52-05: online class route, HTTPS student links, WebRTC screen/audio are wired', () => {
  const app = read('src/App.jsx');
  const shell = read('src/components/AppShell.jsx');
  const klass = read('src/pages/ClassMode.jsx');
  const live = read('src/services/liveClass.js');
  const teacher = read('src/components/live/TeacherLivePanel.jsx');
  assert.match(app, /onlineClass:\s*ClassMode/);
  assert.ok(app.includes('onlineEntry: true'));
  assert.ok(shell.includes("active === 'onlineClass'"));
  assert.ok(klass.includes('onlineEntryHandledRef'));
  assert.ok(klass.includes('TeacherLivePanel'));
  assert.ok(live.includes('buildLiveStudentLink'));
  assert.ok(live.includes("shareKind"))
  assert.ok(live.includes('createLiveRoom'));
  assert.ok(teacher.includes('RTCPeerConnection'));
  assert.ok(teacher.includes('startTeacherAudio'));
  assert.ok(teacher.includes('startScreenShare'));
  assert.ok(teacher.includes('copyRoomLink'));
});

test('post52-06: games support actual multiplayer room/link/questions/answers/scoreboard', () => {
  for (const rel of ['src/components/live/OnlineGameHostPanel.jsx','src/components/live/StudentOnlineGameRoom.jsx','src/services/gameRooms.js','src/pages/SharedAccess.jsx']) assert.ok(exists(rel), `missing ${rel}`);
  const games = read('src/pages/Games.jsx');
  const host = read('src/components/live/OnlineGameHostPanel.jsx');
  const student = read('src/components/live/StudentOnlineGameRoom.jsx');
  assert.ok(games.includes('<OnlineGameHostPanel'));
  assert.ok(host.includes('createOnlineGameRoom'));
  assert.ok(host.includes('makeStudentLink'));
  assert.ok(host.includes('scoreboard'));
  assert.ok(student.includes('joinLiveRoom'));
  assert.ok(student.includes("type: 'game-answer'"));
  assert.ok(student.includes('scoreboard'));
});

test('post52-07: tablet class mode is literal viewport fullscreen with audio/wake/orientation hardening', () => {
  const runtime = read('src/services/v8TabletRuntime.js');
  const main = read('src/main.jsx');
  const klass = read('src/pages/ClassMode.jsx');
  const css = read('src/styles/v8-final-real.css');
  assert.ok(main.includes('installTabletRuntime'));
  assert.ok(runtime.includes("navigator.wakeLock?.request"));
  assert.ok(runtime.includes('speechSynthesis?.resume'));
  assert.ok(runtime.includes("orientation?.lock?.('landscape')"));
  assert.ok(klass.includes('activateClassModeTabletRuntime'));
  assert.ok(klass.includes('reinforceClassModeFullscreen'));
  assert.ok(klass.includes('requestFullscreen || node.webkitRequestFullscreen'));
  assert.ok(css.includes('height:100dvh!important'));
  assert.ok(css.includes('position:fixed!important'));
  const nativeMain = 'android/app/src/main/java/com/mobdea/education/MainActivity.java';
  if (exists(nativeMain)) {
    const native = read(nativeMain);
    assert.ok(native.includes('POST52_MOBDEA_TABLET_IMMERSIVE_V1'));
    assert.ok(native.includes('SYSTEM_UI_FLAG_IMMERSIVE_STICKY'));
    assert.ok(native.includes('setKeepScreenOn(true)'));
    assert.ok(native.includes('setMediaPlaybackRequiresUserGesture(false)'));
  }
});

test('post52-08: whiteboard and ClassMode tools expose professional Arabic fonts/colors/sizes', () => {
  const board = read('src/pages/Whiteboard.jsx');
  const klass = read('src/pages/ClassMode.jsx');
  for (const font of ['Noto Naskh Arabic','Aref Ruqaa','Noto Kufi Arabic','Amiri','Reem Kufi']) {
    assert.ok(board.includes(font), `Whiteboard missing ${font}`);
    assert.ok(klass.includes(font), `ClassMode missing ${font}`);
  }
  for (const color of ['#111827','#ffffff','#2563eb','#06b6d4','#16a34a','#facc15','#f97316','#dc2626','#ec4899','#7c3aed']) {
    assert.ok(board.includes(color), `Whiteboard missing ${color}`);
    assert.ok(klass.includes(color), `ClassMode missing ${color}`);
  }
  assert.ok(board.includes('eraser: [16, 24, 32, 48, 64, 80, 104]'));
  assert.ok(klass.includes('eraser: [24, 32, 40, 52, 64, 80]'));
  assert.ok(klass.includes('DRAW_TOOL_SIZE_LABELS'));
  assert.ok(klass.includes('fontAvailability'));
});

test('post52-09: class-mode navigation remains independent from resource and PDF navigation', () => {
  const klass = read('src/pages/ClassMode.jsx');
  for (const token of ['classmode-user-navigation','selectClassModeNavigation','cycleModeResource','classmode-media-edge-nav','classmode-pdf-edge-nav','classmode-board-tools-toggle']) assert.ok(klass.includes(token), `missing ${token}`);
});
