import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { patchOcrReviewQuestion, approvedOcrQuestions, persistApprovedOcrQuestions } from '../src/services/ocrReviewWorkflow.js';
import { buildOcrImportCandidates, isQuestionReadyForGame } from '../src/services/project08QuestionImport.js';
import { structureOcrQuestions } from '../src/services/ocrQuestionParser.js';
import { prepareManualGameQuestion } from '../src/services/manualQuestionEntry.js';
import { mergeQuestionBanks, sanitizeQuestion } from '../src/services/assessment.js';
import { getRoleModules } from '../src/utils/auth.js';
import { sessionsForToday } from '../src/services/dashboardSchedule.js';
import { createBoundedAsyncCache } from '../src/services/boundedAsyncCache.js';
import { pdfNeighborPages } from '../src/services/v8PdfPreloadPlan.js';

const read = (name) => readFileSync(new URL('../src/' + name, import.meta.url), 'utf8');
const proposed = {
  id: 'ocr-1', type: 'mcq', text: 'ما عاصمة مصر؟', options: ['القاهرة', 'دمشق', 'الرياض'],
  answer: 'القاهرة', answerIndex: 0, needsAnswer: false, approved: false, gradeKey: '6',
};

test('43: OCR review cannot auto-approve an unverified answer', () => {
  const noAnswer = { ...proposed, answer: '', answerIndex: -1 };
  assert.equal(patchOcrReviewQuestion(noAnswer, { approved: true }).approved, false);
  assert.equal(isQuestionReadyForGame(noAnswer), false);
});

test('43: teacher can approve a correct OCR answer (regression for previously unclickable checkbox)', () => {
  const approved = patchOcrReviewQuestion(proposed, { approved: true });
  assert.equal(approved.approved, true);
  assert.equal(approvedOcrQuestions([approved], []).length, 1);
});

test('43: changing options invalidates approval and answer index unless still matching', () => {
  const approved = patchOcrReviewQuestion(proposed, { approved: true });
  const changed = patchOcrReviewQuestion(approved, { options: ['الإسكندرية', 'الرياض'] });
  assert.equal(changed.approved, false);
  assert.equal(changed.answerIndex, -1);
  assert.equal(isQuestionReadyForGame(changed), false);
});

test('43: a teacher can correct OCR answer, then re-approve for games', () => {
  const corrected = patchOcrReviewQuestion({ ...proposed, answer: '', answerIndex: -1 }, { answer: 'الرياض' });
  assert.equal(corrected.answerIndex, 2);
  assert.equal(corrected.approved, false);
  assert.equal(patchOcrReviewQuestion(corrected, { approved: true }).approved, true);
});

test('43: failed persistence never reports saved ids or drops review queue', async () => {
  const approved = patchOcrReviewQuestion(proposed, { approved: true });
  await assert.rejects(persistApprovedOcrQuestions([approved], [], async () => { throw Error('disk full'); }), /disk full/);
  assert.equal(approved.approved, true);
});

test('43: durable callback gets only approved and deduplicated game-ready questions', async () => {
  const approved = patchOcrReviewQuestion(proposed, { approved: true });
  let saved = [];
  const ids = await persistApprovedOcrQuestions([approved, approved, { ...approved, id: 'other', answerIndex: -1 }], [], async (rows) => { saved = rows; });
  assert.deepEqual(ids, ['ocr-1']);
  assert.equal(saved.length, 1);
  assert.equal(saved[0].needsAnswer, false);
});

test('43: Arabic question text is parsed then reviewed; missing answers are not invented', () => {
  const parsed = structureOcrQuestions('1. ما عاصمة مصر؟\nأ. القاهرة\nب. دمشق\nج. الرياض');
  assert.ok(parsed.questions.length > 0);
  const candidates = buildOcrImportCandidates(parsed.questions, { gradeKey: '6', grade: 'السادس' });
  assert.ok(candidates.length > 0);
  assert.equal(candidates[0].approved, false);
  assert.equal(isQuestionReadyForGame(candidates[0]), false);
});

test('44: manual question with matching explicit answer enters same custom bank and game pool', () => {
  const result = prepareManualGameQuestion({ gradeKey: '6', grade: 'السادس', type: 'mcq', text: 'ما عاصمة مصر؟', optionsText: 'القاهرة\nدمشق\nالرياض', answer: 'القاهرة', answerIndex: 0 }, 'manual-001');
  assert.equal(result.error, undefined);
  const bank = mergeQuestionBanks([], [result.question]);
  assert.equal(bank.length, 1);
  assert.equal(bank[0].id, 'manual-001');
  assert.ok(isQuestionReadyForGame(bank[0]));
});

test('44: incomplete manual answers are rejected independently of OCR', () => {
  const result = prepareManualGameQuestion({ type: 'mcq', text: 'من؟', optionsText: 'أ\nب', answer: '' }, 'manual-002');
  assert.ok(result.error);
});

test('44: sanitizing an unanswered question never assigns first option as correct', () => {
  const missing = sanitizeQuestion({ type: 'mcq', text: 'أين؟', options: ['هنا', 'هناك'], answer: '' });
  assert.equal(missing.answerIndex, -1);
  assert.equal(isQuestionReadyForGame(missing), false);
});

test('42: online class and local class are separate route identifiers and not staff-only in student set', () => {
  assert.notEqual('classMode', 'onlineClass');
  assert.equal(getRoleModules('student').has('classMode'), false);
  assert.equal(getRoleModules('student').has('onlineClass'), true);
  assert.equal(getRoleModules('visitor').has('classMode'), false);
  assert.equal(getRoleModules('visitor').has('onlineClass'), false);
});

test('41: today schedule does not silently show another day', () => {
  const sample = [
    { id: 'today', day: 'الأربعاء' }, { id: 'other', day: 'الخميس' },
    { id: 'date', date: '2026-09-23' }, { id: 'old', date: '2026-09-24' },
  ];
  assert.deepEqual(sessionsForToday(sample, '2026-09-23', 3).map(x => x.id), ['today', 'date']);
});

test('45: bounded PDF page cache evicts an old result instead of growing without limit', async () => {
  const cache = createBoundedAsyncCache({ maxEntries: 2, maxCharacters: 100 });
  await cache.get('one', async () => ({ dataUrl: 'A'.repeat(60) }));
  await cache.get('two', async () => ({ dataUrl: 'B'.repeat(60) }));
  assert.equal(cache.stats().size, 1);
  await cache.get('three', async () => ({ dataUrl: 'C'.repeat(20) }));
  assert.ok(cache.stats().size <= 2);
});

test('45: adjacent PDF preload never leaves the book', () => {
  assert.deepEqual(pdfNeighborPages(1, 2), [2]);
  assert.deepEqual(pdfNeighborPages(2, 2), [1]);
  assert.deepEqual(pdfNeighborPages(99, 2), []);
});

test('41/42: real CTAs use separate routes', () => {
  const s = read('pages/Dashboard.jsx');
  assert.match(s, /startClassNow\s*=\s*\(\)\s*=>\s*navigate\('classMode'\)/);
  assert.match(s, /openFullSchedule\s*=\s*\(\)\s*=>\s*navigate\('sessions'\)/);
  assert.match(s, /id:\s*'onlineClass'.*?الحصة الأونلاين/);
});

test('43/44: OCR upload and review are wired to the same bank used by games', () => {
  const comp = read('components/questions/Project08ExamOcrImport.jsx');
  const bank = read('pages/QuestionBankManager.jsx');
  const games = read('pages/Games.jsx');
  assert.match(comp, /accept="image\/\*,application\/pdf,\.pdf"/);
  assert.match(comp, /patchOcrReviewQuestion/);
  assert.match(comp, /await persistApprovedOcrQuestions/);
  assert.match(bank, /onImport=\{async \(accepted\) =>/);
  assert.match(bank, /customQuestionBank:\s*\[\.\.\.prior,\s*\.\.\.fresh\]/);
  assert.match(bank, /prepareManualGameQuestion/);
  assert.match(games, /mergeQuestionBanks\(questionBank, data\.customQuestionBank \|\| \[\]\)/);
});

test('46: errors show a recovery UI without deleting storage or navigating through white screen', () => {
  const source = read('components/AppErrorBoundary.jsx');
  assert.match(source, /getDerivedStateFromError/);
  assert.match(source, /onReset/);
  assert.match(source, /العودة للرئيسية/);
  assert.doesNotMatch(source, /localStorage\.clear\(|indexedDB\.deleteDatabase\(/);
});

test('52: navigation menu owns eight modes and is separate from file switcher and fullscreen', () => {
  const source = read('pages/ClassMode.jsx');
  for (const mode of ['pdf', 'board', 'maps', 'images', 'videos', 'audio', 'slides', 'games']) {
    assert.match(source, new RegExp('key: "' + mode + '"'));
  }
  assert.match(source, /classmode-mode-navigation-menu/);
  assert.match(source, /classmode-user-fullscreen/);
  assert.match(source, /classmode-section3-switcher/);
  assert.match(source, /classmode-board-tools-toggle/);
});

test('43: PDF OCR inspects actual page count and bounds requested pages before worker setup', () => {
  const browser = read('services/browserExamOcr.js');
  const renderer = read('services/webPdfRenderer.js');
  assert.match(renderer, /export async function getWebPdfPageCount\(/);
  assert.match(browser, /const pageCount = await getWebPdfPageCount\(blob, cacheKey\)/);
  assert.match(browser, /const actualLast = Math\.min\(last, pageCount\)/);
  assert.match(browser, /if \(first > pageCount\) throw/);
});

test('43: OCR review keeps the teacher edits on save failure, and reports rejection to UI', () => {
  const component = read('components/questions/Project08ExamOcrImport.jsx');
  assert.match(component, /catch \(error\) \{\s*\/\/ Do not discard a teacher/);
  assert.match(component, /setRunning\(false\)/);
  assert.match(read('pages/QuestionBankManager.jsx'), /throw error;\s*\}\s*\}/);
});

test('52: mode navigation does not call route navigate or trigger fullscreen when selected', () => {
  const source = read('pages/ClassMode.jsx');
  const nav = source.match(/const selectClassModeNavigation = \(mode\) => \{([\s\S]*?)\n  \};/);
  assert.ok(nav);
  assert.match(nav[1], /switchContentMode\(mode\)/);
  assert.doesNotMatch(nav[1], /navigate\(|toggleFullscreen\(|cycleModeResource\(/);
});
