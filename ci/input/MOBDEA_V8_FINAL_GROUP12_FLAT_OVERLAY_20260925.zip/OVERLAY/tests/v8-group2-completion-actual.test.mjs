import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { isArabicBoardFontAvailable, clearArabicBoardFontProbeCache } from '../src/services/v8BoardFontAvailability.js';

const read = (name) => fs.readFileSync(new URL(`../${name}`, import.meta.url), 'utf8');

test('11: missing font / HTML fallback does not count as a loaded font', async () => {
  const previousFetch = globalThis.fetch;
  try {
    globalThis.fetch = async () => ({ ok: true, headers: { get: () => 'text/html' }, arrayBuffer: async () => new ArrayBuffer(80_000) });
    clearArabicBoardFontProbeCache();
    assert.equal(await isArabicBoardFontAvailable('Noto Naskh Arabic', {fonts:{load: async () => [{}],check:()=>true}}),false);
    globalThis.fetch = async () => ({ ok: false, headers: { get: () => 'application/octet-stream' } });
    clearArabicBoardFontProbeCache();
    assert.equal(await isArabicBoardFontAvailable('Amiri',{fonts:{load: async () => [{}],check:()=>true}}),false);
  } finally { globalThis.fetch=previousFetch; clearArabicBoardFontProbeCache(); }
});

test('11: a valid local binary must also be usable by document.fonts', async () => {
  const previousFetch = globalThis.fetch;
  try {
    const bytes = new Uint8Array(70_000); bytes.set([0,1,0,0],0);
    globalThis.fetch = async () => ({ok:true,headers:{get:()=> 'font/ttf'},arrayBuffer:async()=>bytes.buffer});
    clearArabicBoardFontProbeCache();
    assert.equal(await isArabicBoardFontAvailable('Amiri',{fonts:{load:async()=>[{}], check:()=>true}}),true);
    assert.equal(await isArabicBoardFontAvailable('Amiri',{fonts:{load:async()=>[], check:()=>false}}),false);
  } finally {globalThis.fetch=previousFetch;clearArabicBoardFontProbeCache();}
});

test('10: independent whiteboard layers are hydrated per session and all pages are persisted', () => {
 const text=read('src/pages/Whiteboard.jsx');
 assert.match(text,/String\(record\.sessionId \?\? ''\) !== sessionId/);
 assert.match(text,/Array\.from\(\{ length: lastPage \}/);
 assert.match(text,/const records = pages\.flatMap/);
 assert.match(text,/whiteboardRecords: \[\.\.\.records, \.\.\.old\]/);
 assert.match(text,/storeAsset\(file, \{ name: file\.name, kind: 'whiteboard-image' \}\)/);
});

test('08+10: select, text, shapes, move and eraser use same media overlay', () => {
 const text=read('src/pages/ClassMode.jsx');
 assert.match(text,/\{toolOptions\.map\(\(\{ key, label, icon: Icon \}\) => \(/);
 assert.match(text,/tool=\{canvasTool\}/);
 assert.match(text,/const V8_MEDIA_ANNOTATION_FULL_TOOLS_V2 = true/);
 assert.match(text,/contentLibrary: \(latest\.contentLibrary \|\| \[\]\)\.map/);
 assert.match(text,/sessions: \(latest\.sessions \|\| \[\]\)\.map/);
});

test('12: text editor preserves newlines and leading punctuation instead of normalizing on commit', () => {
 const text=read('src/pages/ClassMode.jsx');
 assert.match(text,/const value = String\(textEditor\?\.value \|\| ''\);/);
 assert.match(text,/if \(!value\.trim\(\)\)/);
 assert.match(text,/event\.ctrlKey \|\| event\.metaKey/);
 assert.match(text,/autoCapitalize="off"/);
});
