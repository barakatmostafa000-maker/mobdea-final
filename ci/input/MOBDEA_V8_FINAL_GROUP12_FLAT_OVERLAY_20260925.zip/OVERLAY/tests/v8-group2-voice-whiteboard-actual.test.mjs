import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { boardTextDirection, boardTextAlignment } from '../src/services/v8BoardTextDirection.js';

const project = (name) => fs.readFileSync(new URL(`../${name}`, import.meta.url), 'utf8');
const voiceText = project('src/services/voice.js');
const boardText = project('src/pages/Whiteboard.jsx');
const classText = project('src/pages/ClassMode.jsx');
const cssText = project('src/styles/v8-group2-voice-whiteboard.css');
const mainText = project('src/main.jsx');
let isolatedVoiceModuleNumber = 0;

async function mockedVoice({ native = false, rejectNative = false } = {}) {
  let nativeCalls = 0; let spoken = []; let cancelled = 0;
  const nativePlugin = {
    stop: async () => true,
    speak: async () => { nativeCalls++; if (rejectNative) throw Error('missing Android voice'); return { ok: true, started: true }; },
  };
  globalThis.__mobdeaMockCapacitor = { isNativePlatform: () => native };
  globalThis.__mobdeaMockNative = nativePlugin;
  globalThis.SpeechSynthesisUtterance = class {
    constructor(text) { this.text = text; this.lang = ''; }
  };
  globalThis.window = {
    setTimeout, clearTimeout, addEventListener() {}, removeEventListener() {},
    speechSynthesis: {
      getVoices() { return [{ name: 'Arabic Egyptian', lang: 'ar-EG' }]; },
      get paused() { return false; },
      resume() {},
      cancel() { cancelled++; },
      speak(utterance) { spoken.push(utterance.text); setTimeout(() => utterance.onstart?.(), 0); },
    },
  };
  const source = voiceText.replace(
    "import { Capacitor, registerPlugin } from '@capacitor/core';",
    'const Capacitor = globalThis.__mobdeaMockCapacitor; const registerPlugin = () => globalThis.__mobdeaMockNative;',
  );
  const url = `data:text/javascript;base64,${Buffer.from(source + `\n// isolated-${++isolatedVoiceModuleNumber}`).toString('base64')}`;
  const voice = await import(url);
  return { voice, get nativeCalls() { return nativeCalls; }, get spoken() { return spoken; }, get cancelled() { return cancelled; } };
}

test('06: Android TTS onStart prevents duplicate browser fallback', async () => {
  const runtime = await mockedVoice({ native: true });
  assert.equal(await runtime.voice.speakArabic('مرحبا', {}), true);
  assert.equal(runtime.nativeCalls, 1);
  assert.deepEqual(runtime.spoken, []);
});

test('06: failed Android TTS falls back to browser ar-EG, and stop cancels it', async () => {
  const runtime = await mockedVoice({ native: true, rejectNative: true });
  assert.equal(await runtime.voice.speakArabic('أهلًا بكم', {}), true);
  assert.deepEqual(runtime.spoken, ['أهلًا بكم']);
  assert.equal(runtime.nativeCalls, 1);
  assert.equal(await runtime.voice.stopArabicSpeech(), true);
  assert.ok(runtime.cancelled >= 2);
});

test('06: muting / zero volume does not enqueue speech on either engine', async () => {
  const runtime = await mockedVoice({ native: true });
  assert.equal(await runtime.voice.speakArabic('لا تنطق', { voiceEnabled: false }), false);
  assert.equal(await runtime.voice.speakArabic('لا تنطق', { voiceVolume: 0 }), false);
  assert.equal(runtime.nativeCalls, 0);
  assert.deepEqual(runtime.spoken, []);
});

test('06: second request prevents obsolete browser response from starting', async () => {
  const runtime = await mockedVoice();
  const first = runtime.voice.speakArabic('الجملة الأولى', {});
  const second = runtime.voice.speakArabic('الجملة الثانية', {});
  assert.equal(await first, false);
  assert.equal(await second, true);
  assert.deepEqual(runtime.spoken, ['الجملة الثانية']);
});

test('07-12: multiline Arabic, Latin and diacritics are not normalized or silently corrected', () => {
  assert.equal(boardTextDirection('السلام عليكم: 2027'), 'rtl');
  assert.equal(boardTextDirection('PDF شرح الدرس'), 'ltr');
  assert.equal(boardTextDirection('123٤٥'), 'rtl');
  assert.equal(boardTextAlignment('English'), 'left');
  assert.ok(boardText.includes('text: enteredText'));
  assert.ok(boardText.includes('textEditor.value'));
  assert.ok(boardText.includes('role="dialog"'));
  assert.ok(!boardText.includes('window.prompt('));
  assert.ok(classText.includes('boardTextDirection(line)'));
});

test('07-12: image backing remains distinct from erasable ink and controls remain reachable', () => {
  assert.match(boardText, /const ink = document\.createElement\('canvas'\)/);
  assert.match(boardText, /ctx\.drawImage\(ink, 0, 0\)/);
  assert.match(boardText, /class-board-history-v14\.jpg/);
  assert.match(classText, /classmode-v8-voice-check/);
  assert.match(classText, /classmode-v8-voice-stop/);
  assert.match(classText, /unsavedBoardLayersRef\.current/);
  assert.match(cssText, /touch-action:manipulation/);
  assert.match(mainText, /v8-group2-voice-whiteboard\.css/);
});
