import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync } from 'node:fs';
const app = readFileSync(new URL('../src/App.jsx', import.meta.url), 'utf8');
const dashboard = readFileSync(new URL('../src/pages/Dashboard.jsx', import.meta.url), 'utf8');
const shell = readFileSync(new URL('../src/components/AppShell.jsx', import.meta.url), 'utf8');
const css = readFileSync(new URL('../src/styles/v8-all-pages-layout.css', import.meta.url), 'utf8');

test('student and guardian are not redirected from their actual dashboard on every entry', () => {
  assert.doesNotMatch(app, /active === ["']dashboard["'] && \[["']student["'], ["']guardian["']\]/);
  assert.match(app, /dashboard: \{ data, navigate: navigateAllowed, auth \}/);
});

test('all linked navigation paths invoke the central role gate', () => {
  assert.match(app, /const navigateAllowed = useCallback/);
  assert.match(app, /allowed && !allowed\.has\(destination\)/);
  assert.match(app, /onChange=\{navigateAllowed\}/);
  assert.doesNotMatch(app, /navigate: setActive/);
  assert.match(shell, /roleModules && !roleModules\.has\(id\)/);
});

test('two visible dashboard buttons navigate to distinct local screens', () => {
  assert.match(dashboard, /const startClassNow = \(\) => navigate\('classMode'\)/);
  assert.match(dashboard, /const openFullSchedule = \(\) => navigate\('sessions'\)/);
  assert.match(dashboard, /data-testid="dashboard-direct-start-class"/);
  assert.match(dashboard, /data-testid="dashboard-direct-open-schedule"/);
  assert.match(css, /dashboard-direct-actions-v8 button/);
});

test('four roles expose three independently actionable existing social links', () => {
  assert.match(dashboard, /isStaff && <RoleMobdeaOnlineLinks \/>/);
  assert.match(dashboard, /'student', 'guardian', 'visitor'/);
  assert.ok(dashboard.includes('https://www.facebook.com/share/1AyBatYgJv/'));
  assert.ok(dashboard.includes('https://youtube.com/@mostafabarakat21?si=FczgywNrmc9FTBsl'));
  assert.ok(dashboard.includes('https://www.tiktok.com/@mostafabarakat210?_r=1&_t=ZS-996NuPuPOy1'));
});

test('background auto-sync prevents a stale snapshot replacing newer edits', () => {
  assert.match(app, /commitCloudSnapshot\(latest, seeded/);
  assert.match(app, /commitCloudSnapshot\(latest, pushed\.merged/);
  assert.match(app, /commitCloudSnapshot\(latest, restored/);
  assert.match(app, /localEditRevisionRef\.current !== editRevisionAtStart/);
});
