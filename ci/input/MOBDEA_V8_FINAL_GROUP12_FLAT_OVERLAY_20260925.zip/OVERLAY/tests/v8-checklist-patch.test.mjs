import assert from 'node:assert/strict';
import fs from 'node:fs';
import test from 'node:test';
import { COUNTRY_AR_NAMES, COUNTRY_CAPITALS_AR } from '../src/data/mapEnrichment.js';

const source = (file) => fs.readFileSync(file, 'utf8');

test('dashboard has V8 responsive root and distinct Online/Mobdea routes', () => {
  const dashboard = source('src/pages/Dashboard.jsx');
  assert.match(dashboard, /dashboard-page-v8/);
  assert.match(dashboard, /navigate\('onlineClass'\)/);
  assert.match(dashboard, /navigate\('mobdeaOnline'\)/);
  assert.doesNotMatch(dashboard, /action\.id === 'mobdeaOnline'\) navigate\('onlineClass'\)/);
});

test('two student rails show by default; bottom dock has one save control and no duplicate student-management button', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const dockStart = classMode.indexOf('project12-classmode-dock classmode-user-bottom-dock');
  const dockEnd = classMode.indexOf('classmode-user-fullscreen', dockStart);
  const dock = classMode.slice(dockStart, dockEnd);
  assert.ok(dockStart >= 0 && dockEnd > dockStart);
  assert.match(classMode, /const \[managementOpen, setManagementOpen\] = useState\(true\)/);
  assert.match(dock, /classmode-bottom-save/);
  assert.match(dock, /onClick=\{saveLessonState\}/);
  assert.doesNotMatch(dock, /setManagementOpen|<Users/);
  assert.match(classMode, /classmode-rail-manage/);
  // Saving the actual lesson and annotation layer works for board and PDFs,
  // not just the board image; the former board-only assertion was obsolete.
});

test('whiteboard uses exact 1536x864 working coordinate system and non-cropping background', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const css = source('src/styles/v8-final-real.css');
  assert.match(classMode, /BOARD_CANVAS_WIDTH = 1536/);
  assert.match(classMode, /BOARD_CANVAS_HEIGHT = 864/);
  assert.match(css, /classmode-board-reference-image\{[^}]*object-fit:contain!important/);
  assert.doesNotMatch(css, /classmode-board-reference-image\{[^}]*object-fit:fill!important/);
});

test('font choices are probed and unavailable fonts are removed from the selector', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  assert.match(classMode, /fontAvailability/);
  const verifiedFontProbe = source('src/services/v8BoardFontAvailability.js');
  assert.match(classMode, /isArabicBoardFontAvailable\(item\.probe\)/);
  assert.match(verifiedFontProbe, /fonts\?\.load\(spec, 'المُبدع'\)/);
  assert.match(verifiedFontProbe, /response\.ok/);
  assert.match(classMode, /filter\(\(item\) => fontAvailability\[item\.probe\] !== false\)/);
  assert.match(classMode, /style=\{\{ fontFamily: item\.value \}\}/);
});

test('audio and video both preserve playback position', () => {
  const media = source('src/components/classmode/MediaRenderer.jsx');
  assert.match(media, /function useRememberedPlayback/);
  assert.match(media, /function MediaAudio/);
  assert.match(media, /mediaPlaybackMemory\.set/);
  assert.match(media, /const loaded = \(\) => \{[\s\S]*?playback\.restore\(\)/);
  assert.match(media, /onLoadedMetadata=\{state\.loaded\}/);
});

test('pan memory is retained per resource across remounts and switching resources does not force zoom to 100%', () => {
  const panZoom = source('src/components/classmode/PanZoomSurface.jsx');
  const state = source('src/services/v8ResourceState.js');
  assert.match(panZoom, /const panStateMemory = new Map\(\)/);
  assert.match(panZoom, /readResourceState\('pan', memoryKey, null\)/);
  assert.match(panZoom, /writeResourceState\('pan', memoryKey/);
  assert.match(state, /sessionStorage/);
  assert.match(state, /MAX_STATE_ENTRIES = 120/);
  const resetEffect = panZoom.slice(panZoom.indexOf('const memoryKey = String(resetKey'), panZoom.indexOf('const pointerDistance'));
  assert.doesNotMatch(resetEffect, /onZoomChange\?\.\(minZoom\)/);
});

test('PDF preloads only previous and next pages, with bounded caches', () => {
  const pdf = source('src/components/classmode/PdfCanvasPreview.jsx');
  assert.match(pdf, /MAX_PDF_CACHE = 5/);
  assert.match(pdf, /MAX_RASTER_CACHE = 18/);
  assert.match(pdf, /\[result\.page \+ 1, result\.page - 1\]/);
  assert.doesNotMatch(pdf, /result\.page \+ 2/);
});

test('silent maps retain geometry/rivers/symbols while forcing every teaching label to blank mode', () => {
  const map = source('src/components/maps/ProfessionalMap.jsx');
  assert.match(map, /const effectiveDisplayMode = silent \? 'blank' : displayMode/);
  assert.match(map, /\{teachingMode && <TeachingReferenceGrid[\s\S]*?displayMode=\{effectiveDisplayMode\}/);
  assert.match(map, /<TeachingRiverOverlay[\s\S]*?displayMode=\{effectiveDisplayMode\}/);
  assert.match(map, /\{mapStyle === "relief" && \(/);
  assert.match(map, /\{lineFeatures\.length > 0 && !\(teachingMode && \[.egypt., .nile.\]\.includes\(regionKey\)\) && \(/);
  assert.match(map, /displayMode !== 'blank' && <text[^>]+project06-reference-label/);
  assert.match(map, /displayMode !== 'blank' && labels && <text[^>]+project06-river-label/);
  assert.match(map, /!silent && \(labels \|\| \(!teachingMode && active && showActiveLabel\)\) && \(/);
  assert.match(map, /!silent && \(placement\.showLabel \|\| placement\.type === "custom-label"\) && \(/);
  assert.match(map, /!silent && \(placement\.showLabel \|\| placement\.type === "custom-label"\) &&\s*placement\.hint/);
  assert.doesNotMatch(map, /!silent &&\s*!\["countries", "latitude", "longitude"\]\.includes\(layerKey\)/);
});

test('map symbols support move resize duplicate delete and show selected symbol hint', () => {
  const studio = source('src/components/maps/LessonMapStudio.jsx');
  const map = source('src/components/maps/ProfessionalMap.jsx');
  assert.match(studio, /onMovePlacement=/);
  assert.match(studio, /onResizePlacement=/);
  assert.match(studio, /onDuplicatePlacement=/);
  assert.match(studio, /onRemovePlacement=/);
  assert.match(studio, /lesson-map-selected-symbol-hint/);
  assert.match(map, /aria-label="نسخ الرمز"/);
});

test('Map Challenge floating menus open to the left of the right-side selectors', () => {
  const css = source('src/styles/v8-final-real.css');
  assert.match(css, /map-game-floating-menu\{[^}]*top:0!important;right:44px!important/);
});

test('tablet/fullscreen tool areas are scrollable and touch targets remain stable', () => {
  const css = source('src/styles/v8-final-real.css');
  assert.match(css, /classmode-header-tabs\{[^}]*overflow-x:auto!important/);
  assert.match(css, /classmode-toolbar\{[\s\S]*?overflow:auto!important/);
  assert.match(css, /classmode-header-tabs button\.active\{[^}]*transform:none!important/);
  assert.match(css, /presentation-fullscreen \.classmode-toolbar/);
});


test('country educational dataset has a capital for every mapped country and exposes continent/region', () => {
  const missing = Object.keys(COUNTRY_AR_NAMES).filter((iso) => !COUNTRY_CAPITALS_AR[iso]);
  assert.deepEqual(missing, []);
  const enrichment = source('src/data/mapEnrichment.js');
  assert.match(enrichment, /continent:\s*continentArabic/);
  assert.match(enrichment, /region:\s*regionArabic/);
  assert.match(enrichment, /SUBREGION_AR/);
  assert.match(enrichment, /fallbackFact/);
});

test('library OCR runtime is lazy-loaded only when OCR is invoked', () => {
  const library = source('src/pages/ContentLibrary.jsx');
  assert.doesNotMatch(library, /from "\.\.\/services\/pdfQuestionOcr"/);
  assert.doesNotMatch(library, /from "\.\.\/services\/ocrQuestionParser"/);
  assert.match(library, /import\("\.\.\/services\/pdfQuestionOcr"\)/);
  assert.match(library, /import\("\.\.\/services\/ocrQuestionParser"\)/);
  assert.match(library, /lessonOcrModulesPromise/);
});

test('board interaction surface preserves approved 1536x864 aspect through resize/orientation', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const css = source('src/styles/v8-final-real.css');
  assert.match(classMode, /class-board-coordinate-stage/);
  assert.match(classMode, /rect\.width \/ BOARD_CANVAS_WIDTH/);
  assert.match(classMode, /rect\.height \/ BOARD_CANVAS_HEIGHT/);
  assert.match(classMode, /orientationchange/);
  assert.match(css, /class-board-coordinate-stage\.is-board/);
  assert.match(css, /class-board-coordinate-stage\.is-media/);
});

test('map challenge uses shared selection handlers that close pickers and reselect valid layers', () => {
  const challenge = source('src/pages/MapChallenge.jsx');
  assert.match(challenge, /const chooseRegion =/);
  assert.match(challenge, /getRegionLayerItems\(geo, nextRegionKey, key\)/);
  assert.match(challenge, /const closeFloatingPickers =/);
  assert.match(challenge, /onClick=\{\(\) => chooseRegion\(key\)\}/);
  assert.match(challenge, /onClick=\{\(\) => chooseMode\(key\)\}/);
});

test('student points/random selection use the current class pool and atomic point state', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  assert.match(classMode, /const pointsRef = useRef\(points\)/);
  assert.match(classMode, /withClassPointAward\(\{/);
  assert.match(classMode, /pointsRef\.current = \{ \.\.\.pointsRef\.current, \[studentId\]: Math\.max\(0, Number\(changed\.points/);
  assert.match(classMode, /const pool = displayedStudents\.length \? displayedStudents : students/);
  assert.match(classMode, /const studentRailColumns = useMemo/);
  assert.match(classMode, /return \[displayedStudents\.slice\(0, middle\), displayedStudents\.slice\(middle\)\]/);
});

test('V8 approved board artwork is referenced by both board components with cache-busting URL', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const whiteboard = source('src/pages/Whiteboard.jsx');
  const main = source('src/main.jsx');
  assert.match(classMode, /class-board-history-v14\.jpg/);
  assert.match(whiteboard, /class-board-history-v14\.jpg/);
  assert.match(main, /v8-final-real\.css/);
});
test('resource page zoom playback pan and PowerPoint slide state persist across same-session remounts', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const media = source('src/components/classmode/MediaRenderer.jsx');
  const pan = source('src/components/classmode/PanZoomSurface.jsx');
  const ppt = source('src/components/classmode/PptxPreview.jsx');
  const state = source('src/services/v8ResourceState.js');
  for (const token of ["readResourceState('page'", "writeResourceState('page'", "readResourceState('zoom'", "writeResourceState('zoom'"]) assert.ok(classMode.includes(token), token);
  assert.match(media, /readResourceState\('playback'/); assert.match(media, /writeResourceState\('playback'/);
  assert.match(pan, /readResourceState\('pan'/); assert.match(pan, /writeResourceState\('pan'/);
  assert.match(ppt, /readResourceState\('pptx-slide'/); assert.match(ppt, /writeResourceState\('pptx-slide'/);
  assert.match(state, /mobdea:v8:resource-state:v1/);
});

test('fullscreen paths support browser and Android WebView-prefixed APIs', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const whiteboard = source('src/pages/Whiteboard.jsx');
  const challenge = source('src/pages/MapChallenge.jsx');
  for (const file of [classMode, whiteboard, challenge]) {
    assert.match(file, /webkitRequestFullscreen/);
    assert.match(file, /webkitExitFullscreen/);
  }
  assert.match(classMode, /webkitfullscreenchange/);
  assert.match(challenge, /webkitfullscreenchange/);
});

test('safe Arabic correction normalizes English keyboard punctuation without semantic rewrites', () => {
  const correction = source('src/services/arabicSentenceCorrection.js');
  assert.match(correction, /replace\(\/,\/g, '،'\)/);
  assert.match(correction, /replace\(\/;\/g, '؛'\)/);
  assert.match(correction, /replace\(\/\\\?\/g, '؟'\)/);
});

test('student rails stay vertically scrollable with compact tablet touch controls', () => {
  const css = source('src/styles/v8-final-real.css');
  assert.match(css, /classmode-student-rail-list\{[^}]*flex-direction:column!important/);
  assert.match(css, /classmode-student-rail-row\{[^}]*min-height:38px!important/);
  assert.match(css, /orientation:landscape/);
});


test('drawing tools remember independent pen highlighter and eraser sizes', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  assert.match(classMode, /DRAW_TOOL_SIZE_OPTIONS/);
  assert.match(classMode, /pen:\s*\[2, 3, 4, 6, 10, 14, 20\]/);
  assert.match(classMode, /highlighter:\s*\[12, 18, 24, 32, 40, 52\]/);
  assert.match(classMode, /eraser:\s*\[24, 32, 40, 52, 64, 80\]/);
  assert.match(classMode, /drawToolWidths/);
  assert.match(classMode, /updateActiveStrokeWidth/);
  assert.doesNotMatch(classMode, /\(strokeWidth \|\| 4\) \* 4\.5/);
});

test('same-type resource switcher is one compact edge control with direct selector and independent page arrows', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const start = classMode.indexOf('className="classmode-media-edge-nav"');
  const end = classMode.indexOf('</div>', start);
  const block = classMode.slice(start, end);
  assert.ok(start >= 0 && end > start);
  assert.match(block, /classmode-media-edge-count/);
  assert.match(block, /cycleModeResource\(-1\)/);
  assert.match(block, /cycleModeResource\(1\)/);
  assert.match(block, /<select/);
  assert.match(block, /setSelectedResourceId\(event\.target\.value\)/);
  assert.match(classMode, /classmode-pdf-edge-nav/);
  assert.equal((classMode.match(/className="classmode-media-edge-nav"/g) || []).length, 1);
  assert.doesNotMatch(classMode, /classmode-inline-media-switcher/);
});

test('Egypt Nile path includes southern border Lake Nasser Aswan Cairo Delta and both Mediterranean mouths', () => {
  const nile = source('src/data/project06TeachingMaps.js');
  const map = source('src/components/maps/ProfessionalMap.jsx');
  assert.match(nile, /const nileEgypt =/);
  assert.match(nile, /\[32\.90, 22\.00\]/);
  assert.match(nile, /lake-nasser/);
  assert.match(nile, /السد العالي — أسوان/);
  assert.match(nile, /القاهرة/);
  assert.match(nile, /دلتا النيل/);
  assert.match(nile, /rosetta-mouth/);
  assert.match(nile, /damietta-mouth/);
  assert.match(map, /EGYPT_NILE_LANDMARK_IDS/);
});

test('river cartography distinguishes main river tributaries and delta without neon effects', () => {
  const css = source('src/styles/v8-final-real.css');
  assert.match(css, /project06-river-group\.main \.project06-river-line/);
  assert.match(css, /project06-river-group\.tributary \.project06-river-line/);
  assert.match(css, /project06-river-group\.delta \.project06-river-line/);
  assert.match(css, /project06-river-line\{[^}]*filter:none!important/);
});

test('video/audio playback memory is bounded while preserving positions', () => {
  const media = source('src/components/classmode/MediaRenderer.jsx');
  assert.match(media, /MAX_PLAYBACK_MEMORY = 48/);
  assert.match(media, /function rememberPlaybackPosition/);
  assert.match(media, /while \(mediaPlaybackMemory\.size > MAX_PLAYBACK_MEMORY\)/);
  assert.match(media, /rememberPlaybackPosition\(memoryKey, current\)/);
});

test('Arabic classroom speech remains wired for praise corrective feedback and random student selection', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  assert.match(classMode, /import \{ buildEncouragementPhrase, speakArabic \} from "\.\.\/services\/voice"/);
  assert.match(classMode, /await speakArabic\(/);
  assert.match(classMode, /change >= 0 \? "excited" : "calm"/);
  assert.match(classMode, /تم اختيار الطالب/);
});

test('country cards materialize country capital region and educational fact, not continent-only buttons', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  assert.match(classMode, /info1: card\.capital \? `العاصمة:/);
  assert.match(classMode, /info2: card\.region \? `الإقليم:/);
  assert.match(classMode, /info3: card\.educationalFact/);
  assert.match(classMode, /\["الإقليم", card\.region\]/);
  assert.match(classMode, /kind: "country-card"/);
});

test('OCR-saved questions feed the same custom bank consumed by Games', () => {
  const bank = source('src/pages/QuestionBankManager.jsx');
  const library = source('src/pages/ContentLibrary.jsx');
  const games = source('src/pages/Games.jsx');
  assert.match(bank, /await updateData\(\(currentData\) => \(\{/);
  assert.match(bank, /customQuestionBank:[\s\S]*?currentData\.customQuestionBank[\s\S]*?nextQuestion/);
  assert.match(bank, /prepareManualGameQuestion/);
  assert.match(library, /regenerateLessonQuestions/);
  assert.match(library, /customQuestionBank/);
  assert.match(games, /mergeQuestionBanks\(questionBank, data\.customQuestionBank \|\| \[\]\)\.filter\(isQuestionReadyForGame\)/);
});

test('video and audio use compact custom controls without a duplicate fullscreen control', () => {
  const media = source('src/components/classmode/MediaRenderer.jsx');
  const css = source('src/styles/v8-final-real.css');
  assert.match(media, /className=\{`classmode-compact-media-controls \${kind}`\}/);
  assert.match(media, /className="unified-media-video-shell"/);
  assert.match(media, /className="unified-media-audio-shell"/);
  assert.match(media, /className="classmode-media-progress"/);
  assert.doesNotMatch(media, /<video[\s\S]{0,350}\scontrols(?:\s|>)/);
  assert.doesNotMatch(media, /requestFullscreen|webkitRequestFullscreen/);
  assert.match(css, /classmode-compact-media-controls\{[^}]*height:40px!important/);
});

test('PDF image and PowerPoint annotation mode exposes edit controls while Save remains board-only', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  assert.match(classMode, /media-annotation-toolbar/);
  assert.match(classMode, /<Undo2/);
  assert.match(classMode, /<Redo2/);
  assert.match(classMode, /مسح الكتابة/);
  assert.match(classMode, /onClick=\{saveLessonState\}/);
  assert.match(classMode, /const saveLessonState = async \(\) => \{/);
  assert.match(classMode, /await persistCurrentBoardLayer\(\)/);
  assert.match(classMode, /const timer = window\.setTimeout\(\(\) => \{/);
  assert.match(classMode, /contentLibrary:[\s\S]*?boardLayers:[\s\S]*?\[boardLayerKey\]: layer/);
});

test('lazy runtime observer scans only newly mounted route nodes after the initial boot scan', () => {
  const main = source('src/main.jsx');
  assert.match(main, /mutation\.addedNodes/);
  assert.match(main, /node\.matches\(selector\) \|\| Boolean\(node\.querySelector\(selector\)\)/);
  assert.doesNotMatch(main, /new MutationObserver\(\(\) => \{[\s\S]*?queueMicrotask\(scan\)/);
});

test('real administrative component selectors receive responsive layouts instead of guessed class names', () => {
  const css = source('src/styles/v8-final-real.css');
  for (const selector of [
    'achievements-layout', 'achievements-badge-grid', 'reward-catalog-grid',
    'reports-card-grid', 'report-table-wrap', 'messages-layout', 'game-stage-header',
    'question-marking-list', 'voice-clips-list', 'portal-recordings-list',
  ]) assert.match(css, new RegExp(`\\.${selector}`), selector);
});

test('Egypt curriculum data and the five agreed teaching categories are present in one geography dataset', () => {
  const geography = source('src/data/geography.js');
  for (const category of ['terrain', 'water', 'resources', 'political', 'landmarks']) {
    assert.match(geography, new RegExp(`${category}:\\s*\\{`), category);
  }
  for (const label of [
    'جبال البحر الأحمر', 'جبل سانت كاترين', 'الصحراء الغربية', 'الصحراء الشرقية',
    'منخفض القطارة', 'بحيرة ناصر', 'قناة السويس', 'بترول خليج السويس',
    'ذهب السكري', 'حقل ظهر للغاز الطبيعي', 'ميناء الإسكندرية',
  ]) assert.match(geography, new RegExp(label), label);
});

test('PowerPoint and per-resource page/zoom memories are bounded while preserving revisit state', () => {
  const ppt = source('src/components/classmode/PptxPreview.jsx');
  const classMode = source('src/pages/ClassMode.jsx');
  assert.match(ppt, /MAX_PPTX_SLIDE_MEMORY = 48/);
  assert.match(ppt, /function rememberPptxSlide/);
  assert.match(ppt, /while \(pptxSlideMemory\.size > MAX_PPTX_SLIDE_MEMORY\)/);
  assert.match(classMode, /MAX_RESOURCE_VIEW_MEMORY = 64/);
  assert.match(classMode, /function rememberBoundedViewState/);
  assert.match(classMode, /rememberBoundedViewState\(resourcePageMemoryRef\.current/);
  assert.match(classMode, /rememberBoundedViewState\(resourceZoomMemoryRef\.current/);
});

test('Question Bank mounts OCR only on explicit request and keeps manual entry available', () => {
  const bank = source('src/pages/QuestionBankManager.jsx');
  assert.match(bank, /const \[ocrPanelOpen, setOcrPanelOpen\] = useState\(false\)/);
  assert.match(bank, /OCR عند الحاجة فقط/);
  assert.ok(bank.includes('ocrPanelOpen') && bank.includes('<Suspense'));
  assert.match(bank, /<Project08ExamOcrImport/);
  assert.match(bank, /onClick=\{\(\) => openEditor\(\)\}/);
  assert.match(bank, /\+ سؤال جديد/);
});

test('manual and lesson OCR question text receives conservative Arabic correction before persistence', () => {
  const bank = source('src/pages/QuestionBankManager.jsx');
  const library = source('src/pages/ContentLibrary.jsx');
  assert.match(bank, /correctArabicSentence/);
  assert.match(bank, /onBlur=\{\(\) => correctDraftField\('text', false\)\}/);
  assert.match(bank, /onBlur=\{\(\) => correctDraftField\('answer', false\)\}/);
  assert.match(bank, /onBlur=\{\(\) => correctDraftField\('text', false\)\}/);
  assert.match(library, /function normalizeReviewedOcrQuestions/);
  assert.match(library, /questionText: normalizeLibraryQuestionText\(form\.questionText\)/);
  assert.match(library, /ocrReviewQuestions: normalizeReviewedOcrQuestions\(form\.ocrReviewQuestions\)/);
});

test('lesson OCR review flows into the shared custom question bank on save', () => {
  const library = source('src/pages/ContentLibrary.jsx');
  assert.match(library, /const customQuestionBank = regenerateLessonQuestions\(/);
  assert.match(library, /await updateData\(\{[\s\S]*?customQuestionBank,/);
  assert.match(library, /generateQuestionsForLessonBundle/);
  assert.match(library, /upsertGeneratedQuestions/);
});

test('tablet landscape owns internal page geometry using real page component selectors', () => {
  const css = source('src/styles/v8-final-real.css');
  for (const selector of [
    'student-card-workbench', 'card-preview-stage', 'project13-session-list',
    'project13-links-column', 'project13-result-toolbar', 'project13-analysis-side',
    'assistant-filter-bar', 'assistant-insights-list', 'update-history-row',
    'library-lesson-editor', 'library-editor-grid', 'student-lesson-viewer',
    'whiteboard-tool-rail', 'whiteboard-students-list', 'whiteboard-bottom-toolbar',
  ]) assert.match(css, new RegExp(`\\.${selector}`), selector);
  assert.match(css, /orientation:landscape/);
  assert.match(css, /writing-mode:horizontal-tb!important/);
  assert.match(css, /overflow-x:clip!important/);
});

test('horizontal scrolling is confined to real table/tool surfaces instead of whole admin pages', () => {
  const css = source('src/styles/v8-final-real.css');
  assert.match(css, /grades-page-v8 \.responsive-table[^}]*overflow:auto!important/);
  assert.match(css, /payments-page-v8 \.responsive-table[^}]*overflow:auto!important/);
  assert.match(css, /whiteboard-bottom-toolbar[^}]*overflow-x:auto!important/);
  assert.match(css, /student-card-workbench[^}]*grid-template-columns/);
});

test('ClassMode lazy feature runtimes target the real mounted classmode scene', () => {
  const main = source('src/main.jsx');
  assert.match(main, /selector:\s*'\.classmode-scene, \.standalone-whiteboard-page-v8'/);
  assert.match(main, /selector:\s*'\.classmode-scene, \.student-cards-page-v8, \.content-library-page-v8'/);
  assert.match(main, /selector:\s*'\.classmode-scene'/);
  assert.doesNotMatch(main, /selector:\s*'\.class-mode-page/);
});

test('board ink text and cards now share the approved 1536x864 coordinate space with legacy migration', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  assert.match(classMode, /const BOARD_COORD_WIDTH = BOARD_CANVAS_WIDTH/);
  assert.match(classMode, /const BOARD_COORD_HEIGHT = BOARD_CANVAS_HEIGHT/);
  assert.match(classMode, /const LEGACY_BOARD_COORD_WIDTH = 1200/);
  assert.match(classMode, /const LEGACY_BOARD_COORD_HEIGHT = 720/);
  assert.match(classMode, /function migrateLegacyCanvasAction/);
  assert.match(classMode, /coordinateSpace:\s*BOARD_COORD_SPACE/);
  assert.match(classMode, /setBoardActions\(normalizeBoardLayerActions\(saved\)\)/);
});

test('V8 classroom speech goes through the native-first voice service only once', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const voice = source('src/services/voice.js');
  assert.match(classMode, /await speakArabic\(phrase, settings, tone\)/);
  assert.match(classMode, /void speakClassroomArabic\(/);
  assert.match(voice, /speechSynthesis/);
  assert.match(voice, /ar-EG/);
  assert.doesNotMatch(classMode.slice(classMode.indexOf('async function speakClassroomArabic'), classMode.indexOf('const MOBDEA_LOGO_IMAGE')), /SpeechSynthesisUtterance/);
});
test('shared drawing previews on canvas without React state updates for every pointer sample', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const start = classMode.indexOf('const onPointerMove = (event) => {', classMode.indexOf('function CanvasOverlay'));
  const end = classMode.indexOf('const onPointerUp =', start);
  const block = classMode.slice(start, end);
  assert.ok(start >= 0 && end > start);
  assert.match(block, /getCoalescedEvents/);
  assert.match(block, /render\(currentStroke\.current\)/);
  assert.doesNotMatch(block, /setBoardActions|setState|onDrawAction\(currentStroke\.current\)/);
});

test('pinch zoom keeps the gesture focal point and exposes full two-axis pan limits', () => {
  const panZoom = source('src/components/classmode/PanZoomSurface.jsx');
  assert.match(panZoom, /localX:\s*\(screenVector\.x - currentPan\.x\)/);
  assert.match(panZoom, /localY:\s*\(screenVector\.y - currentPan\.y\)/);
  assert.match(panZoom, /screenVector\.x - nextZoom \* gesture\.localX/);
  assert.match(panZoom, /screenVector\.y - nextZoom \* gesture\.localY/);
  assert.match(panZoom, /scaledWidth - metrics\.hostWidth/);
  assert.match(panZoom, /scaledHeight - metrics\.hostHeight/);
});

test('educational and country cards support tap/drag insertion, internal scrolling and auto-fit fields', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const css = source('src/styles/v8-final-real.css');
  assert.match(classMode, /application\/x-mobdea-board-card/);
  assert.match(classMode, /application\/x-mobdea-country-card/);
  assert.match(classMode, /onClick=\{\(\) => addBoardCard\(card\.key\)\}/);
  assert.match(classMode, /onClick=\{\(\) =>\s*addCountryCard\(DEFAULT_COUNTRY_CARD\.key\)/);
  assert.match(classMode, /<AutoFitCardText/);
  assert.match(classMode, /<AutoFitCardTextarea/);
  assert.match(css, /classmode-card-drawer-list[^}]*overflow-y:auto/);
});
