import assert from 'node:assert/strict';
import test from 'node:test';
import { commitCloudSnapshot } from '../src/services/cloudCommitGuard.js';

function snapshot(name, dirtyAt = '') {
  return {
    students: [{ id: '1', name }],
    settings: { cloudSync: { localChangedAt: dirtyAt, workspaceId: 'the-same-workspace', token: 'configured-locally', autoSyncError: '' } },
  };
}

test('acknowledging a cloud upload keeps grades and students edited during the request', () => {
  const latest = snapshot('الطالب بعد التعديل', '2026-09-23T10:01:00.000Z');
  const old = snapshot('الطالب قبل التعديل', '2026-09-23T10:00:00.000Z');
  const actual = commitCloudSnapshot(latest, old, {
    newerLocalEdits: true,
    uploadedDirtyAt: old.settings.cloudSync.localChangedAt,
    cloudPatch: { revision: 'cloud-2' },
  });
  assert.deepEqual(actual.students, latest.students);
  assert.equal(actual.settings.cloudSync.localChangedAt, latest.settings.cloudSync.localChangedAt);
  assert.equal(actual.settings.cloudSync.revision, 'cloud-2');
});

test('acknowledged cloud snapshot can replace local when no edits occurred during request', () => {
  const local = snapshot('الاسم القديم', '');
  const pulled = snapshot('الاسم من السحابة', '');
  const actual = commitCloudSnapshot(local, pulled, { uploadedDirtyAt: '', cloudPatch: { revision: 'remote-2' } });
  assert.equal(actual.students[0].name, 'الاسم من السحابة');
  assert.equal(actual.settings.cloudSync.localChangedAt, '');
});

test('different dirty timestamps retain local changes even without a revision-counter signal', () => {
  const latest = snapshot('تغيير غير مرسل', 'new-dirty');
  const actual = commitCloudSnapshot(latest, snapshot('بيانات قديمة', 'old-dirty'), {
    uploadedDirtyAt: 'old-dirty',
  });
  assert.equal(actual.students[0].name, 'تغيير غير مرسل');
  assert.equal(actual.settings.cloudSync.localChangedAt, 'new-dirty');
});

test('cloud metadata does not silently erase local workspace configuration', () => {
  const latest = snapshot('محلي', 'changed');
  const actual = commitCloudSnapshot(latest, snapshot('قديم', 'changed'), {
    newerLocalEdits: true,
    uploadedDirtyAt: 'changed',
    cloudPatch: { revision: 'remote-3', lastPushAt: 'today' },
  });
  assert.equal(actual.settings.cloudSync.token, 'configured-locally');
  assert.equal(actual.settings.cloudSync.workspaceId, 'the-same-workspace');
});

test('incomplete snapshots fail closed rather than writing empty app data', () => {
  assert.throws(() => commitCloudSnapshot(null, snapshot('x')), /unavailable/);
  assert.throws(() => commitCloudSnapshot(snapshot('x'), null), /unavailable/);
});
