import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { createRequire } from 'node:module';
import geo from '../src/data/world-countries.json' with { type: 'json' };
import { COUNTRY_CARDS } from '../src/data/countryCards.js';
import { MAP_FEATURE_FACTS, COUNTRY_CAPITALS_AR } from '../src/data/mapEnrichment.js';
import { GEOGRAPHY_REGIONS, getRegionLayerItems, createMapProjector } from '../src/data/geography.js';
import { TEACHING_RIVER_PATHS, NILE_LANDMARKS, TEACHING_WATER_BODIES } from '../src/data/project06TeachingMaps.js';
import { normalizeLessonMapState } from '../src/services/lessonMapState.js';
import { allMapCountryCards, teachingCategoryForLayer, resolveMapSelection } from '../src/services/mapTeachingSelection.js';

const text = path => readFileSync(new URL(path, import.meta.url), 'utf8');

test('all source map countries have real informational cards, but only verified templates claim illustrations', () => {
  const cards = allMapCountryCards();
  const byIso = new Map(cards.map(card => [card.iso, card]));
  assert.equal(byIso.size, cards.length);
  assert.ok(cards.length >= 160, `country count ${cards.length}`);
  assert.equal(COUNTRY_CARDS.length, 35);
  for (const template of COUNTRY_CARDS) {
    assert.equal(byIso.get(template.iso).asset, template.asset);
    assert.ok(existsSync(new URL(`../public${template.asset}`, import.meta.url)), template.iso);
  }
  const mapCountryIsos = new Set(geo.features.map(feature => feature.properties.iso_a3).filter(iso => /^[A-Z]{3}$/.test(iso) && iso !== 'ATA'));
  for (const iso of mapCountryIsos) {
    const card = byIso.get(iso);
    assert.ok(card && card.name && card.region && card.capital && card.fact, iso);
    if (!COUNTRY_CARDS.some(template => template.iso === iso)) {
      assert.equal(card.asset, null, `${iso}: never invent illustrated card`);
      assert.ok(card.flag, `${iso}: missing emoji flag fallback`);
    }
  }
  assert.equal(byIso.get('EGY').capital, COUNTRY_CAPITALS_AR.EGY);
  assert.ok(byIso.get('IRL')?.capital);
  assert.equal(byIso.get('ATA'), undefined);
});

test('maps restore selected country, Nile river, landmark, supplementary dam and water polygon', () => {
  assert.equal(resolveMapSelection(geo, 'egypt', 'countries', 'EGY')?.capital, 'القاهرة');
  assert.equal(resolveMapSelection(geo, 'nile', 'rivers', 'victoria')?.name, 'بحيرة فيكتوريا');
  assert.equal(resolveMapSelection(geo, 'nile', 'rivers', 'blue-nile')?.name, 'النيل الأزرق');
  assert.equal(resolveMapSelection(geo, 'nile', 'water', 'sudd-wetlands')?.name, 'مستنقعات السد');
  assert.equal(resolveMapSelection(geo, 'nile', 'rivers', 'gerd')?.name, 'سد النهضة');
  assert.equal(resolveMapSelection(geo, 'egypt', 'rivers', 'delta-west-egypt')?.name, 'فرع رشيد');
  assert.equal(resolveMapSelection(geo, 'egypt', 'minerals', 'victoria'), null);
  assert.equal(resolveMapSelection(geo, 'egypt', 'countries', 'BAD'), null);
  const egyptLayer = getRegionLayerItems(geo, 'egypt', 'minerals');
  assert.equal(resolveMapSelection(geo, 'egypt', 'minerals', egyptLayer[0].id)?.name, egyptLayer[0].name);
});

test('map region layer classification covers every category and preserves per-region features', () => {
  for (const [layer, category] of Object.entries({ countries:'political', rivers:'water', lakes:'water', minerals:'resources', energy:'resources', mountains:'terrain', ports:'landmarks' })) {
    assert.equal(teachingCategoryForLayer(layer), category);
  }
  const saved = normalizeLessonMapState({ regionKey:'nile', regions: {
    egypt: {layerKey:'minerals', zoom:2.2, placements:[{id:'eg'}], strokes:[{id:'ink-eg'}]},
    nile: {layerKey:'rivers', zoom:1.7, placements:[{id:'nile'}], strokes:[{id:'ink-nile'}]},
  } });
  assert.equal(saved.layerKey, 'rivers');
  assert.equal(saved.regions.egypt.layerKey, 'minerals');
  assert.equal(saved.regions.egypt.placements[0].id, 'eg');
  assert.equal(saved.regions.nile.placements[0].id, 'nile');
  assert.equal(saved.regions.nile.strokes[0].id, 'ink-nile');
  const studio = text('../src/components/maps/LessonMapStudio.jsx');
  assert.match(studio, /loadRegionSnapshot\(nextStates\[returnRegion\] \|\| \{\}, 'countries', returnRegion\)/);
  assert.match(studio, /resolveMapSelection\(geo, targetRegion, restoredLayer, selected\)/);
  assert.match(studio, /setTeachingCategory\(teachingCategoryForLayer\(restoredLayer\)\)/);
  assert.match(studio, /saveQueueRef\.current\.catch\(\(\) => \{\}\)\.then/);
  assert.match(studio, /persistMapSnapshot\(latestStateRef\.current, saveForLesson\)/);
  assert.doesNotMatch(studio, /setRegionStates\(state\?\.regions \|\| \{\}\)/);
});

test('Nile network paths stay inside region bounds and have actual educational facts and correct mouths', () => {
  const [minLon,minLat,maxLon,maxLat] = GEOGRAPHY_REGIONS.nile.bounds;
  const basin = TEACHING_RIVER_PATHS.nile;
  for (const river of basin) {
    assert.ok(river.coords.length >= 3,river.id);
    assert.ok(MAP_FEATURE_FACTS[river.name],river.name);
    for (const [lon,lat] of river.coords) assert.ok(lon >= minLon && lon <= maxLon && lat >= minLat && lat <= maxLat,river.id);
  }
  for (const entry of [...NILE_LANDMARKS, ...TEACHING_WATER_BODIES.nile]) {
    assert.ok(MAP_FEATURE_FACTS[entry.name] || entry.name.includes('البحر المتوسط'),entry.name);
  }
  const egypt = TEACHING_RIVER_PATHS.egypt;
  const main = egypt.find(line => line.id === 'nile-egypt');
  const west = egypt.find(line => line.id === 'delta-west-egypt');
  const east = egypt.find(line => line.id === 'delta-east-egypt');
  assert.deepEqual(west.coords[0],main.coords.at(-1));
  assert.deepEqual(east.coords[0],main.coords.at(-1));
  assert.ok(west.coords.at(-1)[0] < east.coords.at(-1)[0]);
  assert.ok(Math.abs(west.coords.at(-1)[1]-31.4)<0.1);
  assert.ok(Math.abs(east.coords.at(-1)[1]-31.42)<0.1);
  for (const region of ['egypt','nile']) {
    const projection = createMapProjector(region);
    const coords = region === 'egypt' ? [...main.coords,...west.coords,...east.coords] : basin.flatMap(line=>line.coords);
    for(const [lon,lat] of coords) {
      const [x,y]=projection(lon,lat);
      assert.ok(x>=0&&x<=1000&&y>=0&&y<=620,`${region}:${lon},${lat} => ${x},${y}`);
    }
  }
});

test('teacher Nile landmarks, river paths, water bodies and country overlays are selectable without duplicate labels', () => {
  const studio=text('../src/components/maps/LessonMapStudio.jsx');
  const map=text('../src/components/maps/ProfessionalMap.jsx');
  assert.match(studio,/allCountryCards\.length/);
  assert.match(studio,/getRegionLayerItems\(geo, regionKey, 'countries'\)\.some/);
  assert.match(studio,/setLayerKey\('countries'\)/);
  assert.match(studio,/setSelectedName\(card\.name\);\s+markDirty\(\)/);
  assert.match(studio,/const persistMapSnapshot = \(snapshot, saveForLesson = saveCallbackRef\.current\)/);
  assert.match(studio,/selectedCountryCard\?\.asset && !countryCardImageFailed/);
  assert.match(studio,/\['gerd', 'roseires', 'merowe'\]/);
  assert.doesNotMatch(studio,/NILE_RIVER_IDS/);
  assert.match(map,/project06-nile-landmark-touch/);
  assert.match(map,/onFeatureClick\?\.\(place\.id, place\.name, place, event\)/);
  assert.match(map,/onFeatureClick\?\.\(feature\.id, feature\.name, feature, event\)/);
  assert.match(map,/targetItem\?\.id \|\| river\.id/);
  assert.match(map,/displayMode === 'blank' \? 'موضع على الخريطة'/);
  assert.match(map,/labels && displayMode !== 'blank' && <title>/);
});

test('ClassMode keeps illustrated cards, metadata facts in actual board and exported canvas, file switcher and isolated resources', () => {
  const classMode=text('../src/pages/ClassMode.jsx');
  assert.match(classMode,/COUNTRY_FACTS_AR\[iso\]/);
  assert.match(classMode,/educationalFact \|\| COUNTRY_FACTS_AR\[iso\]/);
  assert.match(classMode,/drawCountryCardToCanvas/);
  assert.match(classMode,/countryCardsForCategory\(countryCategory, countryCardSearch\)/);
  assert.match(classMode,/readResourceState\('page', resourceKey/);
  assert.match(classMode,/readResourceState\('zoom', resourceKey/);
  assert.match(classMode,/rememberModeResource\(lastModeResourceRef\.current, contentMode, displayResource\)/);
  assert.match(classMode,/classmode-section3-switcher/);
  assert.match(classMode,/unsavedBoardLayersRef\.current\.set\(boardLayerKey/);
});
