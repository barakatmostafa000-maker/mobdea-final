import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { COUNTRY_CARDS, DEFAULT_COUNTRY_CARD, COUNTRY_CARD_CATEGORIES } from '../src/data/countryCards.js';
import { getCountryCard, countryCardsForCategory } from '../src/services/countryCardCatalog.js';

const root = process.cwd();
test('35 genuine country templates: real artwork, unique ISO and all four educational fields', () => {
  assert.equal(COUNTRY_CARDS.length, 35);
  assert.equal(new Set(COUNTRY_CARDS.map(c => c.key)).size, COUNTRY_CARDS.length);
  assert.equal(new Set(COUNTRY_CARDS.map(c => c.iso)).size, COUNTRY_CARDS.length);
  for (const card of COUNTRY_CARDS) {
    const resolved = getCountryCard(card.key);
    assert.ok(resolved?.name && resolved.capital && resolved.region && resolved.educationalFact,
      `Incomplete metadata for ${card.key}: ${card.name}`);
    assert.ok(resolved.educationalFact !== `عاصمة ${card.name} هي ${card.capital}.`,
      `${card.name}: duplicate capital rather than fact`);
    assert.ok(fs.existsSync(path.join(root, 'public', card.asset)),
      `${card.name}: missing image asset ${card.asset}`);
    assert.ok(resolved.region !== 'أوروبا وآسيا',
      `${card.name}: drawer category cannot be the actual region`);
  }
  assert.ok(fs.existsSync(path.join(root, 'public', DEFAULT_COUNTRY_CARD.asset)));
});

test('country catalogue search crosses category and supports Arabic accents and capitals', () => {
  assert.equal(COUNTRY_CARD_CATEGORIES.reduce((n, c) => n + countryCardsForCategory(c.key).length, 0), 35);
  assert.deepEqual(countryCardsForCategory('arab','موسكو').map(c => c.iso), ['RUS']);
  assert.deepEqual(countryCardsForCategory('africa','ابو ظبي').map(c => c.iso), ['ARE']);
  assert.deepEqual(countryCardsForCategory('africa','أستراليا').map(c => c.iso), ['AUS']);
  assert.deepEqual(countryCardsForCategory('arab','بلد مش موجود'), []);
  assert.equal(getCountryCard('99'), undefined);
});

test('historic continent exceptions have explicitly correct labels', () => {
  assert.match(getCountryCard('01').region, /إفريقيا.*آسيا/);
  assert.match(getCountryCard('19').region, /آسيا.*أوروبا/);
  assert.match(getCountryCard('21').region, /آسيا.*أوروبا/);
});

test('country card appears in lesson media; information UI is selectable and screen/export uses same fields', () => {
  const source = fs.readFileSync(path.join(root,'src/pages/ClassMode.jsx'),'utf8');
  assert.match(source, /import \{ getCountryCard, countryCardsForCategory \} from "\.\.\/services\/countryCardCatalog"/);
  assert.match(source, /className="country-card-facts-panel"/);
  assert.match(source, /aria-expanded=\{detailsOpen\}/);
  assert.match(source, /countryCardsForCategory\(countryCategory, countryCardSearch\)/);
  assert.match(source, /for \(const card of boardActions\.filter\(\s*\(action\) => action.kind === "country-card"/);
  assert.match(source, /<MemoCanvasOverlay[\s\S]*?onAddCountryCard=\{canPlaceLessonCards \? addCountryCard : undefined\}/);
});
