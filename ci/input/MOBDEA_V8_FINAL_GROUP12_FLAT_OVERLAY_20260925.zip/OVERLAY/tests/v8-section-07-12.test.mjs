import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = (path) => fs.readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const board = read('src/pages/Whiteboard.jsx');
const classMode = read('src/pages/ClassMode.jsx');
const css = read('src/styles/v8-section-07-12-whiteboard.css');
const main = read('src/main.jsx');

test('07: approved board artwork is used in standalone and class; white fallback on failure', () => {
  assert.match(board, /whiteboard-approved-history-background/);
  assert.match(board, /class-board-history-v14\.jpg/);
  assert.match(board, /ctx\.fillStyle = '#ffffff'/);
  assert.match(classMode, /onError=\{\(event\) => \{ event\.currentTarget\.style\.display = 'none'; \}\}/);
});
test('08,09: distinct stroke widths, undo, redo, clear, touch and fullscreen controls', () => {
  assert.match(board, /toolWidths, setToolWidths/);
  assert.match(board, /setPointerCapture/);
  assert.match(board, /releasePointerCapture/);
  assert.match(board, /clear-again/);
  assert.match(css, /whiteboard-reference-layout/);
  assert.match(css, /classmode-toolbar.*pointer-events:auto/);
});
test('10: annotations are per resource and page and are saved to data store', () => {
  assert.match(board, /resource:\$\{resource\.id\}:\$\{/);
  assert.match(board, /data\.whiteboardRecords/);
  assert.match(classMode, /\[boardLayerKey\]: layer/);
  assert.match(classMode, /selectedStorageResource\?\.boardLayers/);
});
test('11: absent downloaded font faces offer device fallback, and section styles load after legacy styles', () => {
  assert.match(board, /fontChoices = visibleBoardFonts\.length/);
  assert.match(classMode, /probe: 'System'/);
  assert.ok(main.lastIndexOf('v8-section-07-12-whiteboard.css') > main.lastIndexOf('v8-all-pages-layout.css'));
});
test('12: teacher text remains unchanged unless opt-in correction is selected', () => {
  assert.match(board, /text: enteredText/);
  const textCommit = classMode.slice(classMode.indexOf('const commitTextEditor ='), classMode.indexOf('const commitTextEditor =') + 750);
  assert.match(textCommit, /const value = String\(textEditor\?\.value \|\| ''\);/);
  assert.match(textCommit, /if \(!value\.trim\(\)\)/);
  assert.doesNotMatch(textCommit, /correctArabicSentence\(/);
  assert.match(classMode, /onClick=\{\(\) => correctTextEditorNow/);
  assert.match(classMode, /dir="rtl"/);
});
test('08+12 canvas text renderer keeps Arabic direction and line breaks', () => {
  const begin = board.indexOf('function actionBounds(');
  const end = board.indexOf('function moveAction(', begin);
  assert.ok(begin >= 0 && end > begin);
  const { drawAction } = Function(`${board.slice(begin,end)};return {drawAction};`)();
  const text = [];
  const ctx = new Proxy({save(){},restore(){},setLineDash(){},fillText(...args){text.push(args)}}, {set(target,prop,value){target[prop]=value;return true}});
  drawAction(ctx, {kind:'text',x:500,y:100,text:'نص تجريبي\n١٢٣؟',fontSize:34,color:'#123456'});
  assert.deepEqual(text.map(a=>a[0]), ['نص تجريبي','١٢٣؟']);
  assert.equal(ctx.direction,'rtl');
  assert.equal(ctx.textAlign,'right');
  assert.ok(text[1][2]>text[0][2]);
});
