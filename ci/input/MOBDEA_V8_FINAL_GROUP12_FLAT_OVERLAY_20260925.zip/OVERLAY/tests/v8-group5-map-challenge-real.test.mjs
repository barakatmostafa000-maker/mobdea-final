import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import world from '../src/data/world-countries.json' with { type: 'json' };
import { GEOGRAPHY_SYMBOLS, GEOGRAPHY_REGIONS, GEOGRAPHY_TEACHING_CATEGORIES, getRegionLayerItems } from '../src/data/geography.js';
import { percentWithinMapViewport } from '../src/services/mapSvgViewport.js';
import { challengeSymbolForFeature, filterChallengeSymbols, mapChallengeFeatureInfo, canAnswerMapTap } from '../src/services/v8MapChallengeFeatures.js';
const code=(path)=>readFileSync(new URL('../'+path,import.meta.url),'utf8');
const page=code('src/pages/MapChallenge.jsx');
const map=code('src/components/maps/ProfessionalMap.jsx');
const css=code('src/styles/v8-section-31-40-map-challenge.css');

test('31: fullscreen request and exit update from actual browser event, map remains viewport-sized',()=>{
  assert.match(page,/node\.requestFullscreen \|\| node\.webkitRequestFullscreen/);
  assert.match(page,/document\.addEventListener\('fullscreenchange'/);
  assert.match(page,/setMessage\('لم يسمح المتصفح بملء الشاشة/);
  assert.match(css,/map-challenge-pro:fullscreen/);
  assert.match(css,/height: 100dvh !important/);
  assert.match(css,/grid-template-columns:clamp\(190px,23vw,270px\) minmax\(0,1fr\)/);
});
test('32: one right-side selector rail and no competing top/bottom layer navigation',()=>{
  assert.equal((page.match(/className="map-game-floating-selectors"/g)||[]).length,1);
  assert.equal((page.match(/className="map-game-floating-selector /g)||[]).length,4); // exactly four right-side icon selectors
  assert.doesNotMatch(page,/className="map-layer-dock"/);
  for (const cls of ['region-selector','mode-selector','category-selector','layer-selector'])assert.match(page,new RegExp(cls));
  assert.match(css,/\.map-challenge-pro \.map-game-floating-selector \{[\s\S]*?right:max\(8px, env\(safe-area-inset-right/);
  assert.match(css,/\.map-challenge-pro \.map-game-floating-menu \{/);
});
test('33: only one start action; palette rendered exclusively in running build mode and grouped by topic',()=>{
  assert.equal((page.match(/onClick=\{startGame\}/g)||[]).length,1);
  assert.match(page,/mode === "build" && started && \(/);
  assert.match(page,/buildSymbolCategories\.map/);
  assert.match(page,/filterChallengeSymbols\(allBuildPalette, buildCategory, buildSearch\)/);
  assert.match(css,/is-setup[\s\S]*?\.map-start-button/);
  assert.match(page,/!started \? "is-setup" : ""/);
  assert.match(css,/\.map-challenge-pro\.is-setup \.map-game-layout \{grid-template-columns:minmax\(0,1fr\)/);
});
test('34: inverse placement rect uses SVG viewport including any CSS pan/zoom and rejects letterboxing',()=>{
  assert.deepEqual(percentWithinMapViewport(70,140,{left:20,top:40,width:100,height:200}),{x:50,y:50});
  assert.deepEqual(percentWithinMapViewport(240,340,{left:20,top:40,width:400,height:600}),{x:55.00000000000001,y:50});
  assert.equal(percentWithinMapViewport(21,45,{left:30,top:40,width:100,height:200}),null);
  assert.match(page,/\.map-pro-placement-layer/);
  assert.match(map,/Math\.hypot\(dx, dy\) < 7/);
  assert.match(map,/suppressStageClickRef\.current = true/);
  assert.match(map,/mapPointersRef\.current\.size >= 2/);
  assert.match(map,/onWheel=\{handleMapWheel\}/);
});
test('35: tiny-country targets are expanded without enlarging drawn geometry or nearby large-country targets',()=>{
  assert.match(map,/const SMALL_COUNTRY_ISOS/);
  assert.match(map,/pointerEvents=\{challengeTouchTargets && !isSmallCountry\(feature\) \? 'none'/);
  assert.match(map,/r=\{challengeTouchTargets \? 28 : 22\}/);
  assert.match(map,/r=\{challengeTouchTargets \? 35 : 26\}/);
});
test('36: challenge mounts no drawing canvas and no board tool handlers',()=>{
  assert.match(map,/!challengeTouchTargets && \([\s\S]*?<canvas/);
  assert.doesNotMatch(page,/onDraw\w+=|onErase\w+=|drawTool=/);
  assert.match(css,/\.map-challenge-pro \.map-pro-draw-canvas/);
});
test('37: geography teaching layers have genuine selectable questions in Egypt and other regions',()=>{
  for(const category of Object.keys(GEOGRAPHY_TEACHING_CATEGORIES)){
    const candidates=GEOGRAPHY_TEACHING_CATEGORIES[category].layers;
    assert.ok(candidates.some(layer=>getRegionLayerItems(world,'egypt',layer).length),category);
  }
  for(const layer of ['mountains','plateaus','plains','deserts','rivers','oceans','seas','straits','minerals','energy','agriculture','industry','ports'])
    assert.ok(['egypt','africa','world'].some(region=>getRegionLayerItems(world,region,layer).length),layer);
  assert.ok(GEOGRAPHY_REGIONS.eurasia);
  assert.equal(canAnswerMapTap(false,'challenge'),false);
  assert.equal(canAnswerMapTap(true,'naming'),false);
  assert.equal(canAnswerMapTap(true,'build'),false);
  assert.equal(canAnswerMapTap(true,'explore'),true);
});
test('38: actual resource icon files are used on active quiz questions and available in the searchable 181-item builder',()=>{
  assert.equal(GEOGRAPHY_SYMBOLS.length,181);
  const economic=filterChallengeSymbols(GEOGRAPHY_SYMBOLS,'resources');
  assert.ok(economic.length>=30);
  for(const [layer,name,expected] of [
    ['minerals','ذهب جنوب إفريقيا','mineral-gold'],
    ['minerals','حديد موريتانيا','mineral-iron'],
    ['energy','غاز الجزائر','energy-natural-gas'],
    ['energy','مجمع بنبان للطاقة الشمسية','energy-solar'],
    ['energy','مزارع رياح جبل الزيت','energy-wind'],
    ['ports','ميناء بورسعيد','human-seaport'],
    ['agriculture','وادي النيل الزراعي','agriculture-irrigated'],
    ['industry','حلوان الصناعية','human-industrial-area'],
  ]) {
    const symbol=challengeSymbolForFeature({name},layer);
    assert.equal(symbol?.id,expected,`${layer}: ${name}`);
    assert.ok(existsSync(fileURLToPath(new URL(`../public${symbol.asset}`,import.meta.url))),symbol.asset);
  }
  assert.ok(filterChallengeSymbols(GEOGRAPHY_SYMBOLS,'resources','غاز').some(s=>s.id==='energy-natural-gas'));
  assert.ok(filterChallengeSymbols(GEOGRAPHY_SYMBOLS,'all','زراعة').length>0);
  assert.match(page,/challengeResourceSymbols=\{started/);
  assert.match(map,/challengeSymbolForFeature\(item, layerKey\)/);
  assert.match(page,/buildPalette\.map\(\(item\) =>/);
  assert.match(map,/placement\.asset \? \(/);
});
test('39: country info carries capital, region, continent, accurate card fact and remains until next-question action',()=>{
  const egypt=world.features.find(f=>f.properties.iso_a3==='EGY');
  const info=mapChallengeFeatureInfo({feature:egypt},'countries');
  assert.equal(info.name,'مصر'); assert.equal(info.capital,'القاهرة');assert.ok(info.region && info.continent && info.fact);
  assert.match(page,/setDetailItem\(chosen \|\| target\)/);
  assert.match(page,/setAwaitingNext\(true\)/);
  assert.match(page,/className="map-next-question" onClick=\{\(\) => void advance\(\)\}/);
  assert.match(page,/info\.capital/); assert.match(page,/info\.region/); assert.match(page,/info\.continent/);
});
test('40: feature cards use named facts when available and actual layer-specific definitions otherwise',()=>{
  assert.match(mapChallengeFeatureInfo({name:'جبال أطلس'},'mountains').fact,/شمال غرب إفريقيا/);
  assert.match(mapChallengeFeatureInfo({name:'مضيق غير معروف'},'straits').fact,/ممر مائي/);
  assert.match(mapChallengeFeatureInfo({name:'منجم مجهول'},'minerals').fact,/ثروة معدنية/);
  assert.match(mapChallengeFeatureInfo({name:'مصنع مجهول'},'industry').fact,/نشاط صناعي/);
  assert.match(page,/className="map-challenge-info-card"/);
  assert.match(page,/mapChallengeFeatureInfo\(detailItem, layerKey\)/);
});
