import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = (p) => fs.readFileSync(p, 'utf8');
const classMode = read('src/pages/ClassMode.jsx');
const whiteboard = read('src/pages/Whiteboard.jsx');
const mapChallenge = read('src/pages/MapChallenge.jsx');
const proMap = read('src/components/maps/ProfessionalMap.jsx');
const lessonMap = read('src/components/maps/LessonMapStudio.jsx');
const geography = read('src/data/geography.js');
const enrichment = read('src/data/mapEnrichment.js');
const teaching = read('src/data/project06TeachingMaps.js');
const dashboard = read('src/pages/Dashboard.jsx');
const qbank = read('src/pages/QuestionBankManager.jsx');
const games = read('src/pages/Games.jsx');
const contentLibrary = read('src/pages/ContentLibrary.jsx');
const media = read('src/components/classmode/MediaRenderer.jsx');
const panzoom = read('src/components/classmode/PanZoomSurface.jsx');
const pdf = read('src/components/classmode/PdfCanvasPreview.jsx');
const ppt = read('src/components/classmode/PptxPreview.jsx');
const main = read('src/main.jsx');
const css = read('src/styles/v8-final-real.css');
const packageManifestPath = process.env.V8_PATCH_MANIFEST || 'FULL_CHECKLIST_MANIFEST.json';
const packageDiffPath = process.env.V8_PATCH_DIFF || 'DIFF_VS_V8.json';
const packageInstallerPath = process.env.V8_PATCH_INSTALLER || 'apply_to_v8_codespace.py';
const packageRuntimeDocPath = process.env.V8_PATCH_RUNTIME_DOC || 'RUNTIME_VERIFICATION_REQUIRED_AR.txt';

function hasAll(text, items) { for (const x of items) assert.match(text, x instanceof RegExp ? x : new RegExp(x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))); }

test('01 all-page layout is tablet-landscape owned', () => {
  hasAll(css, [/tablet/i, /landscape/i, /\.classmode-viewport\.classmode-final-layout/, /\.map-challenge-pro/]);
  const pageFiles = fs.readdirSync('src/pages').filter((name) => name.endsWith('.jsx'));
  const pageHooks = new Set();
  for (const name of pageFiles) {
    const source = read(`src/pages/${name}`);
    for (const match of source.matchAll(/([A-Za-z0-9_-]+-page-v8)/g)) pageHooks.add(match[1]);
  }
  assert.ok(pageHooks.size >= 15, `expected broad page hook coverage, got ${pageHooks.size}`);
  for (const hook of pageHooks) assert.ok(css.includes(`.${hook}`), `missing tablet layout CSS hook for ${hook}`);
});
test('02 ClassMode has real fullscreen and stable bottom toolbar', () => { hasAll(classMode, [/requestFullscreen/, /webkitRequestFullscreen/, /classmode-bottom-actions/, /classmode-user-fullscreen/]); assert.match(css, /no black reserved column/i); });
test('03 student system is two rails with plus minus random praise warning and seven-row tablet capacity', () => {
  hasAll(classMode, [/studentRailColumns/, /slice\(0, middle\)/, /slice\(middle\)/, /adjustPoints\(student, -1\)/, /adjustPoints\(student, 1\)/, /randomStudent/, /تشجيع/, /تنبيه/]);
  hasAll(css, [/at least seven compact rows visible/i, /min-height:min\(300px/, /classmode-student-rail-row\{min-height:36px/]);
});
test('04 points mutate atomically and persist', () => { hasAll(classMode, [/pointsRef\.current/, /setPoints\(pointsRef\.current\)/, /updateData\(\(latest\)/, /classPointSessions/]); });
test('05 student controls are on bottom dock and old lock UI is absent from rails', () => { hasAll(classMode, [/classmode-user-bottom-dock/, /classmode-student-rails/]); const rail = classMode.slice(classMode.indexOf('classmode-student-rails'), classMode.indexOf('<ClassModeViewport.Footer>')); assert.doesNotMatch(rail, /<Lock|قفل/); });
test('06 Arabic TTS is native-first with ar-EG browser fallback', () => {
  hasAll(classMode, [/Native/i, /speechSynthesis/, /ar-EG/, /voiceschanged/, /let timer = null/, /timer = globalThis\.setTimeout/]);
  assert.ok(classMode.indexOf('let timer = null') < classMode.indexOf('const finish = (value)'), 'TTS timeout handle must exist before finish() can run');
});
test('07 approved whiteboard image and safe white fallback are wired', () => { hasAll(classMode + whiteboard + css, [/class-board-history-v14\.jpg/, /objectFit|object-fit/, /#fff|white/i]); });
test('08 complete board tool families exist', () => { hasAll(classMode + whiteboard, [/pen/i, /highlighter/i, /eraser/i, /Undo|تراجع/, /Redo|إعادة/, /Clear|مسح/, /selection|select/i, /font/i, /fontSize|font-size/i]); });
test('09 board/tool surfaces remain reachable in fullscreen', () => { hasAll(css + classMode, [/fullscreen/i, /classmode-tool/i, /overflow.*auto|overflow-y.*auto/i]); });
test('10 PDF image PPT share annotation tools', () => { hasAll(classMode + media, [/pdf/i, /image/i, /ppt/i, /annotation/i, /highlighter/i, /eraser/i]); });
test('11 real Arabic fonts are probed before exposure with a safe no-FontFaceSet fallback', () => {
  hasAll(classMode + whiteboard, [/document\.fonts/, /fontFamily/, /Cairo|Tajawal|Amiri|Noto/i, /if \(!fonts\?\.load\)/, /index === 0/]);
});
test('12 Arabic text correction and RTL are wired', () => { hasAll(classMode + qbank, [/arabicSentenceCorrection|correctArabic|normalizeArabic/i]); assert.match(css + classMode, /rtl|direction:\s*rtl/i); });
test('13 same-type resources use a compact numeric switcher', () => { hasAll(classMode, [/modeResources/, /resourceSwitcher/, /classmode-media-edge-nav/, /displayResourceIndex \+ 1/, /modeResources\.length/]); assert.doesNotMatch(classMode, /<select[^>]*resource/i); });
test('14 per-resource page zoom pan playback slide state is retained', () => { hasAll(classMode + media + panzoom + ppt, [/readResourceState/, /writeResourceState/, /page/, /zoom/, /pan/i, /currentTime|playback/i, /slide/i]); });
test('15 PDF has bounded cache adjacent preload pinch pan and lossless render', () => { hasAll(pdf + panzoom, [/cache/i, /previous|prev/i, /next/i, /pinch/i, /pan/i, /PNG|png/, /devicePixelRatio|pixel/i]); });
test('16 video audio PPT image controls are compact/lazy and avoid duplicate fullscreen', () => { hasAll(media + ppt + css, [/video/i, /audio/i, /ppt/i, /compact/i, /lazy/i]); });
test('17 educational cards support actual insertion and fitting', () => { hasAll(classMode + contentLibrary, [/card/i, /drag/i, /auto.?fit|fit/i, /scroll/i]); });
test('18 country cards contain country capital region and educational fact', () => {
  hasAll(enrichment + classMode, [/capital/i, /region/i, /fact/i, /country/i]);
  const parseFrozenJson = (name) => {
    const match = enrichment.match(new RegExp(`export const ${name} = Object\\.freeze\\((\\{.*?\\})\\);`));
    assert.ok(match, `${name} must be a JSON-safe frozen object`);
    return JSON.parse(match[1]);
  };
  const names = parseFrozenJson('COUNTRY_AR_NAMES');
  const capitals = parseFrozenJson('COUNTRY_CAPITALS_AR');
  const iso2 = parseFrozenJson('ISO3_TO_ISO2');
  const missingCapitals = Object.keys(names).filter((iso) => !capitals[iso]);
  const missingFlags = Object.keys(names).filter((iso) => !iso2[iso]);
  assert.deepEqual(missingCapitals, [], `Every mapped country must have a capital entry: ${missingCapitals.join(',')}`);
  assert.deepEqual(missingFlags, [], `Every mapped country must have an ISO2 flag code: ${missingFlags.join(',')}`);
});
test('19 maps preserve aspect and distinguish Asia Europe Eurasia with Russia handling', () => { hasAll(proMap + geography, [/preserveAspectRatio="xMidYMid meet"/, /asia/, /europe/, /eurasia/, /Russia|RUS|روسيا/i]); });
test('20 map-first layout gives the map primary viewport area', () => { hasAll(css, [/map-challenge.*map-first|map-first|map-game-map/i, /minmax\(0,\s*1fr\)|100dvh|100vh/i]); });
test('21 atlas coordinate/reference lines and label modes are present', () => { hasAll(proMap + geography, [/latitude/i, /longitude/i, /Greenwich|جرينتش/i, /atlas/i, /labels/i]); });
test('22 silent map hides textual labels while retaining geometry', () => { hasAll(proMap, [/effectiveDisplayMode = silent \? 'blank'/, /!silent.*text|displayMode !== 'blank'/s, /placement\.showLabel/, /placement\.hint/]); });
test('23 rivers are path-based and distinguish main tributary delta', () => { hasAll(teaching + proMap, [/coords/, /kind:\s*'main'|kind: "main"/, /tributary/, /delta/, /project06-river-line/]); });
test('24 Egypt Nile includes Nasser Aswan Cairo Delta Rosetta Damietta Mediterranean', () => { hasAll(teaching + enrichment, [/Nasser|ناصر/, /Aswan|أسوان/, /Cairo|القاهرة/, /Delta|دلتا/, /Rosetta|رشيد/, /Damietta|دمياط/, /Mediterranean|المتوسط/]); });
test('25 Nile basin sequence includes Kagera Victoria Albert Jebel White Sobat Ghazal Blue Tana Atbara', () => { hasAll(teaching + enrichment, [/Kagera|كاجيرا/, /Victoria|فيكتوريا/, /Albert|ألبرت/, /Jebel|الجبل/, /White Nile|الأبيض/, /Sobat|السوباط/, /Ghazal|الغزال/, /Blue Nile|الأزرق/, /Tana|تانا/, /Atbara|عطبرة/]); });
test('26 Sudd wetlands are explicitly represented', () => { assert.match(teaching + enrichment, /Sudd|مستنقعات السد|المستنقعات/u); });
test('27 five Egyptian curriculum teaching categories exist', () => { hasAll(geography, [/terrain:/, /water:/, /resources:/, /political:/, /landmarks:/]); });
test('28 Egypt data includes deserts Sinai Red Sea mountains Catherine Qattara resources energy ports', () => { hasAll(geography, [/الصحراء الشرقية/, /الصحراء الغربية/, /سيناء/, /جبال البحر الأحمر/, /سانت كاترين/, /القطارة/, /minerals/, /energy/, /ports/]); });
test('29 map symbols include physical economic and human families', () => { hasAll(proMap + geography, [/mountain/, /plateau/, /minerals|iron|gold/, /petroleum|oil/, /gas/, /port/, /capital/, /agric|farm|crop/i, /industry|factory/i]); });
test('30 symbols can move resize duplicate delete and remain inside transformed map', () => {
  hasAll(proMap, [/map-pro-transform/, /map-pro-placement-layer/, /onMovePlacement/, /onResizePlacement/, /onDuplicatePlacement/, /onRemovePlacement/, /clientPointToMapPercent/, /transformRef\.current\?\.getBoundingClientRect/]);
  hasAll(mapChallenge, [/onMovePlacement=/, /onResizePlacement=/, /onDuplicatePlacement=/, /onRemovePlacement=/, /-copy-/]);
  hasAll(lessonMap, [/clientPointToLessonMapPercent/, /map-pro-transform/, /onDuplicatePlacement=/, /onRemovePlacement=/]);
  assert.doesNotMatch(proMap, /placementId[\s\S]{0,260}event\.currentTarget\.getBoundingClientRect\(\)[\s\S]{0,320}onMovePlacement/);
});
test('31 Map Challenge uses real fullscreen API', () => { hasAll(mapChallenge, [/requestFullscreen/, /webkitRequestFullscreen/, /exitFullscreen/, /map-challenge-fullscreen/]); });
test('32 Map Challenge selectors are right-side floating controls with no duplicate legacy selector bars', () => {
  hasAll(mapChallenge + css, [/map-game-floating-selectors/, /right:\s*8px/i, /regionPickerOpen/, /modePickerOpen/, /categoryPickerOpen/]);
  assert.doesNotMatch(mapChallenge, /map-challenge-top-selection-bar|className="map-game-nav"|floatingSelectorPositions|beginFloatingSelectorDrag/);
});
test('33 setup question panel is compact and defers the build palette until start', () => {
  hasAll(mapChallenge + css, [/is-setup/, /map-game-question-panel/, /mode === "build" && started/, /\.is-setup/]);
});
test('34 challenge map supports zoom pan wheel touch pointers and transformed placement coordinates', () => {
  hasAll(proMap + mapChallenge, [/onZoomChange/, /setPan/, /onWheel/, /pointer/i, /pinch/i, /clientPointToChallengeMapPercent/, /querySelector\?\.\("\.map-pro-transform"\)/]);
  const transformedCoordinateUses = (mapChallenge.match(/clientPointToChallengeMapPercent\(/g) || []).length;
  assert.ok(transformedCoordinateUses >= 3, `drop, tap and touch placement paths must all use transformed coordinates; found ${transformedCoordinateUses}`);
});
test('35 small targets receive enlarged invisible hit areas', () => { hasAll(proMap, [/map-pro-country-hit-target/, /r="22"/, /map-pro-feature-hit-target/, /r="26"/]); });
test('36 Map Challenge has no drawing tools', () => { assert.doesNotMatch(mapChallenge, /\bPen\b|\bHighlighter\b|\bEraser\b|drawTool=/); });
test('37 challenge offers terrain rivers oceans straits plains minerals and resources', () => { hasAll(mapChallenge + geography, [/mountains/, /rivers/, /oceans/, /straits/, /plains/, /minerals/, /resources/]); });
test('38 challenge build palette activates economic/resource symbols too', () => { hasAll(mapChallenge, [/semanticKey/, /petroleum|oil/, /gas/, /port/, /agric/, /industry|factory/]); });
test('39 challenge country cards expose capital region and educational fact', () => { hasAll(mapChallenge, [/countryInfo/, /العاصمة/, /region/, /\.fact/]); });
test('40 challenge definition card also covers non-country geographic features', () => { hasAll(mapChallenge, [/featureInfo/, /map-feature-definition-card/, /info\.fact/]); });
test('41 Dashboard Start Class and Show Schedule are wired', () => { hasAll(dashboard, [/ابدأ الحصة/, /عرض الجدول/, /navigate\('classMode'\)/, /navigate\('sessions'\)/]); });
test('42 Dashboard class schedule Mobdea Online and Online Class targets are distinct', () => { hasAll(dashboard, [/mobdeaOnline/, /onlineClass/, /classMode/, /sessions/]); });
test('43 OCR flow reaches review/save shared question bank and games', () => { hasAll(qbank, [/OCR/i, /review|مراجعة/i, /customQuestionBank/, /Save|حفظ/i]); assert.match(games, /customQuestionBank/); });
test('44 manual question creation remains available and feeds same bank', () => { hasAll(qbank, [/سؤال جديد/, /saveQuestion/, /customQuestionBank/]); });
test('45 performance uses lazy loading bounded caches and contained long lists', () => { hasAll(main + classMode + css, [/lazy/i, /bounded|MAX_|limit/i, /content-visibility/i, /IntersectionObserver|MutationObserver/]); });
test('46 app retains an error boundary and removes black reserved ClassMode column', () => { hasAll(main + css, [/AppErrorBoundary/, /no black reserved column/i]); });
test('47 patch changes only owned files and preserves unrelated project files', () => { const manifest = JSON.parse(read(packageManifestPath)); assert.match(manifest.package_type, /surgical_patch/); assert.equal(manifest.removed_files, 0); });
test('48 installer accepts only V8 final marker/baseline', () => { const installer = read(packageInstallerPath); hasAll(installer, [/__MOBDEA_V8_FINAL_REAL_REVIEWED__/, /Refusing to patch a non-V8 baseline/]); });
test('49 patch is surgical and records a diff', () => { const manifest = JSON.parse(read(packageManifestPath)); assert.ok(manifest.payload_files < 60); assert.ok(fs.existsSync(packageDiffPath)); });
test('50 installer gates tests lint build imports and rollback', () => { const installer = read(packageInstallerPath); hasAll(installer, [/deep checklist audit/, /Source lint|Project lint/, /Production build|Web production build/, /verify_relative_imports/, /RELATIVE_IMPORT_GATE/, /ROLLBACK/]); });
test('51 device-only acceptance stays explicitly runtime-required', () => { const runtime = read(packageRuntimeDocPath); hasAll(runtime, [/Tablet/i, /Touch|اللمس|لمس/i, /TTS/i, /Fullscreen/i, /Tesseract|OCR/i, /PDF/i, /Map|الخرائط/i]); });
test('52 fullscreen ClassMode navigation is independent from same-type resource switching and board tools stay bottom-right', () => {
  hasAll(classMode, [
    /classModeNavOpen/,
    /classmode-user-navigation/,
    /classmode-mode-navigation-menu/,
    /selectClassModeNavigation/,
    /key:\s*"pdf"/,
    /key:\s*"board"/,
    /key:\s*"maps"/,
    /key:\s*"images"/,
    /key:\s*"videos"/,
    /key:\s*"audio"/,
    /key:\s*"slides"/,
    /key:\s*"games"/,
  ]);
  hasAll(css, [
    /MOBDEA_V8_REQUIREMENT_52_CLASSMODE_FULLSCREEN_NAV/,
    /\.classmode-mode-navigation\{[\s\S]*?top:max\(7px[\s\S]*?left:max\(8px/,
    /\.classmode-viewport\.classmode-final-layout \.classmode-board-tools-toggle\{[\s\S]*?right:max\(8px[\s\S]*?bottom:max\(8px/,
    /\.classmode-viewport\.classmode-final-layout \.classmode-user-fullscreen\{[\s\S]*?right:max\(8px/,
  ]);
  // The new mode navigation must not replace the existing same-type file switcher.
  hasAll(classMode, [/cycleModeResource/, /modeResources/, /classmode-media-edge-nav/, /displayResourceIndex \+ 1/, /modeResources\.length/]);
  assert.notEqual(classMode.indexOf('selectClassModeNavigation'), classMode.indexOf('cycleModeResource'));
});
