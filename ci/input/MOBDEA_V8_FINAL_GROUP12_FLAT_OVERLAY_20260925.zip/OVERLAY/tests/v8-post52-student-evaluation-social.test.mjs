import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

test('Mobdea Online is exactly three independent official social links', () => {
  const source = read('src/pages/MobdeaOnlineHub.jsx');
  for (const token of ['facebook', 'youtube', 'tiktok', 'mobdea-social-grid-v8', 'target="_blank"']) assert.match(source, new RegExp(token));
  assert.match(source, /https:\/\/www\.facebook\.com\/share\/1AyBatYgJv\//);
  assert.match(source, /https:\/\/youtube\.com\/@mostafabarakat21/);
  assert.match(source, /https:\/\/www\.tiktok\.com\/@mostafabarakat210/);
  const linkCount = (source.match(/id: '(facebook|youtube|tiktok)'/g) || []).length;
  assert.equal(linkCount, 3);
});

test('ClassMode restores functional most-improved student sorting and visible deltas', () => {
  const source = read('src/pages/ClassMode.jsx');
  assert.match(source, /studentSortMode === "improved"/);
  assert.match(source, /الأكثر تحسنًا/);
  assert.match(source, /setStudentSortMode\("improved"\)/);
  assert.match(source, /classmode-progress-delta/);
  assert.match(source, /studentProgress\[student\.id\]\?\.delta/);
});

test('Students and Grades expose global/group evaluation ranking and group-parent message', () => {
  const students = read('src/pages/Students.jsx');
  const grades = read('src/pages/Grades.jsx');
  assert.match(students, /buildEvaluationRanking/);
  assert.match(students, /ترتيب الطلاب في كل المجموعات/);
  assert.match(students, /evaluationGroupOptions/);
  assert.match(grades, /buildEvaluationRanking/);
  assert.match(grades, /الترتيب العام لكل المجموعات/);
  assert.match(grades, /رسالة نتائج الامتحان للمجموعة/);
  assert.match(grades, /نسخ رسالة الجروب/);
  assert.match(grades, /حفظ وتجهيز الرسالة/);
});

test('evaluation service ranks cumulative scores globally and by group and builds branded group message', async () => {
  const mod = await import(pathToFileURL(path.join(root, 'src/services/studentEvaluation.js')).href + `?t=${Date.now()}`);
  const data = {
    students: [
      { id: 1, name: 'أحمد', group: 'أ' },
      { id: 2, name: 'محمود', group: 'أ' },
      { id: 3, name: 'سارة', group: 'ب' },
    ],
    grades: [
      { id: 1, studentId: 1, exam: 'اختبار 1', score: 18, total: 20, date: '2026-09-18' },
      { id: 2, studentId: 2, exam: 'اختبار 1', score: 16, total: 20, date: '2026-09-18' },
      { id: 3, studentId: 3, exam: 'اختبار 1', score: 20, total: 20, date: '2026-09-18' },
      { id: 4, studentId: 1, exam: 'اختبار 2', score: 19, total: 20, date: '2026-09-19' },
    ],
  };
  const global = mod.buildEvaluationRanking(data, '');
  assert.equal(global[0].student.id, 3);
  const groupA = mod.buildEvaluationRanking(data, 'أ');
  assert.equal(groupA[0].student.id, 1);
  assert.deepEqual(mod.evaluationGroups(data), ['أ', 'ب']);
  const message = mod.buildExamGroupMessage(data, { exam: 'اختبار 1', group: 'أ' });
  assert.match(message, /نتيجة امتحان: اختبار 1/);
  assert.match(message, /المجموعة: أ/);
  assert.ok(message.indexOf('أحمد') < message.indexOf('محمود'));
  assert.match(message, /المُبدع مصطفى بركات/);
  assert.match(message, /معلم تاريخ ودراسات/);
});
