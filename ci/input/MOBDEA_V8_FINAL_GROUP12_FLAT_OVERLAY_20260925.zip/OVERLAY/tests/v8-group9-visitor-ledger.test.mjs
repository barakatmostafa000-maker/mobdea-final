import test from 'node:test';
import assert from 'node:assert/strict';
import { handleVisitorTrialRequest, VISITOR_LIMITS } from '../cloud-worker/visitorTrialEdge.js';
import { claimVisitorTrial, fetchVisitorTrialStatus } from '../src/services/visitorTrialClient.js';
import { canStudentAccessResource, canRoleAccessResource, consumeVisitorTrial } from '../src/services/rolePortalAccess.js';
import { readFileSync, writeFileSync, mkdtempSync, copyFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';

class MockD1 {
  values = new Map();
  prepare(sql) {
    return { bind: (...args) => ({
      first: async () => {
        const [workspace, subject, kind, limit] = args;
        const key = `${workspace}:${subject}:${kind}`;
        const previous = this.values.get(key) || 0;
        if (previous >= limit) return null;
        this.values.set(key, previous + 1);
        return { used: previous + 1 };
      },
      all: async () => {
        const [workspace, subject] = args;
        return { results: [...this.values.entries()].filter(([key]) =>
          key.startsWith(`${workspace}:${subject}:`)).map(([key,used]) => ({kind:key.split(':').at(-1),used})) };
      },
    }) };
  }
}
const env = (db = new MockD1()) => ({
  MOBDEA_ALLOWED_ORIGINS:'https://class.example', MOBDEA_TRIAL_PEPPER:'s'.repeat(48), MOBDEA_TRIAL_DB:db,
});
function request(method='GET', kind, opts={}) {
  return new Request('https://worker.example/visitor/trials', {
    method,
    headers: {'Origin':opts.origin || 'https://class.example','X-Mobdea-Workspace':opts.workspace || 'class_1',
      ...(!opts.omitIp ? {'CF-Connecting-IP':opts.ip || '192.0.2.80'} : {}),
      ...(method === 'POST' ? {'Content-Type':'application/json'} : {})},
    ...(method === 'POST' ? {body:JSON.stringify({kind})} : {}),
  });
}

test('D1 quota is enforced on server, independent of localStorage and client-selected identity', async () => {
  const settings=env();
  for (let i=0; i<VISITOR_LIMITS.maps; i++) {
    const resp=await handleVisitorTrialRequest(request('POST','maps'),settings);
    assert.equal(resp.status,200);
    assert.equal((await resp.json()).remaining.maps,VISITOR_LIMITS.maps-i-1);
  }
  const blocked=await handleVisitorTrialRequest(request('POST','maps'),settings);
  assert.equal(blocked.status,403);
  assert.equal((await blocked.json()).allowed,false);
  assert.equal((await (await handleVisitorTrialRequest(request(),settings)).json()).remaining.maps,0);
});
test('concurrent attempts never exceed the server-side allowance', async()=>{
  const settings=env();
  const results=await Promise.all(Array.from({length:35},()=>handleVisitorTrialRequest(request('POST','multiplayer'),settings)));
  const allowed=await Promise.all(results.map(async result=>(await result.json()).allowed));
  assert.equal(allowed.filter(Boolean).length,3);
  assert.equal((await(await handleVisitorTrialRequest(request(),settings)).json()).remaining.multiplayer,0);
});
test('visitor quota is separated by workspace, kind, and edge-confirmed client address',async()=>{
  const settings=env();
  await handleVisitorTrialRequest(request('POST','games'),settings);
  assert.equal((await(await handleVisitorTrialRequest(request(),settings)).json()).remaining.maps,VISITOR_LIMITS.maps);
  assert.equal((await(await handleVisitorTrialRequest(request('GET',null,{workspace:'class_2'}),settings)).json()).remaining.games,VISITOR_LIMITS.games);
  assert.equal((await(await handleVisitorTrialRequest(request('GET',null,{ip:'192.0.2.81'}),settings)).json()).remaining.games,VISITOR_LIMITS.games);
});
test('server fails closed when D1, secret or edge identity is missing',async()=>{
  assert.equal((await handleVisitorTrialRequest(request(), env(null))).status,503);
  const noSecret=env(); noSecret.MOBDEA_TRIAL_PEPPER='tiny';
  assert.equal((await handleVisitorTrialRequest(request(),noSecret)).status,503);
  assert.equal((await handleVisitorTrialRequest(request('GET',null,{omitIp:true}),env())).status,503);
});
test('wrong origin, workspace and kind do not consume quota', async()=>{
  const settings=env();
  assert.equal((await handleVisitorTrialRequest(request('POST','games',{origin:'https://attacker.example'}),settings)).status,403);
  assert.equal((await handleVisitorTrialRequest(request('POST','games',{workspace:'../'}),settings)).status,400);
  assert.equal((await handleVisitorTrialRequest(request('POST','payment'),settings)).status,400);
  assert.equal((await (await handleVisitorTrialRequest(request(),settings)).json()).remaining.games,5);
});
test('visitor client uses server URL and rejects fake network success',async()=>{
  const url='https://worker.example/visitor/trials';
  const settings={cloudSync:{endpoint:'https://worker.example',workspaceId:'class_1'}};
  const accepted=await claimVisitorTrial(settings,'games',async(got,options)=>{
    assert.equal(got,url);assert.equal(options.method,'POST');assert.equal(options.headers['X-Mobdea-Workspace'],'class_1');
    return new Response(JSON.stringify({allowed:true,remaining:{games:4},limits:{games:5}}),{status:200});
  });
  assert.equal(accepted.allowed,true);
  await assert.rejects(claimVisitorTrial(settings,'maps',async()=>new Response(JSON.stringify({allowed:false,remaining:{maps:5}}))),/تعذر التحقق/);
  await assert.rejects(claimVisitorTrial({},'games',async()=>{throw Error('should not fetch');}),/إعداد خادم/);
});
test('visitor trial status is taken from server, never localStorage',async()=>{
  const status=await fetchVisitorTrialStatus({endpoint:'https://worker.example',workspaceId:'class_1'},
    async()=>new Response(JSON.stringify({remaining:{games:4,maps:5,multiplayer:3},limits:{games:5,maps:5,multiplayer:3}})));
  assert.equal(status.remaining.games,4);
  assert.equal(consumeVisitorTrial('games').allowed,false);
});
test('unpublished resources cannot be retrieved through direct role checks',()=>{
  const pupil={id:'1',grade:'2'};
  const hidden={id:'book',published:false,access:{mode:'public'}};
  const archived={id:'old',archived:true,access:{mode:'students',studentIds:['1']}};
  assert.equal(canStudentAccessResource(hidden,pupil),false);
  assert.equal(canRoleAccessResource(hidden,{students:[pupil]},{role:'visitor'}),false);
  assert.equal(canStudentAccessResource(archived,pupil),false);
});
test('actual map/game/room entry points claim guest quota from server, no local grant',()=>{
  const root=new URL('../',import.meta.url);
  const game=readFileSync(new URL('src/pages/Games.jsx',root),'utf8');
  const map=readFileSync(new URL('src/pages/MapChallenge.jsx',root),'utf8');
  const room=readFileSync(new URL('src/components/live/StudentOnlineGameRoom.jsx',root),'utf8');
  assert.match(game,/await claimVisitorTrial\(data.settings, 'games'\)/);
  assert.match(map,/await claimVisitorTrial\(data.settings, 'maps'\)/);
  assert.doesNotMatch(room,/await claimVisitorTrial\(/);
  const edge=readFileSync(new URL('cloud-worker/worker.group11.js',root),'utf8');
  assert.match(edge,/handleVisitorTrialRequest\(quotaRequest,env\)/);
  assert.match(edge,/body.studentId='';body.studentCode=''/);
  for (const text of [game,map,room]) assert.doesNotMatch(text,/consumeVisitorTrial\(/);
});

test('Worker group9 routes quota requests and preserves original unrelated routes', async()=>{
  const dir=mkdtempSync(join(tmpdir(),'mobdea-group9-edge-'));
  try {
    const here=fileURLToPath(new URL('../cloud-worker/',import.meta.url));
    for (const name of ['worker.group9.js','visitorTrialEdge.js']) copyFileSync(join(here,name),join(dir,name));
    writeFileSync(join(dir,'package.json'),'{"type":"module"}\n');
    writeFileSync(join(dir,'worker.js'),"export default { async fetch() { return new Response('LEGACY_ROUTE_OK'); } };\n");
    const edge=(await import(pathToFileURL(join(dir,'worker.group9.js')).href)).default;
    const ordinary=await edge.fetch(new Request('https://worker.example/health'),env());
    assert.equal(await ordinary.text(),'LEGACY_ROUTE_OK');
    const trial=await edge.fetch(request(),env());
    assert.equal(trial.status,200);
    assert.equal((await trial.json()).remaining.games,5);
  } finally { rmSync(dir,{recursive:true,force:true}); }
});
