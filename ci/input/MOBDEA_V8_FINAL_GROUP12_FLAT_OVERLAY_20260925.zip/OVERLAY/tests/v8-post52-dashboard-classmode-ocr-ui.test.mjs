import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');
const exists = (rel) => fs.existsSync(path.join(root, rel));

function source(rel) {
  assert.ok(exists(rel), `missing ${rel}`);
  return read(rel);
}

test('dashboard tablet header fix and real start/schedule actions are present', () => {
  const dashboard = source('src/pages/Dashboard.jsx');
  const css = source('src/styles/v8-final-real.css');
  assert.match(dashboard, /POST52_DASHBOARD_REAL_ACTIONS_V2/);
  assert.match(dashboard, /const startClassNow = \(\) => navigate\('classMode'\)/);
  assert.match(dashboard, /const openFullSchedule = \(\) => navigate\('sessions'\)/);
  assert.match(dashboard, /data-testid="dashboard-start-class"/);
  assert.match(dashboard, /data-testid="dashboard-open-schedule"/);
  assert.match(dashboard, /dashboard-hero-action-dock-v8/);
  assert.match(css, /POST52_TABLET_HEADER_CLASSMODE_OCR_FIX_V2/);
  assert.match(css, /grid-template-columns:minmax\(0,1fr\) auto/);
  assert.match(css, /\.dashboard-page-v8 \.dashboard-account-strip/);
  assert.match(css, /\.app-shell-v103:not\(\.lesson-mode-shell\) > \.mobile-header/);
});

test('ClassMode PDF/board/maps/images/video/audio/PPT/games stay in one tablet row', () => {
  const classMode = source('src/pages/ClassMode.jsx');
  const css = source('src/styles/v8-final-real.css');
  for (const mode of ['pdf','board','maps','images','videos','audio','slides','games']) {
    assert.match(classMode, new RegExp(`key: ["']${mode}["']`), `missing ClassMode mode ${mode}`);
  }
  assert.match(classMode, /classmode-header-tabs/);
  assert.match(classMode, /classmode-mode-navigation-menu/);
  assert.match(classMode, /classmode-media-edge-nav/);
  assert.match(css, /\.classmode-scene\.classmode-final-layout \.classmode-header-tabs/);
  assert.match(css, /grid-template-columns:repeat\(8,minmax\(34px,1fr\)\)/);
  assert.match(css, /\.classmode-scene\.classmode-final-layout \.classmode-header-tabs button span\{display:none!important\}/);
});

test('Question Bank keeps manual entry independent of OCR and provides OCR retry isolation', () => {
  const qbank = source('src/pages/QuestionBankManager.jsx');
  assert.match(qbank, /data-testid="manual-question-add"/);
  assert.match(qbank, /\+ إضافة سؤال يدويًا/);
  assert.match(qbank, /openEditor\(\)/);
  assert.match(qbank, /POST52_OCR_LOCAL_ERROR_BOUNDARY_V2/);
  assert.match(qbank, /OcrImportErrorBoundary/);
  assert.match(qbank, /Project08ExamOcrImport/);
  assert.match(qbank, /customQuestionBank: \[\.\.\.custom, \.\.\.next\]/);
  assert.match(qbank, /بنك الأسئلة والألعاب/);
});

test('full project OCR pipeline and manual-to-games integration exist when running inside Codespace project', () => {
  // The distributed artifact is a surgical patch, so these dependencies live
  // in the V8 project rather than inside payload/. Enforce them in Codespace.
  if (!exists('package.json')) return;
  const componentRel = 'src/components/questions/Project08ExamOcrImport.jsx';
  const importServiceRel = 'src/services/project08QuestionImport.js';
  assert.ok(exists(componentRel), 'Project08ExamOcrImport.jsx is missing');
  assert.ok(exists(importServiceRel), 'project08QuestionImport.js is missing');
  const ocr = read(componentRel).toLowerCase();
  assert.match(ocr, /onimport/);
  assert.ok(ocr.includes('image') && ocr.includes('pdf'), 'OCR UI must support image and PDF');
  const pkg = read('package.json').toLowerCase();
  const srcHasTesseract = (() => {
    if (pkg.includes('tesseract')) return true;
    const stack = [path.join(root, 'src')];
    while (stack.length) {
      const dir = stack.pop();
      for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
        const p = path.join(dir, ent.name);
        if (ent.isDirectory()) stack.push(p);
        else if (/\.(js|jsx|mjs|ts|tsx)$/.test(ent.name) && fs.readFileSync(p, 'utf8').toLowerCase().includes('tesseract')) return true;
      }
    }
    return false;
  })();
  assert.ok(srcHasTesseract, 'Tesseract OCR source/dependency is missing');
  if (exists('src/pages/Games.jsx')) assert.match(read('src/pages/Games.jsx'), /customQuestionBank/);
});
