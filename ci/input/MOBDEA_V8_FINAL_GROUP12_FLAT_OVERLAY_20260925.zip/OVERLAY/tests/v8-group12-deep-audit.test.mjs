import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
const root = resolve(import.meta.dirname, '..');

test('group12 source audit reports concrete evidence, including blockers, without returning a false green result', () => {
  const result = spawnSync(process.execPath,['scripts/group12-deep-audit.mjs'],{cwd:root,encoding:'utf8'});
  assert.equal(result.status,0,result.stderr);
  const report = JSON.parse(result.stdout);
  assert.equal(report.reference,'V8_FINAL_MASTER_REAL_REVIEWED');
  assert.ok(report.results.some(entry=>entry.id==='RELATIVE_IMPORTS' && entry.status==='PASS'));
  assert.ok(report.results.some(entry=>entry.id==='MAP_SYMBOL_IMAGE_FILES' && entry.status==='PASS'));
  assert.equal(report.summary.checks,report.results.length);
  assert.equal(report.summary.blocked,report.results.filter(entry=>entry.status==='BLOCKED').length);
  assert.equal(report.summary.passed + report.summary.blocked,report.summary.checks);
});

test('group12 strict audit fails safely when any required source, asset, config or dependency is missing', () => {
  const result = spawnSync(process.execPath,['scripts/group12-deep-audit.mjs','--strict'],{cwd:root,encoding:'utf8'});
  const report = JSON.parse(result.stdout);
  assert.equal(result.status,report.summary.blocked>0?1:0);
});

test('new backend source is syntactically valid and cannot bypass the original worker entrypoint', () => {
  for(const file of ['cloud-worker/worker.group11.js','cloud-worker/group11Portal.js','cloud-worker/visitorTrialEdge.js']) {
    const check=spawnSync(process.execPath,['--check',file],{cwd:root,encoding:'utf8'});
    assert.equal(check.status,0,`${file}: ${check.stderr}`);
  }
});
