import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import worldCountries from '../src/data/world-countries.json' with { type: 'json' };
import { COUNTRY_CARDS } from '../src/data/countryCards.js';
import { countryCardByIso } from '../src/services/mapCountryCard.js';
import { getCountryFeatureId, GEOGRAPHY_REGIONS, getRegionCountries, getRegionLayerItems, GEOGRAPHY_TEACHING_CATEGORIES, GEOGRAPHY_SYMBOLS, createMapProjector } from '../src/data/geography.js';
import { TEACHING_RIVER_PATHS, TEACHING_WATER_BODIES, NILE_LANDMARKS } from '../src/data/project06TeachingMaps.js';
import { referenceLinesForBounds } from '../src/data/mapReferenceGrid.js';
import { normalizeLessonMapState, mergeLessonMapRegion } from '../src/services/lessonMapState.js';
import { pdfNeighborPages } from '../src/services/v8PdfPreloadPlan.js';
import { rememberModeResource, preferredResourceForMode } from '../src/services/v8ModeResourceMemory.js';
import { resourcesForContentMode, nextResourceId } from '../src/services/mediaNavigation.js';
import { readResourceState, writeResourceState, clearV8ResourceSessionState } from '../src/services/v8ResourceState.js';
import { fitMapSvgViewport, percentWithinMapViewport } from '../src/services/mapSvgViewport.js';
const code = (path) => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');

// These tests check algorithms and real data in addition to source-level integration.
test('13: file switcher isolates a media type and remembers the last file in each mode', () => {
  const files = [{ id:'book1', type:'pdf' }, { id:'book2', type:'pdf' }, { id:'film', type:'video' }, { id:'song', type:'audio' }];
  const mem = new Map(); rememberModeResource(mem,'pdf',files[1]);
  assert.equal(preferredResourceForMode(files,'pdf',mem,files[0]).id,'book2');
  assert.deepEqual(resourcesForContentMode(files,'pdf').map(x=>x.id), ['book1','book2']);
  assert.equal(nextResourceId(resourcesForContentMode(files,'pdf'),'book2',1),'book1');
  assert.equal(preferredResourceForMode(files,'videos',mem,files[1]).id,'film');
});

test('14: page/zoom positions are isolated and bounded in memory by resource', () => {
  clearV8ResourceSessionState();
  writeResourceState('page','bookA',8);writeResourceState('page','bookB',23);
  writeResourceState('zoom','bookA',2.1);writeResourceState('zoom','bookB',1.2);
  assert.equal(readResourceState('page','bookA'),8);
  assert.equal(readResourceState('page','bookB'),23);
  assert.equal(readResourceState('zoom','bookA'),2.1);
  assert.equal(readResourceState('zoom','bookB'),1.2);
  const renderer=code('src/components/classmode/MediaRenderer.jsx');
  assert.match(renderer,/readResourceState\('playback'/);
  assert.match(renderer,/kind}:\$\{String\(resource\?\.assetId/);
  const slides=code('src/components/classmode/PptxPreview.jsx');
  assert.match(slides,/WeakMap\(\)/);
  assert.match(slides,/pptx-slide/);
  clearV8ResourceSessionState();
});

test('15: PDF preload avoids invalid pages, limits queue and preserves exact source identity', () => {
  assert.deepEqual(pdfNeighborPages(1,12),[2]);
  assert.deepEqual(pdfNeighborPages(5,12),[6,4]);
  assert.deepEqual(pdfNeighborPages(12,12),[11]);
  assert.deepEqual(pdfNeighborPages(1,1),[]);
  for(const pair of [[0,10], [11,10],[2,-1],[NaN,10]]) assert.deepEqual(pdfNeighborPages(...pair),[]);
  assert.match(code('src/services/webPdfRenderer.js'),/preloadWebPdfNeighbors/);
  assert.match(code('src/hooks/usePdfPage.js'),/cancelPreload\?\.\(\)/);
  assert.match(code('src/services/pdfRenderer.js'),/MAX_CACHED_PDF_PAGES = 18/);
});

test('16: audio/video and PowerPoint keep independent positions and bounded caches', () => {
  const src=code('src/components/classmode/MediaRenderer.jsx');
  assert.match(src,/const MAX_PLAYBACK_MEMORY = 48/);
  assert.match(src,/preload="metadata"/);
  assert.match(src,/onTimeUpdate=\{state\.progress\}/);
  assert.match(src,/onLoadedMetadata=\{state\.loaded\}/);
  const pptx=code('src/components/classmode/PptxPreview.jsx');
  assert.match(pptx,/MAX_PPTX_CACHE = 4/);
  assert.match(pptx,/blob:\$\{actualBlob/);
});

test('17,18: real country cards show capital/region/fact and are placed over media layers', () => {
  assert.equal(COUNTRY_CARDS.length,35);
  assert.equal(new Set(COUNTRY_CARDS.map(x=>x.iso)).size,35);
  COUNTRY_CARDS.forEach(card=>{
    assert.ok(card.iso && card.name && card.capital && card.region && card.fact,card.name);
    assert.equal(countryCardByIso(card.iso),card);
    const path=fileURLToPath(new URL(`../public/whiteboard/country-cards/v8-verified-${card.key}.png`,import.meta.url));
    assert.ok(existsSync(path),path);
  });
  const classMode=code('src/pages/ClassMode.jsx');
  assert.match(classMode,/const addCountryCard =/);
  assert.match(classMode,/canPlaceLessonCards/);
  assert.match(classMode,/countryCardFields/);
  assert.match(classMode,/getCountryCard\(cardKey, countryCategory\)/);
});

test('19,20: geometries exist and projected coordinates preserve map proportions', () => {
  for(const region of ['egypt','africa','asia','europe','eurasia','nile','world']) {
    const actual=getRegionCountries(worldCountries,region);
    assert.ok(actual.length,region);
    assert.ok(actual.every(x=>x.geometry?.coordinates?.length));
    const project=createMapProjector(region);
    assert.equal(project(GEOGRAPHY_REGIONS[region].bounds[0],GEOGRAPHY_REGIONS[region].bounds[1]).length,2);
  }
  const asia=new Set(getRegionCountries(worldCountries,'asia').map(getCountryFeatureId));
  const europe=new Set(getRegionCountries(worldCountries,'europe').map(getCountryFeatureId));
  assert.ok(asia.has('RUS') && europe.has('RUS'));
  assert.ok(getRegionCountries(worldCountries,'eurasia').length>getRegionCountries(worldCountries,'europe').length);
});

test('21,22: the grid is geographic and all map-caption emitters obey label visibility', () => {
  const lines=referenceLinesForBounds(GEOGRAPHY_REGIONS.africa.bounds);
  assert.ok(lines.latitudes.some(x=>x.value===0));
  assert.ok(lines.longitudes.some(x=>x.value===0));
  const svg=code('src/components/maps/ProfessionalMap.jsx');
  assert.match(svg,/TeachingReferenceGrid[^\n]+labels=\{labels\}/);
  assert.match(svg,/TeachingRiverOverlay[^\n]+labels=\{labels\}/);
  assert.match(svg,/TeachingWaterBodies[^\n]+labels=\{labels\}/);
  assert.match(svg,/!silent && labels && <MapFurniture/);
  assert.match(svg,/\{labels && displayMode !== 'blank' && <text/);
});

test('23–26: the Nile path and both branches join; White/Blue/Atbara and Sudd are present', () => {
  const egypt=TEACHING_RIVER_PATHS.egypt;
  const main=egypt.find(x=>x.id==='nile-egypt');
  const west=egypt.find(x=>x.id==='delta-west-egypt');
  const east=egypt.find(x=>x.id==='delta-east-egypt');
  assert.deepEqual(main.coords.at(-1),west.coords[0]);
  assert.deepEqual(main.coords.at(-1),east.coords[0]);
  assert.ok(main.coords[0][1]<=22.1 && main.coords.at(-1)[1]>30);
  const nile=TEACHING_RIVER_PATHS.nile;
  for(const word of ['kagera','victoria-nile','albert-nile','bahr-jebel','bahr-ghazal','sobat','white-nile','blue-nile','atbara','main-nile','delta-west','delta-east'])
    assert.ok(nile.some(item=>item.id===word),word);
  for(const name of ['بحيرة فيكتوريا','بحيرة ألبرت','بحيرة تانا','مستنقعات السد','بحيرة ناصر'])
    assert.ok(TEACHING_WATER_BODIES.nile.some(x=>x.name===name),name);
  assert.ok(NILE_LANDMARKS.some(x=>x.id==='sudd'));
  assert.ok(NILE_LANDMARKS.some(x=>x.id==='khartoum'));
});

test('27–29: all Egyptian categories have actual features and 181 pictographic assets', () => {
  for(const [category,{ layers }] of Object.entries(GEOGRAPHY_TEACHING_CATEGORIES)) {
    assert.ok(layers.length,category);
    assert.ok(layers.some(key=>getRegionLayerItems(worldCountries,'egypt',key).length),category);
  }
  assert.equal(GEOGRAPHY_SYMBOLS.length,181);
  for(const sym of GEOGRAPHY_SYMBOLS) {
    const abs=fileURLToPath(new URL(`../public${sym.asset}`,import.meta.url));
    assert.ok(existsSync(abs),sym.asset);
  }
  for(const type of ['minerals','energy','agriculture','industry','ports','landmarks'])
    assert.ok(getRegionLayerItems(worldCountries,'egypt',type).length,type);
  const nile=getRegionLayerItems(worldCountries,'nile','rivers').map(x=>x.name);
  const seas=getRegionLayerItems(worldCountries,'nile','seas').map(x=>x.name);
  assert.ok(nile.includes('بحر الجبل'));
  assert.equal(seas.includes('بحر الجبل'),false);
  assert.ok(nile.every(item=>!item.startsWith('قناة ') && !item.startsWith('مضيق ')));
});

test('30: map percent coordinates remain invertible under a fitted SVG viewport', () => {
  const fitted=fitMapSvgViewport(1280,720);
  const rect={left:200+fitted.left,top:50+fitted.top,width:fitted.width,height:fitted.height};
  const point=percentWithinMapViewport(rect.left+rect.width*.28,rect.top+rect.height*.64,rect);
  assert.ok(Math.abs(point.x-28)<1e-8 && Math.abs(point.y-64)<1e-8);
  assert.equal(percentWithinMapViewport(rect.left-2,rect.top,rect),null);
  const svg=code('src/components/maps/ProfessionalMap.jsx');
  assert.match(svg,/onMovePlacement\(placementId, point.x, point.y\)/);
  assert.match(svg,/onDuplicatePlacement\?\.\(placement.id\)/);
  assert.match(svg,/onResizePlacement\?\.\(placement.id, 0.2\)/);
  assert.match(code('src/components/maps/LessonMapStudio.jsx'),/onSaveState\?\.\(state\)/);
});

test('map region snapshots do not erase another region’s layer, zoom, markers, or drawings',()=>{
  const original=normalizeLessonMapState({regionKey:'egypt',regions:{egypt:{layerKey:'minerals',zoom:2,placements:[{id:'a',x:3,y:6}]},nile:{layerKey:'rivers',zoom:1.6,strokes:[{id:'ink'}]}}});
  const next=mergeLessonMapRegion(original,'nile',{layerKey:'water',zoom:2.7,placements:[{id:'b',x:7,y:8}],strokes:[{id:'new'}]});
  assert.deepEqual(next.regions.egypt,original.regions.egypt);
  assert.equal(next.regions.nile.layerKey,'water');
  assert.equal(next.regionKey,'nile');
});
