#!/usr/bin/env python3
from pathlib import Path

worker = Path("cloud-worker/worker.js")
if not worker.is_file():
    raise SystemExit("Pinned base worker is missing")
text = worker.read_text(encoding="utf-8")


def replace_once(old, new, label):
    global text
    count = text.count(old)
    if count == 0:
        if new in text:
            return
        raise SystemExit(f"Pinned worker contract changed; missing {label}")
    if count != 1:
        raise SystemExit(f"Pinned worker contract ambiguous for {label}: {count}")
    text = text.replace(old, new, 1)


replace_once(
    "const PROJECT12_DEFAULT_STUDENT_PIN='123456';",
    "const PROJECT12_DEFAULT_STUDENT_PIN='12345678';",
    "student default PIN",
)
replace_once(
    "code=String(body.studentCode||'').replace(/\\D/g,'')",
    "code=String(body.studentCode||body.code||'').replace(/\\D/g,'')",
    "student login code compatibility",
)
replace_once(
    "message:'اختر PIN جديدًا من 6 إلى 10 أرقام غير 123456.'",
    "message:'اختر PIN جديدًا من 6 إلى 10 أرقام غير 12345678.'",
    "student PIN validation message",
)
replace_once(
    "studentPinDefaultVersion:1,studentPinChangedByStudentAt:changedAt",
    "studentPinDefaultVersion:2,studentPinChangedByStudentAt:changedAt",
    "student PIN policy version",
)

anchor = "const project12Same=(a,b)=>String(a??'')===String(b??'');\nfunction project12PortalData(data={},student={}){"
helper = """const project12Same=(a,b)=>String(a??'')===String(b??'');
function project12List(value){return Array.isArray(value)?value.map(x=>String(x??'').trim()).filter(Boolean):String(value??'').split(/[,\\n،]/g).map(x=>x.trim()).filter(Boolean);}
function project12ResourceAccess(resource={}){const raw=resource.access&&typeof resource.access==='object'?resource.access:{};let mode=String(raw.mode||resource.accessMode||'').trim();if(!mode){if(resource.publicVisible===true||resource.isPublic===true)mode='public';else mode='private';}return{mode,grade:String(raw.grade||resource.grade||'').trim(),groups:project12List(raw.groups||resource.accessGroups||resource.groups),studentIds:project12List(raw.studentIds||resource.accessStudentIds||resource.studentIds)};}
function project12StudentCanAccess(resource={},student={}){if(!resource||!student||resource.published===false||resource.archived===true)return false;const access=project12ResourceAccess(resource),grade=String(student.grade||''),group=String(student.group||''),id=String(student.id??''),code=String(student.code??'');if(access.mode==='public'||access.mode==='allStudents')return true;if(access.mode==='grade')return Boolean(access.grade)&&grade===access.grade;if(access.mode==='group')return Boolean(access.groups.length)&&(!access.grade||grade===access.grade)&&access.groups.includes(group);if(access.mode==='students')return access.studentIds.includes(id)||(code&&access.studentIds.includes(code));return false;}
function project12RecordMatchesStudent(record={},student={}){const id=String(student.id??''),code=String(student.code??''),grade=String(student.grade||''),group=String(student.group||''),ids=project12List(record.studentIds),codes=project12List(record.studentCodes);if(record.studentId!=null&&String(record.studentId)!==id)return false;if(record.studentCode!=null&&String(record.studentCode)!==code)return false;if(ids.length&&!ids.includes(id)&&(!code||!ids.includes(code)))return false;if(codes.length&&!codes.includes(code))return false;if(record.grade&&grade&&String(record.grade)!==grade)return false;if(record.group&&group&&String(record.group)!==group)return false;return true;}
function project12StudentContentLibrary(data={},student={}){const library=Array.isArray(data.contentLibrary)?data.contentLibrary:[],permittedLessons=library.filter(x=>x?.type==='lesson'&&project12StudentCanAccess(x,student)),lessonIds=new Set(permittedLessons.map(x=>String(x.id)));return library.flatMap(item=>{if(!item||item.published===false||item.archived===true)return[];if(project12StudentCanAccess(item,student))return[item];const type=String(item.type||'').toLowerCase(),lessonId=String(item.lessonId||item.parentLessonId||''),inherit=item.inheritLessonAccess===true&&['image','video','audio','ppt','pptx','pdf-page','lesson-attachment'].includes(type);return inherit&&lessonId&&lessonIds.has(lessonId)?[item]:[];});}
function project12PortalData(data={},student={}){"""
replace_once(anchor, helper, "explicit student content access helpers")
replace_once(
    "contentLibrary:(data.contentLibrary||[]).filter(x=>x?.studentVisible!==false&&x?.published!==false&&(!x?.grade||!grade||String(x.grade)===grade)),",
    "contentLibrary:project12StudentContentLibrary(data,student),",
    "student content library isolation",
)
replace_once(
    "contentLibrary:project12StudentContentLibrary(data,student),\n    customQuestionBank:",
    "contentLibrary:project12StudentContentLibrary(data,student),\n    lessonRecordings:(data.lessonRecordings||[]).filter(x=>x?.visibleToStudents!==false&&project12RecordMatchesStudent(x,student)),\n    customQuestionBank:",
    "student lesson-recording isolation",
)
replace_once(
    "sessions:(data.sessions||[]).filter(x=>(!grade||!x?.title||String(x.title)===grade)&&(!group||!x?.group||String(x.group)===group)),",
    "sessions:(data.sessions||[]).filter(x=>project12RecordMatchesStudent(x,student)),",
    "student session grade/group isolation",
)
replace_once(
    "customQuestionBank:(data.customQuestionBank||[]).filter(x=>!x?.grade||!grade||String(x.grade)===grade),",
    "customQuestionBank:(data.customQuestionBank||[]).filter(x=>x?.approved!==false&&project12RecordMatchesStudent(x,student)),",
    "student question-bank review isolation",
)
replace_once(
    "exams:Array.isArray(data.exams)?data.exams:[],",
    "exams:(data.exams||[]).filter(x=>x?.published!==false&&x?.archived!==true&&project12RecordMatchesStudent(x,student)),",
    "student exam isolation",
)
replace_once(
    "classPointSessions:(data.classPointSessions||[]).map(s=>({...s,points:s?.points&&Object.prototype.hasOwnProperty.call(s.points,id)?{[id]:s.points[id]}:{}})),",
    "classPointSessions:(data.classPointSessions||[]).filter(s=>project12RecordMatchesStudent(s,student)).map(s=>({...s,points:s?.points&&Object.prototype.hasOwnProperty.call(s.points,id)?{[id]:s.points[id]}:{},startPoints:s?.startPoints&&Object.prototype.hasOwnProperty.call(s.startPoints,id)?{[id]:s.startPoints[id]}:{},earned:s?.earned&&Object.prototype.hasOwnProperty.call(s.earned,id)?{[id]:s.earned[id]}:{}})),",
    "student class-point session isolation",
)

old_asset_loop = """  for (const item of portal.contentLibrary || []) {
    const type = String(item?.type || '').toLowerCase();
    const kind = String(item?.kind || '').toLowerCase();
    if ((type === 'image' || kind === 'lesson-media' || kind === 'lesson-image') && item?.assetId) allowed.add(String(item.assetId));
    if (item?.thumbnailAssetId) allowed.add(String(item.thumbnailAssetId));
  }
"""
new_asset_loop = """  const addAsset = (value) => { if (value) allowed.add(String(value)); };
  for (const item of portal.contentLibrary || []) {
    addAsset(item?.assetId); addAsset(item?.examAssetId); addAsset(item?.thumbnailAssetId); addAsset(item?.recordingAssetId);
  }
  for (const item of portal.lessonRecordings || []) {
    addAsset(item?.assetId); addAsset(item?.boardAssetId); addAsset(item?.videoAssetId); addAsset(item?.audioAssetId); addAsset(item?.thumbnailAssetId);
  }
"""
replace_once(old_asset_loop, new_asset_loop, "student authorized asset allow-list")

worker.write_text(text, encoding="utf-8")
print("Pinned base worker R13 policy patch: OK")
