/** Read-only structural gate on the actual project tree (not a string-only feature test). */
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const failures = [];
const exists = (relative) => fs.existsSync(path.join(root, relative));
const required = [
  'package.json', 'src/App.jsx', 'src/pages/ClassMode.jsx',
  'src/pages/Dashboard.jsx', 'src/pages/OnlineClass.jsx',
  'src/pages/MapChallenge.jsx', 'src/pages/Whiteboard.jsx',
  'src/pages/Students.jsx', 'src/pages/Reports.jsx',
  'src/pages/ContentLibrary.jsx', 'src/pages/PortalPreview.jsx',
  'src/pages/MobdeaOnlineHub.jsx',
  'src/components/AppErrorBoundary.jsx',
  'public/identity/class-board-history-v14.jpg',
  'public/identity/mostafa-barakat.jpg',
];
for (const file of required) if (!exists(file)) failures.push(`missing project/identity asset: ${file}`);
const { MAP_SYMBOLS } = await import('../src/data/mapSymbolCatalog.js');
const iconPaths = MAP_SYMBOLS.map((item) => `public${item.asset}`);
if (MAP_SYMBOLS.length !== 181) failures.push(`expected 181 map symbols; got ${MAP_SYMBOLS.length}`);
for (const icon of iconPaths) {
  if (!exists(icon)) { failures.push(`missing map symbol image: ${icon}`); continue; }
  const image = fs.readFileSync(path.join(root, icon));
  if (!image.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) {
    failures.push(`invalid map symbol PNG: ${icon}`);
  }
}
const visited = new Set();
function visit(directory) {
  if (!fs.existsSync(directory)) return;
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) visit(full);
    else if (/\.(jsx?|mjs|cjs)$/.test(entry.name)) visited.add(full);
  }
}
visit(path.join(root, 'src'));
const dependency = /\b(?:from\s*|import\s*\(\s*|import\s*|require\s*\(\s*)['"](\.{1,2}\/[^'"\n]+)['"]/g;
for (const full of visited) {
  const text = fs.readFileSync(full, 'utf8');
  for (const match of text.matchAll(dependency)) {
    const base = path.resolve(path.dirname(full), match[1]);
    if (![base, `${base}.js`, `${base}.jsx`, `${base}.mjs`, `${base}.json`, `${base}.css`,
      path.join(base, 'index.js'), path.join(base, 'index.jsx')].some(fs.existsSync)) {
      failures.push(`missing relative import: ${path.relative(root, full)} → ${match[1]}`);
    }
  }
}
if (failures.length) {
  process.stderr.write(`Section-7 structural preflight FAILED (${failures.length}):\n${failures.join('\n')}\n`);
  process.exitCode = 1;
} else {
  process.stdout.write(`Section-7 structural preflight PASS: ${visited.size} source files, ${iconPaths.length} referenced icon images. Does NOT prove browser/device behavior.\n`);
}
