import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { collectStudentVisibleImageIds } from '../src/services/studentVisibleImageIds.js';
import { linkedStudentsForGuardian } from '../src/services/rolePortalAccess.js';

const text = (path) => readFileSync(new URL(path, import.meta.url), 'utf8');
const asUrl = (value) => 'data:text/javascript;base64,' + Buffer.from(value).toString('base64');
const securityUrl = asUrl(text('../src/utils/security.js'));
const cloudUrl = asUrl('export const cloudConfigured=()=>false;export const pushCloudData=async()=>{throw Error("unreachable")}');
const policyUrl = asUrl(text('../src/services/studentPinPolicy.js')
  .replace("from '../utils/security'", `from '${securityUrl}'`)
  .replace("from './cloudSync'", `from '${cloudUrl}'`));
const policy = await import(policyUrl);
const security = await import(securityUrl);

test('PIN 123456 does not bypass a freshly reset hashed 12345678 credential', async () => {
  const reset = { id: 1, ...await security.createCredentialSecret('12345678', 'student'),
    studentPinMustChange: true };
  assert.deepEqual(await policy.verifyLocalStudentPin(reset, '123456'), { valid: false, mustChangePin: false });
  assert.deepEqual(await policy.verifyLocalStudentPin(reset, '12345678'), { valid: true, mustChangePin: true });
});

test('fresh new student can enter 12345678 but not 123456; custom PIN survives', async () => {
  assert.deepEqual(await policy.verifyLocalStudentPin({ id: 1 }, '12345678'), { valid: true, mustChangePin: true });
  assert.equal((await policy.verifyLocalStudentPin({ id: 1 }, '123456')).valid, false);
  const custom = { ...await security.createCredentialSecret('98765432', 'student'), studentPinChangedByStudentAt: '2026-09-01' };
  assert.deepEqual(await policy.verifyLocalStudentPin(custom, '98765432'), { valid: true, mustChangePin: false });
  assert.equal((await policy.verifyLocalStudentPin(custom, '12345678')).valid, false);
  assert.equal((await policy.verifyLocalStudentPin({ studentPin: '87654321' }, '12345678')).valid, false);
});

test('LockScreen delegates credential check to the unified PIN policy', () => {
  const source = text('../src/components/LockScreen.jsx');
  assert.match(source, /await verifyLocalStudentPin\(student, pin\)/);
  assert.doesNotMatch(source, /normalizePin\(pin\) === '123456'/);
});

test('shared guardian phone numbers alone cannot link a second child', () => {
  const data = { students: [{ id: 1, guardianPhone: '0100' }, { id: 2, guardianPhone: '0100' }] };
  assert.deepEqual(linkedStudentsForGuardian(data, { role: 'guardian', guardianPhone: '0100', studentId: 1 }).map(x => x.id), [1]);
  assert.deepEqual(linkedStudentsForGuardian(data, { role: 'guardian', guardianPhone: '0100' }), []);
  const app = text('../src/App.jsx');
  assert.match(app, /linkedStudentsForGuardian\(data, auth\)\.length > 0/);
  assert.doesNotMatch(app, /normalize\(student\.guardianPhone\) === normalize\(auth\.guardianPhone\)/);
});

test('only explicitly published image IDs belonging to the authenticated student can be prefetched', () => {
  const library = [
    { id: 'published', type: 'image', assetId: 'public-1', access: { mode: 'public' } },
    { id: 'mine', type: 'image', assetId: 'mine-1', access: { mode: 'students', studentIds: ['1'] } },
    { id: 'their', type: 'image', assetId: 'their-2', access: { mode: 'students', studentIds: ['2'] } },
    { id: 'unpublished-grade', type: 'image', assetId: 'private-grade', grade: '6' },
    { id: 'private-thumb', type: 'textbook', thumbnailAssetId: 'secret-thumb', access: { mode: 'private' } },
    { id: 'public-thumb', type: 'textbook', thumbnailAssetId: 'public-thumb', access: { mode: 'public' } },
    { id: 'disabled', type: 'image', assetId: 'disabled', published: false, access: { mode: 'public' } },
  ];
  assert.deepEqual(collectStudentVisibleImageIds({ students: [{ id: 1, code: '001', grade: '6' }], contentLibrary: library }),
    ['public-1','mine-1','public-thumb']);
  assert.deepEqual(collectStudentVisibleImageIds({ students: [{ id: 1 }, { id: 2 }], contentLibrary: library }), []);
  assert.deepEqual(collectStudentVisibleImageIds({ contentLibrary: library }), []);
});
