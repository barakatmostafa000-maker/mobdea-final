import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
// Isolated unit tests for snapshot reconciliation while the offline QA image
// lacks the project's Capacitor packages; the release still requires npm ci.
const code = (await readFile(new URL('../src/services/studentPortalCloud.js', import.meta.url), 'utf8'))
  .replace(/^import\s+.*?;\s*$/gm, '');
const { mergeStudentPortalSnapshot } = await import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'));

const base = () => ({
  students: [{ id: 'alice', code: '110', name: 'Alice' }, { id: 'bob', code: '220', name: 'Bob' }],
  settings: { studentPortalSession: { studentId: 'alice', studentCode: '110', studentToken: 'token-alice' } },
  grades: [], attendance: [], achievements: [], payments: [], gameResults: [], mapResults: [],
  contentLibrary: [], lessonRecordings: [], customQuestionBank: [],
});

test('refresh cannot replace the authenticated child with another child', () => {
  assert.throws(() => mergeStudentPortalSnapshot(base(), {
    student: { id: 'bob', code: '220' },
    data: { students: [{ id: 'bob', code: '220' }], grades: [{ id: 'bob-grade', studentId: 'bob', score: 50 }] },
  }, base().settings.studentPortalSession), /هوية الطالب/);
});

test('refresh cannot silently accept conflicting student ID/code from response', () => {
  assert.throws(() => mergeStudentPortalSnapshot(base(), {
    student: { id: 'alice', code: '220' }, data: {},
  }, base().settings.studentPortalSession), /هوية الطالب/);
});

test('recycled school code cannot overwrite a different student or create duplicate logins', () => {
  const local = base();
  assert.throws(() => mergeStudentPortalSnapshot(local, {
    student: { id: 'charlie', code: '220', name: 'Charlie' }, data: {},
  }, { studentToken: 'fresh-session', studentId: 'charlie', studentCode: '220' }), /تعارض كود الطالب/);
  assert.deepEqual(local.students.map((s) => s.name), ['Alice', 'Bob']);
});

test('refresh discards records from unrelated students sent by a faulty server', () => {
  const local = base();
  const merged = mergeStudentPortalSnapshot(local, {
    student: { id: 'alice', code: '110' }, data: {
      grades: [{ id: 'a-grade', studentId: 'alice', score: 8 }, { id: 'b-grade', studentId: 'bob', score: 99 }],
      attendance: [{ id: 'a-att', studentId: 'alice' }, { id: 'b-att', studentId: 'bob' }],
    },
  }, local.settings.studentPortalSession);
  assert.deepEqual(merged.grades.map((g) => g.id), ['a-grade']);
  assert.deepEqual(merged.attendance.map((g) => g.id), ['a-att']);
});

test('merging an exam with the same ID cannot copy another child’s cached data', () => {
  const local = base();
  local.grades = [{ id: 'exam1', studentId: 'bob', teacherSecret: 'bob-private-comment', score: 100 }];
  const merged = mergeStudentPortalSnapshot(local, {
    student: { id: 'alice', code: '110' }, data: { grades: [{ id: 'exam1', studentId: 'alice', score: 80 }] },
  }, local.settings.studentPortalSession);
  assert.equal(merged.grades.length, 1);
  const alice = merged.grades.find((g) => g.studentId === 'alice');
  assert.equal(alice.score, 80);
  assert.equal(Object.hasOwn(alice, 'teacherSecret'), false);
});

test('a snapshot student code inconsistent with authenticated student is rejected', () => {
  assert.throws(() => mergeStudentPortalSnapshot(base(), {
    student: { id: 'alice', code: '110' }, data: { students: [{ id: 'alice', code: '220' }] },
  }, base().settings.studentPortalSession), /هوية الطالب/);
});
