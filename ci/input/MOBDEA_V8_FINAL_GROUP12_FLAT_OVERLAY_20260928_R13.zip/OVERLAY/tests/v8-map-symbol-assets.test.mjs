import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { MAP_SYMBOL_GROUPS, MAP_SYMBOLS } from '../src/data/mapSymbolCatalog.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const pngHeader=Buffer.from([137,80,78,71,13,10,26,10]);
test('181 functional symbol PNG files exist and are valid at exactly the catalog paths',()=>{
 assert.equal(MAP_SYMBOL_GROUPS.length,19);assert.equal(MAP_SYMBOLS.length,181);
 const ids=new Set(); const urls=new Set();
 for (const item of MAP_SYMBOLS){
  assert.ok(!ids.has(item.id),'duplicate icon id '+item.id);ids.add(item.id);
  assert.ok(item.asset.startsWith('/map-symbols/'));assert.ok(!urls.has(item.asset),'duplicate icon URL '+item.asset);urls.add(item.asset);
  const file=path.resolve(root,'public',item.asset.slice(1));
  assert.ok(file.startsWith(path.resolve(root,'public','map-symbols')+path.sep),'icon outside public');
  assert.ok(existsSync(file),'MISSING ICON '+file);
  const buffer=readFileSync(file);assert.ok(buffer.length>550,'empty icon '+file);
  assert.ok(buffer.subarray(0,8).equals(pngHeader),'not PNG '+file);
  const w=buffer.readUInt32BE(16),h=buffer.readUInt32BE(20);
  assert.ok(w>0 && h>0 && w<=4096 && h<=4096,'invalid PNG dimensions '+file);
 }
});
