import test from 'node:test';
import assert from 'node:assert/strict';
import { pdfDocumentIdentity, pdfPageIdentity } from '../src/services/pdfDocumentIdentity.js';

test('two PDFs with same size, filename, type and resource ID never reuse cached pages', () => {
  const a = new Blob(['abcdef'], { type: 'application/pdf' });
  const b = new Blob(['uvwxyz'], { type: 'application/pdf' });
  assert.equal(a.size, b.size);
  assert.notEqual(pdfDocumentIdentity({ blob: a }, 'book1'), pdfDocumentIdentity({ blob: b }, 'book1'));
  assert.equal(pdfDocumentIdentity({ blob: a }, 'book1'), pdfDocumentIdentity({ blob: a }, 'book1'));
});

test('PDF page or signed URL change invalidates visible page identity', () => {
  const source = { url: 'https://example.test/file?version=1' };
  assert.notEqual(pdfPageIdentity(source, 'book1', 1), pdfPageIdentity(source, 'book1', 2));
  assert.notEqual(pdfDocumentIdentity(source, 'book1'), pdfDocumentIdentity({ url: 'https://example.test/file?version=2' }, 'book1'));
  assert.notEqual(pdfDocumentIdentity(source, 'book1'), pdfDocumentIdentity(source, 'book2'));
});

test('ClassMode focus control toggles the existing focus state independently from Fullscreen', async () => {
  const { readFile } = await import('node:fs/promises');
  const source = await readFile(new URL('../src/pages/ClassMode.jsx', import.meta.url), 'utf8');
  assert.match(source, /classmode-stage-focus-toggle/);
  assert.match(source, /classmode-board-focus-toggle/);
  assert.match(source, /onClick=\{\(\) => setStageFocus\(\(current\) => !current\)\}/);
  assert.match(source, /onClick=\{toggleFullscreen\}/);
});

test('PDF canvas rejects previous book/page preview synchronously, even before its effect runs', async () => {
  const { readFile } = await import('node:fs/promises');
  const source = await readFile(new URL('../src/components/classmode/PdfCanvasPreview.jsx', import.meta.url), 'utf8');
  assert.match(source, /renderedIdentity === requestIdentity \? renderedUrl : ""/);
  assert.match(source, /\{visibleRenderedUrl && \(/);
  assert.match(source, /src=\{visibleRenderedUrl\}/);
});
