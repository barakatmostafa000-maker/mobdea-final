import test from 'node:test';
import assert from 'node:assert/strict';
import { recognizePageForQuestions, clearR20PageOcrCache } from '../src/services/r20PageOcrPipeline.js';

test('native PDF OCR follows the same normalized promise contract and caches only same asset/page', async () => {
  let calls = 0;
  const prev = globalThis.Capacitor;
  globalThis.Capacitor = {
    isNativePlatform: () => true,
    Plugins: {R20PageOcr: {recognizePdfPage: async () => {calls++; return {text:'نص الصفحة', pageNumber:3};}}},
  };
  try {
    clearR20PageOcrCache();
    const request = {assetId:'book-A',pageNumber:3};
    const first = await recognizePageForQuestions(request);
    const second = await recognizePageForQuestions(request);
    assert.equal(first.ok,true);
    assert.equal(first.pageNumber,3);
    assert.equal(first.text,'نص الصفحة');
    assert.equal(first.engine,'native');
    assert.deepEqual(second,first);
    assert.equal(calls,1);
    await recognizePageForQuestions({...request,pageNumber:4});
    assert.equal(calls,2);
  } finally {clearR20PageOcrCache();globalThis.Capacitor=prev;}
});

test('two unkeyed uploaded images never share stale recognized answers', async () => {
  const prev = globalThis.Capacitor;
  let calls = 0;
  globalThis.Capacitor = {
    isNativePlatform: () => true,
    Plugins: {R20PageOcr: {recognizePage: async () => ({text:`different-image-${++calls}`})}},
  };
  try {
    clearR20PageOcrCache();
    const a = await recognizePageForQuestions({imageBase64:'image-A'});
    const b = await recognizePageForQuestions({imageBase64:'image-B'});
    assert.equal(a.text,'different-image-1');
    assert.equal(b.text,'different-image-2');
    assert.equal(calls,2);
  } finally {clearR20PageOcrCache();globalThis.Capacitor=prev;}
});

test('rejected native OCR request is removed from cache so retry works', async () => {
  const prev = globalThis.Capacitor;
  let calls = 0;
  globalThis.Capacitor = {
    isNativePlatform: () => true,
    Plugins: {R20PageOcr: {recognizePdfPage: async () => {
      if (++calls === 1) throw new Error('temporary device problem');
      return {text:'recovered OCR'};
    }}},
  };
  try {
    clearR20PageOcrCache();
    await assert.rejects(recognizePageForQuestions({resourceId:'doc-retry',pageNumber:1}), /temporary device problem/);
    const again = await recognizePageForQuestions({resourceId:'doc-retry',pageNumber:1});
    assert.equal(again.ok,true);
    assert.equal(again.text,'recovered OCR');
    assert.equal(calls,2);
  } finally {clearR20PageOcrCache();globalThis.Capacitor=prev;}
});
