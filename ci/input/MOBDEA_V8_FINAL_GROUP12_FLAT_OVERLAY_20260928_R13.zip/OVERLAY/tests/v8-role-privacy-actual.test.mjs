import test from 'node:test';
import assert from 'node:assert/strict';
import { findStudentForAuth, linkedStudentsForGuardian, filterContentLibraryForRole, scopeReadOnlyDataForRole } from '../src/services/rolePortalAccess.js';
const students = [
  { id: 1, code: 'one', name: 'A', guardianPhone: '01012345678', grade: 'g', group: 'one' },
  { id: 2, code: 'two', name: 'B', guardianPhone: '01012345678', grade: 'g', group: 'two' },
];
const data = {
  students, passwords: ['teacher-secret'], customQuestionBank: [{ id:'teacher-secret-question' }],
  contentLibrary: [
    {id:'lesson',type:'lesson', grade:'g', access:{mode:'students',studentIds:['1']}},
    {id:'private-book',type:'textbook',grade:'g',access:{mode:'private'}, assetId:'private-teacher-book'},
    {id:'public-book',type:'textbook',grade:'g',access:{mode:'public'}},
  ],
  sessions: [{id:1,group:'one'},{id:2,group:'two'}],
  grades: [{studentId:1,value:5},{studentId:2,value:10}],
  notifications: [{studentId:1,message:'a'},{studentId:2,message:'b'}],
};
test('guardian only sees explicitly linked children, not anyone sharing a phone', () => {
  const auth = { role:'guardian', studentIds:['1'], guardianPhone:'01012345678' };
  assert.deepEqual(linkedStudentsForGuardian(data,auth).map(s=>s.id),[1]);
  const result = scopeReadOnlyDataForRole(data,auth);
  assert.deepEqual(result.students.map(s=>s.id),[1]);
  assert.deepEqual(result.grades.map(s=>s.studentId),[1]);
  assert.deepEqual(result.sessions.map(s=>s.id),[1]);
  assert.equal('passwords' in result,false);
  assert.equal('customQuestionBank' in result,false);
});
test('unlinked guardian session cannot see all groups or children', () => {
  const result = scopeReadOnlyDataForRole(data,{role:'guardian',guardianPhone:'01012345678'});
  assert.deepEqual(result.students,[]);
  assert.deepEqual(result.sessions,[]);
  assert.deepEqual(result.grades,[]);
});
test('authorized lesson does not disclose the entire private teacher textbook by grade', () => {
  const result = filterContentLibraryForRole(data,{role:'student', studentId:1});
  assert.deepEqual(result.map(r=>r.id),['lesson','public-book']);
});
test('visitor search cannot see grades, children, credentials or sessions', () => {
  const result = scopeReadOnlyDataForRole(data,{role:'visitor'});
  assert.deepEqual(result.students,[]);
  assert.deepEqual(result.grades,[]);
  assert.deepEqual(result.sessions,[]);
  assert.deepEqual(result.notifications,[]);
  assert.deepEqual(result.contentLibrary.map(r=>r.id),['public-book']);
  assert.equal('passwords' in result,false);
});


test('conflicting student ID and student code never select an unrelated student', () => {
  assert.equal(findStudentForAuth(data, {role:'student',studentId:1, studentCode:'two'}), null);
  assert.deepEqual(scopeReadOnlyDataForRole(data, {role:'student',studentId:1,studentCode:'two'}).students, []);
  assert.equal(findStudentForAuth(data, {role:'student',studentId:1,studentCode:'one'})?.id, 1);
});

test('private books/exams cannot be inherited by attaching them to an assigned lesson', () => {
  const mixed = {...data, contentLibrary: [
    ...data.contentLibrary,
    {id:'linked-private-book',type:'textbook',lessonId:'lesson', access:{mode:'private'}, assetId:'all-chapters'},
    {id:'linked-private-exams',type:'exams',lessonId:'lesson',access:{mode:'private'}},
    {id:'linked-private-file',type:'pdf-page',lessonId:'lesson',access:{mode:'private'}},
    {id:'approved-lesson-attachment',type:'pdf-page',lessonId:'lesson',inheritLessonAccess:true,access:{mode:'private'}},
  ]};
  assert.deepEqual(filterContentLibraryForRole(mixed,{role:'student',studentId:1}).map(v=>v.id),[
    'lesson','public-book','approved-lesson-attachment',
  ]);
});

test('role projection excludes unlinked achievements rather than exposing other students', () => {
  const mixed={...data, achievements:[
    {studentId:1,title:'mine'},{studentId:2,title:'other'},{title:'unlinked private record'},
  ]};
  assert.deepEqual(scopeReadOnlyDataForRole(mixed,{role:'student',studentId:1}).achievements.map(v=>v.title),['mine']);
});
