import test from 'node:test';
import assert from 'node:assert/strict';
import { structureOcrQuestions } from '../src/services/ocrQuestionParser.js';
test('OCR preserves original multiple-choice label for review and full answer for game bank', () => {
 const result=structureOcrQuestions('١- ما عاصمة مصر؟\nأ) القاهرة\nب) الإسكندرية\nالإجابة: أ');
 assert.equal(result.questions[0].answer, 'القاهرة');
 assert.match(result.questionText, /الإجابة: أ/);
});
