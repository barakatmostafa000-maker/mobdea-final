import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = (p) => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('R13: V8 owns global CSS; no R18/R19/R20 stylesheet is imported by main', () => {
  const main = read('src/main.jsx');
  assert.doesNotMatch(main, /import\s+['"]\.\/styles\/(?:r18|r19|r20)-[^'"]+\.css['"]/);
  assert.match(main, /v8-authoritative-compat\.css/);
});

test('R13: compatibility layer contains only current React-owned critical controls', () => {
  const css = read('src/styles/v8-authoritative-compat.css');
  for (const selector of [
    '.classmode-management-actions-panel',
    '.classmode-management-actions-grid',
    '.classmode-text-size-btn',
    '.classmode-text-size-value',
    '.classmode-pdf-edge-nav',
    '.dashboard-v103 .dashboard-image-hotspot',
    '.dashboard-v103 .dashboard-hotspot-schedule',
    '.dashboard-v103 .dashboard-hotspot-class',
  ]) assert.match(css, new RegExp(selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  assert.doesNotMatch(css, /data-r20-|r20-master|r20-classmode|r19-students-left-panel/);
});

test('R13: release identity is distinct from R12', () => {
  const pkg = JSON.parse(read('package.json'));
  const version = read('src/config/version.js');
  assert.equal(pkg.version, '10.14.5');
  assert.equal(Number(pkg.mobdea?.versionCode), 122);
  assert.match(version, /RELEASE_TAG = "V8-G12-R13"/);
});
