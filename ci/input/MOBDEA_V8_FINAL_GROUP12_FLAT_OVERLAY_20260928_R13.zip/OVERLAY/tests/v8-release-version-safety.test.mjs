import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = process.cwd();
const source = fs.readFileSync(path.join(root,'scripts/sync-version.mjs'),'utf8');
const generated = fs.readFileSync(path.join(root,'src/config/version.js'),'utf8');
test('V8 release tag is package-driven and consistent in displayed version and generator', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  const expected = String(pkg.mobdea?.releaseTag || '');
  assert.match(expected, /^V8-G12-R1[3-9]$/);
  assert.ok(source.includes('const releaseTag = String(pkg.mobdea?.releaseTag'));
  assert.ok(source.includes('RELEASE_TAG = \"${releaseTag}\"'));
  assert.ok(generated.includes(`RELEASE_TAG = "${expected}"`));
});
test('missing native project aborts version synchronization before any source edits', () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(),'mobdea-version-'));
  try {
    fs.mkdirSync(path.join(temp,'scripts'));
    fs.mkdirSync(path.join(temp,'src/config'),{recursive:true});
    fs.mkdirSync(path.join(temp,'public'),{recursive:true});
    fs.copyFileSync(path.join(root,'scripts/sync-version.mjs'),path.join(temp,'scripts/sync-version.mjs'));
    fs.writeFileSync(path.join(temp,'package.json'),JSON.stringify({version:'10.14.1',mobdea:{versionCode:118},type:'module'}));
    fs.writeFileSync(path.join(temp,'src/config/version.js'),'SENTINEL_UNMODIFIED');
    fs.writeFileSync(path.join(temp,'public/update.manifest.json'),'{}');
    const proc=spawnSync(process.execPath,['scripts/sync-version.mjs'],{cwd:temp,encoding:'utf8'});
    assert.notEqual(proc.status,0);
    assert.match(proc.stderr,/Missing Android build configuration/);
    assert.equal(fs.readFileSync(path.join(temp,'src/config/version.js'),'utf8'),'SENTINEL_UNMODIFIED');
  } finally {fs.rmSync(temp,{recursive:true,force:true});}
});
