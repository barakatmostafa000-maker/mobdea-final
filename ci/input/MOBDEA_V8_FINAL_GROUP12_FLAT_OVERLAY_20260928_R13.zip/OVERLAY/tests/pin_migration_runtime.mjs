import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
const dir = process.argv[2] || process.cwd();
const asUrl = (s) => 'data:text/javascript;base64,' + Buffer.from(s).toString('base64');
const security = asUrl(readFileSync(`${dir}/src/utils/security.js`, 'utf8'));
const cloud = asUrl('export const cloudConfigured=()=>false; export const pushCloudData=async()=>{throw Error("unreachable")}');
const policySource = readFileSync(`${dir}/src/services/studentPinPolicy.js`, 'utf8')
  .replace("from '../utils/security'", `from '${security}'`)
  .replace("from './cloudSync'", `from '${cloud}'`);
const policy = await import(asUrl(policySource));
const { createCredentialSecret, verifyCredentialSecret } = await import(security);
const custom = await createCredentialSecret('96385274','student');
const oldFactory = await createCredentialSecret('123456','student');
const source = {settings:{studentPinDefaultVersion:1}, students:[
  {id: 'changed', ...custom, studentPinChangedByStudentAt:'2026-08-01', studentPinMustChange:false},
  {id: 'legacy-factory', ...oldFactory, studentPinMustChange:true},
  {id: 'unmarked-custom', ...custom},
  {id: 'new-no-secret',studentPin:'123456'},
  {id:'legacy-plain-custom', studentPin:'76543219'},
]};
let saved;
const result = await policy.migrateAllStudentsToUnifiedDefaultPin(source, async(data)=>{saved=data;return data;});
const get = id => saved.students.find(x=>x.id===id);
assert.equal(result.resetCount, 2);
assert.equal(result.preservedCount, 3);
assert.deepEqual(get('changed'),source.students[0]);
assert.deepEqual(get('unmarked-custom'),source.students[2]);
assert.deepEqual(get('legacy-plain-custom'),source.students[4]);
for(const id of ['legacy-factory','new-no-secret']){
 assert.equal(await verifyCredentialSecret('12345678',get(id),'student'),true,id);
 assert.equal(get(id).studentPinMustChange,true,id);
 assert.equal(await verifyCredentialSecret('123456',get(id),'student'),false, `old default must not remain valid: ${id}`);
 assert.equal(Object.hasOwn(get(id),'studentPin'),false, `plain-text secret must be removed: ${id}`);
}
assert.equal(policy.needsUnifiedStudentPinMigration(saved),false);
console.log('PASS: changed and unknown-custom PINs preserved; only provable defaults/new students receive 12345678; first login requires change.');
