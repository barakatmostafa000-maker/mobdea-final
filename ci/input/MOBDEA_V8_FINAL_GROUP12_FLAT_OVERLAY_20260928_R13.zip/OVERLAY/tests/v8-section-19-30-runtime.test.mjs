import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import world from '../src/data/world-countries.json' with { type: 'json' };
import {
  GEOGRAPHY_REGIONS, GEOGRAPHY_LAYERS, GEOGRAPHY_SYMBOL_GROUPS, GEOGRAPHY_FEATURES,
  GEOGRAPHY_TEACHING_CATEGORIES, createMapProjector, getRegionCountries,
  getRegionLayerItems, getTeachingCategoryLayers,
} from '../src/data/geography.js';
import { TEACHING_RIVER_PATHS, TEACHING_WATER_BODIES, NILE_LANDMARKS } from '../src/data/project06TeachingMaps.js';
import { normalizeLessonMapState, normalizeMapRegionSnapshot } from '../src/services/lessonMapState.js';

const text = (f) => fs.readFileSync(new URL(f, import.meta.url), 'utf8');

test('19 geography shapes: Asia, Europe and Eurasia are independently selectable; Russia included both', () => {
  const country = new Map(world.features.map((v) => [v.properties.iso_a3, v]));
  for (const region of ['asia', 'europe', 'eurasia']) {
    assert.ok(GEOGRAPHY_REGIONS[region]);
    assert.ok(getRegionCountries(world, region).length > 25);
    assert.ok(getRegionCountries(world, region).some((f) => f.properties.iso_a3 === 'RUS'));
    const project = createMapProjector(region);
    const [x,y]=project(30,50); assert.ok(Number.isFinite(x)&&Number.isFinite(y));
  }
  assert.ok(country.has('EGY'));
});
test('20 map layout: teaching map is viewport-contained, has zoom and pan; symbols transform with map', () => {
  const renderer=text('../src/components/maps/ProfessionalMap.jsx');
  const css=text('../src/styles/v8-section-19-30-maps.css');
  assert.match(renderer,/map-pro-transform/); assert.match(renderer,/translate3d/);
  assert.match(renderer,/map-pro-placement-layer/); assert.match(renderer,/clientPointToMapPercent/);
  assert.match(css,/lesson-map-studio/);
});
test('21 and 22 atlas/blank modes survive region save and reload, without leaked labels', () => {
  const state=normalizeLessonMapState({regionKey:'egypt',regions:{egypt:{displayMode:'blank',silentMap:true,labels:false,mapStyle:'atlas',zoom:2,placements:[{id:'p',x:28,y:32}]}}});
  assert.equal(state.displayMode,'blank');assert.equal(state.silentMap,true); assert.equal(state.labels,false);
  assert.equal(state.mapStyle,'atlas');assert.equal(state.zoom,2);assert.equal(state.placements[0].id,'p');
  const snapshot=normalizeMapRegionSnapshot({displayMode:'atlas',labels:true,mapStyle:'relief',silentMap:false});
  assert.equal(snapshot.silentMap,false);
  const renderer=text('../src/components/maps/ProfessionalMap.jsx');
  assert.match(renderer,/effectiveDisplayMode = silent \? 'blank' : displayMode/);
  assert.match(renderer,/displayMode !== 'blank'/);
});
test('23-26 real split Nile network: mouths, Victoria, Sudd, White and Blue Nile, Atbara', () => {
  const river=Object.fromEntries(TEACHING_RIVER_PATHS.nile.map((v)=>[v.id,v]));
  for(const id of ['kagera','victoria-nile','albert-nile','bahr-jebel','bahr-ghazal','sobat','white-nile','blue-nile','atbara','main-nile','delta-west','delta-east']){
    assert.ok(river[id],id); assert.ok(river[id].coords.length>=3,id);
  }
  const delta=TEACHING_RIVER_PATHS.egypt;
  assert.ok(delta.find((x)=>x.id==='delta-west-egypt').coords.at(-1)[0]<30.5);
  assert.ok(delta.find((x)=>x.id==='delta-east-egypt').coords.at(-1)[0]<32);
  assert.ok(delta.find((x)=>x.id==='nile-egypt').coords.length>16);
  assert.ok(delta.find((x)=>x.id==='nile-egypt').coords[0][1]<=22.1, 'southern border and Lake Nasser visible');
  const waters=TEACHING_WATER_BODIES.nile;
  for(const id of ['sudd-wetlands','victoria-basin','albert-basin','tana-basin','nasser-lake']){
    assert.ok(waters.some((v)=>v.id===id&&v.coords.length>=5),id);
  }
  assert.ok(NILE_LANDMARKS.some(x=>x.id==='rosetta-mouth'));
  assert.ok(NILE_LANDMARKS.some(x=>x.id==='damietta-mouth'));
});
test('27/28 five Egypt study categories and actual geography teaching places', () => {
  for(const cat of ['terrain','water','resources','political','landmarks']){
    assert.ok(GEOGRAPHY_TEACHING_CATEGORIES[cat]); assert.ok(getTeachingCategoryLayers(cat).length>1);
  }
  for(const layer of ['minerals','ports','energy','capitals','mountains','plateaus','deserts']){
    assert.ok(GEOGRAPHY_LAYERS[layer]);assert.ok(getRegionLayerItems(world,'egypt',layer).length>0,layer);
  }
  assert.ok(GEOGRAPHY_FEATURES.egypt.terrain.some(([n])=>n.includes('سيناء')));
  assert.ok(GEOGRAPHY_FEATURES.egypt.minerals.some(([n])=>n.includes('حديد')));
});
test('29/30 placements: symbol library and actual move/resize/copy/delete UI remain available',()=>{
  assert.ok(GEOGRAPHY_SYMBOL_GROUPS.length>=10);
  assert.ok(GEOGRAPHY_SYMBOL_GROUPS.flatMap(x=>x.items).some(x=>/ميناء/.test(x.label)));
  const studio=text('../src/components/maps/LessonMapStudio.jsx');
  const renderer=text('../src/components/maps/ProfessionalMap.jsx');
  for(const token of ['onMovePlacement','onResizePlacement','onDuplicatePlacement','onRemovePlacement','markDirty()'])assert.ok(studio.includes(token),token);
  for(const token of ['setPointerCapture','clientPointToMapPercent','onDropPlacement','GeographyGlyph'])assert.ok(renderer.includes(token),token);
  assert.ok(fs.existsSync(new URL('../src/styles/v8-section-19-30-maps.css',import.meta.url)));
});
