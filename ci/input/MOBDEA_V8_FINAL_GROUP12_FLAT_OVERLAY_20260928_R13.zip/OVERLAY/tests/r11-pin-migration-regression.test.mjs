import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { test } from 'node:test';

const original = await readFile(new URL('../src/services/studentPinPolicy.js', import.meta.url), 'utf8');
const source = original
  .replace(/^import \{ createCredentialSecret, hasCredentialSecret, normalizePin, verifyCredentialSecret \} from '\.\.\/utils\/security';\s*/m,
    'const { createCredentialSecret, hasCredentialSecret, normalizePin, verifyCredentialSecret } = globalThis.__r11PinDeps;\n')
  .replace(/^import \{ cloudConfigured, pushCloudData \} from '\.\/cloudSync';\s*/m,
    'const { cloudConfigured, pushCloudData } = globalThis.__r11PinDeps;\n');

assert.notEqual(source, original, 'studentPinPolicy must be evaluated from the real source');
assert.ok(!/^import\s/m.test(source), 'Unexpected import remained in isolated PIN policy module');

let creates = [];
globalThis.__r11PinDeps = {
  createCredentialSecret: async (pin) => {
    creates.push(pin);
    return { studentCredentialHash: `hashed:${pin}`, studentCredentialSalt: `salt:${pin}` };
  },
  hasCredentialSecret: (student) => Boolean(student.studentCredentialHash && student.studentCredentialSalt),
  normalizePin: (value) => String(value ?? '').trim(),
  verifyCredentialSecret: async () => false,
  cloudConfigured: () => false,
  pushCloudData: async () => ({ revision: '' }),
};

const mod = await import(`data:text/javascript,${encodeURIComponent(source)}`);
const { migrateAllStudentsToUnifiedDefaultPin, DEFAULT_STUDENT_PIN, STUDENT_PIN_POLICY_VERSION } = mod;

test('R11 rotates only an explicitly old still-default hashed PIN to 12345678', async () => {
  creates = [];
  const changedAt = '2026-05-01T00:00:00.000Z';
  const data = {
    settings: { studentPinDefaultVersion: 1 },
    students: [
      {
        id: 'old-default',
        studentCredentialHash: 'hashed:123456',
        studentCredentialSalt: 'salt:123456',
        studentPinMustChange: true,
        studentPinDefaultVersion: 1,
        studentPinChangedByStudentAt: '',
      },
      {
        id: 'changed-by-student',
        studentCredentialHash: 'hashed:864209',
        studentCredentialSalt: 'salt:864209',
        studentPinMustChange: false,
        studentPinDefaultVersion: 1,
        studentPinChangedByStudentAt: changedAt,
      },
      {
        id: 'explicit-custom',
        studentCredentialHash: 'hashed:975310',
        studentCredentialSalt: 'salt:975310',
        studentPinMustChange: false,
        studentPinDefaultVersion: 1,
      },
    ],
  };
  let saved;
  const result = await migrateAllStudentsToUnifiedDefaultPin(data, async (next) => {
    saved = typeof next === 'function' ? next(saved) : next;
    return saved;
  });

  assert.equal(result.changed, true);
  assert.equal(saved.settings.studentPinDefaultVersion, STUDENT_PIN_POLICY_VERSION);
  assert.equal(saved.students[0].studentCredentialHash, `hashed:${DEFAULT_STUDENT_PIN}`);
  assert.equal(saved.students[0].studentPinMustChange, true);
  assert.equal(saved.students[0].studentPinDefaultVersion, STUDENT_PIN_POLICY_VERSION);
  assert.equal(saved.students[0].studentPinChangedByStudentAt, '');

  assert.equal(saved.students[1].studentCredentialHash, 'hashed:864209');
  assert.equal(saved.students[1].studentPinChangedByStudentAt, changedAt);
  assert.equal(saved.students[2].studentCredentialHash, 'hashed:975310');
  assert.deepEqual(creates, [DEFAULT_STUDENT_PIN], 'Only the old still-default credential should be rotated');
});
