import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createBoundedAsyncCache } from '../src/services/boundedAsyncCache.js';

const source = (path) => fs.readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');

test('45: same PDF/page render is deduplicated while rendering', async () => {
  const cache = createBoundedAsyncCache({ maxEntries: 3 });
  let loads = 0;
  const load = async () => { loads += 1; await Promise.resolve(); return { dataUrl: 'jpeg-p1' }; };
  const [a, b] = await Promise.all([cache.get('book:1', load), cache.get('book:1', load)]);
  assert.equal(loads, 1);
  assert.equal(a.dataUrl, b.dataUrl);
  await cache.get('book:1', load);
  assert.equal(loads, 1);
});

test('45: bounded LRU evicts old image data instead of unbounded cache', async () => {
  const cache = createBoundedAsyncCache({ maxEntries: 2, maxCharacters: 9 });
  await cache.get('a', async () => ({ dataUrl: '1111' }));
  await cache.get('b', async () => ({ dataUrl: '2222' }));
  await cache.get('a', async () => ({ dataUrl: 'bad' }));
  await cache.get('c', async () => ({ dataUrl: '3333' }));
  assert.equal(cache.stats().size, 2);
  let loads = 0;
  await cache.get('b', async () => { loads += 1; return { dataUrl: '4444' }; });
  assert.equal(loads, 1);
  cache.clear();
  assert.equal(cache.stats().size, 0);
});

test('45: a failed render must be retried after failure', async () => {
  const cache = createBoundedAsyncCache();
  await assert.rejects(cache.get('book:2', async () => { throw new Error('load failed'); }));
  assert.equal(cache.stats().size, 0);
  const ok = await cache.get('book:2', async () => ({ dataUrl: 'ok' }));
  assert.equal(ok.dataUrl, 'ok');
});

test('45: PDF uses Blob identity, bounded document and image caches and lazy worker import', () => {
  const web = source('src/services/webPdfRenderer.js');
  const hook = source('src/hooks/usePdfPage.js');
  assert.match(web, /WeakMap\(\)/);
  assert.match(web, /MAX_DOCUMENTS = 3/);
  assert.match(web, /maxCharacters: 32_000_000/);
  assert.match(hook, /import\('\.\.\/services\/webPdfRenderer'\)/);
  assert.doesNotMatch(hook, /^import .*webPdfRenderer/m);
});

test('46: startup failure shows recoverable UI without destructive reset or stale blank screen', () => {
  const app = source('src/App.jsx');
  const boundary = source('src/components/AppErrorBoundary.jsx');
  assert.match(app, /<AppErrorBoundary/);
  assert.match(app, /clearTimeout\(timeoutId\)/);
  assert.match(app, /setLoadError\(error\?\.message/);
  assert.match(boundary, /تعذر عرض هذه الصفحة/);
  assert.match(boundary, /العودة للرئيسية/);
  assert.doesNotMatch(boundary, /localStorage\?\.clear\(|resetAppData\(/);
});

test('47–50: cumulative integrity/rollback gate and complete code checks are included', () => {
  const preflight = source('scripts/v8-section7-preflight.mjs');
  assert.match(preflight, /import\s+fs/);
  assert.match(preflight, /missing relative import/);
  const root = source('src/App.jsx');
  assert.match(root, /mobdeaOnline: MobdeaOnlineHub/);
  assert.match(root, /onlineClass: OnlineClass/);
  assert.match(root, /classMode: ClassMode/);
});
