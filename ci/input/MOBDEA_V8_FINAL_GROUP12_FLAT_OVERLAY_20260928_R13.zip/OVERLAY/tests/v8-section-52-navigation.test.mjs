import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = (path) => fs.readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const page = read('src/pages/ClassMode.jsx');
const styles = read('src/styles/v8-section-52-navigation.css');
const main = read('src/main.jsx');

test('52: one compact menu exposes all eight lesson sections inside the fullscreen scene', () => {
  const menu = page.slice(page.indexOf('className="classmode-mode-navigation-menu"'), page.indexOf('<Project12PageQuestionDock'));
  for (const [key, label] of [
    ['pdf', 'PDF'], ['board', 'السبورة'], ['maps', 'الخرائط'],
    ['images', 'الصور'], ['videos', 'الفيديو'], ['audio', 'الصوت'],
    ['slides', 'PowerPoint'], ['games', 'الألعاب'],
  ]) {
    assert.match(page, new RegExp(`\\{ key: "${key}", label: "${label}"`));
  }
  assert.match(menu, /classModeNavigationItems\.map/);
  assert.match(menu, /selectClassModeNavigation\(key\)/);
  assert.match(menu, /role="menuitem"/);
  assert.match(page, /ref=\{classModeNavigationRef\}/);
  assert.match(page, /onOutsidePress/);
  assert.match(page, /if \(classModeNavOpen\) \{/);
  assert.doesNotMatch(page, /className="classmode-header-tabs"/);
});

test('52: fullscreen button top-right and bottom-right tools remain mounted at scene root', () => {
  const scene = page.slice(page.indexOf('return (\n    <ClassModeViewport', page.indexOf('const currentCount = students.length;')));
  assert.match(scene, /className="classmode-user-fullscreen"[\s\S]*?onClick=\{toggleFullscreen\}/);
  assert.match(scene, /classmode-section8-floating-tools/);
  assert.equal((scene.match(/className=\{`classmode-board-tools-toggle/g) || []).length, 1);
  assert.match(styles, /classmode-section8-floating-tools[\s\S]*?position: fixed !important/);
  assert.match(styles, /safe-area-inset-right/);
  assert.match(styles, /safe-area-inset-left/);
  assert.match(main, /import '\.\/styles\/v8-section-52-navigation\.css';/);
});

test('52: PDF page controls and same-type file selector remain distinct from mode selection', () => {
  assert.match(page, /className="classmode-media-edge-nav"/);
  assert.match(page, /className="classmode-pdf-edge-nav"/);
  assert.match(page, /cycleModeResource\(-1\)/);
  assert.match(page, /cycleModeResource\(1\)/);
  assert.match(page, /aria-label="اختيار ملف آخر من النوع الحالي"/);
  const modeChange = page.slice(page.indexOf('const selectClassModeNavigation ='),page.indexOf('const activeClassModeLabel ='));
  assert.match(modeChange,/switchContentMode\(mode\)/);
  assert.doesNotMatch(modeChange, /navigate\(|toggleFullscreen|cycleModeResource|setClassPage/);
});

test('52: actual content-mode switch selects right media kind, including exam PDF, and does not navigate away', () => {
  const part = page.slice(page.indexOf('  const switchContentMode = (mode) => {'), page.indexOf('  const classModeNavigationItems = ['));
  assert.ok(part.includes('wantedTypes.includes(resourceMediaType(item))'));
  const resources = [
    { id: 'intro', type: 'image' }, { id: 'exam', type: 'exams' },
    { id: 'movie', type: 'video' }, { id: 'audio1', type: 'audio' },
    { id: 'ppt', type: 'slides' },
  ];
  const modes = {pdf:['textbook','pdf'],images:['image'],videos:['video'],audio:['audio'],slides:['slides']};
  const chosen = [];
  const opened = [];
  const switchContentMode = Function('resources','modeResourceTypes','selectedResourceType','selectedResource','selectedResourceId','setSelectedResourceId','setContentMode','resourceMediaType',`${part}; return switchContentMode;`)(
    resources,modes,'image',resources[0],'intro',id => chosen.push(id),mode => opened.push(mode),resource => resource.type==='exams'?'pdf':resource.type,
  );
  switchContentMode('pdf');
  switchContentMode('videos');
  switchContentMode('audio');
  switchContentMode('slides');
  switchContentMode('board');
  switchContentMode('maps');
  switchContentMode('games');
  assert.deepEqual(chosen,['exam','movie','audio1','ppt']);
  assert.deepEqual(opened,['pdf','videos','audio','slides','board','maps','games']);
});
