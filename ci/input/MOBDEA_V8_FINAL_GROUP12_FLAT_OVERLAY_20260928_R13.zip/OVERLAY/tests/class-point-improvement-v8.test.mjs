import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildClassPointProgress, withClassPointAward, rankByClassImprovement,
} from '../src/services/classPointImprovement.js';

const students = [
  { id: 1, name: 'علي', group: 'أ', points: 20 },
  { id: 2, name: 'منى', group: 'أ', points: 8 },
  { id: 3, name: 'سلمى', group: 'ب', points: 16 },
];
const session = (id, earned, cumulative, group = 'أ') => ({
  id, date: `2026-09-${id === 'old' ? '18' : '20'}`, updatedAt: `2026-09-${id === 'old' ? '18' : '20'}T12:00:00Z`,
  group, earned, points: cumulative,
});

test('two lesson awards are summed, and other students retain independent baselines', () => {
  let data = { students: structuredClone(students), classPointSessions: [session('old', { 1: 4, 2: 3 }, { 1: 20, 2: 8 })] };
  const award = (studentId, change) => withClassPointAward({
    latest: data, studentId: String(studentId), change,
    sessionKey: 'new', session: { id: 'new' }, today: '2026-09-20', group: 'أ', grade: 'أولى',
  });
  data = award(1, 1); data = award(2, 3); data = award(1, 2); data = award(2, -1);
  assert.equal(data.students.find((s) => s.id === 1).points, 23);
  assert.equal(data.students.find((s) => s.id === 2).points, 10);
  assert.equal(data.students.find((s) => s.id === 3).points, 16);
  assert.deepEqual(data.classPointSessions[0].earned, { 1: 3, 2: 2 });
  assert.deepEqual(data.classPointSessions[0].startPoints, { 1: 20, 2: 8 });
  assert.equal(data.classPointSessions.filter((r) => r.id === 'new').length, 1);
  const progress = buildClassPointProgress({
    students: data.students.filter((s) => s.group === 'أ'),
    livePoints: Object.fromEntries(data.students.map((s) => [s.id, s.points])),
    sessions: data.classPointSessions, sessionKey: 'new', group: 'أ',
  });
  assert.deepEqual([progress['1'].current, progress['1'].earned, progress['1'].previous, progress['1'].delta], [23, 3, 4, -1]);
  assert.deepEqual([progress['2'].current, progress['2'].earned, progress['2'].previous, progress['2'].delta], [10, 2, 3, -1]);
});

test('a student who earned less cumulatively can still be most improved per lesson', () => {
  const list = students.slice(0, 2);
  const progress = {
    1: { current: 40, earned: 2, previous: 8, delta: -6, hasPrevious: true },
    2: { current: 10, earned: 6, previous: 1, delta: 5, hasPrevious: true },
  };
  assert.deepEqual(rankByClassImprovement(list, progress).map((s) => s.id), [2, 1]);
});

test('first lesson and unknown legacy session never produce invented improvement', () => {
  const noPrior = buildClassPointProgress({ students, sessions: [], sessionKey: 'new', group: 'أ' });
  assert.equal(noPrior['1'].hasPrevious, false);
  assert.equal(noPrior['1'].delta, null);
  const old = [{ id: 'old', group: 'أ', updatedAt: '2026-09-18T12:00:00Z', points: { 1: 20 } }];
  const unknown = buildClassPointProgress({ students, sessions: old, sessionKey: 'new', group: 'أ' });
  assert.equal(unknown['1'].delta, null);
  assert.equal(unknown['2'].delta, null);
});

test('legacy snapshots with earlier totals yield derived previous lesson points', () => {
  const history = [
    { id: 'old', group: 'أ', updatedAt: '2026-09-18T12:00:00Z', points: { 1: 20 } },
    { id: 'older', group: 'أ', updatedAt: '2026-09-11T12:00:00Z', points: { 1: 17 } },
  ];
  const row = buildClassPointProgress({ students, sessions: history, sessionKey: 'new', group: 'أ' })['1'];
  assert.equal(row.previous, 3);
  assert.equal(row.delta, -3);
});

test('different groups do not contribute scores; hitting zero never awards a negative point', () => {
  const history = [session('old', { 1: 9 }, { 1: 22 }, 'ب')];
  const row = buildClassPointProgress({ students, sessions: history, sessionKey: 'new', group: 'أ' })['1'];
  assert.equal(row.hasPrevious, false);
  const data = { students: [{ id: 1, group: 'أ', points: 0 }], classPointSessions: [] };
  assert.equal(withClassPointAward({ latest: data, studentId: '1', change: -1, sessionKey: 'new', group: 'أ' }), data);
});

test('an older lesson edited today is not treated as the most recent class', () => {
  const history = [
    { id: 'lesson-17', group: 'أ', date: '2026-09-17', updatedAt: '2026-09-20T19:00:00Z', earned: { 1: 100 } },
    { id: 'lesson-19', group: 'أ', date: '2026-09-19', updatedAt: '2026-09-19T11:00:00Z', earned: { 1: 2 } },
  ];
  const progress = buildClassPointProgress({ students: students.slice(0, 1),
    sessions: history, sessionKey: 'class:2026-09-20', group: 'أ' });
  assert.equal(progress['1'].previous, 2);
  assert.equal(progress['1'].delta, -2);
});

test('the future lesson is never used as previous when viewing an older lesson', () => {
  const history = [
    { id: 'future', group: 'أ', date: '2026-09-25', earned: { 1: 50 } },
    { id: 'older', group: 'أ', date: '2026-09-18', earned: { 1: 3 } },
  ];
  const progress = buildClassPointProgress({ students: students.slice(0, 1),
    sessions: history, sessionKey: 'class:2026-09-20', group: 'أ' });
  assert.equal(progress['1'].previous, 3);
});
