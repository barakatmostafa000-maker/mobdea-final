import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = (path) => fs.readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');

const main = read('src/main.jsx');
const classMode = read('src/pages/ClassMode.jsx');
const media = read('src/components/classmode/MediaRenderer.jsx');
const pptx = read('src/components/classmode/PptxPreview.jsx');
const dashboard = read('src/pages/Dashboard.jsx');
const reports = read('src/pages/Reports.jsx');
const assistant = read('src/pages/SmartAssistant.jsx');
const cards = read('src/pages/StudentCards.jsx');
const students = read('src/pages/Students.jsx');
const version = read('src/config/version.js');
const pkg = JSON.parse(read('package.json'));

const quarantined = [
  'r20RuntimeCore',
  'r20PortalAccountRuntime',
  'r20PortalDashboard',
  'r20TeacherTabletDashboard',
  'r20MonthlyEvaluation',
  'r20CriticalViewGuard',
  'r20PortalLoginBridge',
  'r20PortalScopeGuard',
  'r20OcrUiGuard',
  'r20WhiteboardRuntime',
  'r20EducationalCards',
  'r20CountryCards',
  'r20ImageMode',
  'r20MediaControls',
  'r20PowerPointMode',
  'r20GamesRuntime',
  'r20ExamTracking',
  'r20ReportsWhatsApp',
  'r20RemedialAssistant',
  'r20DuplexPrinting',
];

test('R12 has a unique release identity', () => {
  assert.ok(Number(pkg.mobdea?.versionCode) >= 121);
  assert.ok(pkg.version.startsWith('10.14.'));
  assert.ok(Number(pkg.mobdea?.versionCode) >= 121);
  assert.match(version, /APP_VERSION = "10\.14\.[4-9]"/);
  assert.match(version, /APP_VERSION_CODE = 12[1-9]/);
  assert.match(version, /RELEASE_TAG = "V8-G12-R1[2-9]"/);
});

test('V8 is the only UI authority: legacy DOM-mutating R20 runtimes are not booted', () => {
  for (const name of quarantined) {
    assert.doesNotMatch(main, new RegExp(`(?:import\\s+[\\s\\S]*?from\\s+|import\\s*\\()?["']\\./services/${name}\\.js["']`), name);
  }
  assert.match(main, /r20PageOcrPipeline/);
  assert.match(main, /r20QuestionBankPipeline/);
  assert.match(main, /r20GeographyTruth/);
});

test('current React implementation owns ClassMode students, tools and most-improved UI', () => {
  assert.match(classMode, /Project03StudentPanels|classStudentRails|student-rail|studentRail/i);
  assert.match(classMode, /الأكثر تحسنًا/);
  assert.match(classMode, /persistCurrentBoardLayer|حفظ/);
  assert.match(classMode, /fullscreen/i);
});

test('current React media and PPT renderers own playback and slide state', () => {
  assert.match(media, /classmode-compact-media-controls/);
  assert.match(media, /onEnded/);
  assert.match(pptx, /MAX_PPTX_CACHE/);
  assert.match(pptx, /rememberPptxSlide/);
});

test('dashboard/reports/assistant/printing features exist natively without DOM injectors', () => {
  assert.match(dashboard, /ابدأ الحصة/);
  assert.match(dashboard, /عرض الجدول/);
  assert.match(reports, /openWhatsApp/);
  assert.match(assistant, /openWhatsApp/);
  assert.match(cards, /printCurrentView/);
  assert.match(students, /الأكثر تحسنًا/);
});
