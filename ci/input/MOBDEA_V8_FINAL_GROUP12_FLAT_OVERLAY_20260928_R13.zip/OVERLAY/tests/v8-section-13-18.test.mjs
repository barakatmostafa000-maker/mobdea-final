import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { resourcesForContentMode, nextResourceId } from '../src/services/mediaNavigation.js';
import { clampLessonPage } from '../src/services/libraryModel.js';
import {
  readResourceState, writeResourceState, clearV8ResourceSessionState,
  V8_RESOURCE_STATE_LIMIT,
} from '../src/services/v8ResourceState.js';
import { COUNTRY_CARD_MAP } from '../src/data/countryCards.js';
import { COUNTRY_CAPITALS_AR, COUNTRY_FACTS_AR } from '../src/data/mapEnrichment.js';
const src = await readFile(new URL('../src/pages/ClassMode.jsx', import.meta.url), 'utf8');
const media = await readFile(new URL('../src/components/classmode/MediaRenderer.jsx', import.meta.url), 'utf8');
const pdf = await readFile(new URL('../src/components/classmode/PdfCanvasPreview.jsx', import.meta.url), 'utf8');
const ppt = await readFile(new URL('../src/components/classmode/PptxPreview.jsx', import.meta.url), 'utf8');
const pan = await readFile(new URL('../src/components/classmode/PanZoomSurface.jsx', import.meta.url), 'utf8');
const css = await readFile(new URL('../src/styles/v8-section-13-18-media.css', import.meta.url), 'utf8');
const main = await readFile(new URL('../src/main.jsx', import.meta.url), 'utf8');
const resources = [
  { id: 'p1', type: 'pdf', title: 'الأول' }, { id: 'p2', type: 'textbook', title: 'الثاني' },
  { id: 'i1', type: 'image' }, { id: 'i2', type: 'image' },
  { id: 'v1', type: 'video' }, { id: 'v2', type: 'video' },
  { id: 'a1', type: 'audio' }, { id: 'a2', type: 'audio' },
  { id: 's1', type: 'slides' }, { id: 's2', type: 'slides' },
];
test('13 functional: switch within every media category without crossing into another category', () => {
  for (const [mode, ids] of Object.entries({ pdf:['p1','p2'], images:['i1','i2'], videos:['v1','v2'], audio:['a1','a2'], slides:['s1','s2'] })) {
    const filtered = resourcesForContentMode(resources, mode);
    assert.deepEqual(filtered.map(x => x.id), ids);
    assert.equal(nextResourceId(filtered, ids[0], 1), ids[1]);
    assert.equal(nextResourceId(filtered, ids[1], -1), ids[0]);
  }
});
test('13 UI: dropdown lives in resource switcher and is independent of page arrows and mode navigation', () => {
  assert.match(src, /aria-label="اختيار ملف آخر من النوع الحالي"/);
  assert.match(src, /modeResources\.map\(\(item, index\)/);
  assert.match(src, /aria-label="التنقل بين صفحات PDF"/);
  assert.match(src, /classModeNavigationItems/);
  assert.match(css, /display:flex!important/);
  assert.match(main, /v8-section-13-18-media\.css/);
});
test('14 functional: page, zoom, slide and pan remain independently scoped and survive session memory reload', () => {
  const data = new Map();
  const prior = globalThis.sessionStorage;
  globalThis.sessionStorage = {getItem:key=>data.get(key)??null,setItem:(key,val)=>data.set(key,val),removeItem:key=>data.delete(key)};
  try {
    clearV8ResourceSessionState();
    for (const [scope, name, value] of [['page','p1',13],['page','p2',5],['zoom','p1',2.5],['zoom','p2',1.2],['pptx-slide','s1',3],['pptx-slide','s2',7],['playback','v1',95],['playback','v2',13],['pan','p1:13',{x:42,y:-14}]]) writeResourceState(scope,name,value);
    for (const [scope,name,value] of [['page','p1',13],['page','p2',5],['zoom','p1',2.5],['zoom','p2',1.2],['pptx-slide','s1',3],['pptx-slide','s2',7],['playback','v1',95],['playback','v2',13]]) assert.equal(readResourceState(scope,name),value);
    assert.deepEqual(readResourceState('pan','p1:13'), {x:42,y:-14});
    assert.equal(V8_RESOURCE_STATE_LIMIT >= 48, true);
  } finally {clearV8ResourceSessionState(); globalThis.sessionStorage = prior;}
});
test('14: reopening saved page 13 is not silently reset to page 1', () => {
  assert.equal(clampLessonPage(13, {pageStart:1}, Infinity),13);
  assert.equal(clampLessonPage(13, {pageStart:1,pageEnd:8},Infinity),8);
  assert.match(src, /rememberedPage \?\? viewResource\?\.pageStart \?\? 1,[\s\S]*?viewResource,\s*Infinity/);
  assert.match(src, /pageStateResourceRef\.current !== resourceKey/);
  assert.match(src, /zoomStateResourceRef\.current !== resourceKey/);
});
test('15: Web PDF has bounded document/raster caches, page preloading, pinch and stale-document isolation',()=>{
  assert.match(pdf,/MAX_PDF_CACHE = [1-9]/);
  assert.match(pdf,/MAX_RASTER_CACHE = [1-9]/);
  assert.match(pdf,/rasterPromiseCache/);
  assert.match(pdf,/result\.page \+ 1, result\.page - 1/);
  assert.match(pdf,/if \(cancelled\) return;/);
  assert.match(media,/key=\{`\$\{resource\.assetId \|\| resource\.id \|\| assetUrl\}:\$\{page \|\| 1\}`\}/);
  assert.match(pan,/onPointerMove=\{handlePointerMove\}/);
});
test('16: independent audio/video time, lazy PPT state and compact controls are present',()=>{
  assert.match(media,/writeResourceState\('playback'/);
  assert.match(media,/onLoadedMetadata=\{state\.loaded\}/);
  assert.match(media,/classmode-compact-media-controls/);
  assert.match(media,/preload="metadata"/);
  assert.match(media,/lazy\(\(\) => import\('\.\/PptxPreview'\)\)/);
  assert.match(ppt,/writeResourceState\('pptx-slide'/);
  assert.match(ppt,/pptxParsedCache/);
});
test('17: card drag, resize, RTL autofit and page-layer save use actual board layers',()=>{
  assert.match(src,/function BoardCardOverlay/);
  assert.match(src,/className="board-card-resize-handle"/);
  assert.match(src,/role="button"\s+aria-label="تغيير حجم البطاقة التعليمية"/);
  assert.match(src,/function useAutoFitCardField/);
  assert.match(src,/setBoardActions\(\(current\) => \[\.\.\.current, next\]\)/);
  assert.match(src,/\[boardLayerKey\]: layer/);
});
test('18: country cards include capital, region and an educational fact on the actual card',()=>{
  assert.equal(COUNTRY_CARD_MAP['01'].name,'مصر');
  assert.equal(COUNTRY_CAPITALS_AR.EGY,'القاهرة');
  assert.match(src,/info3: card\.educationalFact \|\| ""/);
  assert.match(src,/COUNTRY_FACTS_AR\[iso\]/);
  assert.match(src,/function CountryCardOverlay/);
  assert.match(src,/function drawCountryCardToCanvas/);
  assert.match(css,/country-card-field-text/);
});
