import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { prepareManualGameQuestion } from '../src/services/manualQuestionEntry.js';
import { isQuestionReadyForGame } from '../src/services/project08QuestionImport.js';
import { mergeQuestionBanks } from '../src/services/assessment.js';

const read = (name) => fs.readFileSync(new URL(`../src/${name}`, import.meta.url), 'utf8');

test('44: manual MCQ refuses blank/incorrect answers instead of defaulting to first choice', () => {
  const base = { gradeKey: '6', grade: 'الصف السادس الابتدائي', type: 'mcq', text: 'متى بني السد؟', optionsText: '1960\n1970\n1980', answerIndex: -1 };
  assert.match(prepareManualGameQuestion({ ...base, answer: '' }, 'manual-1').error, /إجابة/);
  assert.match(prepareManualGameQuestion({ ...base, answer: '1965' }, 'manual-1').error, /اختيار/);
  const prepared = prepareManualGameQuestion({ ...base, answer: '1970' }, 'manual-2');
  assert.equal(prepared.error, undefined);
  assert.equal(prepared.question.answerIndex, 1);
  assert.equal(isQuestionReadyForGame(prepared.question), true);
  assert.ok(mergeQuestionBanks([], [prepared.question]).some((q) => q.id === 'manual-2'));
});

test('44: manual true/false and free-text answers remain usable by games', () => {
  for (const [type, answer, expected] of [['tf', 'صح', 0], ['tf', 'خطأ', 1], ['fill', 'القاهرة', -1]]) {
    const prepared = prepareManualGameQuestion({ type, text: 'السؤال', answer }, `manual-${type}-${answer}`);
    assert.equal(prepared.error, undefined);
    assert.equal(prepared.question.answerIndex, expected);
    assert.ok(isQuestionReadyForGame(prepared.question));
  }
  assert.match(prepareManualGameQuestion({ type: 'tf', text: 'سؤال', answer: 'ربما' }, 'bad').error, /إجابة/);
});

test('41: dashboard buttons navigate to local ClassMode or schedule directly', () => {
  const dashboard = read('pages/Dashboard.jsx');
  assert.match(dashboard, /const startClassNow = \(\) => navigate\('classMode'\)/);
  assert.match(dashboard, /const openFullSchedule = \(\) => navigate\('sessions'\)/);
  assert.match(dashboard, /data-testid="dashboard-start-class"/);
  assert.match(dashboard, /data-testid="dashboard-open-schedule"/);
});

test('42: online and social routes are distinct React pages, never ClassMode', () => {
  const app = read('App.jsx');
  assert.match(app, /onlineClass: OnlineClass/);
  assert.match(app, /mobdeaOnline: MobdeaOnlineHub/);
  assert.match(app, /classMode: ClassMode/);
  assert.doesNotMatch(app, /onlineClass: ClassMode/);
  const online = read('pages/OnlineClass.jsx');
  assert.match(online, /TeacherLivePanel/);
  assert.match(online, /data-testid="online-class-standalone"/);
  assert.doesNotMatch(online, /<ClassMode/);
});

test('43: uploaded image chooses actual browser OCR; PDF supports file review/import', () => {
  const ocr = read('services/r20PageOcrPipeline.js');
  const ui = read('components/questions/Project08ExamOcrImport.jsx');
  const pdf = read('services/pdfQuestionOcr.js');
  assert.match(ocr, /recognizeBrowserExamImage\(image/);
  assert.match(ocr, /browserCall\(request\)/);
  assert.match(ui, /image\/\*,application\/pdf,\.pdf/);
  assert.match(ui, /approved && isQuestionReadyForGame/);
  assert.match(pdf, /extractBrowserExamPdf/);
});
