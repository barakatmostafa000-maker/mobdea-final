import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { nativePdfBlobIdentity } from "../src/services/pdfNativeBlobIdentity.js";

test("Native PDF cache never reuses pages of distinct equally sized uploads", () => {
  const a = new Blob(["AAAAAA"], { type: "application/pdf" });
  const b = new Blob(["BBBBBB"], { type: "application/pdf" });
  assert.equal(a.size, b.size);
  assert.notEqual(nativePdfBlobIdentity(a, "book-7"), nativePdfBlobIdentity(b, "book-7"));
  assert.equal(nativePdfBlobIdentity(a, "book-7"), nativePdfBlobIdentity(a, "book-7"));
  assert.notEqual(nativePdfBlobIdentity(a, "book-7"), nativePdfBlobIdentity(a, "book-8"));
});

test("Native PDF renderer stages blobs using actual identity, not MIME and byte length", () => {
  const source = readFileSync(new URL("../src/services/pdfRenderer.js", import.meta.url), "utf8");
  assert.match(source, /nativePdfBlobIdentity\(blob, cacheKey\)/);
  assert.doesNotMatch(source, /const assetKey = cacheKey \|\| `\$\{blob\.type\}:\$\{blob\.size\}`/);
  assert.match(source, /if \(staleKey === activeAssetKey\)/);
  assert.match(source, /nativePaths\.set\(staleKey, activePath\)/);
});
