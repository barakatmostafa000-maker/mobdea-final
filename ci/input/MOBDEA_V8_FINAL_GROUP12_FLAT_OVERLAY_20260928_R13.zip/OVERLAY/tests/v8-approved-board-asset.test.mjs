import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
const root = process.cwd();
const art = path.join(root, 'public/identity/class-board-history-v14.jpg');
const expected = '050a3927a7baade881e14006a02cea265ad1df0c1e645412d575b39d8627f913';
test('user-approved artwork is present unchanged, JPEG-encoded and 1536x864', () => {
  const bytes=fs.readFileSync(art);
  assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),expected);
  assert.equal(bytes.subarray(0,3).toString('hex'),'ffd8ff');
  // Width and height of this user-supplied image were validated with Pillow in package preparation.
  assert.equal(bytes.length, 165388);
});
test('both whiteboards and saved board exports refer to the packaged approved artwork', () => {
  const standalone=fs.readFileSync(path.join(root,'src/pages/Whiteboard.jsx'),'utf8');
  const classMode=fs.readFileSync(path.join(root,'src/pages/ClassMode.jsx'),'utf8');
  const style=[
    fs.readFileSync(path.join(root,'src/styles/v8-section-07-12-whiteboard.css'),'utf8'),
    fs.readFileSync(path.join(root,'src/styles/v8-group2-voice-whiteboard.css'),'utf8'),
    fs.readFileSync(path.join(root,'src/styles/v8-final-real.css'),'utf8'),
  ].join('\n');
  const ref='/identity/class-board-history-v14.jpg';
  assert.ok(standalone.split(ref).length>=3,'standalone board + saved export must use art');
  assert.ok(standalone.includes(ref+'?art=050a3927a7ba'),'standalone board must bypass cached old background');
  assert.ok(classMode.split(ref).length>=3,'ClassMode board + export must use art');
  assert.ok(classMode.includes(ref+'?art=050a3927a7ba'),'ClassMode board must bypass cached old background');
  assert.match(style,/whiteboard-approved-history-background/);
  assert.match(style,/object-fit:contain/);
});
