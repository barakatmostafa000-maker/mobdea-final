import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { isSamePdfPreview } from '../src/services/v8PdfSourceIdentity.js';
const id = (overrides = {}) => ({ url:'/book.pdf',blob:null, cacheKey:'book-1', page:1,maxWidth:1600,...overrides });
test('PDF preview does not migrate between books/pages/resolutions/blobs',()=>{
  const reference = id();
  assert.equal(isSamePdfPreview(reference,id()),true);
  for(const change of [{url:'/other.pdf'},{cacheKey:'book-2'},{page:2},{maxWidth:2200},{blob:new Blob(['different'])}]) {
    assert.equal(isSamePdfPreview(reference,id(change)),false);
  }
});
test('PDF hook clears the old rendered page before new async page is available',()=>{
  const text = fs.readFileSync(new URL('../src/hooks/usePdfPage.js',import.meta.url),'utf8');
  assert.match(text,/if \(!isSamePdfPreview\(state\.identity, identity\)\)/);
  assert.match(text,/return \{ \.\.\.initialState, loading: Boolean\(blob \|\| url\) \}/);
  assert.match(text,/if \(cancelled\) return;/);
});
