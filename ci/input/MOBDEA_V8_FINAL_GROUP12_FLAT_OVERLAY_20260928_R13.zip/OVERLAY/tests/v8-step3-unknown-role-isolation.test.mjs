import test from 'node:test';
import assert from 'node:assert/strict';
import { getRoleModules } from '../src/utils/auth.js';
import { createCredentialSecret, verifyCredentialSecret } from '../src/utils/security.js';
import { canRoleAccessResource, filterContentLibraryForRole, roleDashboardProfile, scopeReadOnlyDataForRole } from '../src/services/rolePortalAccess.js';

const data = {
  students: [{ id: 's1', name: 'أحمد', grade: 'السادس' }],
  grades: [{ studentId: 's1', score: 10 }],
  sessions: [{ group: 'السادس' }],
  passwords: [{ teacher: 'private' }],
  customQuestionBank: [{ id: 'private-questions' }],
  contentLibrary: [
    { id: 'private', access: { mode: 'private' } },
    { id: 'public', access: { mode: 'public' } },
  ],
};

test('missing or invented roles cannot read teacher records or unassigned books', () => {
  for (const role of [undefined, null, { role: 'nonexistent' }, { role: '' }]) {
    assert.equal(canRoleAccessResource(data.contentLibrary[0], data, role), false);
    assert.equal(canRoleAccessResource(data.contentLibrary[1], data, role), true);
    assert.deepEqual(filterContentLibraryForRole(data, role).map((item) => item.id), ['public']);
    const projected = scopeReadOnlyDataForRole(data, role);
    assert.deepEqual(projected.students, []);
    assert.deepEqual(projected.grades, []);
    assert.deepEqual(projected.sessions, []);
    assert.equal(Object.hasOwn(projected, 'passwords'), false);
    assert.equal(Object.hasOwn(projected, 'customQuestionBank'), false);
    assert.deepEqual(roleDashboardProfile(data, role).students, []);
  }
});

test('missing or invented roles have visitor navigation, teacher retains own modules', () => {
  for (const role of [undefined, null, 'nonexistent', '']) {
    assert.equal(getRoleModules(role).has('settings'), false);
    assert.equal(getRoleModules(role).has('contentLibrary'), true);
    assert.equal(getRoleModules(role).has('students'), false);
  }
  assert.equal(getRoleModules('teacher'), null);
  assert.equal(getRoleModules('admin'), null);
});


test('a leftover old plaintext student PIN cannot bypass a newly issued salted credential', async () => {
  const secret = await createCredentialSecret('12345678', 'student');
  const student = { studentPin: '123456', ...secret };
  assert.equal(await verifyCredentialSecret('123456', student, 'student'), false);
  assert.equal(await verifyCredentialSecret('12345678', student, 'student'), true);
  assert.equal(await verifyCredentialSecret('123456', {studentPin: '123456'}, 'student'), true, 'legacy-only login stays migratable');
  assert.equal(await verifyCredentialSecret('123456', {...student, studentPinSalt: ''}, 'student'), false);
});

test('dashboard and online class cannot promote an unset session to the teacher role', async () => {
  const { readFile } = await import('node:fs/promises');
  const { fileURLToPath } = await import('node:url');
  const root = fileURLToPath(new URL('../', import.meta.url));
  const dashboard = await readFile(new URL('../src/pages/Dashboard.jsx', import.meta.url), 'utf8');
  const online = await readFile(new URL('../src/pages/OnlineClass.jsx', import.meta.url), 'utf8');
  const games = await readFile(new URL('../src/pages/Games.jsx', import.meta.url), 'utf8');
  assert.match(dashboard, /const isStaff = \['teacher', 'admin'\]\.includes\(auth\?\.role\)/);
  assert.match(dashboard, /const focusStudents = !isStaff/);
  assert.doesNotMatch(dashboard, /!auth\s*\|\|\s*\['teacher',\s*'admin'\]/);
  assert.doesNotMatch(online, /const teacher = !auth\s*\|\|/);
  assert.doesNotMatch(games, /\(!auth\s*\|\|\s*\['teacher',\s*'admin'\]/);
  assert.ok(root);
});
