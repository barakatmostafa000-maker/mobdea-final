import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import world from '../src/data/world-countries.json' with {type:'json'};
import {
  GEOGRAPHY_REGIONS, GEOGRAPHY_LAYERS, GEOGRAPHY_SYMBOLS,
  GEOGRAPHY_TEACHING_CATEGORIES, getRegionLayerItems, getTeachingCategoryLayers,
} from '../src/data/geography.js';
import {countryInfo, featureInfo} from '../src/data/mapEnrichment.js';
const read = (path)=>fs.readFileSync(new URL(path,import.meta.url),'utf8');
const page=read('../src/pages/MapChallenge.jsx');
const map=read('../src/components/maps/ProfessionalMap.jsx');
const css=read('../src/styles/v8-section-31-40-map-challenge.css');

test('31: challenge uses real Fullscreen API and does not fake a successful fullscreen when denied',()=>{
 assert.match(page,/requestFullscreen/);assert.match(page,/fullscreenchange/);
 assert.doesNotMatch(page,/catch\s*\{\s*setFullscreen\(\(value\) => !value\)/);
 assert.match(css,/map-challenge-pro:fullscreen/);
});
test('32: category/layer choices are right-hand icons only; old bottom/top layer dock removed',()=>{
 assert.match(page,/className="map-game-floating-selector layer-selector"/);
 assert.match(page,/setLayerPickerOpen/);assert.doesNotMatch(page,/className="map-layer-dock"/);
 assert.match(css,/layer-selector.*right:8px/s);
});
test('33: single start button and build palette only when mode build and started',()=>{
 assert.equal((page.match(/onClick=\{startGame\}/g)||[]).length,1);
 assert.match(page,/mode === "build" && started && \(/);
 assert.match(css,/is-setup.*max-height:/);
});
test('34: gesture pan threshold suppresses stage click; country taps keep their click handler',()=>{
 assert.match(map,/Math\.hypot\(dx, dy\) < 7/);
 assert.match(map,/if \(!pending\.moved && Number\(zoom \|\| 1\) > 1\) event\.currentTarget\.setPointerCapture/);
 assert.match(map,/suppressStageClickRef\.current = true/);
 assert.match(map,/onClickCapture=\{\(event\)/);
 assert.match(map,/transformRef\.current\?\.getBoundingClientRect/);
 assert.match(page,/clientPointToChallengeMapPercent/);
 assert.match(map,/onZoomChange\(Number\(next\.toFixed\(2\)\)\)/);
});
test('35: hit areas enlarge in challenge only without changing visible glyph',()=>{
 assert.match(map,/challengeTouchTargets = false/);
 assert.match(map,/r=\{challengeTouchTargets \? 28 : 22\}/);
 assert.match(map,/r=\{challengeTouchTargets \? 35 : 26\}/);
 assert.match(page,/challengeTouchTargets/);
});
test('36: map game has no active canvas drawing tools and no board toolbars',()=>{
 assert.match(css,/\.map-pro-draw-canvas/);assert.match(css,/display:none!important;pointer-events:none!important/);
 assert.doesNotMatch(page,/onDraw\w+=|onErase\w+=|drawTool=/);
});
test('37: geography categories have actual playable data for major study groups',()=>{
 for(const cat of ['terrain','water','resources','political','landmarks']){
  assert.ok(GEOGRAPHY_TEACHING_CATEGORIES[cat]);
  assert.ok(getTeachingCategoryLayers(cat).some(layer=>getRegionLayerItems(world,'egypt',layer).length>0),cat);
 }
 for(const layer of ['mountains','plateaus','plains','deserts','rivers','seas','lakes','gulfs','canals','minerals','energy','ports']){
  assert.ok(GEOGRAPHY_LAYERS[layer]);
  assert.ok(getRegionLayerItems(world,'egypt',layer).length>0,layer);
 }
 assert.ok(GEOGRAPHY_REGIONS.eurasia && GEOGRAPHY_REGIONS.asia && GEOGRAPHY_REGIONS.europe);
});
test('38: economic resources present in active build palette and feature datasets',()=>{
 const all=GEOGRAPHY_SYMBOLS.map(s=>[s.id,s.label].join(' ').toLowerCase());
 for(const pattern of [/بترول|نفط|oil|petroleum/,/غاز|gas/,/ميناء|port/,/زراع|agric/,/صناع|industry|factory/,/حديد|iron/,/ذهب|gold/]){
  assert.ok(all.some(s=>pattern.test(s)),String(pattern));
 }
 assert.match(page,/buildPalette\.map\(\(item\) =>/);
 assert.match(page,/mineral\|iron\|gold\|phosphate/);
 assert.match(page,/onDropPlacement=\{handleDropPlacement\}/);
});
test('39: tapped country yields region, continent, capital and fact; in-game card is interactive',()=>{
 const feature=world.features.find(f=>f.properties.iso_a3==='EGY');
 const card=countryInfo(feature);
 assert.equal(card.name,'مصر');assert.ok(card.capital);assert.ok(card.region);assert.ok(card.fact);
 assert.match(page,/setDetailItem\(chosen \|\| target\)/);
 for(const field of ['info.capital','info.region','info.continent','info.fact']) assert.ok(page.includes(field));
});
test('40: geographic feature cards use factual source and render only on requested click/answer',()=>{
 const items=getRegionLayerItems(world,'egypt','mountains');
 assert.ok(items.length>0);
 assert.ok(featureInfo(items[0],'mountains').fact);
 assert.match(page,/setDetailItem\(chosen\)/);
 assert.match(page,/setDetailItem\(null\)/);
 assert.match(page,/className="map-challenge-info-card"/);
 assert.match(css,/\.map-challenge-info-card/);
});
