import test from 'node:test';
import assert from 'node:assert/strict';
import { buildOcrImportCandidates, isQuestionReadyForGame } from '../src/services/project08QuestionImport.js';
const base = { question: 'أين المنبع؟', options: ['الشرق', 'الغرب', 'الشمال'] };
for (const input of [undefined, null, '', '  ', 'NaN', -1, 8, 0.5]) {
  test(`OCR cannot invent first answer for missing/invalid answerIndex=${String(input)}`, () => {
    const [item] = buildOcrImportCandidates([{ ...base, answerIndex: input }]);
    assert.equal(item.needsAnswer, true);
    assert.equal(item.answer, '');
    assert.equal(item.answerIndex, -1);
    assert.equal(isQuestionReadyForGame(item), false);
  });
}
test('explicit zero answer index remains a valid first choice', () => {
  const [item] = buildOcrImportCandidates([{ ...base, answerIndex: 0 }]);
  assert.equal(item.needsAnswer, false);
  assert.equal(item.answer, 'الشرق');
  assert.equal(item.answerIndex, 0);
});
test('unknown answer text cannot borrow unrelated index', () => {
  const [item] = buildOcrImportCandidates([{ ...base, answer: 'جنوب', answerIndex: 0 }]);
  assert.equal(item.needsAnswer, true);
  assert.equal(item.answerIndex, -1);
  assert.equal(isQuestionReadyForGame(item), false);
});
test('label and exact text resolve to selected option', () => {
  for (const answer of ['ب', 'الغرب']) {
    const [item] = buildOcrImportCandidates([{ ...base, answer }]);
    assert.equal(item.needsAnswer, false);
    assert.equal(item.answerIndex, 1);
    assert.equal(item.answer, 'الغرب');
  }
});

test('game bank rejects missing index or answer inconsistent with selected option', () => {
  for (const answerIndex of [null, undefined, '', '   ']) {
    assert.equal(isQuestionReadyForGame({ type: 'mcq', answer: 'الشرق', options: base.options, answerIndex }), false);
  }
  assert.equal(isQuestionReadyForGame({ type: 'mcq', answer: 'الشمال', options: base.options, answerIndex: 0 }), false);
  assert.equal(isQuestionReadyForGame({ type: 'mcq', answer: 'الشمال', options: base.options, answerIndex: 2 }), true);
});
