import assert from 'node:assert/strict';
import fs from 'node:fs';
import test from 'node:test';

const patch = fs.readFileSync('scripts/patch-pinned-base-r13.py', 'utf8');

test('R13 worker patch moves the server contract to the eight-digit default PIN', () => {
  assert.match(patch, /PROJECT12_DEFAULT_STUDENT_PIN='12345678'/);
  assert.match(patch, /studentPinDefaultVersion:2/);
  assert.match(patch, /body\.studentCode\|\|body\.code/);
});

test('R13 worker patch returns only student-scoped content, recordings, questions, exams and point sessions', () => {
  assert.match(patch, /function project12StudentContentLibrary/);
  assert.match(patch, /lessonRecordings:\(data\.lessonRecordings\|\|\[\]\)\.filter/);
  assert.match(patch, /customQuestionBank:\(data\.customQuestionBank\|\|\[\]\)\.filter/);
  assert.match(patch, /exams:\(data\.exams\|\|\[\]\)\.filter/);
  assert.match(patch, /classPointSessions:\(data\.classPointSessions\|\|\[\]\)/);
});

test('R13 worker patch expands the existing authorized-asset allow-list only from permitted portal records', () => {
  assert.match(patch, /for \(const item of portal\.contentLibrary \|\| \[\]\)/);
  assert.match(patch, /for \(const item of portal\.lessonRecordings \|\| \[\]\)/);
  for (const field of ['assetId', 'examAssetId', 'thumbnailAssetId', 'recordingAssetId', 'boardAssetId', 'videoAssetId', 'audioAssetId']) {
    assert.ok(patch.includes(field), `missing asset authorization field: ${field}`);
  }
  assert.match(patch, /student authorized asset allow-list/);
});
