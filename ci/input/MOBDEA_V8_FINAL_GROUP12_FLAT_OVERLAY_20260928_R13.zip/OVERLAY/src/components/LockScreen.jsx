import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Camera, KeyRound, UsersRound, ShieldCheck, UserRound, PersonStanding, ScanLine,
  ArrowRight, BadgeInfo, GraduationCap, Eye, EyeOff, HelpCircle, Check, X,
} from 'lucide-react';
import { identity } from '../config/identity';
import {
  assertLoginAllowed, clearLoginFailures, createStaffPasswordSecret, hasCredentialSecret,
  hasStaffPasswordSecret, normalizePin, normalizeStaffPassword, recordLoginFailure,
  verifyCredentialSecret, verifyFactoryStaffPassword, verifyRecoverySecret, verifyStaffPasswordSecret,
} from '../utils/security';
import {
  defaultAuthState, normalizeDigits, resolveGuardianByPhone, resolveStudentByCode,
  resolveStudentFromQrPayload, ROLE_LABELS,
} from '../utils/auth';
import { verifyLocalStudentPin } from '../services/studentPinPolicy';
import { bootstrapTeacherCloud, loginStudentCloud } from '../services/project12StudentCloud';
import { pushCloudData } from '../services/cloudSync';
import { loginGuardianCloud } from '../services/guardianPortalCloud';

const roles = [
  { key: 'teacher', title: 'المعلم', hint: 'كلمة مرور موحدة', icon: GraduationCap, pinPrefix: 'teacher' },
  { key: 'admin', title: 'الإدارة', hint: 'كلمة مرور موحدة', icon: ShieldCheck, pinPrefix: 'admin' },
  { key: 'student', title: 'الطالب', hint: 'الكود + PIN', icon: UserRound, pinPrefix: 'student' },
  { key: 'guardian', title: 'ولي الأمر', hint: 'معرّف حساب ولي الأمر + PIN', icon: UsersRound, pinPrefix: 'guardian' },
  { key: 'visitor', title: 'الزائر', hint: 'دخول محدود', icon: PersonStanding },
];

const STAFF_ROLES = new Set(['teacher', 'admin']);

function cleanQrPayload(payload) {
  if (payload == null) return null;
  return String(payload).trim();
}

const PROJECT12_STUDENT_CLOUD_LOGIN_V1 = true;

export default function LockScreen({ data, onUnlock, updateData }) {
  const [role, setRole] = useState('teacher');
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [identifier, setIdentifier] = useState('');
  const [visitorName, setVisitorName] = useState('');
  const [remember, setRemember] = useState(false);
  const [notice, setNotice] = useState('');
  const [loading, setLoading] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [scanMessage, setScanMessage] = useState('');

  const [forgotOpen, setForgotOpen] = useState(false);
  const [recoveryAnswer, setRecoveryAnswer] = useState('');
  const [recoveryNewPin, setRecoveryNewPin] = useState('');
  const [recoveryConfirmPin, setRecoveryConfirmPin] = useState('');
  const [recoveryNotice, setRecoveryNotice] = useState('');
  const [recoveryLoading, setRecoveryLoading] = useState(false);
  const [recoverySuccess, setRecoverySuccess] = useState(false);

  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const detectorRef = useRef(null);
  const scanTimerRef = useRef(null);

  const roleInfo = useMemo(() => roles.find((item) => item.key === role) || roles[0], [role]);
  const selectedLabel = ROLE_LABELS[role] || 'المستخدم';
  const staffConfigured = STAFF_ROLES.has(role) && hasStaffPasswordSecret(data?.settings, roleInfo.pinPrefix);

  useEffect(() => {
    setPin('');
    setShowPin(false);
    setIdentifier('');
    setVisitorName('');
    setNotice('');
    setScanMessage('');
    setCameraOpen(false);
    setForgotOpen(false);
    setRecoveryAnswer('');
    setRecoveryNewPin('');
    setRecoveryConfirmPin('');
    setRecoveryNotice('');
    setRecoverySuccess(false);
  }, [role]);

  useEffect(() => () => {
    if (scanTimerRef.current) window.clearInterval(scanTimerRef.current);
    streamRef.current?.getTracks?.().forEach((track) => track.stop());
  }, []);

  useEffect(() => {
    if (!cameraOpen) return undefined;
    let cancelled = false;
    const openCamera = async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          setScanMessage('الكاميرا غير مدعومة على هذا الجهاز.');
          return;
        }
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
        if (cancelled) { stream.getTracks().forEach((track) => track.stop()); return; }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        if (!('BarcodeDetector' in window)) {
          setScanMessage('المسح التلقائي غير مدعوم؛ اكتب كود الطالب يدويًا.');
          return;
        }
        detectorRef.current = new window.BarcodeDetector({ formats: ['qr_code', 'code_128', 'code_39'] });
        scanTimerRef.current = window.setInterval(async () => {
          if (!videoRef.current || !detectorRef.current) return;
          try {
            const codes = await detectorRef.current.detect(videoRef.current);
            const value = cleanQrPayload(codes?.[0]?.rawValue);
            if (!value) return;
            const student = resolveStudentFromQrPayload(data, value);
            if (!student) { setScanMessage('تمت قراءة QR لكن الطالب غير موجود.'); return; }
            setIdentifier(String(student.code));
            setScanMessage(`تم اختيار الطالب: ${student.name}. أدخل PIN لإكمال الدخول.`);
            setCameraOpen(false);
          } catch {
            // Continue scan loop.
          }
        }, 1100);
      } catch (error) {
        setScanMessage(error?.message || 'تعذر فتح الكاميرا.');
      }
    };
    openCamera();
    return () => {
      cancelled = true;
      if (scanTimerRef.current) window.clearInterval(scanTimerRef.current);
      streamRef.current?.getTracks?.().forEach((track) => track.stop());
      detectorRef.current = null;
      streamRef.current = null;
    };
  }, [cameraOpen, data]);

  const failLogin = (scope, message) => {
    const throttle = recordLoginFailure(scope);
    if (throttle.blocked) {
      const seconds = Math.ceil(throttle.remainingMs / 1000);
      throw new Error(`بيانات الدخول غير صحيحة. تم إيقاف المحاولات لمدة ${seconds} ثانية.`);
    }
    throw new Error(message);
  };

  const handleUnlock = async () => {
    setLoading(true);
    setNotice('');
    try {
      if (STAFF_ROLES.has(role)) {
        const prefix = roleInfo.pinPrefix;
        const scope = `staff:${role}`;
        assertLoginAllowed(scope);
        const normalized = normalizeStaffPassword(pin);
        if (!normalized) throw new Error('اكتب كلمة مرور المعلم والإدارة.');
        const configuredOk = staffConfigured
          ? await verifyStaffPasswordSecret(normalized, data.settings, prefix)
          : false;
        const factoryAllowed = data.settings?.staffFactoryPasswordDisabled !== true;
        const factoryOk = factoryAllowed ? await verifyFactoryStaffPassword(normalized) : false;
        if (!configuredOk && !factoryOk) failLogin(scope, 'كلمة المرور غير صحيحة.');
        clearLoginFailures(scope);
        if (factoryOk || !staffConfigured || data.settings[`${prefix}PinAlgorithm`] !== 'PBKDF2-SHA256') {
          const upgraded = await createStaffPasswordSecret(normalized, prefix);
          await updateData({ ...data, settings: { ...data.settings, ...upgraded, [`${prefix}Pin`]: '' } });
        }
        let loginData = data;
        if (!String(data.settings?.cloudSync?.token || '').trim() && data.settings?.cloudSync?.endpoint && data.settings?.cloudSync?.workspaceId) {
          try {
            const cloud = await bootstrapTeacherCloud(data.settings, normalized);
            loginData = await updateData({
              ...data,
              settings: {
                ...data.settings,
                cloudSync: {
                  ...(data.settings.cloudSync || {}),
                  ...cloud,
                  autoSync: true,
                  bootstrapVersion: 12,
                  bootstrapAt: new Date().toISOString(),
                },
              },
            });
            try {
              const pushed = await pushCloudData(loginData);
              if (pushed?.revision) {
                loginData = await updateData({
                  ...loginData,
                  settings: {
                    ...loginData.settings,
                    cloudSync: {
                      ...loginData.settings.cloudSync,
                      revision: pushed.revision,
                      lastPushAt: new Date().toISOString(),
                    },
                  },
                });
              }
            } catch (pushError) {
              console.warn('Initial Project12 cloud push failed:', pushError);
            }
          } catch (cloudError) {
            console.warn('Project12 automatic cloud bootstrap failed:', cloudError);
          }
        }
        onUnlock(defaultAuthState(role), { remember, bootstrappedData: loginData });
        return;
      }

      if (role === 'student') {

      const scope = `student:${normalizeDigits(identifier) || 'unknown'}`;

      assertLoginAllowed(scope);


      if (data.settings?.cloudSync?.endpoint && data.settings?.cloudSync?.workspaceId) {

      try {

      const remote = await loginStudentCloud(data.settings, identifier, pin);

      clearLoginFailures(scope);

      onUnlock({

      ...defaultAuthState('student', remote.student),

      cloudPortal: true,

      studentSessionToken: remote.studentToken,

      mustChangePin: Boolean(remote.mustChangePin),

      }, { remember, portalData: remote.data });

      return;

      } catch (cloudError) {

      if ([401, 403, 429].includes(Number(cloudError?.status || 0))) {

      failLogin(scope, cloudError.message || 'كود الطالب أو PIN غير صحيح.');

      }

      console.warn('Cloud student login unavailable, trying local:', cloudError);

      }

      }


      const student = resolveStudentByCode(data, identifier) || resolveStudentFromQrPayload(data, identifier);

      if (!student) failLogin(scope, 'كود الطالب أو PIN غير صحيح.');

      const localLogin = await verifyLocalStudentPin(student, pin);

      if (!localLogin.valid) failLogin(scope, 'كود الطالب أو PIN غير صحيح.');

      clearLoginFailures(scope);

      onUnlock({

      ...defaultAuthState('student', student),

      mustChangePin: localLogin.mustChangePin,

      }, { remember });

      return;

      }

      if (role === 'guardian') {
        if (data.settings?.cloudSync?.endpoint && data.settings?.cloudSync?.workspaceId) {
          const result = await loginGuardianCloud(data.settings, identifier.trim(), pin);
          const ids = result.students.map((student) => String(student.id));
          if (!ids.length) throw new Error('حساب ولي الأمر غير مرتبط بطلاب على الخادم.');
          onUnlock({ role: 'guardian', studentIds: ids, childIds: ids,
            displayName: 'ولي الأمر', cloudPortal: true, roleSessionToken: result.roleToken },
            { remember, portalData: result.data });
          return;
        }
        // Offline legacy login works only when cloud is not configured; a
        // phone number alone must never create cloud-level authorization.
        const phone = normalizeDigits(identifier);
        const scope = `guardian:${phone || 'unknown'}`;
        assertLoginAllowed(scope);
        const student = resolveGuardianByPhone(data, phone);
        if (!student) failLogin(scope, 'رقم الهاتف أو PIN غير صحيح.');
        if (!hasCredentialSecret(student, 'guardian')) throw new Error('حساب ولي الأمر غير مفعّل.');
        if (!(await verifyCredentialSecret(pin, student, 'guardian'))) failLogin(scope, 'رقم الهاتف أو PIN غير صحيح.');
        clearLoginFailures(scope);
        onUnlock(defaultAuthState('guardian', student), { remember });
        return;
      }

      onUnlock({ ...defaultAuthState('visitor'), displayName: visitorName.trim().slice(0, 80) || 'زائر' }, { remember: false });
    } catch (error) {
      setNotice(error?.message || 'تعذر تسجيل الدخول.');
    } finally {
      setLoading(false);
    }
  };

  const submitRecovery = async () => {
    setRecoveryNotice('');
    const scope = `recovery:${role}`;
    try {
      assertLoginAllowed(scope);
      const normalized = normalizeStaffPassword(recoveryNewPin);
      if (normalized.length < 8) throw new Error('اكتب كلمة مرور جديدة لا تقل عن 8 خانات.');
      if (normalized !== normalizeStaffPassword(recoveryConfirmPin)) throw new Error('كلمتا المرور غير متطابقتين.');
      setRecoveryLoading(true);
      if (!(await verifyRecoverySecret(recoveryAnswer, data.settings))) failLogin(scope, 'عبارة الاسترجاع غير صحيحة.');
      const teacherSecret = await createStaffPasswordSecret(normalized, 'teacher');
      const adminSecret = await createStaffPasswordSecret(normalized, 'admin');
      await updateData({ ...data, settings: { ...data.settings, ...teacherSecret, ...adminSecret, teacherPin: '', adminPin: '', staffFactoryPasswordDisabled: true } });
      clearLoginFailures(scope);
      setRecoverySuccess(true);
    } catch (error) {
      setRecoveryNotice(error?.message || 'تعذر استرجاع الحساب.');
    } finally {
      setRecoveryLoading(false);
    }
  };

  const closeRecovery = () => {
    setForgotOpen(false);
    setRecoveryAnswer('');
    setRecoveryNewPin('');
    setRecoveryConfirmPin('');
    setRecoveryNotice('');
    setRecoverySuccess(false);
  };

  const pinField = (label = 'PIN', staffPassword = false) => (
    <label className="auth-field">
      <span>{label}</span>
      <div className="auth-pin-wrap">
        <input
          type={showPin ? 'text' : 'password'}
          inputMode={staffPassword ? 'text' : 'numeric'}
          maxLength={staffPassword ? 128 : 10}
          value={pin}
          onChange={(event) => setPin(staffPassword ? event.target.value.slice(0, 128) : normalizePin(event.target.value))}
          onKeyDown={(event) => event.key === 'Enter' && handleUnlock()}
          placeholder={staffPassword ? 'اكتب كلمة المرور الموحدة' : '6 إلى 10 أرقام'}
          autoComplete={staffPassword ? 'current-password' : 'one-time-code'}
        />
        <button type="button" className="auth-pin-eye" onClick={() => setShowPin((value) => !value)} aria-label={showPin ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}>{showPin ? <EyeOff size={17} /> : <Eye size={17} />}</button>
      </div>
    </label>
  );

  return (
    <div className="auth-screen">
      <div className="auth-background"><div className="auth-glow auth-glow-1" /><div className="auth-glow auth-glow-2" /><div className="auth-glow auth-glow-3" /></div>
      <section className="auth-card">
        <aside className="auth-brand-panel">
          <div className="auth-brand-orb"><img src={identity.icon} alt={identity.schoolName} /></div>
          <div className="auth-brand-copy"><span className="auth-kicker">منصة رقمية متكاملة</span><h1>{identity.schoolName}</h1><p>{identity.teacherName}</p><small>{identity.teacherTitle}</small></div>
          <div className="auth-brand-notes"><div><BadgeInfo size={16} /><span>حسابات منفصلة وصلاحيات محددة</span></div><div><ScanLine size={16} /><span>QR للتعريف فقط وPIN لإثبات الهوية</span></div></div>
        </aside>

        <div className="auth-form-panel">
          <div className="auth-topline">
            <div><span className="eyebrow">تسجيل الدخول الآمن</span><h2>اختر الدور الذي تريد الدخول به</h2><p>لا يكفي كود الطالب أو رقم الهاتف وحده؛ كل حساب يحتاج PIN مستقلًا.</p></div>
            <div className="auth-role-pill"><KeyRound size={16} /><span>{selectedLabel}</span></div>
          </div>

          <div className="auth-role-grid">
            {roles.map(({ key, title, hint, icon: Icon }) => (
              <button key={key} className={`auth-role-card ${role === key ? 'active' : ''}`} onClick={() => setRole(key)} type="button"><span><Icon size={18} /></span><strong>{title}</strong><small>{hint}</small></button>
            ))}
          </div>

          <div className="auth-fields-area">
            {STAFF_ROLES.has(role) && !forgotOpen && (
              <>
                {!staffConfigured && <div className="auth-notice success">استخدم كلمة المرور الموحدة المعتمدة للمعلم والإدارة. لا يمكن إنشاء كلمة مرور جديدة من شاشة الدخول.</div>}
                {pinField(`كلمة مرور ${roleInfo.title}`, true)}
                <div className="auth-remember-row">
                  <label className="auth-remember"><input type="checkbox" checked={remember} onChange={(event) => setRemember(event.target.checked)} /><span>تذكرني لمدة 7 أيام</span></label>
                  {staffConfigured && data.settings.staffRecoveryAnswerHash && <button type="button" className="auth-link-btn" onClick={() => setForgotOpen(true)}>نسيت كلمة المرور؟</button>}
                </div>
                <button className="auth-submit" onClick={handleUnlock} disabled={loading} type="button"><ArrowRight size={17} /> {`دخول ${roleInfo.title}`}</button>
              </>
            )}

            {STAFF_ROLES.has(role) && forgotOpen && (
              <div className="auth-recovery">
                <div className="auth-recovery-head"><span><HelpCircle size={16} /> استرجاع كلمة المرور</span><button type="button" className="auth-icon-btn" onClick={closeRecovery} aria-label="إغلاق"><X size={16} /></button></div>
                {recoverySuccess ? (
                  <><div className="auth-notice success"><Check size={16} /> تم تحديث كلمة المرور الموحدة بنجاح.</div><button className="auth-submit" type="button" onClick={closeRecovery}><ArrowRight size={17} /> العودة للدخول</button></>
                ) : (
                  <>
                    <p className="auth-recovery-question">أدخل عبارة الاسترجاع الخاصة التي تم ضبطها من الإعدادات.</p>
                    <label className="auth-field"><span>عبارة الاسترجاع</span><input type="password" value={recoveryAnswer} onChange={(event) => setRecoveryAnswer(event.target.value)} autoComplete="off" /></label>
                    <label className="auth-field"><span>كلمة مرور جديدة</span><input type="password" maxLength={128} value={recoveryNewPin} onChange={(event) => setRecoveryNewPin(event.target.value.slice(0, 128))} placeholder="8 خانات على الأقل" autoComplete="new-password" /></label>
                    <label className="auth-field"><span>تأكيد كلمة المرور</span><input type="password" maxLength={128} value={recoveryConfirmPin} onChange={(event) => setRecoveryConfirmPin(event.target.value.slice(0, 128))} autoComplete="new-password" /></label>
                    {recoveryNotice && <div className="auth-notice error">{recoveryNotice}</div>}
                    <button className="auth-submit" type="button" onClick={submitRecovery} disabled={recoveryLoading}><ArrowRight size={17} /> تحديث PIN</button>
                  </>
                )}
              </div>
            )}

            {role === 'student' && (
              <>
                <label className="auth-field"><span>كود الطالب أو QR</span><input inputMode="numeric" placeholder="ادخل الكود أو امسحه بالكاميرا" value={identifier} onChange={(event) => setIdentifier(normalizeDigits(event.target.value).slice(0, 10))} /></label>
                {pinField('PIN الطالب')}
                <div className="auth-inline-actions">
                  <button className="auth-submit secondary" onClick={handleUnlock} disabled={loading} type="button"><ArrowRight size={17} /> دخول الطالب</button>
                  <button className="auth-submit ghost" onClick={() => setCameraOpen((value) => !value)} type="button"><Camera size={17} /> {cameraOpen ? 'إغلاق الكاميرا' : 'مسح QR'}</button>
                </div>
                {cameraOpen && <div className="qr-scanner-box"><video ref={videoRef} playsInline muted autoPlay /><div className="qr-scanner-frame" /><small>{scanMessage || 'وجّه الكاميرا إلى QR، ثم أدخل PIN.'}</small></div>}
              </>
            )}

            {role === 'guardian' && (
              <>
                <label className="auth-field"><span>معرّف حساب ولي الأمر</span><input placeholder="معرّف الدخول الذي أنشأه المعلم" value={identifier} onChange={(event) => setIdentifier(event.target.value.trim().slice(0, 80))} /></label>
                {pinField('PIN ولي الأمر')}
                <label className="auth-remember"><input type="checkbox" checked={remember} onChange={(event) => setRemember(event.target.checked)} /><span>تذكرني لمدة 7 أيام</span></label>
                <button className="auth-submit" onClick={handleUnlock} disabled={loading} type="button"><ArrowRight size={17} /> دخول ولي الأمر</button>
              </>
            )}

            {role === 'visitor' && (
              <><label className="auth-field"><span>اسم الزائر</span><input placeholder="اكتب الاسم أو اتركه فارغًا" value={visitorName} onChange={(event) => setVisitorName(event.target.value.slice(0, 80))} onKeyDown={(event) => event.key === 'Enter' && handleUnlock()} /></label><button className="auth-submit" onClick={handleUnlock} disabled={loading} type="button"><ArrowRight size={17} /> دخول محدود</button></>
            )}

            {notice && !forgotOpen && <div className="auth-notice error">{notice}</div>}
          </div>
        </div>
      </section>
    </div>
  );
}
