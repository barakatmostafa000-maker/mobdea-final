/** Each distinct Blob must be staged independently, even with the same MIME,
 * byte length and resource ID. A WeakMap keeps identity metadata from pinning
 * large textbook files in memory after their UI releases them. */
const blobIds = new WeakMap();
let nextBlobId = 0;

export function nativePdfBlobIdentity(blob, hint = "") {
  if (!(blob instanceof Blob)) throw new TypeError("PDF source must be a Blob");
  let id = blobIds.get(blob);
  if (id === undefined) {
    id = ++nextBlobId;
    blobIds.set(blob, id);
  }
  return `${String(hint || "")}|pdf-blob:${id}`;
}
