import { filterContentLibraryForRole } from './rolePortalAccess.js';

/**
 * Images requested from the student cloud must be explicitly published for
 * the authenticated child. Being the same grade is NOT publication. The worker
 * must independently enforce token-based asset authorization as well.
 */
export function collectStudentVisibleImageIds(data = {}) {
  const students = Array.isArray(data?.students) ? data.students : [];
  if (students.length !== 1 || students[0]?.id == null) return [];
  const student = students[0];
  const visible = filterContentLibraryForRole(data, {
    role: 'student', studentId: student.id,
    ...(student.code != null ? { studentCode: student.code } : {}),
  });
  const ids = new Set();
  for (const item of visible) {
    if (!item || item.published === false) continue;
    const type = String(item.type || '').toLowerCase();
    const kind = String(item.kind || '').toLowerCase();
    if (type === 'image' || kind === 'lesson-media' || kind === 'lesson-image') {
      if (item.assetId) ids.add(String(item.assetId));
    }
    if (item.thumbnailAssetId) ids.add(String(item.thumbnailAssetId));
  }
  return [...ids].slice(0, 120);
}
