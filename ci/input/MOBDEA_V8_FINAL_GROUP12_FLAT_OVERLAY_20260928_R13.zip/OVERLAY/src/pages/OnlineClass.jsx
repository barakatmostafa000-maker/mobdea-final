import { useMemo, useState } from 'react';
import { ArrowRight, Radio, Settings, Users } from 'lucide-react';
import TeacherLivePanel from '../components/live/TeacherLivePanel';

const ONLINE_CLASS_STANDALONE_V1 = true;

function newestSession(sessions = []) {
  return [...(Array.isArray(sessions) ? sessions : [])]
    .filter(Boolean)
    .sort((left, right) => String(right?.date || '').localeCompare(String(left?.date || '')))[0] || null;
}

export default function OnlineClass({ data = {}, updateData, auth, navigate }) {
  const [notice, setNotice] = useState('');
  const [startRequest, setStartRequest] = useState(0);
  const session = useMemo(() => newestSession(data.sessions), [data.sessions]);
  const role = auth?.role || 'teacher';
  const teacherLike = !['student', 'guardian', 'visitor'].includes(role);
  const cloudSync = data.settings?.cloudSync || {};

  const roomMeta = useMemo(() => ({
    title: session?.title || 'الحصة الأونلاين',
    grade: session?.grade || '',
    lesson: session?.lesson || session?.title || '',
    sessionId: session?.id || null,
    lessonId: session?.lessonId || null,
  }), [session]);

  const liveState = useMemo(() => ({
    contentMode: 'online',
    contentModeLabel: 'الحصة الأونلاين',
    resourceId: '',
    resourceTitle: roomMeta.lesson || roomMeta.title,
    page: 1,
    boardRevision: 0,
    pointsRevision: 0,
    elapsedSeconds: 0,
  }), [roomMeta]);

  const saveCloudSync = async (nextCloudSync) => {
    if (typeof updateData !== 'function') return;
    await updateData({
      ...data,
      settings: { ...data.settings, cloudSync: nextCloudSync },
    });
  };

  return (
    <section className="online-class-page-v8" data-testid="online-class-standalone" data-online-class-standalone={ONLINE_CLASS_STANDALONE_V1 ? 'true' : 'false'}>
      <header className="online-class-hero-v8">
        <div>
          <span className="eyebrow">المُبدع أونلاين</span>
          <h1>الحصة الأونلاين</h1>
          <p>غرفة مستقلة للبث المباشر، مشاركة الشاشة والصوت، وإدارة دخول الطلاب من أجهزتهم.</p>
        </div>
        <div className="online-class-hero-actions-v8">
          {teacherLike && (
            <button type="button" className="primary-btn" onClick={() => setStartRequest((value) => value + 1)}>
              <Radio size={17} /> إنشاء حصة الآن
            </button>
          )}
          <button type="button" className="secondary-btn" onClick={() => navigate?.('settings')}>
            <Settings size={17} /> إعدادات الاتصال
          </button>
          <button type="button" className="secondary-btn" onClick={() => navigate?.('dashboard')}>
            <ArrowRight size={17} /> الرئيسية
          </button>
        </div>
      </header>

      {notice && <div className="online-class-notice-v8" role="status">{notice}</div>}

      {teacherLike ? (
        <div className="online-class-live-shell-v8">
          <TeacherLivePanel
            cloudSync={cloudSync}
            roomMeta={roomMeta}
            liveState={liveState}
            buildSnapshot={null}
            onNotice={setNotice}
            onOpenSettings={() => navigate?.('settings')}
            onSaveCloudSync={saveCloudSync}
            startRequest={startRequest}
          />
        </div>
      ) : (
        <article className="panel online-class-student-entry-v8">
          <Users size={34} />
          <h2>الدخول إلى الحصة</h2>
          <p>ادخل من رابط الحصة الذي أرسله المعلم. الرابط يفتح غرفة الطالب المستقلة ويدعم الصوت والبث المباشر.</p>
          <button type="button" className="secondary-btn" onClick={() => navigate?.('dashboard')}>العودة للرئيسية</button>
        </article>
      )}
    </section>
  );
}
