export const APP_VERSION = "10.14.5";
export const APP_VERSION_CODE = 122;
export const DATA_SCHEMA_VERSION = 13;
export const RELEASE_CHANNEL = "stable";
export const RELEASE_TAG = "V8-G12-R13";
