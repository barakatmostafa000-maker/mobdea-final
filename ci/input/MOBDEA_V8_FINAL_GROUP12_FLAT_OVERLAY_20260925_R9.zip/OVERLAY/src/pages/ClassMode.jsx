import { lazy, memo, Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeftRight,
  BookOpen,
  Camera,
  CirclePause,
  CirclePlay,
  Dices,
  Eraser,
  FileImage,
  FileText,
  Gamepad2,
  Highlighter,
  LayoutGrid,
  Minus,
  PenTool,
  Plus,
  Presentation,
  Radio,
  Clock,
  Redo2,
  RotateCcw,
  Save,
  ScanLine,
  Shapes,
  Shuffle,
  Sparkles,
  StickyNote,
  TimerReset,
  Trophy,
  Undo2,
  Users,
  X,
  Waves,
  ZoomIn,
  ZoomOut,
  MailCheck,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Map as MapIcon,
  Video,
  File,
  CircleDot,
  ArrowUpRight,
  Type,
  MousePointer2,
  Move,
} from "lucide-react";
import { identity } from "../config/identity";
import { buildEncouragementPhrase, speakArabic, diagnoseArabicVoice, stopArabicSpeech } from "../services/voice";
import { openResourceDocument } from "../services/nativePlatform";
import {
  nativeScreenRecordingAvailable,
  pauseNativeScreenRecording,
  readNativeScreenRecording,
  releaseNativeScreenRecording,
  resumeNativeScreenRecording,
  startNativeScreenRecording,
  stopNativeScreenRecording,
} from "../services/screenRecording";
import { buildShareLink, copyToClipboard } from "../services/share";
import { questionBank } from "../data/questionBank";
import { COUNTRY_CARD_CATEGORIES, DEFAULT_COUNTRY_CARD } from "../data/countryCards";
import { COUNTRY_FACTS_AR } from "../data/mapEnrichment.js";
import { getCountryCard, countryCardsForCategory } from "../services/countryCardCatalog";
import { queueAbsenceNotification } from "../services/notifications";
import {
  deleteAsset,
  importAssetBlob,
  importLegacyDataUrl,
} from "../services/assetStore";
import { useAssetUrl } from "../hooks/useAssetUrl";
import { useAssetSource } from "../hooks/useAssetSource";
import { usePdfPage } from "../hooks/usePdfPage";
import { todayISO, formatDateAr } from "../utils/time";
import { recognizeHandwritingStrokes } from "../services/handwritingRecognition";
import { correctArabicSentence } from "../services/arabicSentenceCorrection";
import { boardPointFromClient } from "../utils/boardPoint.js";
import { boardTextDirection } from "../services/v8BoardTextDirection.js";
import { isArabicBoardFontAvailable } from "../services/v8BoardFontAvailability.js";
import { readResourceState, writeResourceState } from "../services/v8ResourceState";
import { activateClassModeTabletRuntime, deactivateClassModeTabletRuntime, reinforceClassModeFullscreen } from "../services/v8TabletRuntime";
import MediaRenderer from "../components/classmode/MediaRenderer";
import { rememberModeResource } from "../services/v8ModeResourceMemory";
import LessonRecordingItem from "../components/classmode/LessonRecordingItem";
import ClassModeViewport from "../components/classmode/ClassModeViewport";
import {
  appendQuestionHistory,
  selectQuestionRound,
} from "../services/questionRotation";
import { rankStudentsByPoints } from "../services/studentRanking";
import { buildClassPointProgress, rankByClassImprovement, withClassPointAward } from "../services/classPointImprovement";
import { drawRandomStudents } from "../services/project11StudentSelection";
import { splitStudentRails } from "../services/classStudentRails";
import Project11ClassSyncBridge from '../components/classmode/Project11ClassSyncBridge';
import Project12PageQuestionDock from '../components/classmode/Project12PageQuestionDock';
import { buildPageAwareQuestionSets, pickPageQuestionScope } from '../services/project12PageQuestions';
import Project13LinkHub from '../components/links/Project13LinkHub';
import {
  getAllLibraryGrades,
  getLessonsForGrade,
  getLessonModeResources,
  resolveDefaultLesson,
  clampLessonPage,
  inferMediaType,
} from "../services/libraryModel";

const LessonMapStudio = lazy(() => import("../components/maps/LessonMapStudio"));
const ClassroomGamePanel = lazy(() => import("../components/classmode/ClassroomGamePanel"));
const TeacherLivePanel = lazy(() => import("../components/live/TeacherLivePanel"));
const OnlineGameHostPanel = lazy(() => import("../components/live/OnlineGameHostPanel"));

async function recognizePageForQuestionsLazy(...args) {
  const { recognizePageForQuestions } = await import('../services/r20PageOcrPipeline.js');
  return recognizePageForQuestions(...args);
}

const statusLabels = {
  present: "حاضر",
  late: "متأخر",
  absent: "غائب",
  excused: "غياب بعذر",
};
const defaultEncouragementPhrases = [
  "أحسنت يا بطل",
  "إجابة ممتازة",
  "تفكيرك رائع",
  "أبدعت وواصل التقدم",
  "مشاركة مميزة",
  "تفوق رائع",
  "فخور بك",
  "استمر يا مبدع",
];
const defaultCorrectivePhrases = [
  "ركز وحاول مرة أخرى",
  "انتبه إلى السؤال جيدًا",
  "اهدأ وفكر قبل الإجابة",
  "راجع إجابتك مرة أخرى",
  "أحتاج منك تركيزًا أكبر",
  "لا تتعجل في الإجابة",
  "حاول أن تشارك معنا",
  "انتبه للشرح من فضلك",
];
const toolOptions = [
  { key: "select", label: "تحديد", icon: MousePointer2 },
  { key: "pen", label: "قلم", icon: PenTool },
  { key: "normal-text", label: "كتابة عادية", icon: Type },
  { key: "shape", label: "أشكال", icon: Shapes },
  { key: "eraser", label: "ممحاة", icon: Eraser },
  { key: "highlighter", label: "هايلايتر", icon: Highlighter },
  { key: "arrow", label: "سهم", icon: ArrowUpRight },
  { key: "move", label: "تحريك", icon: Move },
];
const MEDIA_ANNOTATION_TOOL_KEYS = Object.freeze(["pen", "highlighter", "eraser"]);
const DRAW_TOOL_SIZE_OPTIONS = Object.freeze({
  pen: [2, 3, 4, 6, 10, 14, 20],
  highlighter: [12, 18, 24, 32, 40, 52],
  eraser: [24, 32, 40, 52, 64, 80],
});
const DRAW_TOOL_SIZE_LABELS = Object.freeze({
  pen: "حجم القلم",
  highlighter: "حجم الهايلايتر",
  eraser: "حجم الممحاة",
});
const V8_MEDIA_ANNOTATION_FULL_TOOLS_V2 = true;
const TEXT_TOOL_STYLES = Object.freeze({
  "normal-text": "plain",
  "historical-term": "historical",
  "geographical-term": "geography",
  "important-event": "event",
  "date-term": "date",
  "person-term": "person",
  "place-term": "place",
  "definition-term": "definition",
  "note-term": "note",
});
const TEXT_STYLE_TO_TOOL = Object.freeze(
  Object.fromEntries(
    Object.entries(TEXT_TOOL_STYLES).map(([key, value]) => [value, key]),
  ),
);
const shapeOptions = [
  { key: "rect", label: "مستطيل" },
  { key: "circle", label: "دائرة" },
  { key: "triangle", label: "مثلث" },
  { key: "line", label: "خط" },
];
const historicalSymbolOptions = [
  { key: "pyramid", label: "هرم مجسم" },
  { key: "column", label: "عمود أثري" },
  { key: "scroll", label: "مخطوطة" },
  { key: "obelisk", label: "مسلة" },
  { key: "crown", label: "تاج ملكي" },
  { key: "compass", label: "بوصلة أثرية" },
  { key: "sphinx", label: "أبو الهول" },
  { key: "temple", label: "بوابة معبد" },
  { key: "mobdea-seal", label: "شعار المُبدع" },
];
const geographicalSymbolOptions = [
  { key: "mountain", label: "جبل مجسم" },
  { key: "plateau", label: "هضبة مجسمة" },
  { key: "river", label: "نهر" },
  { key: "globe", label: "كرة أرضية" },
  { key: "compass-rose", label: "وردة بوصلة" },
  { key: "contours", label: "خطوط كنتور" },
  { key: "latlon", label: "طول وعرض" },
  { key: "map-sheet", label: "خريطة مطوية" },
];
const boardFontOptions = [
  {
    value: "'Noto Naskh Arabic', 'Amiri', serif",
    probe: "Noto Naskh Arabic",
    label: "نسخ — شرح واضح",
  },
  {
    value: "'Aref Ruqaa', 'Amiri', serif",
    probe: "Aref Ruqaa",
    label: "رقعة — كتابة يدوية",
  },
  {
    value: "'Noto Kufi Arabic', 'Reem Kufi', sans-serif",
    probe: "Noto Kufi Arabic",
    label: "كوفي — عرض وشاشة",
  },
  {
    value: "'Amiri', 'Noto Naskh Arabic', serif",
    probe: "Amiri",
    label: "أميري — نص رسمي",
  },
  {
    value: "'Reem Kufi', 'Noto Kufi Arabic', sans-serif",
    probe: "Reem Kufi",
    label: "ريم كوفي — عناوين حديثة",
  },
];

const BOARD_CANVAS_WIDTH = 1536;
const BOARD_CANVAS_HEIGHT = 864;
const MAX_RESOURCE_VIEW_MEMORY = 64;
function rememberBoundedViewState(memory, key, value) {
  const memoryKey = String(key || "");
  if (!memoryKey || !(memory instanceof Map)) return;
  if (memory.has(memoryKey)) memory.delete(memoryKey);
  memory.set(memoryKey, value);
  while (memory.size > MAX_RESOURCE_VIEW_MEMORY) {
    memory.delete(memory.keys().next().value);
  }
}

async function speakClassroomArabic(text, settings, tone = "normal") {
  const phrase = String(text || "").trim();
  if (!phrase) return false;
  // speakArabic already tries native Android first, then ar-EG browser speech.
  // A second browser fallback here re-spoke the same phrase when the FIRST
  // browser utterance timed out / was cancelled and bypassed muted settings.
  try {
    return await speakArabic(phrase, settings, tone);
  } catch {
    return false;
  }
}
const MOBDEA_LOGO_IMAGE = typeof Image !== "undefined" ? new Image() : null;
if (MOBDEA_LOGO_IMAGE) {
  MOBDEA_LOGO_IMAGE.decoding = "async";
  MOBDEA_LOGO_IMAGE.src = identity.logo;
}
const BOARD_TEXT_PRESETS = Object.freeze([
  { key: "main", label: "رئيسي", size: 84, weight: 900, lineHeight: 1.18 },
  { key: "heading", label: "عنوان", size: 64, weight: 800, lineHeight: 1.22 },
  { key: "explanation", label: "شرح", size: 46, weight: 700, lineHeight: 1.34 },
  { key: "note", label: "ملاحظة", size: 34, weight: 700, lineHeight: 1.32 },
]);
const BOARD_TEXT_PRESET_MAP = Object.freeze(
  Object.fromEntries(BOARD_TEXT_PRESETS.map((item) => [item.key, item])),
);

// V7_DEEP_REVIEWED_TERM_CARD_INPLACE_TEXT_V1
const BOARD_CARD_TEMPLATES = Object.freeze([
  {
    key: "geographical-term",
    label: "مصطلح جغرافي",
    asset: "/whiteboard/cards/geographical-term.png",
    assetFallback: "/whiteboard/cards/v8-geographical-term-fallback.svg",
    ratio: 1.5,
    fields: [
      {
        key: "title",
        label: "اسم المصطلح",
        placeholder: "اسم المصطلح",
        x: 30,
        y: 10.5,
        w: 40,
        h: 14,
        tone: "navy",
        size: 34,
        replacePrintedLabel: true,
      },
      {
        key: "body",
        label: "التعريف",
        placeholder: "اكتب التعريف هنا…",
        x: 23.5,
        y: 40.5,
        w: 53,
        h: 34,
        tone: "ink",
        size: 27,
        verticalAlign: "start",
        replacePrintedLabel: true,
      },
    ],
  },
  {
    key: "historical-term",
    label: "مصطلح تاريخي",
    asset: "/whiteboard/cards/historical-term.png",
    assetFallback: "/whiteboard/cards/v8-historical-term-fallback.svg",
    ratio: 1.5,
    fields: [
      {
        key: "title",
        label: "اسم المصطلح",
        placeholder: "اسم المصطلح",
        x: 31.5,
        y: 20.5,
        w: 37,
        h: 11.5,
        tone: "brown",
        size: 32,
        replacePrintedLabel: true,
      },
      {
        key: "body",
        label: "التعريف",
        placeholder: "اكتب التعريف هنا…",
        x: 23.5,
        y: 39.5,
        w: 53,
        h: 35,
        tone: "ink",
        size: 27,
        verticalAlign: "start",
        replacePrintedLabel: true,
      },
    ],
  },
  {
    key: "event",
    label: "حدث مهم",
    asset: "/whiteboard/cards/event.png",
    ratio: 0.667,
    fields: [
      {
        key: "title",
        label: "اسم الحدث",
        placeholder: "اسم الحدث",
        x: 13,
        y: 18,
        w: 74,
        h: 13,
        tone: "gold",
        size: 35,
      },
      {
        key: "date",
        label: "التاريخ",
        placeholder: "التاريخ",
        x: 28,
        y: 32,
        w: 44,
        h: 8,
        tone: "gold",
        size: 24,
      },
      {
        key: "body",
        label: "الوصف/النتيجة",
        placeholder: "اكتب وصف الحدث ونتيجته…",
        x: 17,
        y: 51,
        w: 66,
        h: 28,
        tone: "ink",
        size: 25,
      },
    ],
  },
  {
    key: "date",
    label: "تاريخ / سنة",
    asset: "/whiteboard/cards/date.png",
    ratio: 1.5,
    fields: [
      {
        key: "date",
        label: "التاريخ أو السنة",
        placeholder: "التاريخ / السنة",
        x: 27,
        y: 25,
        w: 46,
        h: 18,
        tone: "gold",
        size: 42,
      },
      {
        key: "body",
        label: "الحدث المرتبط",
        placeholder: "الحدث المرتبط",
        x: 27,
        y: 69,
        w: 46,
        h: 11,
        tone: "cream",
        size: 25,
      },
    ],
  },
  {
    key: "place",
    label: "مكان",
    asset: "/whiteboard/cards/place.png",
    ratio: 1.5,
    imageZone: { x: 9, y: 31, w: 34, h: 50, radius: 16 },
    fields: [
      {
        key: "title",
        label: "اسم المكان",
        placeholder: "اسم المكان",
        x: 34,
        y: 10,
        w: 35,
        h: 10,
        tone: "cream",
        size: 31,
      },
      {
        key: "subtitle",
        label: "الوصف/الأهمية",
        placeholder: "الوصف / الأهمية",
        x: 47,
        y: 30,
        w: 39,
        h: 9,
        tone: "cream",
        size: 24,
      },
      {
        key: "body",
        label: "معلومات",
        placeholder: "اكتب أهم المعلومات هنا…",
        x: 49,
        y: 43,
        w: 38,
        h: 36,
        tone: "ink",
        size: 22,
      },
    ],
  },
  {
    key: "timeline",
    label: "تسلسل أحداث",
    asset: "/whiteboard/cards/timeline.png",
    ratio: 1.5,
    fields: [
      {
        key: "title",
        label: "العنوان",
        placeholder: "العنوان",
        x: 37,
        y: 8,
        w: 26,
        h: 10,
        tone: "brown",
        size: 30,
      },
      {
        key: "one",
        label: "الحدث الأول",
        placeholder: "الحدث الأول",
        x: 10,
        y: 54,
        w: 18,
        h: 10,
        tone: "brown",
        size: 20,
      },
      {
        key: "two",
        label: "الحدث الثاني",
        placeholder: "الحدث الثاني",
        x: 31,
        y: 54,
        w: 18,
        h: 10,
        tone: "brown",
        size: 20,
      },
      {
        key: "three",
        label: "الحدث الثالث",
        placeholder: "الحدث الثالث",
        x: 52,
        y: 54,
        w: 18,
        h: 10,
        tone: "brown",
        size: 20,
      },
      {
        key: "four",
        label: "الحدث الرابع",
        placeholder: "الحدث الرابع",
        x: 73,
        y: 54,
        w: 18,
        h: 10,
        tone: "brown",
        size: 20,
      },
    ],
  },
  {
    key: "note",
    label: "ملاحظة",
    asset: "/whiteboard/cards/note.png",
    ratio: 1.5,
    fields: [
      {
        key: "body",
        label: "نص الملاحظة",
        placeholder: "نص الملاحظة",
        x: 18,
        y: 42,
        w: 64,
        h: 27,
        tone: "ink",
        size: 31,
      },
    ],
  },
  {
    key: "historical-witness",
    label: "شاهد تاريخي",
    asset: "/whiteboard/cards/historical-witness.png",
    ratio: 1.5,
    imageZone: { x: 9, y: 27, w: 38, h: 57, radius: 8 },
    fields: [
      {
        key: "type",
        label: "نوع الشاهد",
        placeholder: "نوع الشاهد",
        x: 58,
        y: 31,
        w: 29,
        h: 9,
        tone: "cream",
        size: 22,
      },
      {
        key: "evidence",
        label: "الدليل/التحليل",
        placeholder: "اكتب الدليل أو التحليل…",
        x: 55,
        y: 61,
        w: 34,
        h: 20,
        tone: "ink",
        size: 21,
      },
    ],
  },
  {
    key: "person",
    label: "شخصية",
    asset: "/whiteboard/cards/person.png",
    ratio: 1.5,
    imageZone: { x: 10, y: 24, w: 31, h: 53, radius: 50 },
    fields: [
      {
        key: "title",
        label: "اسم الشخصية",
        placeholder: "اسم الشخصية",
        x: 47,
        y: 11,
        w: 39,
        h: 13,
        tone: "brown",
        size: 32,
      },
      {
        key: "role",
        label: "الدور/أهم المعلومات",
        placeholder: "الدور / أهم المعلومات",
        x: 51,
        y: 36,
        w: 35,
        h: 9,
        tone: "cream",
        size: 22,
      },
      {
        key: "body",
        label: "التفاصيل",
        placeholder: "اكتب أهم المعلومات هنا…",
        x: 53,
        y: 53,
        w: 35,
        h: 28,
        tone: "ink",
        size: 21,
      },
    ],
  },
  {
    key: "cause-result",
    label: "سبب ونتيجة",
    asset: "/whiteboard/cards/cause-result.png",
    ratio: 1.5,
    fields: [
      {
        key: "cause",
        label: "السبب",
        placeholder: "اكتب السبب",
        x: 55,
        y: 35,
        w: 34,
        h: 24,
        tone: "ink",
        size: 25,
      },
      {
        key: "result",
        label: "النتيجة",
        placeholder: "اكتب النتيجة",
        x: 10,
        y: 35,
        w: 34,
        h: 24,
        tone: "ink",
        size: 25,
      },
      {
        key: "summary",
        label: "التفسير المختصر",
        placeholder: "التفسير المختصر",
        x: 19,
        y: 76,
        w: 62,
        h: 10,
        tone: "ink",
        size: 21,
      },
    ],
  },
  {
    key: "thinking-question",
    label: "سؤال تفكير",
    asset: "/whiteboard/cards/thinking-question.png",
    ratio: 1.5,
    fields: [
      {
        key: "question",
        label: "السؤال",
        placeholder: "اكتب السؤال هنا",
        x: 18,
        y: 42,
        w: 62,
        h: 28,
        tone: "ink",
        size: 31,
      },
    ],
  },
  {
    key: "comparison",
    label: "مقارنة",
    asset: "/whiteboard/cards/comparison.png",
    ratio: 1.5,
    fields: [
      {
        key: "title",
        label: "وجه المقارنة",
        placeholder: "وجه المقارنة",
        x: 35,
        y: 8,
        w: 30,
        h: 10,
        tone: "cream",
        size: 27,
      },
      {
        key: "first",
        label: "العنصر الأول",
        placeholder: "العنصر الأول",
        x: 64,
        y: 24,
        w: 26,
        h: 10,
        tone: "brown",
        size: 25,
      },
      {
        key: "second",
        label: "العنصر الثاني",
        placeholder: "العنصر الثاني",
        x: 10,
        y: 24,
        w: 26,
        h: 10,
        tone: "cream",
        size: 25,
      },
      {
        key: "firstBody",
        label: "تفاصيل العنصر الأول",
        placeholder: "• ...\\n• ...\\n• ...",
        x: 61,
        y: 42,
        w: 31,
        h: 33,
        tone: "ink",
        size: 21,
      },
      {
        key: "secondBody",
        label: "تفاصيل العنصر الثاني",
        placeholder: "• ...\\n• ...\\n• ...",
        x: 8,
        y: 42,
        w: 31,
        h: 33,
        tone: "ink",
        size: 21,
      },
      {
        key: "summary",
        label: "أوجه الشبه/الاختلاف",
        placeholder: "أوجه الشبه / الاختلاف",
        x: 30,
        y: 87,
        w: 40,
        h: 8,
        tone: "brown",
        size: 20,
      },
    ],
  },
]);
const BOARD_CARD_TEMPLATE_MAP = Object.freeze(
  Object.fromEntries(BOARD_CARD_TEMPLATES.map((item) => [item.key, item])),
);

const boardTemplates = [
  { key: "history", label: "تاريخي", icon: BookOpen },
  { key: "geography", label: "جغرافي", icon: MapIcon },
  { key: "manuscript", label: "مخطوطات", icon: StickyNote },
  { key: "blank", label: "فارغ", icon: X },
  { key: "grid", label: "شبكة", icon: LayoutGrid },
  { key: "lines", label: "سطور", icon: Waves },
  { key: "focus", label: "تركيز", icon: Presentation },
];
const flowLabels = {
  preview: "تمهيد",
  board: "شرح على السبورة",
  practice: "تدريب",
  quiz: "تقويم سريع",
};
const modeResourceTypes = {
  pdf: ["textbook", "pdf"],
  images: ["image"],
  videos: ["video"],
  audio: ["audio"],
  slides: ["slides"],
  files: ["file", "document", "link"],
  maps: ["map"],
  games: ["game"],
  board: [],
};

function resourceMediaType(resource) {
  if (!resource) return "";
  if (resource.type === "textbook") return "textbook";
  if (resource.type === "exams") return "pdf";
  return inferMediaType({
    type: resource.type,
    mimeType: resource.mimeType,
    fileName: resource.fileName,
    name: resource.title,
  });
}

function resourceContentMode(resource) {
  if (!resource) return "board";
  const type = resourceMediaType(resource);
  if (type === "image") return "images";
  if (type === "video") return "videos";
  if (type === "audio") return "audio";
  if (type === "slides") return "slides";
  if (["file", "document", "link"].includes(type)) return "files";
  if (["pdf", "textbook"].includes(type)) return "pdf";
  if (type === "map") return "maps";
  if (type === "game") return "games";
  return "board";
}

const normalizeSequence = (sequence) => {
  if (Array.isArray(sequence) && sequence.length)
    return sequence.filter(Boolean);
  if (typeof sequence === "string")
    return sequence
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean);
  return ["preview", "board", "practice"];
};

const normalizeTags = (tags) => {
  if (Array.isArray(tags)) return tags.filter(Boolean);
  if (typeof tags === "string")
    return tags
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean);
  return [];
};

function boardBackground(template) {
  switch (template) {
    case "grid":
      return {
        backgroundImage:
          "linear-gradient(to right, rgba(17,24,39,.09) 1px, transparent 1px), linear-gradient(to bottom, rgba(17,24,39,.09) 1px, transparent 1px)",
        backgroundSize: "32px 32px",
      };
    case "lines":
      return {
        backgroundImage:
          "repeating-linear-gradient(to bottom, rgba(17,24,39,.06) 0, rgba(17,24,39,.06) 1px, transparent 1px, transparent 29px)",
        backgroundSize: "100% 30px",
      };
    case "history":
      return {
        backgroundImage:
          "radial-gradient(circle at 50% 45%, rgba(139,92,35,.10), transparent 32%), repeating-linear-gradient(0deg, rgba(111,78,45,.025) 0 1px, transparent 1px 7px), linear-gradient(145deg, #f6edda, #fffaf0)",
      };
    case "geography":
      return {
        backgroundImage:
          "radial-gradient(circle at 50% 45%, rgba(38,113,92,.09), transparent 32%), linear-gradient(rgba(46,95,78,.045) 1px, transparent 1px), linear-gradient(90deg, rgba(46,95,78,.045) 1px, transparent 1px), linear-gradient(145deg, #f2f7ef, #fbfff9)",
        backgroundSize: "auto, 42px 42px, 42px 42px, auto",
      };
    case "manuscript":
      return {
        backgroundImage:
          "radial-gradient(ellipse at center, rgba(168,116,52,.06), transparent 62%), repeating-linear-gradient(0deg, rgba(103,68,32,.025) 0 1px, transparent 1px 5px), linear-gradient(145deg, #f1dfbc, #fff7e6)",
      };
    case "focus":
      return {
        backgroundImage:
          "radial-gradient(circle at 50% 5%, rgba(215,173,53,.12), transparent 35%), linear-gradient(180deg, #ffffff 0%, #f9fafb 100%)",
      };
    default:
      return {
        backgroundImage: "linear-gradient(180deg, #ffffff 0%, #fbfcfd 100%)",
      };
  }
}

function BoardThemeDecor({ template }) {
  // History intentionally never uses the legacy vector/decorative board.
  // The approved white reference image is the single source of truth.
  if (!["geography", "manuscript"].includes(template)) return null;
  return (
    <svg
      className={`classmode-board-theme-art theme-${template}`}
      viewBox="0 0 1200 720"
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      {template === "history" && (
        <>
          <defs>
            <linearGradient id="historyGold" x1="0" x2="1">
              <stop offset="0" stopColor="#4d2a11" />
              <stop offset=".25" stopColor="#f2cf74" />
              <stop offset=".52" stopColor="#8d581f" />
              <stop offset=".78" stopColor="#f5d98b" />
              <stop offset="1" stopColor="#4b2910" />
            </linearGradient>
            <linearGradient id="historyStone" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#f3d9a8" />
              <stop offset=".4" stopColor="#b98750" />
              <stop offset=".72" stopColor="#78502e" />
              <stop offset="1" stopColor="#3f2819" />
            </linearGradient>
            <linearGradient id="historyPapyrus" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#ffecc0" />
              <stop offset=".48" stopColor="#e9c98c" />
              <stop offset="1" stopColor="#b77d3c" />
            </linearGradient>
            <radialGradient id="historyVignette">
              <stop offset="0" stopColor="#fff6d9" stopOpacity=".28" />
              <stop offset=".7" stopColor="#5c3516" stopOpacity=".02" />
              <stop offset="1" stopColor="#351b0a" stopOpacity=".22" />
            </radialGradient>
            <pattern
              id="papyrusFibres"
              width="52"
              height="22"
              patternUnits="userSpaceOnUse"
            >
              <path
                d="M0 5c13-3 26 3 52 0M0 16c16 3 31-3 52 0"
                stroke="#805323"
                strokeWidth="1"
                opacity=".16"
                fill="none"
              />
            </pattern>
            <filter
              id="historyRelief"
              x="-40%"
              y="-40%"
              width="180%"
              height="190%"
            >
              <feDropShadow
                dx="0"
                dy="11"
                stdDeviation="9"
                floodColor="#1d0c03"
                floodOpacity=".46"
              />
              <feDropShadow
                dx="0"
                dy="2"
                stdDeviation="1.2"
                floodColor="#fff1bb"
                floodOpacity=".25"
              />
            </filter>
            <filter
              id="historySoftShadow"
              x="-30%"
              y="-30%"
              width="160%"
              height="170%"
            >
              <feDropShadow
                dx="0"
                dy="7"
                stdDeviation="7"
                floodColor="#241006"
                floodOpacity=".32"
              />
            </filter>
          </defs>
          <rect
            x="12"
            y="12"
            width="1176"
            height="696"
            rx="24"
            fill="url(#historyVignette)"
            stroke="url(#historyGold)"
            strokeWidth="6"
            opacity=".72"
          />
          <rect
            x="27"
            y="27"
            width="1146"
            height="666"
            rx="18"
            fill="url(#papyrusFibres)"
            stroke="#7f5126"
            strokeWidth="2"
            opacity=".42"
          />
          <g filter="url(#historyRelief)" opacity=".38">
            <g transform="translate(58 128)">
              <path
                d="M0 22h122l-13 24H13Z"
                fill="url(#historyStone)"
                stroke="#68421f"
                strokeWidth="3"
              />
              <path
                d="M22 46h78v360H22Z"
                fill="url(#historyStone)"
                stroke="#68421f"
                strokeWidth="3"
              />
              <path
                d="M12 406h100l18 31H-6Z"
                fill="url(#historyStone)"
                stroke="#68421f"
                strokeWidth="3"
              />
              <path
                d="M38 58v334M57 58v334M76 58v334"
                stroke="#f3d9aa"
                strokeWidth="3"
                opacity=".35"
              />
            </g>
            <g transform="translate(1020 128)">
              <path
                d="M0 22h122l-13 24H13Z"
                fill="url(#historyStone)"
                stroke="#68421f"
                strokeWidth="3"
              />
              <path
                d="M22 46h78v360H22Z"
                fill="url(#historyStone)"
                stroke="#68421f"
                strokeWidth="3"
              />
              <path
                d="M12 406h100l18 31H-6Z"
                fill="url(#historyStone)"
                stroke="#68421f"
                strokeWidth="3"
              />
              <path
                d="M38 58v334M57 58v334M76 58v334"
                stroke="#f3d9aa"
                strokeWidth="3"
                opacity=".35"
              />
            </g>
          </g>
          <g
            transform="translate(790 510)"
            filter="url(#historyRelief)"
            opacity=".34"
          >
            <ellipse
              cx="160"
              cy="132"
              rx="205"
              ry="18"
              fill="#241006"
              opacity=".22"
            />
            <path
              d="M0 130 92 0l72 130Z"
              fill="url(#historyStone)"
              stroke="#6b431f"
              strokeWidth="4"
            />
            <path d="M92 0 164 130 112 112Z" fill="#5a351e" opacity=".62" />
            <path
              d="M120 130 215 30l92 100Z"
              fill="url(#historyStone)"
              stroke="#6b431f"
              strokeWidth="4"
            />
            <path d="M215 30 307 130 238 112Z" fill="#4e2e1a" opacity=".58" />
          </g>
          <g
            transform="translate(275 560)"
            filter="url(#historySoftShadow)"
            opacity=".31"
          >
            <path
              d="M0 38c32-28 67-28 99 0 32 27 64 27 96 0 32-27 65-27 98 0"
              fill="none"
              stroke="#3e6d8f"
              strokeWidth="10"
              strokeLinecap="round"
            />
            <path
              d="M0 36c32-20 67-20 99 0 32 20 64 20 96 0 32-20 65-20 98 0"
              fill="none"
              stroke="#a9d7e5"
              strokeWidth="2.5"
              opacity=".55"
            />
          </g>
          <g
            transform="translate(875 125)"
            filter="url(#historyRelief)"
            opacity=".35"
          >
            <circle
              cx="90"
              cy="90"
              r="72"
              fill="#11161b"
              stroke="url(#historyGold)"
              strokeWidth="6"
            />
            <circle
              cx="90"
              cy="90"
              r="57"
              fill="none"
              stroke="#e7c66d"
              strokeWidth="2"
              opacity=".6"
            />
            <path d="M90 26 104 78 90 154 76 78Z" fill="url(#historyGold)" />
            <path
              d="M26 90 78 76 154 90 78 104Z"
              fill="#d9b75f"
              opacity=".86"
            />
          </g>
          <g
            transform="translate(198 92)"
            filter="url(#historySoftShadow)"
            opacity=".38"
          >
            <path
              d="M20 14h260c18 0 31 13 31 30v78c0 17-13 30-31 30H20c-18 0-31-13-31-30V44c0-17 13-30 31-30Z"
              fill="url(#historyPapyrus)"
              stroke="#74461f"
              strokeWidth="3"
            />
            <rect
              x="-18"
              y="6"
              width="25"
              height="154"
              rx="10"
              fill="url(#historyGold)"
            />
            <rect
              x="293"
              y="6"
              width="25"
              height="154"
              rx="10"
              fill="url(#historyGold)"
            />
            <path
              d="M42 58h214M42 82h192M42 106h218"
              stroke="#75491f"
              strokeWidth="4"
              opacity=".36"
            />
            <circle
              cx="246"
              cy="121"
              r="19"
              fill="#8f281f"
              stroke="#e9bd73"
              strokeWidth="3"
            />
          </g>
          <g opacity=".16" fill="#70421c">
            <circle cx="420" cy="83" r="5" />
            <rect x="440" y="77" width="22" height="11" rx="2" />
            <path d="m482 88 12-20 12 20Z" />
            <circle
              cx="532"
              cy="82"
              r="8"
              fill="none"
              stroke="#70421c"
              strokeWidth="3"
            />
          </g>
          <g
            transform="translate(430 632)"
            opacity=".38"
            filter="url(#historySoftShadow)"
          >
            <rect
              x="0"
              y="0"
              width="340"
              height="48"
              rx="24"
              fill="#2a170b"
              stroke="url(#historyGold)"
              strokeWidth="2"
            />
            <text
              x="170"
              y="21"
              textAnchor="middle"
              fill="#f6d77d"
              fontSize="17"
              fontWeight="800"
              fontFamily="Tahoma, Arial"
            >
              {identity.teacherName}
            </text>
            <text
              x="170"
              y="39"
              textAnchor="middle"
              fill="#fff1c0"
              fontSize="11"
              fontWeight="600"
              fontFamily="Tahoma, Arial"
            >
              {identity.teacherTitle}
            </text>
          </g>
        </>
      )}
      {template === "geography" && (
        <>
          <g fill="none" stroke="#2d7562" opacity=".13">
            <ellipse cx="1010" cy="165" rx="105" ry="78" strokeWidth="4" />
            <ellipse cx="1010" cy="165" rx="65" ry="78" strokeWidth="3" />
            <path d="M905 165h210M1010 87v156" strokeWidth="3" />
          </g>
          <g fill="none" stroke="#2d7562" opacity=".11" strokeWidth="3">
            <path d="M80 555c90-72 170-68 250 5s160 75 250-8 170-76 265 6 175 80 270-6" />
            <path d="M105 585c80-52 160-48 235 4s155 55 235-6 160-56 250 5 165 59 260-8" />
          </g>
          <g fill="none" stroke="#467b68" opacity=".09">
            <ellipse cx="250" cy="300" rx="180" ry="110" />
            <ellipse cx="250" cy="300" rx="140" ry="82" />
            <ellipse cx="250" cy="300" rx="90" ry="50" />
          </g>
          <path
            d="M740 620 800 520l55 55 62-130 78 175"
            fill="#4c806b"
            opacity=".10"
          />
          <g
            transform="translate(1060 540)"
            opacity=".22"
            fill="none"
            stroke="#2d7562"
            strokeWidth="5"
          >
            <circle r="54" />
            <path d="M0-48 13-8 0 48-13-8ZM-48 0-8-13 48 0-8 13Z" />
          </g>
        </>
      )}
      {template === "manuscript" && (
        <>
          <path
            d="M70 110c60-38 145-30 198 5M930 610c65 32 145 26 205-12"
            fill="none"
            stroke="#7e5126"
            strokeWidth="7"
            opacity=".11"
          />
          <path
            d="M48 104h145c35 0 50 35 18 56H48c-30 0-35-40 0-56Zm1104 512H1002c-36 0-50-35-18-56h168c31 0 36 40 0 56Z"
            fill="#a86f32"
            opacity=".08"
            stroke="#7e5126"
            strokeWidth="4"
          />
          <g stroke="#7e5126" opacity=".075" strokeWidth="2">
            <path d="M90 180h1020M90 220h1020M90 260h1020M90 300h1020M90 340h1020M90 380h1020M90 420h1020M90 460h1020M90 500h1020" />
          </g>
          <path
            d="M1020 150c-75 85-110 190-135 320m0 0 48-35m-48 35-15-55"
            fill="none"
            stroke="#603b1d"
            strokeWidth="9"
            opacity=".11"
            strokeLinecap="round"
          />
        </>
      )}
    </svg>
  );
}

function drawBoardThemeMotifs(ctx, template, width, height) {
  ctx.save();
  if (template === "history") {
    ctx.globalAlpha = 0.11;
    ctx.strokeStyle = "#7b4b1f";
    ctx.fillStyle = "#a87335";
    ctx.lineWidth = 5;
    const pyramid = (x, base, w, h) => {
      ctx.beginPath();
      ctx.moveTo(x, base);
      ctx.lineTo(x + w / 2, base - h);
      ctx.lineTo(x + w, base);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    };
    pyramid(width - 250, height - 36, 170, 215);
    pyramid(45, height - 36, 140, 165);
    ctx.beginPath();
    ctx.arc(width - 145, 145, 58, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 0.16;
    ctx.strokeRect(24, 100, width - 48, height - 132);
  } else if (template === "geography") {
    ctx.globalAlpha = 0.105;
    ctx.strokeStyle = "#2d7562";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(width - 170, 165, 108, 78, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(width - 170, 165, 62, 78, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(width - 278, 165);
    ctx.lineTo(width - 62, 165);
    ctx.moveTo(width - 170, 87);
    ctx.lineTo(width - 170, 243);
    ctx.stroke();
    for (let radius = 55; radius <= 165; radius += 35) {
      ctx.beginPath();
      ctx.ellipse(230, 310, radius, radius * 0.55, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.globalAlpha = 0.12;
    ctx.fillStyle = "#4c806b";
    ctx.beginPath();
    ctx.moveTo(width - 470, height - 32);
    ctx.lineTo(width - 390, height - 160);
    ctx.lineTo(width - 330, height - 90);
    ctx.lineTo(width - 255, height - 245);
    ctx.lineTo(width - 155, height - 32);
    ctx.closePath();
    ctx.fill();
  } else if (template === "manuscript") {
    ctx.globalAlpha = 0.08;
    ctx.strokeStyle = "#7e5126";
    ctx.lineWidth = 2;
    for (let y = 175; y < height - 80; y += 42) {
      ctx.beginPath();
      ctx.moveTo(85, y);
      ctx.lineTo(width - 85, y);
      ctx.stroke();
    }
    ctx.globalAlpha = 0.11;
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.moveTo(width - 165, 145);
    ctx.quadraticCurveTo(width - 260, 260, width - 300, height - 150);
    ctx.stroke();
  }
  ctx.restore();
}

function dataUrlToImage(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}

async function drawBoardIdentity(ctx, template, width, height, meta = {}) {
  if (!["history", "geography", "manuscript"].includes(template)) return;
  if (template === "history") {
    try {
      const reference = await dataUrlToImage(
        "/identity/class-board-history-v14.jpg?art=050a3927a7ba",
      );
      const ratio = Math.min(
        width / reference.width,
        height / reference.height,
      );
      const drawWidth = reference.width * ratio;
      const drawHeight = reference.height * ratio;
      ctx.drawImage(
        reference,
        (width - drawWidth) / 2,
        (height - drawHeight) / 2,
        drawWidth,
        drawHeight,
      );
      return;
    } catch {
      // The approved white board image is the only History board identity.
      // If the asset is unavailable, fail safely to a plain white board rather
      // than resurrecting the old decorative/vector whiteboard structure.
      ctx.save();
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, width, height);
      ctx.restore();
      return;
    }
  }
  const backgrounds = {
    history: ["#f6edda", "#fffaf0"],
    geography: ["#eef6ec", "#fbfff9"],
    manuscript: ["#f1dfbc", "#fff7e6"],
  };
  const [start, end] = backgrounds[template];
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, start);
  gradient.addColorStop(1, end);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  ctx.save();
  ctx.globalAlpha = 0.045;
  ctx.strokeStyle = template === "geography" ? "#1f6b55" : "#6d421d";
  ctx.lineWidth = 2;
  for (let x = 40; x < width; x += 90) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }
  for (let y = 35; y < height; y += 75) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }
  ctx.restore();
  drawBoardThemeMotifs(ctx, template, width, height);

  ctx.save();
  ctx.strokeStyle =
    template === "geography" ? "rgba(31,107,85,.22)" : "rgba(109,66,29,.24)";
  ctx.lineWidth = 3;
  ctx.strokeRect(18, 18, width - 36, height - 36);
  ctx.restore();

  try {
    const logo = await dataUrlToImage(identity.logo);
    const target = Math.min(width, height) * 0.3;
    ctx.save();
    ctx.globalAlpha = 0.05;
    ctx.drawImage(
      logo,
      (width - target) / 2,
      (height - target) / 2,
      target,
      target,
    );
    ctx.restore();
  } catch {
    // Optional watermark.
  }

  const ribbonHeight = 82;
  const ribbonGradient = ctx.createLinearGradient(0, 0, width, 0);
  ribbonGradient.addColorStop(0, "#080a0f");
  ribbonGradient.addColorStop(0.5, "#17120a");
  ribbonGradient.addColorStop(1, "#080a0f");
  ctx.save();
  ctx.fillStyle = ribbonGradient;
  ctx.fillRect(0, 0, width, ribbonHeight);
  ctx.strokeStyle = "#d7ad35";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(0, ribbonHeight - 3);
  ctx.lineTo(width, ribbonHeight - 3);
  ctx.stroke();
  ctx.direction = "rtl";
  ctx.textAlign = "right";
  ctx.fillStyle = "#e7bf62";
  ctx.font = "700 18px Tahoma, Arial, sans-serif";
  ctx.fillText("الصف", width - 36, 23);
  ctx.fillStyle = "#fff7df";
  ctx.font = "700 25px Tahoma, Arial, sans-serif";
  ctx.fillText(String(meta.grade || "غير محدد"), width - 36, 55);
  ctx.fillStyle = "#e7bf62";
  ctx.font = "700 18px Tahoma, Arial, sans-serif";
  ctx.fillText("الدرس", width - 390, 23);
  ctx.fillStyle = "#fff7df";
  ctx.font = "700 25px Tahoma, Arial, sans-serif";
  ctx.fillText(
    String(meta.lesson || "حصة جديدة").slice(0, 38),
    width - 390,
    55,
  );
  ctx.restore();

  try {
    const portrait = await dataUrlToImage(identity.portrait);
    const size = 66;
    const centerX = 44;
    const centerY = ribbonHeight / 2;
    ctx.save();
    ctx.beginPath();
    ctx.arc(centerX, centerY, size / 2, 0, Math.PI * 2);
    ctx.clip();
    ctx.drawImage(portrait, centerX - size / 2, centerY - size / 2, size, size);
    ctx.restore();
    ctx.save();
    ctx.strokeStyle = "#d7ad35";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(centerX, centerY, size / 2 + 2, 0, Math.PI * 2);
    ctx.stroke();
    ctx.direction = "rtl";
    ctx.textAlign = "left";
    ctx.fillStyle = "#f3d783";
    ctx.font = "700 22px Tahoma, Arial, sans-serif";
    ctx.fillText(identity.teacherName, 88, 34);
    ctx.fillStyle = "#fff7df";
    ctx.font = "600 16px Tahoma, Arial, sans-serif";
    ctx.fillText(identity.teacherTitle, 88, 59);
    ctx.restore();
  } catch {
    // Portrait is decorative.
  }
}

function drawStamp(ctx, stamp) {
  const x = stamp.x;
  const y = stamp.y;
  ctx.save();
  ctx.translate(x, y);
  const visualScale = Math.max(0.35, Number(stamp.visualScale || 1));
  if (stamp.kind !== "text" && Math.abs(visualScale - 1) > 0.001) ctx.scale(visualScale, visualScale);
  ctx.fillStyle = stamp.color || "#d7ad35";
  ctx.strokeStyle = stamp.color || "#d7ad35";
  ctx.lineWidth = 4;
  ctx.font = `${stamp.fontWeight || 700} ${stamp.fontSize || 22}px ${stamp.fontFamily || "Tahoma, Arial, sans-serif"}`;

  if (stamp.kind === "text") {
    const lines = String(stamp.text || "")
      .split("\n")
      .slice(0, 5);
    const style = stamp.textStyle || "plain";
    const lineHeight = Math.max(
      31,
      Number(stamp.fontSize || 22) * Number(stamp.lineHeight || 1.35),
    );
    const measuredWidth = Math.max(
      ...lines.map((line) => ctx.measureText(line || " ").width),
      0,
    );
    const boxWidth = Math.min(620, Math.max(230, measuredWidth + 48));
    const boxHeight = Math.max(62, lines.length * lineHeight + 22);
    ctx.direction = boardTextDirection(stamp.text);
    ctx.textAlign = "right";
    ctx.textBaseline = "top";

    if (style !== "plain") {
      ctx.lineWidth = 3;
      ctx.shadowColor = "rgba(20,12,5,.42)";
      ctx.shadowBlur = 14;
      ctx.shadowOffsetY = 6;
      if (style === "historical") {
        const paper = ctx.createLinearGradient(-boxWidth, 0, 0, boxHeight);
        paper.addColorStop(0, "#c99a54");
        paper.addColorStop(0.15, "#f0d49b");
        paper.addColorStop(0.82, "#f8e7bd");
        paper.addColorStop(1, "#b77b37");
        ctx.fillStyle = paper;
        ctx.strokeStyle = "#87501f";
        ctx.shadowColor = "rgba(45,25,8,.28)";
        ctx.shadowBlur = 10;
        ctx.beginPath();
        if (typeof ctx.roundRect === "function")
          ctx.roundRect(-boxWidth, -12, boxWidth, boxHeight, 10);
        else ctx.rect(-boxWidth, -12, boxWidth, boxHeight);
        ctx.fill();
        ctx.stroke();
        ctx.shadowBlur = 0;
        ctx.fillStyle = "#a96d2d";
        ctx.fillRect(-boxWidth + 12, -6, 9, boxHeight - 12);
        ctx.fillRect(-18, -6, 9, boxHeight - 12);
        const seal = ctx.createRadialGradient(
          -boxWidth + 38,
          boxHeight - 22,
          2,
          -boxWidth + 38,
          boxHeight - 22,
          17,
        );
        seal.addColorStop(0, "#e56b4b");
        seal.addColorStop(0.55, "#a92e24");
        seal.addColorStop(1, "#5b1716");
        ctx.fillStyle = seal;
        ctx.beginPath();
        ctx.arc(-boxWidth + 38, boxHeight - 22, 16, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#f0c27a";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(-boxWidth + 38, boxHeight - 22, 10, 0, Math.PI * 2);
        ctx.stroke();
        ctx.strokeStyle = "rgba(91,51,18,.3)";
        ctx.beginPath();
        ctx.moveTo(-boxWidth + 34, boxHeight - 9);
        ctx.lineTo(-34, boxHeight - 9);
        ctx.stroke();
        ctx.fillStyle = "#3d2816";
      } else if (style === "geography") {
        const mapFill = ctx.createLinearGradient(-boxWidth, -12, 0, boxHeight);
        mapFill.addColorStop(0, "#dcebd3");
        mapFill.addColorStop(0.55, "#f4ecd2");
        mapFill.addColorStop(1, "#b9d8cb");
        ctx.fillStyle = mapFill;
        ctx.strokeStyle = "#276a58";
        ctx.beginPath();
        if (typeof ctx.roundRect === "function")
          ctx.roundRect(-boxWidth, -12, boxWidth, boxHeight, 8);
        else ctx.rect(-boxWidth, -12, boxWidth, boxHeight);
        ctx.fill();
        ctx.stroke();
        ctx.save();
        ctx.globalAlpha = 0.18;
        ctx.strokeStyle = "#2b6f63";
        ctx.lineWidth = 1;
        for (let gx = -boxWidth + 26; gx < -10; gx += 42) {
          ctx.beginPath();
          ctx.moveTo(gx, -9);
          ctx.lineTo(gx, boxHeight - 16);
          ctx.stroke();
        }
        for (let gy = 12; gy < boxHeight - 12; gy += 30) {
          ctx.beginPath();
          ctx.moveTo(-boxWidth + 8, gy);
          ctx.lineTo(-10, gy);
          ctx.stroke();
        }
        ctx.restore();
        ctx.fillStyle = "#1f6b55";
        ctx.beginPath();
        ctx.arc(-boxWidth + 34, boxHeight / 2 - 4, 12, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#e9d699";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(-boxWidth + 34, boxHeight / 2 - 4, 16, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = "#e9d699";
        ctx.beginPath();
        ctx.moveTo(-boxWidth + 34, boxHeight / 2 - 16);
        ctx.lineTo(-boxWidth + 39, boxHeight / 2 - 1);
        ctx.lineTo(-boxWidth + 34, boxHeight / 2 + 7);
        ctx.lineTo(-boxWidth + 29, boxHeight / 2 - 1);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = "#173f37";
      } else if (style === "event") {
        ctx.fillStyle = "rgba(17,24,39,.96)";
        ctx.strokeStyle = "#d7ad35";
        ctx.beginPath();
        ctx.moveTo(-boxWidth + 16, -12);
        ctx.lineTo(-16, -12);
        ctx.lineTo(0, 4);
        ctx.lineTo(0, boxHeight - 28);
        ctx.lineTo(-16, boxHeight - 12);
        ctx.lineTo(-boxWidth + 16, boxHeight - 12);
        ctx.lineTo(-boxWidth, boxHeight - 28);
        ctx.lineTo(-boxWidth, 4);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = "#d7ad35";
        ctx.font = "700 28px Tahoma, Arial, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText("★", -boxWidth + 32, boxHeight / 2 - 2);
        ctx.textAlign = "right";
        ctx.font = `${stamp.fontWeight || 700} ${stamp.fontSize || 22}px ${stamp.fontFamily || "Tahoma, Arial, sans-serif"}`;
        ctx.fillStyle = "#fff5d6";
      } else if (style === "date") {
        ctx.fillStyle = "#6b3f22";
        ctx.strokeStyle = "#e4bd72";
        ctx.beginPath();
        if (typeof ctx.roundRect === "function")
          ctx.roundRect(-boxWidth, -12, boxWidth, boxHeight, 999);
        else ctx.rect(-boxWidth, -12, boxWidth, boxHeight);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = "#e4bd72";
        ctx.beginPath();
        ctx.arc(-boxWidth + 30, boxHeight / 2 - 6, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#fff4d8";
      } else if (style === "person") {
        ctx.fillStyle = "#2e2239";
        ctx.strokeStyle = "#d2a957";
        ctx.beginPath();
        if (typeof ctx.roundRect === "function")
          ctx.roundRect(-boxWidth, -12, boxWidth, boxHeight, 18);
        else ctx.rect(-boxWidth, -12, boxWidth, boxHeight);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = "#d2a957";
        ctx.beginPath();
        ctx.arc(-boxWidth + 32, boxHeight / 2 - 12, 10, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(-boxWidth + 32, boxHeight / 2 + 13, 17, Math.PI, 0);
        ctx.fill();
        ctx.fillStyle = "#fff7df";
      } else if (style === "place") {
        ctx.fillStyle = "#173f37";
        ctx.strokeStyle = "#e2c56e";
        ctx.beginPath();
        if (typeof ctx.roundRect === "function")
          ctx.roundRect(-boxWidth, -12, boxWidth, boxHeight, 12);
        else ctx.rect(-boxWidth, -12, boxWidth, boxHeight);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = "#e2c56e";
        ctx.beginPath();
        ctx.arc(-boxWidth + 34, boxHeight / 2 - 12, 11, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(-boxWidth + 34, boxHeight / 2 + 18);
        ctx.lineTo(-boxWidth + 22, boxHeight / 2 - 4);
        ctx.lineTo(-boxWidth + 46, boxHeight / 2 - 4);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = "#fff7df";
      } else if (style === "definition") {
        const definitionFill = ctx.createLinearGradient(
          -boxWidth,
          -12,
          0,
          boxHeight,
        );
        definitionFill.addColorStop(0, "#1b2130");
        definitionFill.addColorStop(1, "#35250f");
        ctx.fillStyle = definitionFill;
        ctx.strokeStyle = "#d7ad35";
        ctx.beginPath();
        if (typeof ctx.roundRect === "function")
          ctx.roundRect(-boxWidth, -12, boxWidth, boxHeight, 16);
        else ctx.rect(-boxWidth, -12, boxWidth, boxHeight);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = "#d7ad35";
        ctx.font = "700 25px Georgia, serif";
        ctx.textAlign = "center";
        ctx.fillText("❖", -boxWidth + 34, boxHeight / 2 - 3);
        ctx.textAlign = "right";
        ctx.font = `${stamp.fontWeight || 700} ${stamp.fontSize || 22}px ${stamp.fontFamily || "Tahoma, Arial, sans-serif"}`;
        ctx.fillStyle = "#fff6d8";
      } else if (style === "note") {
        ctx.fillStyle = "#fff1a9";
        ctx.strokeStyle = "#9d7621";
        ctx.beginPath();
        ctx.moveTo(-boxWidth, -12);
        ctx.lineTo(-28, -12);
        ctx.lineTo(0, 16);
        ctx.lineTo(0, boxHeight - 12);
        ctx.lineTo(-boxWidth, boxHeight - 12);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = "#e1b947";
        ctx.beginPath();
        ctx.moveTo(-28, -12);
        ctx.lineTo(0, 16);
        ctx.lineTo(-28, 16);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = "#4c3510";
      } else {
        ctx.fillStyle = "rgba(57,36,18,.94)";
        ctx.strokeStyle = "#d7ad35";
        ctx.beginPath();
        if (typeof ctx.roundRect === "function")
          ctx.roundRect(-boxWidth, -12, boxWidth, boxHeight, 14);
        else ctx.rect(-boxWidth, -12, boxWidth, boxHeight);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = "#fff7df";
      }
    }
    if (style !== "plain") {
      const styleLabels = {
        historical: "مصطلح تاريخي",
        geography: "مصطلح جغرافي",
        event: "حدث مهم",
        date: "تاريخ",
        person: "شخصية",
        place: "مكان",
        definition: "تعريف",
        note: "ملاحظة",
      };
      ctx.save();
      ctx.shadowBlur = 0;
      ctx.shadowOffsetY = 0;
      ctx.globalAlpha = 0.92;
      ctx.direction = "rtl";
      ctx.textAlign = "left";
      ctx.textBaseline = "alphabetic";
      ctx.font = "700 10px Tahoma, Arial, sans-serif";
      ctx.fillStyle =
        style === "note"
          ? "#785516"
          : style === "geography"
            ? "#2a6858"
            : "#b67a2c";
      ctx.fillText(
        styleLabels[style] || "بطاقة تعليمية",
        -boxWidth + 18,
        boxHeight - 3,
      );
      ctx.restore();
    }
    ctx.shadowBlur = 0;
    ctx.shadowOffsetY = 0;
    ctx.textAlign = "right";
    ctx.textBaseline = "top";
    ctx.font = `${stamp.fontWeight || 700} ${stamp.fontSize || 22}px ${stamp.fontFamily || "Tahoma, Arial, sans-serif"}`;
    lines.forEach((line, index) => {
      ctx.direction = boardTextDirection(line);
      ctx.fillText(line, -20, 8 + index * lineHeight);
    });
  } else if (stamp.kind === "shape") {
    const kind = stamp.shape || "rect";
    const fill = ctx.createLinearGradient(15, 5, 145, 115);
    fill.addColorStop(0, "rgba(255,244,192,.40)");
    fill.addColorStop(0.42, "rgba(215,173,53,.24)");
    fill.addColorStop(1, "rgba(72,44,12,.14)");
    ctx.fillStyle = fill;
    ctx.strokeStyle = stamp.color || "#d7ad35";
    ctx.lineWidth = Math.max(4, Number(stamp.width || 4));
    ctx.shadowColor = "rgba(0,0,0,.38)";
    ctx.shadowBlur = 12;
    ctx.shadowOffsetY = 5;
    if (kind === "circle") {
      ctx.beginPath();
      ctx.arc(80, 60, 46, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.save();
      ctx.globalAlpha = 0.55;
      ctx.strokeStyle = "#fff2b5";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(72, 51, 34, Math.PI * 1.05, Math.PI * 1.75);
      ctx.stroke();
      ctx.restore();
    } else if (kind === "triangle") {
      ctx.beginPath();
      ctx.moveTo(80, 10);
      ctx.lineTo(130, 102);
      ctx.lineTo(30, 102);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.save();
      ctx.globalAlpha = 0.45;
      ctx.strokeStyle = "#fff2b5";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(80, 20);
      ctx.lineTo(119, 93);
      ctx.stroke();
      ctx.restore();
    } else if (kind === "line") {
      ctx.shadowBlur = 7;
      ctx.beginPath();
      ctx.moveTo(0, 60);
      ctx.lineTo(160, 60);
      ctx.stroke();
    } else {
      ctx.beginPath();
      if (typeof ctx.roundRect === "function")
        ctx.roundRect(20, 20, 120, 86, 14);
      else ctx.rect(20, 20, 120, 86);
      ctx.fill();
      ctx.stroke();
      ctx.save();
      ctx.globalAlpha = 0.48;
      ctx.strokeStyle = "#fff2b5";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(32, 31);
      ctx.lineTo(128, 31);
      ctx.stroke();
      ctx.restore();
    }
  } else if (stamp.kind === "historical-symbol") {
    const kind = stamp.symbolKind || "pyramid";
    const gold = ctx.createLinearGradient(16, 8, 152, 118);
    gold.addColorStop(0, "#fff4b5");
    gold.addColorStop(0.2, "#e9c45d");
    gold.addColorStop(0.48, "#9b621e");
    gold.addColorStop(0.72, "#f4d274");
    gold.addColorStop(1, "#694015");
    const stone = ctx.createLinearGradient(18, 5, 145, 116);
    stone.addColorStop(0, "#fff0c3");
    stone.addColorStop(0.28, "#d7af78");
    stone.addColorStop(0.58, "#9a6a3d");
    stone.addColorStop(1, "#4b2b19");
    const darkStone = ctx.createLinearGradient(30, 20, 145, 115);
    darkStone.addColorStop(0, "#9c6a3b");
    darkStone.addColorStop(1, "#3c2113");
    const paper = ctx.createLinearGradient(10, 10, 150, 105);
    paper.addColorStop(0, "#fff1c7");
    paper.addColorStop(0.5, "#ddb979");
    paper.addColorStop(1, "#9b622e");
    ctx.shadowColor = "rgba(24,10,2,.58)";
    ctx.shadowBlur = 18;
    ctx.shadowOffsetY = 10;
    ctx.lineWidth = 3;
    ctx.fillStyle = "rgba(25,10,3,.24)";
    ctx.beginPath();
    ctx.ellipse(83, 111, 69, 11, 0, 0, Math.PI * 2);
    ctx.fill();
    if (kind === "pyramid") {
      ctx.fillStyle = stone;
      ctx.strokeStyle = "#6e431e";
      ctx.beginPath();
      ctx.moveTo(16, 106);
      ctx.lineTo(82, 10);
      ctx.lineTo(92, 106);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = darkStone;
      ctx.beginPath();
      ctx.moveTo(82, 10);
      ctx.lineTo(151, 106);
      ctx.lineTo(92, 106);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.save();
      ctx.globalAlpha = 0.45;
      ctx.strokeStyle = "#fff0ba";
      ctx.lineWidth = 1.5;
      for (let y = 36; y < 101; y += 15) {
        ctx.beginPath();
        ctx.moveTo(31 + y * 0.32, y);
        ctx.lineTo(132 - y * 0.23, y);
        ctx.stroke();
      }
      ctx.restore();
      ctx.fillStyle = "#f7d47a";
      ctx.beginPath();
      ctx.moveTo(77, 18);
      ctx.lineTo(82, 10);
      ctx.lineTo(87, 18);
      ctx.closePath();
      ctx.fill();
    } else if (kind === "column") {
      ctx.fillStyle = darkStone;
      ctx.strokeStyle = "#65401f";
      ctx.fillRect(51, 30, 61, 72);
      ctx.strokeRect(51, 30, 61, 72);
      ctx.fillStyle = stone;
      ctx.fillRect(47, 29, 49, 72);
      ctx.strokeRect(47, 29, 49, 72);
      ctx.fillStyle = gold;
      ctx.beginPath();
      ctx.moveTo(35, 18);
      ctx.lineTo(124, 18);
      ctx.lineTo(116, 34);
      ctx.lineTo(43, 34);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(31, 101);
      ctx.lineTo(128, 101);
      ctx.lineTo(140, 114);
      ctx.lineTo(20, 114);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.save();
      ctx.globalAlpha = 0.45;
      ctx.strokeStyle = "#fff2c9";
      ctx.lineWidth = 2;
      for (let x = 57; x < 92; x += 10) {
        ctx.beginPath();
        ctx.moveTo(x, 36);
        ctx.lineTo(x, 95);
        ctx.stroke();
      }
      ctx.restore();
    } else if (kind === "scroll") {
      ctx.fillStyle = paper;
      ctx.strokeStyle = "#75461f";
      ctx.beginPath();
      if (typeof ctx.roundRect === "function")
        ctx.roundRect(25, 22, 116, 82, 12);
      else ctx.rect(25, 22, 116, 82);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = gold;
      ctx.beginPath();
      ctx.ellipse(25, 63, 12, 45, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.ellipse(141, 63, 12, 45, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = "rgba(78,43,16,.45)";
      ctx.lineWidth = 2;
      for (let y = 42; y < 88; y += 12) {
        ctx.beginPath();
        ctx.moveTo(44, y);
        ctx.lineTo(120, y);
        ctx.stroke();
      }
      const wax = ctx.createRadialGradient(83, 91, 2, 83, 91, 15);
      wax.addColorStop(0, "#e66c52");
      wax.addColorStop(0.55, "#a62d25");
      wax.addColorStop(1, "#551515");
      ctx.fillStyle = wax;
      ctx.beginPath();
      ctx.arc(83, 91, 14, 0, Math.PI * 2);
      ctx.fill();
    } else if (kind === "obelisk") {
      ctx.fillStyle = stone;
      ctx.strokeStyle = "#68401d";
      ctx.beginPath();
      ctx.moveTo(58, 28);
      ctx.lineTo(80, 5);
      ctx.lineTo(82, 104);
      ctx.lineTo(50, 104);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = darkStone;
      ctx.beginPath();
      ctx.moveTo(80, 5);
      ctx.lineTo(105, 28);
      ctx.lineTo(112, 104);
      ctx.lineTo(82, 104);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = gold;
      ctx.beginPath();
      ctx.moveTo(38, 104);
      ctx.lineTo(124, 104);
      ctx.lineTo(135, 115);
      ctx.lineTo(27, 115);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.save();
      ctx.globalAlpha = 0.38;
      ctx.strokeStyle = "#f1d18c";
      ctx.lineWidth = 2;
      ctx.strokeRect(61, 45, 12, 18);
      ctx.strokeRect(59, 69, 15, 17);
      ctx.restore();
    } else if (kind === "crown") {
      ctx.fillStyle = gold;
      ctx.strokeStyle = "#704311";
      ctx.beginPath();
      ctx.moveTo(20, 45);
      ctx.lineTo(45, 72);
      ctx.lineTo(62, 31);
      ctx.lineTo(83, 72);
      ctx.lineTo(108, 27);
      ctx.lineTo(142, 72);
      ctx.lineTo(132, 104);
      ctx.lineTo(30, 104);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      [
        ["#d44333", 48],
        ["#2877bd", 78],
        ["#3a9c6c", 108],
        ["#8c4dcc", 128],
      ].forEach(([c, x]) => {
        const g = ctx.createRadialGradient(x - 2, 78, 1, x, 80, 9);
        g.addColorStop(0, "#fff");
        g.addColorStop(0.2, c);
        g.addColorStop(1, "#381313");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(x, 82, 8, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.strokeStyle = "rgba(255,246,185,.7)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(38, 94);
      ctx.lineTo(125, 94);
      ctx.stroke();
    } else if (kind === "sphinx") {
      ctx.fillStyle = darkStone;
      ctx.strokeStyle = "#68401d";
      ctx.beginPath();
      ctx.ellipse(88, 79, 55, 25, -0.06, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = stone;
      ctx.beginPath();
      ctx.ellipse(71, 72, 42, 21, -0.06, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillRect(34, 83, 80, 18);
      ctx.strokeRect(34, 83, 80, 18);
      ctx.fillStyle = stone;
      ctx.beginPath();
      ctx.arc(42, 57, 17, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = gold;
      ctx.beginPath();
      ctx.moveTo(26, 54);
      ctx.lineTo(42, 38);
      ctx.lineTo(59, 54);
      ctx.lineTo(53, 66);
      ctx.lineTo(31, 66);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#3b2114";
      ctx.beginPath();
      ctx.arc(37, 56, 2.4, 0, Math.PI * 2);
      ctx.arc(47, 56, 2.4, 0, Math.PI * 2);
      ctx.fill();
    } else if (kind === "temple") {
      ctx.fillStyle = darkStone;
      ctx.strokeStyle = "#5f391b";
      ctx.beginPath();
      ctx.moveTo(20, 32);
      ctx.lineTo(146, 32);
      ctx.lineTo(134, 47);
      ctx.lineTo(31, 47);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = stone;
      for (const x of [35, 65, 96, 126]) {
        ctx.fillRect(x, 45, 18, 58);
        ctx.strokeRect(x, 45, 18, 58);
        ctx.save();
        ctx.globalAlpha = 0.35;
        ctx.strokeStyle = "#ffe9bc";
        ctx.beginPath();
        ctx.moveTo(x + 5, 49);
        ctx.lineTo(x + 5, 98);
        ctx.stroke();
        ctx.restore();
      }
      ctx.fillStyle = gold;
      ctx.beginPath();
      ctx.moveTo(16, 21);
      ctx.lineTo(150, 21);
      ctx.lineTo(143, 34);
      ctx.lineTo(23, 34);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillRect(18, 103, 132, 11);
      ctx.strokeRect(18, 103, 132, 11);
    } else if (kind === "mobdea-seal") {
      if (MOBDEA_LOGO_IMAGE?.complete && MOBDEA_LOGO_IMAGE.naturalWidth > 0) {
        const ratio =
          MOBDEA_LOGO_IMAGE.naturalWidth /
          Math.max(1, MOBDEA_LOGO_IMAGE.naturalHeight);
        const maxWidth = 138;
        const maxHeight = 104;
        let logoWidth = maxWidth;
        let logoHeight = logoWidth / ratio;
        if (logoHeight > maxHeight) {
          logoHeight = maxHeight;
          logoWidth = logoHeight * ratio;
        }
        ctx.save();
        ctx.globalAlpha = 0.98;
        ctx.drawImage(
          MOBDEA_LOGO_IMAGE,
          82 - logoWidth / 2,
          62 - logoHeight / 2,
          logoWidth,
          logoHeight,
        );
        ctx.restore();
      } else {
        ctx.fillStyle = "rgba(8,10,14,.86)";
        ctx.strokeStyle = "#d7ad35";
        ctx.lineWidth = 4;
        ctx.beginPath();
        if (typeof ctx.roundRect === "function")
          ctx.roundRect(20, 18, 124, 88, 14);
        else ctx.rect(20, 18, 124, 88);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = "#f5d47c";
        ctx.textAlign = "center";
        ctx.font = "800 16px Tahoma, Arial, sans-serif";
        ctx.fillText("شعار المُبدع", 82, 68);
      }
    } else {
      ctx.fillStyle = "rgba(12,22,28,.96)";
      ctx.strokeStyle = "#d7ad35";
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(82, 62, 48, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      const needle = ctx.createLinearGradient(70, 18, 94, 105);
      needle.addColorStop(0, "#fff1aa");
      needle.addColorStop(0.52, "#d5a234");
      needle.addColorStop(0.53, "#9a2f27");
      needle.addColorStop(1, "#5d1717");
      ctx.fillStyle = needle;
      ctx.beginPath();
      ctx.moveTo(82, 15);
      ctx.lineTo(92, 62);
      ctx.lineTo(82, 109);
      ctx.lineTo(72, 62);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = "#f7d97c";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(36, 62);
      ctx.lineTo(128, 62);
      ctx.moveTo(82, 17);
      ctx.lineTo(82, 107);
      ctx.stroke();
      ctx.fillStyle = "#f7d97c";
      ctx.beginPath();
      ctx.arc(82, 62, 6, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (stamp.kind === "geographical-symbol") {
    const kind = stamp.symbolKind || "mountain";
    ctx.shadowColor = "rgba(0,15,17,.55)";
    ctx.shadowBlur = 18;
    ctx.shadowOffsetY = 9;
    ctx.lineWidth = 3;
    ctx.fillStyle = "rgba(0,20,24,.25)";
    ctx.beginPath();
    ctx.ellipse(84, 108, 70, 10, 0, 0, Math.PI * 2);
    ctx.fill();
    if (kind === "mountain") {
      const left = ctx.createLinearGradient(18, 22, 95, 108);
      left.addColorStop(0, "#edf0d8");
      left.addColorStop(0.22, "#7f9a66");
      left.addColorStop(1, "#31492d");
      const right = ctx.createLinearGradient(82, 15, 148, 110);
      right.addColorStop(0, "#8fa16e");
      right.addColorStop(1, "#182b21");
      ctx.fillStyle = left;
      ctx.strokeStyle = "#263d2a";
      ctx.beginPath();
      ctx.moveTo(13, 105);
      ctx.lineTo(78, 17);
      ctx.lineTo(95, 105);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = right;
      ctx.beginPath();
      ctx.moveTo(78, 17);
      ctx.lineTo(151, 105);
      ctx.lineTo(95, 105);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#f8f7ec";
      ctx.beginPath();
      ctx.moveTo(61, 41);
      ctx.lineTo(78, 17);
      ctx.lineTo(96, 40);
      ctx.lineTo(88, 36);
      ctx.lineTo(82, 47);
      ctx.lineTo(74, 36);
      ctx.lineTo(68, 44);
      ctx.closePath();
      ctx.fill();
    } else if (kind === "plateau") {
      const top = ctx.createLinearGradient(40, 25, 120, 58);
      top.addColorStop(0, "#d8b477");
      top.addColorStop(1, "#8f6337");
      const side = ctx.createLinearGradient(35, 50, 130, 110);
      side.addColorStop(0, "#9b6a3d");
      side.addColorStop(1, "#4b3020");
      ctx.fillStyle = top;
      ctx.strokeStyle = "#5b3b23";
      ctx.beginPath();
      ctx.moveTo(30, 38);
      ctx.lineTo(116, 27);
      ctx.lineTo(144, 48);
      ctx.lineTo(52, 59);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = side;
      ctx.beginPath();
      ctx.moveTo(52, 59);
      ctx.lineTo(144, 48);
      ctx.lineTo(132, 103);
      ctx.lineTo(44, 105);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.save();
      ctx.globalAlpha = 0.35;
      ctx.strokeStyle = "#f5d6a2";
      ctx.beginPath();
      ctx.moveTo(43, 48);
      ctx.lineTo(117, 39);
      ctx.stroke();
      ctx.restore();
    } else if (kind === "river") {
      const water = ctx.createLinearGradient(20, 15, 145, 110);
      water.addColorStop(0, "#b9f3ff");
      water.addColorStop(0.28, "#2fb8df");
      water.addColorStop(0.62, "#1a73b8");
      water.addColorStop(1, "#0b315e");
      ctx.strokeStyle = water;
      ctx.lineWidth = 20;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(25, 22);
      ctx.bezierCurveTo(145, 35, 23, 73, 143, 105);
      ctx.stroke();
      ctx.strokeStyle = "rgba(255,255,255,.65)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(27, 22);
      ctx.bezierCurveTo(145, 35, 23, 73, 143, 105);
      ctx.stroke();
    } else if (kind === "globe") {
      const sphere = ctx.createRadialGradient(63, 42, 4, 80, 62, 52);
      sphere.addColorStop(0, "#bcecf2");
      sphere.addColorStop(0.36, "#3e9eb7");
      sphere.addColorStop(0.72, "#1e657d");
      sphere.addColorStop(1, "#0a3144");
      ctx.fillStyle = sphere;
      ctx.strokeStyle = "#c8e9d0";
      ctx.beginPath();
      ctx.arc(82, 62, 51, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.save();
      ctx.globalAlpha = 0.62;
      ctx.fillStyle = "#79a969";
      ctx.beginPath();
      ctx.moveTo(57, 35);
      ctx.lineTo(74, 29);
      ctx.lineTo(83, 41);
      ctx.lineTo(76, 50);
      ctx.lineTo(60, 49);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(94, 59);
      ctx.lineTo(119, 50);
      ctx.lineTo(127, 68);
      ctx.lineTo(111, 82);
      ctx.lineTo(99, 78);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = "#d8f4f3";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.ellipse(82, 62, 28, 51, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(31, 62);
      ctx.lineTo(133, 62);
      ctx.stroke();
      ctx.restore();
    } else if (kind === "compass-rose") {
      ctx.fillStyle = "#10202b";
      ctx.strokeStyle = "#e6c463";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(82, 62, 50, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      const rg = ctx.createLinearGradient(65, 16, 99, 108);
      rg.addColorStop(0, "#fff1a4");
      rg.addColorStop(0.48, "#d6a536");
      rg.addColorStop(0.5, "#b93c30");
      rg.addColorStop(1, "#671e1b");
      ctx.fillStyle = rg;
      ctx.beginPath();
      ctx.moveTo(82, 10);
      ctx.lineTo(93, 52);
      ctx.lineTo(134, 62);
      ctx.lineTo(93, 72);
      ctx.lineTo(82, 114);
      ctx.lineTo(71, 72);
      ctx.lineTo(30, 62);
      ctx.lineTo(71, 52);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#f7df87";
      ctx.beginPath();
      ctx.arc(82, 62, 6, 0, Math.PI * 2);
      ctx.fill();
    } else if (kind === "contours") {
      ctx.fillStyle = "rgba(24,75,62,.12)";
      ctx.strokeStyle = "#357965";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.ellipse(82, 62, 64, 45, -0.12, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      for (const [rx, ry, rot] of [
        [51, 34, 0.08],
        [39, 26, -0.08],
        [28, 18, 0.14],
        [16, 10, -0.1],
      ]) {
        ctx.beginPath();
        ctx.ellipse(82, 62, rx, ry, rot, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.fillStyle = "#d7ad35";
      ctx.beginPath();
      ctx.arc(82, 62, 5, 0, Math.PI * 2);
      ctx.fill();
    } else if (kind === "latlon") {
      const sphere = ctx.createRadialGradient(60, 42, 4, 82, 62, 52);
      sphere.addColorStop(0, "#c9f2e8");
      sphere.addColorStop(0.65, "#438b75");
      sphere.addColorStop(1, "#173e37");
      ctx.fillStyle = sphere;
      ctx.strokeStyle = "#e7d27b";
      ctx.beginPath();
      ctx.arc(82, 62, 50, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = "rgba(237,248,225,.75)";
      ctx.lineWidth = 1.8;
      for (const ry of [17, 34]) {
        ctx.beginPath();
        ctx.ellipse(82, 62, 49, ry, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
      for (const rx of [18, 34]) {
        ctx.beginPath();
        ctx.ellipse(82, 62, rx, 49, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
    } else {
      const a = ctx.createLinearGradient(20, 20, 145, 100);
      a.addColorStop(0, "#e7d49a");
      a.addColorStop(0.45, "#b4c88a");
      a.addColorStop(1, "#68895d");
      ctx.fillStyle = a;
      ctx.strokeStyle = "#476146";
      ctx.beginPath();
      ctx.moveTo(18, 28);
      ctx.lineTo(61, 20);
      ctx.lineTo(102, 31);
      ctx.lineTo(146, 19);
      ctx.lineTo(139, 103);
      ctx.lineTo(99, 109);
      ctx.lineTo(58, 98);
      ctx.lineTo(18, 108);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = "rgba(255,255,255,.55)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(61, 20);
      ctx.lineTo(58, 98);
      ctx.moveTo(102, 31);
      ctx.lineTo(99, 109);
      ctx.stroke();
      ctx.strokeStyle = "#2a6b79";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(33, 77);
      ctx.bezierCurveTo(62, 45, 80, 91, 129, 48);
      ctx.stroke();
    }
  } else if (stamp.kind === "arrow") {
    ctx.beginPath();
    ctx.moveTo(10, 70);
    ctx.lineTo(130, 70);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(112, 52);
    ctx.lineTo(140, 70);
    ctx.lineTo(112, 88);
    ctx.stroke();
  }

  ctx.restore();
}
function boardActionBounds(action) {
  if (action.kind === "board-card" || action.kind === "country-card")
    return {
      x: action.x || 0,
      y: action.y || 0,
      width: action.width || 620,
      height: action.height || 414,
    };
  if (action.kind === "stroke") {
    const points = action.points || [];
    if (!points.length) return { x: 0, y: 0, width: 0, height: 0 };
    const xs = points.map((point) => point.x);
    const ys = points.map((point) => point.y);
    return {
      x: Math.min(...xs) - 15,
      y: Math.min(...ys) - 15,
      width: Math.max(...xs) - Math.min(...xs) + 30,
      height: Math.max(...ys) - Math.min(...ys) + 30,
    };
  }
  if (action.kind === "text") {
    const lines = String(action.text || "")
      .split("\n")
      .slice(0, 5);
    const fontSize = Number(action.fontSize || 22);
    const width = Math.min(
      620,
      Math.max(
        230,
        Math.max(...lines.map((line) => line.length), 1) * fontSize * 0.72 + 48,
      ),
    );
    return {
      x: action.x - width,
      y: action.y - 12,
      width,
      height: Math.max(
        62,
        lines.length *
          Math.max(31, fontSize * Number(action.lineHeight || 1.35)) +
          22,
      ),
    };
  }
  const visualScale = Math.max(0.35, Number(action.visualScale || 1));
  return { x: action.x, y: action.y, width: 170 * visualScale, height: 115 * visualScale };
}

function moveBoardAction(action, dx, dy) {
  if (action.kind === "stroke")
    return {
      ...action,
      points: (action.points || []).map((point) => ({
        ...point,
        x: point.x + dx,
        y: point.y + dy,
      })),
    };
  return { ...action, x: action.x + dx, y: action.y + dy };
}

function recentHandwritingStrokes(actions = []) {
  const picked = [];
  for (let index = actions.length - 1; index >= 0; index -= 1) {
    const action = actions[index];
    const isWritingStroke =
      action?.kind === "stroke" &&
      action?.tool === "pen" &&
      Array.isArray(action.points) &&
      action.points.length > 1;
    if (isWritingStroke) {
      picked.unshift(action);
      if (picked.length >= 90) break;
      continue;
    }
    if (picked.length) break;
  }
  return picked;
}

function handwritingSnapshot(strokes = []) {
  const points = strokes.flatMap((stroke) => stroke.points || []);
  if (!points.length) return null;
  const minX = Math.min(...points.map((point) => point.x));
  const minY = Math.min(...points.map((point) => point.y));
  const maxX = Math.max(...points.map((point) => point.x));
  const maxY = Math.max(...points.map((point) => point.y));
  const padding = 34;
  const sourceWidth = Math.max(80, maxX - minX + padding * 2);
  const sourceHeight = Math.max(55, maxY - minY + padding * 2);
  const scale = Math.min(
    3.5,
    Math.max(2, 1100 / Math.max(sourceWidth, sourceHeight)),
  );
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(300, Math.ceil(sourceWidth * scale));
  canvas.height = Math.max(180, Math.ceil(sourceHeight * scale));
  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx) return null;
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.strokeStyle = "#050505";
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  for (const stroke of strokes) {
    const strokePoints = stroke.points || [];
    if (strokePoints.length < 2) continue;
    ctx.lineWidth = Math.max(7, Number(stroke.width || 4) * scale * 1.45);
    ctx.beginPath();
    ctx.moveTo(
      (strokePoints[0].x - minX + padding) * scale,
      (strokePoints[0].y - minY + padding) * scale,
    );
    for (let index = 1; index < strokePoints.length - 1; index += 1) {
      const point = strokePoints[index];
      const next = strokePoints[index + 1];
      const x = (point.x - minX + padding) * scale;
      const y = (point.y - minY + padding) * scale;
      const midX = ((point.x + next.x) / 2 - minX + padding) * scale;
      const midY = ((point.y + next.y) / 2 - minY + padding) * scale;
      ctx.quadraticCurveTo(x, y, midX, midY);
    }
    const last = strokePoints[strokePoints.length - 1];
    ctx.lineTo(
      (last.x - minX + padding) * scale,
      (last.y - minY + padding) * scale,
    );
    ctx.stroke();
  }
  return {
    dataUrl: canvas.toDataURL("image/png"),
    bounds: { minX, minY, maxX, maxY, width: maxX - minX, height: maxY - minY },
    ids: new Set(strokes.map((stroke) => stroke.id)),
  };
}

function drawBoardAction(ctx, action, selected = false) {
  if (action.kind === "board-card" || action.kind === "country-card") return;
  if (action.kind === "stroke") {
    ctx.save();
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.globalAlpha = action.tool === 'highlighter' ? 0.24 : 1;
    ctx.globalCompositeOperation =
      action.tool === "eraser" ? "destination-out" : "source-over";
    ctx.strokeStyle =
      action.tool === "eraser" ? "rgba(0,0,0,1)" : action.color || "#111827";
    const actionWidth = Math.max(1, Number(action.width || 4));
    ctx.lineWidth = action.tool === 'eraser'
      ? Math.max(22, actionWidth)
      : action.tool === 'highlighter'
        ? Math.max(10, actionWidth)
        : actionWidth;
    const points = action.points || [];
    if (points.length === 1) {
      ctx.beginPath();
      ctx.arc(
        points[0].x,
        points[0].y,
        Math.max(1.5, ctx.lineWidth / 2),
        0,
        Math.PI * 2,
      );
      ctx.fillStyle =
        action.tool === "eraser" ? "#000" : action.color || "#111827";
      ctx.fill();
    } else if (points.length > 1) {
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      for (let index = 1; index < points.length - 1; index += 1) {
        const point = points[index];
        const next = points[index + 1];
        ctx.quadraticCurveTo(
          point.x,
          point.y,
          (point.x + next.x) / 2,
          (point.y + next.y) / 2,
        );
      }
      const last = points[points.length - 1];
      ctx.lineTo(last.x, last.y);
      ctx.stroke();
    }
    ctx.restore();
  } else {
    drawStamp(ctx, action);
  }
  if (selected) {
    const bounds = boardActionBounds(action);
    ctx.save();
    ctx.strokeStyle = "#d7ad35";
    ctx.lineWidth = 2;
    ctx.setLineDash([9, 6]);
    ctx.strokeRect(
      bounds.x,
      bounds.y,
      Math.max(20, bounds.width),
      Math.max(20, bounds.height),
    );
    ctx.restore();
  }
}

function boardCardFieldScale(field, value) {
  const length = String(value || "").trim().length;
  const density =
    length > 150
      ? 0.48
      : length > 100
        ? 0.58
        : length > 70
          ? 0.68
          : length > 45
            ? 0.78
            : length > 28
              ? 0.88
              : 1;
  return Math.max(1.7, (Number(field?.size || 24) / 650) * 100 * density);
}


function useAutoFitCardField(value, { min = 7, max = 42 } = {}) {
  const ref = useRef(null);
  useEffect(() => {
    const node = ref.current;
    if (!node) return undefined;
    let frame = 0;
    const fit = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        if (!node.isConnected) return;
        const width = Math.max(1, node.clientWidth);
        const height = Math.max(1, node.clientHeight);
        if (width < 2 || height < 2) return;
        const upper = Math.max(min, Math.min(max, height * 0.72));
        let low = min;
        let high = upper;
        let best = min;
        for (let index = 0; index < 11; index += 1) {
          const size = (low + high) / 2;
          node.style.setProperty("--v7-card-field-font", `${size}px`);
          const fits =
            node.scrollWidth <= width + 1 && node.scrollHeight <= height + 1;
          if (fits) {
            best = size;
            low = size;
          } else {
            high = size;
          }
        }
        node.style.setProperty("--v7-card-field-font", `${best}px`);
        node.dataset.v7CardFit = best.toFixed(1);
      });
    };
    fit();
    const observer =
      typeof ResizeObserver !== "undefined" ? new ResizeObserver(fit) : null;
    observer?.observe(node);
    window.addEventListener("resize", fit, { passive: true });
    return () => {
      cancelAnimationFrame(frame);
      observer?.disconnect();
      window.removeEventListener("resize", fit);
    };
  }, [value, min, max]);
  return ref;
}

function AutoFitCardText({
  value,
  className,
  style,
  min = 7,
  max = 42,
  verticalAlign = "center",
  fieldKey = "",
}) {
  const ref = useAutoFitCardField(value, { min, max });
  return (
    <div
      ref={ref}
      className={className}
      style={style}
      data-v7-card-autofit="true"
      data-v7-card-valign={verticalAlign}
      data-card-field={fieldKey || undefined}
    >
      {value}
    </div>
  );
}

function AutoFitCardTextarea({
  value,
  className,
  style,
  placeholder,
  onChange,
  onPointerDown,
  min = 7,
  max = 36,
  fieldKey = "",
  verticalAlign = "center",
}) {
  const ref = useAutoFitCardField(value || placeholder, { min, max });
  return (
    <textarea
      ref={ref}
      className={className}
      dir="rtl"
      lang="ar"
      spellCheck={true}
      autoCorrect="off"
      autoCapitalize="off"
      inputMode="text"
      wrap="soft"
      value={value}
      placeholder={placeholder}
      style={style}
      onPointerDown={onPointerDown}
      onChange={onChange}
      data-v7-card-autofit="true"
      data-v7-card-valign={verticalAlign}
      data-card-field={fieldKey || undefined}
      aria-label={placeholder}
      title={value || placeholder}
    />
  );
}

function wrapCanvasText(ctx, value, maxWidth) {
  const paragraphs = String(value || "").split(/\n/u);
  const lines = [];
  for (const paragraph of paragraphs) {
    const words = paragraph.trim().split(/\s+/u).filter(Boolean);
    if (!words.length) {
      lines.push("");
      continue;
    }
    let line = "";
    for (const word of words) {
      const candidate = line ? `${line} ${word}` : word;
      if (ctx.measureText(candidate).width <= maxWidth) {
        line = candidate;
        continue;
      }
      if (line) lines.push(line);
      if (ctx.measureText(word).width <= maxWidth) {
        line = word;
        continue;
      }
      let chunk = "";
      for (const char of [...word]) {
        const next = chunk + char;
        if (chunk && ctx.measureText(next).width > maxWidth) {
          lines.push(chunk);
          chunk = char;
        } else {
          chunk = next;
        }
      }
      line = chunk;
    }
    if (line) lines.push(line);
  }
  return lines.length ? lines : [""];
}

function fitCanvasTextBlock(ctx, value, maxWidth, maxHeight, options = {}) {
  const fontFamily = options.fontFamily || "'Noto Naskh Arabic','Amiri',serif";
  const weight = Number(options.weight || 800);
  // Cards have a minimum physical size, so 5px is only an emergency export
  // floor for unusually long text. It is preferable to dropping the text.
  const minSize = Math.max(5, Number(options.minSize || 8));
  const maxSize = Math.max(minSize, Number(options.maxSize || 34));
  const lineHeightRatio = Number(options.lineHeight || 1.18);

  ctx.font = `${weight} ${minSize}px ${fontFamily}`;
  const minimumLines = wrapCanvasText(ctx, value, Math.max(4, maxWidth));
  let best = {
    size: minSize,
    lines: minimumLines,
    lineHeight: minSize * lineHeightRatio,
  };
  let low = minSize;
  let high = maxSize;
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const size = (low + high) / 2;
    ctx.font = `${weight} ${size}px ${fontFamily}`;
    const lines = wrapCanvasText(ctx, value, Math.max(4, maxWidth));
    const lineHeight = size * lineHeightRatio;
    const tallest = lines.length * lineHeight;
    const widest = lines.reduce(
      (current, line) => Math.max(current, ctx.measureText(line).width),
      0,
    );
    if (widest <= maxWidth + 0.5 && tallest <= maxHeight + 0.5) {
      best = { size, lines, lineHeight };
      low = size;
    } else {
      high = size;
    }
  }
  ctx.font = `${weight} ${best.size}px ${fontFamily}`;
  const maxLines = Math.max(1, Math.floor(maxHeight / best.lineHeight));
  const lines = best.lines.slice(0, maxLines);
  if (best.lines.length > maxLines && lines.length) {
    const last = lines.length - 1;
    let candidate = String(lines[last] || "").replace(/…$/u, "");
    while (candidate && ctx.measureText(`${candidate}…`).width > maxWidth) {
      candidate = [...candidate].slice(0, -1).join("");
    }
    lines[last] = `${candidate}…`;
  }
  return { ...best, lines };
}

function drawCanvasTextBlock(ctx, value, x, y, width, height, options = {}) {
  const block = fitCanvasTextBlock(ctx, value, width, height, options);
  const totalHeight = block.lines.length * block.lineHeight;
  const verticalAlign = options.verticalAlign || "center";
  const firstY =
    verticalAlign === "start"
      ? y + block.lineHeight / 2
      : verticalAlign === "end"
        ? y + height - totalHeight + block.lineHeight / 2
        : y + (height - totalHeight) / 2 + block.lineHeight / 2;
  ctx.textBaseline = "middle";
  ctx.textAlign = options.align || "center";
  const textX =
    options.align === "right"
      ? x + width
      : options.align === "left"
        ? x
        : x + width / 2;
  block.lines.forEach((line, index) => {
    ctx.fillText(line, textX, firstY + index * block.lineHeight);
  });
  return block;
}

function BoardCardOverlay({ action, selected, onSelect, onChange }) {
  const template = BOARD_CARD_TEMPLATE_MAP[action.templateKey];
  const dragRef = useRef(null);
  const resizeRef = useRef(null);
  if (!template) return null;
  const changeMedia = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () =>
      onChange({ ...action, mediaDataUrl: String(reader.result || "") });
    reader.readAsDataURL(file);
    event.target.value = "";
  };
  const onMoveStart = (event) => {
    if (event.target?.closest?.("textarea,input,button,.board-card-resize-handle")) return;
    if (event.button != null && event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    onSelect(action.id);
    const point = event.touches?.[0] || event;
    dragRef.current = {
      x: point.clientX,
      y: point.clientY,
      startX: action.x,
      startY: action.y,
    };
    const host = event.currentTarget.parentElement?.getBoundingClientRect?.();
    const onMove = (moveEvent) => {
      if (!dragRef.current || !host?.width || !host?.height) return;
      const p = moveEvent.touches?.[0] || moveEvent;
      const dx =
        ((p.clientX - dragRef.current.x) / host.width) * BOARD_CANVAS_WIDTH;
      const dy =
        ((p.clientY - dragRef.current.y) / host.height) * BOARD_CANVAS_HEIGHT;
      onChange({
        ...action,
        x: Math.max(
          0,
          Math.min(
            BOARD_CANVAS_WIDTH - action.width,
            dragRef.current.startX + dx,
          ),
        ),
        y: Math.max(
          0,
          Math.min(
            BOARD_CANVAS_HEIGHT - action.height,
            dragRef.current.startY + dy,
          ),
        ),
      });
    };
    const onEnd = () => {
      dragRef.current = null;
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onEnd);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onEnd, { once: true });
  };
  const onResizeStart = (event) => {
    event.preventDefault();
    event.stopPropagation();
    onSelect(action.id);
    const host =
      event.currentTarget.parentElement?.parentElement?.getBoundingClientRect?.();
    const point = event.touches?.[0] || event;
    resizeRef.current = { x: point.clientX, width: action.width };
    const onMove = (moveEvent) => {
      const p = moveEvent.touches?.[0] || moveEvent;
      if (!resizeRef.current || !host?.width) return;
      const delta =
        ((p.clientX - resizeRef.current.x) / host.width) * BOARD_CANVAS_WIDTH;
      const width = Math.max(
        220,
        Math.min(1050, resizeRef.current.width + delta),
      );
      onChange({ ...action, width, height: width / template.ratio });
    };
    const onEnd = () => {
      resizeRef.current = null;
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onEnd);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onEnd, { once: true });
  };
  return (
    <div
      className={`board-card-overlay ${selected ? "selected" : ""}`}
      data-card-template={template.key}
      style={{
        left: `${(action.x / BOARD_CANVAS_WIDTH) * 100}%`,
        top: `${(action.y / BOARD_CANVAS_HEIGHT) * 100}%`,
        width: `${(action.width / BOARD_CANVAS_WIDTH) * 100}%`,
        aspectRatio: String(template.ratio),
      }}
      onPointerDown={onMoveStart}
      onDoubleClick={(event) => {
        if (event.target?.closest?.("textarea,input,button")) return;
        event.stopPropagation();
        onSelect(action.id);
        event.currentTarget.querySelector("textarea[data-card-field='body']")?.focus();
      }}
    >
      <img
        src={template.asset}
        alt={template.label}
        draggable="false"
        onError={(event) => {
          const fallback = template.assetFallback;
          if (fallback && !event.currentTarget.src.endsWith(fallback))
            event.currentTarget.src = fallback;
        }}
      />
      {template.imageZone && action.mediaDataUrl && (
        <img
          className="board-card-user-media"
          src={action.mediaDataUrl}
          alt=""
          draggable="false"
          style={{
            left: `${template.imageZone.x}%`,
            top: `${template.imageZone.y}%`,
            width: `${template.imageZone.w}%`,
            height: `${template.imageZone.h}%`,
            borderRadius: `${template.imageZone.radius || 8}%`,
          }}
        />
      )}
      {template.fields.map((field) => {
        const value = String(action.fields?.[field.key] || "");
        const replacementField = Boolean(field.replacePrintedLabel);
        const style = {
          left: `${field.x}%`, top: `${field.y}%`,
          width: `${field.w}%`, height: `${field.h}%`,
        };
        const fieldClass = `board-card-field tone-${field.tone || "ink"} ${value ? "has-value" : "placeholder"} ${replacementField ? "replace-printed-label" : ""} ${value || selected ? "" : "empty-mask"}`;
        if (selected) return (
          <AutoFitCardTextarea
            key={field.key}
            fieldKey={field.key}
            value={value}
            placeholder={field.placeholder || field.label}
            verticalAlign={field.verticalAlign || "center"}
            className={`${fieldClass} board-card-field-editor`}
            style={style}
            min={6}
            max={Math.max(16, Number(field.size || 24) * 1.35)}
            onPointerDown={(event) => event.stopPropagation()}
            onChange={(event) => onChange({
              ...action,
              fields: { ...(action.fields || {}), [field.key]: event.target.value },
            })}
          />
        );
        // A text field replaces the image's printed definition INSIDE the same
        // reserved rectangle. When empty the original image remains untouched.
        if (!value) return null;
        return (
          <AutoFitCardText
            key={field.key}
            value={value}
            fieldKey={field.key}
            verticalAlign={field.verticalAlign || "center"}
            className={fieldClass}
            style={style}
            min={6}
            max={Math.max(16, Number(field.size || 24) * 1.35)}
          />
        );
      })}
      {selected && (
        <div
          className="board-card-actions"
          onPointerDown={(event) => event.stopPropagation()}
        >
          <button type="button" onClick={(event) => event.currentTarget.closest(".board-card-overlay")?.querySelector("textarea[data-card-field='body'],textarea[data-card-field='title']")?.focus()}>
            تحرير التعريف داخل البطاقة
          </button>
          {template.imageZone && (
            <label className="board-card-media-button">
              تغيير الصورة
              <input
                type="file"
                accept="image/*"
                hidden
                onChange={changeMedia}
              />
            </label>
          )}
          <span
            className="board-card-resize-handle"
            onPointerDown={onResizeStart}
            role="button"
            aria-label="تغيير حجم البطاقة التعليمية"
            title="تغيير الحجم"
          >
            ↘
          </span>
        </div>
      )}
    </div>
  );
}

async function drawBoardCardToCanvas(ctx, action) {
  const template = BOARD_CARD_TEMPLATE_MAP[action.templateKey];
  if (!template) return;
  const x = Number(action.x || 0);
  const y = Number(action.y || 0);
  const width = Number(action.width || 650);
  const height = Number(action.height || width / template.ratio);
  let frame;
  try {
    frame = await dataUrlToImage(template.asset);
  } catch {
    if (!template.assetFallback) return;
    try {
      frame = await dataUrlToImage(template.assetFallback);
    } catch {
      return;
    }
  }
  ctx.drawImage(frame, x, y, width, height);
  if (template.imageZone && action.mediaDataUrl) {
    try {
      const media = await dataUrlToImage(action.mediaDataUrl);
      const z = template.imageZone;
      const mx = x + (width * z.x) / 100,
        my = y + (height * z.y) / 100,
        mw = (width * z.w) / 100,
        mh = (height * z.h) / 100;
      const scale = Math.max(mw / media.width, mh / media.height);
      const dw = media.width * scale,
        dh = media.height * scale;
      ctx.save();
      ctx.beginPath();
      ctx.rect(mx, my, mw, mh);
      ctx.clip();
      ctx.drawImage(media, mx + (mw - dw) / 2, my + (mh - dh) / 2, dw, dh);
      ctx.restore();
    } catch {
      /* optional media */
    }
  }
  ctx.save();
  ctx.direction = "rtl";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  for (const field of template.fields) {
    const value = String(action.fields?.[field.key] || "").trim();
    const fx = x + (width * (field.x + field.w / 2)) / 100;
    const fy = y + (height * (field.y + field.h / 2)) / 100;
    const fw = (width * field.w) / 100;
    const fh = (height * field.h) / 100;
    const size = Math.max(12, (field.size || 24) * (width / 650));
    if (field.tone === "ink") {
      ctx.fillStyle = "rgba(255,246,220,.82)";
      ctx.fillRect(fx - fw / 2, fy - fh / 2, fw, fh);
      ctx.fillStyle = "#2e1609";
    } else if (field.tone === "brown") {
      ctx.fillStyle = "rgba(115,61,14,.90)";
      ctx.fillRect(fx - fw / 2, fy - fh / 2, fw, fh);
      ctx.fillStyle = "#fff4c8";
    } else if (field.tone === "navy") {
      ctx.fillStyle = "rgba(31,48,72,.94)";
      ctx.fillRect(fx - fw / 2, fy - fh / 2, fw, fh);
      ctx.fillStyle = "#fff3b7";
    } else if (field.tone === "gold") {
      ctx.fillStyle = "rgba(39,26,18,.86)";
      ctx.fillRect(fx - fw / 2, fy - fh / 2, fw, fh);
      ctx.fillStyle = "#ffe68c";
    } else {
      ctx.fillStyle = "rgba(84,43,10,.88)";
      ctx.fillRect(fx - fw / 2, fy - fh / 2, fw, fh);
      ctx.fillStyle = "#fff4c8";
    }
    if (!value) continue;
    drawCanvasTextBlock(
      ctx,
      value,
      fx - fw / 2 + 5,
      fy - fh / 2 + 3,
      Math.max(8, fw - 10),
      Math.max(8, fh - 6),
      {
        maxSize: Math.max(12, size),
        minSize: Math.max(8, Math.min(12, size * 0.42)),
        fontFamily: "'Noto Naskh Arabic','Amiri',serif",
        weight: 800,
        lineHeight: 1.18,
        align: "center",
        verticalAlign: field.verticalAlign || "center",
      },
    );
  }
  ctx.restore();
}

const COUNTRY_CARD_STANDARD_FIELDS = Object.freeze([
  { key: "info1", label: "المعلومة الأولى", x: 44, y: 32.5, w: 48, h: 8.8 },
  { key: "info2", label: "المعلومة الثانية", x: 44, y: 43.0, w: 48, h: 8.8 },
  { key: "info3", label: "المعلومة الثالثة", x: 44, y: 53.5, w: 48, h: 8.8 },
  { key: "info4", label: "المعلومة الرابعة", x: 44, y: 64.0, w: 48, h: 8.8 },
]);
const COUNTRY_CARD_DEFAULT_FIELDS = Object.freeze([
  {
    key: "title",
    label: "اسم الدولة",
    x: 29,
    y: 28,
    w: 43,
    h: 10,
    title: true,
  },
  { key: "info1", label: "المعلومة الأولى", x: 54, y: 47.5, w: 31, h: 8 },
  { key: "info2", label: "المعلومة الثانية", x: 54, y: 57.5, w: 31, h: 8 },
  { key: "info3", label: "المعلومة الثالثة", x: 54, y: 67.5, w: 31, h: 8 },
  { key: "info4", label: "المعلومة الرابعة", x: 54, y: 77.2, w: 31, h: 8 },
  { key: "capital", label: "العاصمة", x: 7, y: 76, w: 35, h: 7 },
  { key: "language", label: "اللغة الرسمية", x: 7, y: 85, w: 35, h: 7 },
]);

function countryCardFields(card) {
  return card?.isDefault
    ? COUNTRY_CARD_DEFAULT_FIELDS
    : COUNTRY_CARD_STANDARD_FIELDS;
}

function countryCardFontSize(action, value, title = false) {
  const width = Number(action.width || 650);
  const base = title ? width * 0.052 : width * 0.036;
  const length = String(value || "").trim().length;
  const shrink =
    length > 42 ? 0.66 : length > 30 ? 0.76 : length > 20 ? 0.86 : 1;
  return Math.max(title ? 16 : 13, Math.min(title ? 38 : 27, base * shrink));
}

const COUNTRY_CARD_FALLBACK_ART = "/whiteboard/country-cards/v8-card-fallback.svg";

function showCountryCardFallback(event) {
  const image = event.currentTarget;
  // A failed fallback must not recurse forever, and must never hide the text.
  if (image.dataset.countryFallback === "1") {
    image.style.display = "none";
    return;
  }
  image.dataset.countryFallback = "1";
  image.src = COUNTRY_CARD_FALLBACK_ART;
}

function CountryCardOverlay({ action, selected, onSelect, onChange }) {
  const card = getCountryCard(action.cardKey, action.countryMeta?.categoryKey || "");
  const dragRef = useRef(null);
  const resizeRef = useRef(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  if (!card) return null;
  const fields = countryCardFields(card);
  const iso = String(card?.iso || action.countryMeta?.iso || '').toUpperCase();
  const educationalFact = card.educationalFact || COUNTRY_FACTS_AR[iso] || '';
  const onMoveStart = (event) => {
    if (
      event.target?.closest?.(
        "textarea,input,button,.country-card-resize-handle",
      )
    )
      return;
    if (event.button != null && event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    onSelect(action.id);
    const point = event.touches?.[0] || event;
    dragRef.current = {
      x: point.clientX,
      y: point.clientY,
      startX: action.x,
      startY: action.y,
    };
    const host = event.currentTarget.parentElement?.getBoundingClientRect?.();
    const onMove = (moveEvent) => {
      if (!dragRef.current || !host?.width || !host?.height) return;
      const p = moveEvent.touches?.[0] || moveEvent;
      const dx =
        ((p.clientX - dragRef.current.x) / host.width) * BOARD_CANVAS_WIDTH;
      const dy =
        ((p.clientY - dragRef.current.y) / host.height) * BOARD_CANVAS_HEIGHT;
      onChange({
        ...action,
        x: Math.max(
          0,
          Math.min(
            BOARD_CANVAS_WIDTH - action.width,
            dragRef.current.startX + dx,
          ),
        ),
        y: Math.max(
          0,
          Math.min(
            BOARD_CANVAS_HEIGHT - action.height,
            dragRef.current.startY + dy,
          ),
        ),
      });
    };
    const onEnd = () => {
      dragRef.current = null;
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onEnd);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onEnd, { once: true });
  };
  const onResizeStart = (event) => {
    event.preventDefault();
    event.stopPropagation();
    onSelect(action.id);
    const host =
      event.currentTarget.parentElement?.parentElement?.getBoundingClientRect?.();
    resizeRef.current = { x: event.clientX, width: action.width };
    const onMove = (moveEvent) => {
      if (!resizeRef.current || !host?.width) return;
      const delta =
        ((moveEvent.clientX - resizeRef.current.x) / host.width) *
        BOARD_CANVAS_WIDTH;
      const width = Math.max(
        240,
        Math.min(1120, resizeRef.current.width + delta),
      );
      onChange({ ...action, width, height: width * 0.75 });
    };
    const onEnd = () => {
      resizeRef.current = null;
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onEnd);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onEnd, { once: true });
  };
  return (
    <div
      className={`board-card-overlay country-card-overlay ${selected ? "selected" : ""}`}
      style={{
        left: `${(action.x / BOARD_CANVAS_WIDTH) * 100}%`,
        top: `${(action.y / BOARD_CANVAS_HEIGHT) * 100}%`,
        width: `${(action.width / BOARD_CANVAS_WIDTH) * 100}%`,
        aspectRatio: "4 / 3",
      }}
      onPointerDown={onMoveStart}
    >
      <img src={card.asset} alt={`قالب بطاقة ${card.name}`} draggable="false" onError={showCountryCardFallback} />
      {!card.isDefault && (
        <AutoFitCardText
          value={card.name}
          className="v8-country-card-title"
          style={{ direction: "rtl" }}
          min={7}
          max={28}
        />
      )}
      {fields.map((field) => {
        const value = String(action.fields?.[field.key] ?? (field.key === 'info3' && !card.isDefault ? educationalFact : ''));
        const style = {
          left: `${field.x}%`,
          top: `${field.y}%`,
          width: `${field.w}%`,
          height: `${field.h}%`,
        };
        const maxFont = field.title ? 42 : 30;
        if (selected)
          return (
            <AutoFitCardTextarea
              key={field.key}
              value={value}
              placeholder={field.label}
              className={`country-card-field-editor ${field.title ? "title" : ""}`}
              style={style}
              min={field.title ? 9 : 7}
              max={maxFont}
              onPointerDown={(event) => event.stopPropagation()}
              onChange={(event) =>
                onChange({
                  ...action,
                  fields: {
                    ...(action.fields || {}),
                    [field.key]: event.target.value,
                  },
                })
              }
            />
          );
        if (!value) return null;
        return (
          <AutoFitCardText
            key={field.key}
            value={value}
            className={`country-card-field-text ${field.title ? "title" : ""}`}
            style={style}
            min={field.title ? 9 : 7}
            max={maxFont}
          />
        );
      })}
      {!card.isDefault && (
        <div className="country-card-meta-strip">
          {[
            ["الدولة", card.name],
            ["العاصمة", card.capital],
            ["الإقليم", card.region],
          ].map(([label, value]) => (
            <span key={label} title={`${label}: ${value}`}>
              {label}: {value}
            </span>
          ))}
        </div>
      )}
      {selected && detailsOpen && (
        <section
          className="country-card-facts-panel"
          dir="rtl"
          aria-label={`معلومات تعليمية عن ${card.name}`}
          onPointerDown={(event) => event.stopPropagation()}
        >
          <strong>{card.isDefault ? (action.fields?.title || "بطاقة دولة") : card.name}</strong>
          <dl>
            <div><dt>العاصمة</dt><dd>{card.isDefault ? (action.fields?.capital || "—") : card.capital}</dd></div>
            <div><dt>الإقليم والقارة</dt><dd>{card.isDefault ? "أدخل بيانات الدولة" : card.region}</dd></div>
            {!card.isDefault && <div className="country-card-fact"><dt>معلومة تعليمية</dt><dd>{action.fields?.info3 || educationalFact}</dd></div>}
          </dl>
          <button type="button" onClick={() => setDetailsOpen(false)}>إغلاق المعلومات</button>
        </section>
      )}
      {selected && (
        <div
          className="country-card-actions"
          onPointerDown={(event) => event.stopPropagation()}
        >
          <strong>{card.name}</strong>
          <button
            type="button"
            className="country-card-info-toggle"
            aria-expanded={detailsOpen}
            onClick={() => setDetailsOpen((current) => !current)}
          >
            {detailsOpen ? "إخفاء المعلومات" : "معلومات الدولة"}
          </button>
          <span
            className="country-card-resize-handle"
            onPointerDown={onResizeStart}
            role="button"
            aria-label="تغيير حجم بطاقة الدولة"
            title="تغيير الحجم"
          >
            ↘
          </span>
        </div>
      )}
    </div>
  );
}

async function drawCountryCardToCanvas(ctx, action) {
  const card = getCountryCard(action.cardKey, action.countryMeta?.categoryKey || "");
  if (!card) return;
  const x = Number(action.x || 0);
  const y = Number(action.y || 0);
  const width = Number(action.width || 690);
  const height = Number(action.height || width * 0.75);
  try {
    const image = await dataUrlToImage(card.asset);
    ctx.drawImage(image, x, y, width, height);
  } catch {
    ctx.save();
    ctx.fillStyle = "#23374a";
    ctx.fillRect(x, y, width, height);
    ctx.strokeStyle = "#d8b366";
    ctx.lineWidth = Math.max(2, width / 140);
    ctx.strokeRect(x + 2, y + 2, width - 4, height - 4);
    ctx.restore();
  }
  ctx.save();
  ctx.direction = "rtl";
  ctx.textBaseline = "middle";
  ctx.fillStyle = "#f8e7b0";
  ctx.shadowColor = "rgba(0,0,0,.78)";
  ctx.shadowBlur = 3;
  const family = "'Noto Naskh Arabic','Amiri','Traditional Arabic',serif";
  if (!card.isDefault && card.name) {
    drawCanvasTextBlock(ctx, card.name, x + width * .45, y + height * .155,
      width * .44, height * .095,
      { maxSize: Math.max(17, width * .048), minSize: 12,
        fontFamily: family, weight: 900, lineHeight: 1.08, align: "center" });
  }
  for (const field of countryCardFields(card)) {
    const iso = String(card?.iso || action.countryMeta?.iso || '').toUpperCase();
    const value = String(action.fields?.[field.key] ?? (field.key === 'info3' && !card.isDefault ? (card.educationalFact || COUNTRY_FACTS_AR[iso] || '') : '')).trim();
    if (!value) continue;
    const fx = x + (width * field.x) / 100;
    const fy = y + (height * field.y) / 100;
    const fw = (width * field.w) / 100;
    const fh = (height * field.h) / 100;
    const requested = countryCardFontSize(action, value, field.title);
    ctx.fillStyle = field.title ? "#ffe7a3" : "#f7e5ad";
    drawCanvasTextBlock(
      ctx,
      value,
      fx + 4,
      fy + 2,
      Math.max(8, fw - 8),
      Math.max(8, fh - 4),
      {
        maxSize: requested,
        minSize: field.title ? 10 : 8,
        fontFamily: family,
        weight: field.title ? 900 : 800,
        lineHeight: 1.12,
        align: field.title ? "center" : "right",
      },
    );
  }
  if (!card.isDefault) {
    const meta = [
      `الدولة: ${card.name}`,
      `العاصمة: ${card.capital}`,
      `اللغة: ${card.language}`,
    ];
    const metaY = y + height * 0.895;
    const segment = width * 0.28;
    const starts = [x + width * 0.11, x + width * 0.39, x + width * 0.67];
    ctx.fillStyle = "#f8e3a7";
    meta.forEach((value, index) => {
      drawCanvasTextBlock(
        ctx,
        value,
        starts[index],
        metaY,
        segment,
        Math.max(12, height * 0.085),
        {
          maxSize: Math.max(11, width * 0.024),
          minSize: 6,
          fontFamily: family,
          weight: 800,
          lineHeight: 1.05,
          align: "center",
        },
      );
    });
  }
  ctx.restore();
}

const LEGACY_BOARD_COORD_WIDTH = 1200;
const LEGACY_BOARD_COORD_HEIGHT = 720;
const BOARD_COORD_WIDTH = BOARD_CANVAS_WIDTH;
const BOARD_COORD_HEIGHT = BOARD_CANVAS_HEIGHT;
const BOARD_COORD_SPACE = "1536x864-v1";
const LEGACY_CANVAS_ACTION_KINDS = new Set([
  "stroke",
  "text",
  "shape",
  "arrow",
  "historical-symbol",
  "geographical-symbol",
]);

function stampBoardCoordinateSpace(action) {
  if (!action || typeof action !== "object") return action;
  if (!LEGACY_CANVAS_ACTION_KINDS.has(action.kind)) return action;
  return { ...action, coordinateSpace: BOARD_COORD_SPACE };
}

function migrateLegacyCanvasAction(action) {
  if (!action || typeof action !== "object") return action;
  if (!LEGACY_CANVAS_ACTION_KINDS.has(action.kind)) return action;
  if (action.coordinateSpace) return action;
  const sx = BOARD_CANVAS_WIDTH / LEGACY_BOARD_COORD_WIDTH;
  const sy = BOARD_CANVAS_HEIGHT / LEGACY_BOARD_COORD_HEIGHT;
  const sw = Math.sqrt(sx * sy);
  if (action.kind === "stroke") {
    return {
      ...action,
      coordinateSpace: BOARD_COORD_SPACE,
      width: Math.max(1, Number(action.width || 4) * sw),
      points: (action.points || []).map((point) => ({
        ...point,
        x: Number(point.x || 0) * sx,
        y: Number(point.y || 0) * sy,
      })),
    };
  }
  return {
    ...action,
    coordinateSpace: BOARD_COORD_SPACE,
    x: Number(action.x || 0) * sx,
    y: Number(action.y || 0) * sy,
    fontSize: action.fontSize == null ? action.fontSize : Number(action.fontSize) * sy,
    visualScale: action.kind === "text" ? action.visualScale : Number(action.visualScale || 1) * sw,
    handwritingSourceStrokes: Array.isArray(action.handwritingSourceStrokes)
      ? action.handwritingSourceStrokes.map((stroke) => migrateLegacyCanvasAction(stroke))
      : action.handwritingSourceStrokes,
  };
}

function normalizeBoardLayerActions(actions) {
  return (Array.isArray(actions) ? actions : []).map((action) => migrateLegacyCanvasAction(action));
}

const PROJECT01_WHITEBOARD_ENGINE_V1 = true;

function CanvasOverlay({
  actions,
  onDrawAction,
  onMoveAction,
  onSelectAction,
  selectedActionId,
  template,
  zoom,
  boardRef,
  tool,
  selectedColor,
  strokeWidth,
  shapeKind,
  historicalSymbol,
  geographicalSymbol,
  arrowMode,
  textValue,
  textStyle,
  fontFamily,
  fontSize,
  fontWeight = 700,
  textPreset = "explanation",
  boardReady,
  setBoardReady,
  hasResourceHeader = false,
  onAddCard,
  onAddCountryCard,
}) {
  const shellRef = useRef(null);
  const canvasRef = useRef(null);
  const currentStroke = useRef(null);
  const drawing = useRef(false);
  const moving = useRef(null);
  const actionsRef = useRef(actions);
  const selectedActionIdRef = useRef(selectedActionId);
  actionsRef.current = actions;
  selectedActionIdRef.current = selectedActionId;
  const [textEditor, setTextEditor] = useState(null);
  const [coordinateStageStyle, setCoordinateStageStyle] = useState(null);

  // Keep the real board surface at the same 1536×864 aspect ratio as the
  // approved background. Media annotation remains edge-to-edge. This keeps
  // pointer/card coordinates stable through resize and orientation changes
  // without stretching the board artwork.
  useEffect(() => {
    const shell = shellRef.current;
    if (!shell) return undefined;
    const updateStage = () => {
      const rect = shell.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      if (hasResourceHeader) {
        setCoordinateStageStyle({ left: 0, top: 0, width: rect.width, height: rect.height });
        return;
      }
      const scale = Math.min(
        rect.width / BOARD_CANVAS_WIDTH,
        rect.height / BOARD_CANVAS_HEIGHT,
      );
      const width = Math.max(1, BOARD_CANVAS_WIDTH * scale);
      const height = Math.max(1, BOARD_CANVAS_HEIGHT * scale);
      setCoordinateStageStyle({
        left: (rect.width - width) / 2,
        top: (rect.height - height) / 2,
        width,
        height,
      });
    };
    updateStage();
    const observer = typeof ResizeObserver !== "undefined" ? new ResizeObserver(updateStage) : null;
    observer?.observe(shell);
    globalThis.addEventListener?.("resize", updateStage);
    globalThis.addEventListener?.("orientationchange", updateStage);
    return () => {
      observer?.disconnect();
      globalThis.removeEventListener?.("resize", updateStage);
      globalThis.removeEventListener?.("orientationchange", updateStage);
    };
  }, [hasResourceHeader]);

  // Typing on a board must preserve the teacher's wording and cursor.
  // The dedicated "تصحيح الآن" button below the editor is opt-in.
  const correctTextEditorNow = ({ finish = true } = {}) => {
    setTextEditor((current) => {
      if (!current?.value) return current;
      const correction = correctArabicSentence(current.value, { finish });
      return correction.changed ? { ...current, value: correction.text, autoCorrected: true } : current;
    });
  };

  const render = (preview = null) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.setTransform(canvas.width / BOARD_COORD_WIDTH, 0, 0, canvas.height / BOARD_COORD_HEIGHT, 0, 0);
    actionsRef.current.forEach((action) => drawBoardAction(ctx, action, action.id === selectedActionIdRef.current));
    if (preview) drawBoardAction(ctx, preview, false);
  };

  useEffect(() => {
    render();
  }, [actions, selectedActionId]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return undefined;
    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(2, Math.max(1, Number(globalThis.devicePixelRatio || 1)));
      const nextWidth = Math.max(1, Math.round(rect.width * dpr));
      const nextHeight = Math.max(1, Math.round(rect.height * dpr));
      if (canvas.width !== nextWidth || canvas.height !== nextHeight) {
        canvas.width = nextWidth;
        canvas.height = nextHeight;
      }
      render();
    };
    resizeCanvas();
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(resizeCanvas) : null;
    observer?.observe(canvas);
    globalThis.addEventListener?.('resize', resizeCanvas);
    return () => {
      observer?.disconnect();
      globalThis.removeEventListener?.('resize', resizeCanvas);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const fonts = globalThis.document?.fonts;
    if (!fonts?.ready) return undefined;
    Promise.resolve(fonts.ready)
      .then(() => {
        if (!cancelled) render();
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [fontFamily, actions]);

  useEffect(() => {
    const image = MOBDEA_LOGO_IMAGE;
    if (!image || image.complete) return undefined;
    const onLoad = () => render();
    image.addEventListener("load", onLoad);
    return () => image.removeEventListener("load", onLoad);
  }, [actions, selectedActionId]);

  useEffect(() => {
    if (!boardReady && canvasRef.current) setBoardReady(true);
  }, [boardReady, setBoardReady]);

  const getPoint = (event) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const width = Math.max(1, rect.width);
    const height = Math.max(1, rect.height);
    const x = ((event.clientX - rect.left) / width) * BOARD_COORD_WIDTH;
    const y = ((event.clientY - rect.top) / height) * BOARD_COORD_HEIGHT;
    return {
      x: Math.max(0, Math.min(BOARD_COORD_WIDTH, x)),
      y: Math.max(0, Math.min(BOARD_COORD_HEIGHT, y)),
    };
  };

  const findAction = (point) => {
    for (let index = actions.length - 1; index >= 0; index -= 1) {
      const bounds = boardActionBounds(actions[index]);
      if (
        point.x >= bounds.x &&
        point.x <= bounds.x + Math.max(20, bounds.width) &&
        point.y >= bounds.y &&
        point.y <= bounds.y + Math.max(20, bounds.height)
      )
        return actions[index];
    }
    return null;
  };

  const onPointerDown = (event) => {
    if (!canvasRef.current) return;
    event.preventDefault();
    try {
      event.currentTarget?.setPointerCapture?.(event.pointerId);
    } catch {
      /* Pointer capture is optional. */
    }
    const point = getPoint(event);
    if (tool === "select" || tool === "move") {
      const action = findAction(point);
      onSelectAction(action?.id || null);
      if (tool === "move" && action) moving.current = { action, start: point };
      return;
    }
    if (tool === "text") {
      setTextEditor({ x: point.x, y: point.y, value: String(textValue || "") });
      return;
    }
    if (
      tool === "shape" ||
      tool === "arrow" ||
      tool === "historical-symbol" ||
      tool === "geographical-symbol"
    ) {
      onDrawAction({
        kind: tool,
        x: point.x,
        y: point.y,
        text: `سهم ${arrowMode}`,
        shape: shapeKind,
        symbolKind:
          tool === "geographical-symbol"
            ? geographicalSymbol
            : historicalSymbol,
        arrowMode,
        color: selectedColor,
        textStyle,
        fontFamily,
        fontSize,
      });
      return;
    }

    drawing.current = true;
    currentStroke.current = {
      kind: "stroke",
      tool,
      color: selectedColor,
      width: Math.max(1, Number(strokeWidth || 4)),
      points: [
        {
          ...point,
          pressure: Number(event.pressure || 0.5),
          t: Math.max(
            1,
            Math.round(Number(event.timeStamp || performance.now())),
          ),
        },
      ],
    };
  };

  const onPointerMove = (event) => {
    if (moving.current) {
      event.preventDefault();
      const point = getPoint(event);
      onMoveAction(
        moveBoardAction(
          moving.current.action,
          point.x - moving.current.start.x,
          point.y - moving.current.start.y,
        ),
      );
      return;
    }
    if (!drawing.current || !currentStroke.current) return;
    event.preventDefault();
    const nativeEvent = event.nativeEvent || event;
    const samples = nativeEvent.getCoalescedEvents?.() || [nativeEvent];
    for (const sample of samples) {
      const point = getPoint(sample);
      const previous =
        currentStroke.current.points[currentStroke.current.points.length - 1];
      if (!previous) {
        currentStroke.current.points.push({ ...point, pressure: Number(sample.pressure || 0.5), t: Math.max(1, Math.round(Number(sample.timeStamp || performance.now()))) });
        continue;
      }
      const dx = point.x - previous.x;
      const dy = point.y - previous.y;
      const distance = Math.hypot(dx, dy);
      if (distance < 0.8) continue;
      // Tablets can deliver pointer samples in bursts. Interpolate those gaps so
      // pen/highlighter strokes remain continuous over PDF, PPT, images and board.
      const steps = Math.max(1, Math.ceil(distance / 4));
      for (let step = 1; step <= steps; step += 1) {
        currentStroke.current.points.push({
          x: previous.x + (dx * step) / steps,
          y: previous.y + (dy * step) / steps,
          pressure: Number(sample.pressure || 0.5),
          t: Math.max(1, Math.round(Number(sample.timeStamp || performance.now()))),
        });
      }
    }
    render(currentStroke.current);
  };

  const onPointerUp = (event) => {
    try {
      event?.currentTarget?.releasePointerCapture?.(event.pointerId);
    } catch {
      /* Pointer capture may already be released. */
    }
    if (moving.current) {
      moving.current = null;
      return;
    }
    if (drawing.current && currentStroke.current)
      onDrawAction(currentStroke.current);
    currentStroke.current = null;
    drawing.current = false;
  };

  const commitTextEditor = () => {
    // Keep the exact text, punctuation and line breaks the teacher entered.
    const value = String(textEditor?.value || '');
    if (!value.trim()) {
      setTextEditor(null);
      return;
    }
    onDrawAction({
      kind: "text",
      x: textEditor.x,
      y: textEditor.y,
      text: value,
      autoCorrected: Boolean(textEditor?.autoCorrected),
      color: selectedColor,
      textStyle,
      fontFamily,
      fontSize,
      fontWeight,
      lineHeight: BOARD_TEXT_PRESET_MAP[textPreset]?.lineHeight || 1.35,
      textPreset,
    });
    setTextEditor(null);
  };

  return (
    <div
      ref={shellRef}
      className={`class-board-canvas-shell tool-${tool} board-theme-${template} ${hasResourceHeader ? "has-resource-head" : ""}`}
      style={{ "--board-zoom": zoom }}
    >
      <div
        ref={boardRef}
        className={`class-board-coordinate-stage ${hasResourceHeader ? "is-media" : "is-board"}`}
        style={coordinateStageStyle || undefined}
        onDragOver={(event) => {
        const types = event.dataTransfer?.types || [];
        if (
          types.includes("application/x-mobdea-board-card") ||
          types.includes("application/x-mobdea-country-card")
        )
          event.preventDefault();
      }}
      onDrop={(event) => {
        const templateKey = event.dataTransfer?.getData(
          "application/x-mobdea-board-card",
        );
        const countryKey = event.dataTransfer?.getData(
          "application/x-mobdea-country-card",
        );
        if (!templateKey && !countryKey) return;
        event.preventDefault();
        const rect = event.currentTarget.getBoundingClientRect();
        const point = boardPointFromClient(event.clientX, event.clientY, rect, BOARD_CANVAS_WIDTH, BOARD_CANVAS_HEIGHT);
        if (!point) return; // Never persist NaN positions while the board is hidden or resizing.
        if (countryKey && onAddCountryCard) onAddCountryCard(countryKey, point.x, point.y);
        else if (templateKey && onAddCard) onAddCard(templateKey, point.x, point.y);
      }}
    >
      {!hasResourceHeader && template === "history" && (
        <div
          className="classmode-board-identity classmode-board-reference-identity"
          aria-hidden="true"
        >
          <img
            className="classmode-board-reference-image"
            src="/identity/class-board-history-v14.jpg?art=050a3927a7ba"
            alt=""
            onError={(event) => { event.currentTarget.style.display = 'none'; }}
          />
        </div>
      )}
      {!hasResourceHeader && ["geography", "manuscript"].includes(template) && (
        <div className="classmode-board-identity" aria-hidden="true">
          <BoardThemeDecor template={template} />
          <div className="classmode-history-ornament ornament-top" />
          <img
            className="classmode-board-watermark"
            src={identity.logo}
            alt=""
          />
          <div className="classmode-history-ornament ornament-bottom" />
        </div>
      )}
      <canvas
        ref={canvasRef}
        width={BOARD_CANVAS_WIDTH}
        height={BOARD_CANVAS_HEIGHT}
        className="class-board-canvas"
        style={
          hasResourceHeader ||
          ["history", "geography", "manuscript"].includes(template)
            ? undefined
            : { ...boardBackground(template) }
        }
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onPointerLeave={(event) => {
          if (drawing.current) onPointerUp(event);
        }}
      />
      <div className="board-card-layer" aria-label="البطاقات على السبورة">
        {actions
          .filter((action) => action.kind === "board-card")
          .map((action) => (
            <BoardCardOverlay
              key={action.id}
              action={action}
              selected={action.id === selectedActionId}
              onSelect={onSelectAction}
              onChange={onMoveAction}
            />
          ))}
        {actions
          .filter((action) => action.kind === "country-card")
          .map((action) => (
            <CountryCardOverlay
              key={action.id}
              action={action}
              selected={action.id === selectedActionId}
              onSelect={onSelectAction}
              onChange={onMoveAction}
            />
          ))}
      </div>
      {textEditor && (
        <div
          className="classmode-inline-text-editor"
          style={{
            left: `${(textEditor.x / BOARD_CANVAS_WIDTH) * 100}%`,
            top: `${(textEditor.y / BOARD_CANVAS_HEIGHT) * 100}%`,
          }}
          onPointerDown={(event) => event.stopPropagation()}
        >
          <textarea
            autoFocus
            dir="auto"
            lang="ar"
            spellCheck={true}
            autoCorrect="off"
            autoCapitalize="off"
            inputMode="text"
            value={textEditor.value}
            onChange={(event) =>
              setTextEditor((current) => ({
                ...current,
                value: event.target.value,
              }))
            }
            onBlur={() => { /* Keep exactly what the teacher wrote. */ }}
            onKeyDown={(event) => {
              if (event.key === "Escape") setTextEditor(null);
              if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
                event.preventDefault();
                commitTextEditor();
              }
            }}
            placeholder="اكتب هنا…"
            style={{
              fontFamily,
              fontSize: `${Math.max(18, fontSize * 0.72)}px`,
              fontWeight,
            }}
          />
          <div>
            <button type="button" onMouseDown={(event) => event.preventDefault()} onClick={() => correctTextEditorNow({ finish: true })}>
              تصحيح الآن
            </button>
            <button type="button" onClick={commitTextEditor}>
              إضافة
            </button>
            <button type="button" onClick={() => setTextEditor(null)}>
              إلغاء
            </button>
          </div>
        </div>
      )}
      </div>
    </div>
  );
}

const MemoCanvasOverlay = memo(CanvasOverlay, (previous, next) => {
  const stableKeys = [
    'actions', 'selectedActionId', 'template', 'zoom', 'tool', 'selectedColor',
    'strokeWidth', 'shapeKind', 'historicalSymbol', 'geographicalSymbol',
    'arrowMode', 'textValue', 'textStyle', 'fontFamily', 'fontSize',
    'fontWeight', 'textPreset', 'boardReady', 'hasResourceHeader',
  ];
  return stableKeys.every((key) => previous[key] === next[key]);
});

function BoardLessonRibbon({ grade, lesson }) {
  return (
    <div
      className="classmode-board-lesson-ribbon"
      aria-label="بيانات الحصة الحالية"
    >
      <div className="board-ribbon-seal" aria-hidden="true">
        <BookOpen size={24} />
      </div>
      <div className="board-ribbon-stat">
        <span>الصف</span>
        <strong>{grade || "غير محدد"}</strong>
      </div>
      <i className="board-ribbon-divider" />
      <div className="board-ribbon-stat board-ribbon-lesson">
        <span>الدرس</span>
        <strong>{lesson || "حصة جديدة"}</strong>
      </div>
      <i className="board-ribbon-divider" />
      <div className="board-ribbon-teacher">
        <span>
          <strong>{identity.teacherName}</strong>
          <small>{identity.teacherTitle}</small>
        </span>
        <img src={identity.portrait} alt={identity.teacherName} />
      </div>
    </div>
  );
}

const PROJECT12_PAGE_AWARE_CLASSMODE_V1 = true;

const PROJECT13_CLASSMODE_IMAGE_LINKS_V1 = true;

const R20_FIX08_CLASSMODE_OCR_BRIDGE = recognizePageForQuestionsLazy;

export default function ClassMode({data, updateData, navigate, onlineEntry = false}) {
  const PROJECT10_ONLINE_CLASS_V1 = true;
  const sessionList = Array.isArray(data.sessions) ? data.sessions : [];
  const current = sessionList.find((session) => session.current) ||
    sessionList[0] || {
      id: "standalone-class",
      title: "حصة جديدة",
      group: "",
      grade: "",
      time: "",
      current: false,
    };
  const studentList = Array.isArray(data.students) ? data.students : [];
  const students = current.group
    ? studentList.filter((student) => student.group === current.group)
    : studentList;
  const today = todayISO();
  const availableGrades = useMemo(() => getAllLibraryGrades(data), [data]);

  const preferredLesson = useMemo(
    () =>
      (data.contentLibrary || []).find(
        (item) =>
          item.type === "lesson" &&
          String(item.id) === String(data.settings?.classLessonId || ""),
      ) || null,
    [data.contentLibrary, data.settings?.classLessonId],
  );

  const currentGrade = useMemo(() => {
    const normalize = (value) =>
      String(value || "")
        .trim()
        .replace(/\s+/g, " ")
        .toLowerCase();

    const candidates = [
      preferredLesson?.grade,
      data.settings?.libraryGrade,
      current?.grade,
      students[0]?.grade,
      current?.group,
    ].filter(Boolean);

    const exactGrade = availableGrades.find((grade) =>
      candidates.some((candidate) => normalize(candidate) === normalize(grade)),
    );
    if (exactGrade) return exactGrade;

    const embeddedGrade = availableGrades.find((grade) =>
      candidates.some((candidate) => {
        const normalizedCandidate = normalize(candidate);
        const normalizedGrade = normalize(grade);
        return (
          normalizedCandidate.includes(normalizedGrade) ||
          normalizedGrade.includes(normalizedCandidate)
        );
      }),
    );

    return embeddedGrade || preferredLesson?.grade || students[0]?.grade || "";
  }, [
    availableGrades,
    current?.grade,
    current?.group,
    data.settings?.libraryGrade,
    preferredLesson?.grade,
    students,
  ]);
  const lessons = useMemo(
    () => getLessonsForGrade(data, currentGrade),
    [data, currentGrade],
  );
  const [activeLessonId, setActiveLessonId] = useState(
    data.settings?.classLessonId || "",
  );
  const activeLesson = useMemo(
    () =>
      resolveDefaultLesson(
        data,
        currentGrade,
        activeLessonId || data.settings?.classLessonId || "",
      ),
    [data, currentGrade, activeLessonId],
  );
  const resources = useMemo(
    () =>
      getLessonModeResources(
        data,
        currentGrade,
        activeLesson?.id || activeLessonId,
      ),
    [data, currentGrade, activeLesson?.id, activeLessonId],
  );

  const [lastPraise, setLastPraise] = useState("");
  const [boardControlsOpen, setBoardControlsOpen] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(true);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [phraseMenu, setPhraseMenu] = useState("");
  const [points, setPoints] = useState(() =>
    Object.fromEntries(
      students.map((student) => [
        student.id,
        Math.max(0, Number(student.points || 0)),
      ]),
    ),
  );
  const pointsRef = useRef(points);
  useEffect(() => {
    pointsRef.current = points;
  }, [points]);
  const rankedStudents = useMemo(
    () => rankStudentsByPoints(students, points),
    [students, points],
  );
  const [studentSortMode, setStudentSortMode] = useState("points");
  const pointSessionKey = `${current?.id || "standalone-class"}:${today}`;
  // Keep per-lesson earned points separate from lifetime totals. A comparison
  // is shown only when a previous lesson has actual recorded scores.
  const studentProgress = useMemo(
    () => buildClassPointProgress({
      students, livePoints: points,
      sessions: data.classPointSessions,
      sessionKey: pointSessionKey,
      group: current?.group || "",
      grade: currentGrade || current?.grade || "",
    }),
    [students, points, data.classPointSessions, pointSessionKey, current?.group, current?.grade, currentGrade],
  );
  const displayedStudents = useMemo(
    () => studentSortMode === "improved"
      ? rankByClassImprovement(rankedStudents, studentProgress)
      : rankedStudents,
    [rankedStudents, studentSortMode, studentProgress],
  );
  const studentRailColumns = useMemo(
    () => splitStudentRails(displayedStudents),
    [displayedStudents],
  );
  const randomUsedBySideRef = useRef({ right: [], left: [] });
  const [randomPickedStudentId, setRandomPickedStudentId] = useState("");
  // Keep the random cycle scoped to the actual membership of each rail. A
  // changed class or a different split must not inherit the previous group's
  // random-selection history.
  const railMembership = studentRailColumns.map((column) =>
    column.map((student) => String(student.id)).join("|"),
  ).join("//");
  useEffect(() => {
    randomUsedBySideRef.current = { right: [], left: [] };
    setRandomPickedStudentId("");
  }, [current?.id, railMembership]);
  useEffect(() => {
    setPoints((currentPoints) => {
      const next = { ...currentPoints };
      let changed = false;
      // The data store can roll back after a failed write or receive a synced
      // score from another screen. Mirror persisted balances, not just new ids.
      for (const student of students) {
        const saved = Math.max(0, Number(student.points || 0));
        if (next[student.id] === saved) continue;
        next[student.id] = saved;
        changed = true;
      }
      for (const id of Object.keys(next)) {
        if (students.some((student) => String(student.id) === String(id))) continue;
        delete next[id];
        changed = true;
      }
      if (changed) pointsRef.current = next;
      return changed ? next : currentPoints;
    });
  }, [students]);
  const [view, setView] = useState("board");
  const [tool, setTool] = useState("pen");
  const [notes, setNotes] = useState("");
  const [fullscreen, setFullscreen] = useState(false);
  const [stageFocus, setStageFocus] = useState(false);
  const [managementOpen, setManagementOpen] = useState(true);
  const [managementDrawerOpen, setManagementDrawerOpen] = useState(false);
  const [resourceSwitcherOpen, setResourceSwitcherOpen] = useState(false);
  const lastModeResourceRef = useRef(new Map());
  // Independent ClassMode navigation: switches between presentation modes while
  // staying inside the fullscreen lesson. This is deliberately separate from
  // cycleModeResource(), which only switches files of the currently selected type.
  const [classModeNavOpen, setClassModeNavOpen] = useState(false);
  const classModeNavigationRef = useRef(null);
  const R20_MOVABLE_CLASS_DOCK_V1 = true;
  const [classDockPosition, setClassDockPosition] = useState(null);
  const classDockDragRef = useRef(null);
  const classDockDraggedRef = useRef(false);

  const beginClassDockDrag = (event) => {
    if (event.button != null && event.button !== 0) return;
    // Never capture the student's tap or the save button as a drag gesture.
    if (!event.target.closest?.(".classmode-dock-drag-handle")) return;
    const node = event.currentTarget;
    const rect = node.getBoundingClientRect();
    classDockDragRef.current = {
      pointerId: event.pointerId,
      offsetX: event.clientX - rect.left,
      offsetY: event.clientY - rect.top,
      startX: event.clientX,
      startY: event.clientY,
      width: rect.width,
      height: rect.height,
    };
    classDockDraggedRef.current = false;
    try { node.setPointerCapture?.(event.pointerId); } catch { /* optional */ }
  };

  const moveClassDock = (event) => {
    const drag = classDockDragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const distance = Math.hypot(event.clientX - drag.startX, event.clientY - drag.startY);
    if (distance > 4) classDockDraggedRef.current = true;
    if (!classDockDraggedRef.current) return;
    event.preventDefault();
    const maxX = Math.max(4, Number(globalThis.innerWidth || 0) - drag.width - 4);
    const maxY = Math.max(4, Number(globalThis.innerHeight || 0) - drag.height - 4);
    setClassDockPosition({
      x: Math.max(4, Math.min(maxX, event.clientX - drag.offsetX)),
      y: Math.max(4, Math.min(maxY, event.clientY - drag.offsetY)),
    });
  };

  const endClassDockDrag = (event) => {
    const drag = classDockDragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    classDockDragRef.current = null;
    try { event.currentTarget?.releasePointerCapture?.(event.pointerId); } catch { /* optional */ }
    globalThis.setTimeout?.(() => { classDockDraggedRef.current = false; }, 250);
  };

  const suppressClassDockClickAfterDrag = (event) => {
    if (!classDockDraggedRef.current) return;
    event.preventDefault();
    event.stopPropagation();
  };
  const [contentMode, setContentMode] = useState("pdf");
  const [clockTime, setClockTime] = useState(() =>
    new Date().toLocaleTimeString("ar-EG", {
      hour: "2-digit",
      minute: "2-digit",
    }),
  );
  useEffect(() => {
    const timer = setInterval(
      () =>
        setClockTime(
          new Date().toLocaleTimeString("ar-EG", {
            hour: "2-digit",
            minute: "2-digit",
          }),
        ),
      30000,
    );
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    document.documentElement.classList.add("mobdea-classmode-active");
    document.body.classList.add("mobdea-classmode-active");
    void activateClassModeTabletRuntime();
    return () => {
      document.documentElement.classList.remove("mobdea-classmode-active");
      document.body.classList.remove("mobdea-classmode-active");
      deactivateClassModeTabletRuntime();
    };
  }, []);
  const [boardTemplate, setBoardTemplate] = useState("history");
  const [selectedResourceId, setSelectedResourceId] = useState(
    data.settings?.classResourceId || resources[0]?.id || "",
  );
  const [flowIndex, setFlowIndex] = useState(0);
  const [annotationText, setAnnotationText] = useState("");
  const [annotationColor, setAnnotationColor] = useState("#d7ad35");
  const [drawToolWidths, setDrawToolWidths] = useState(() => ({
    pen: 4,
    highlighter: 24,
    eraser: 32,
  }));
  const [annotationMode, setAnnotationMode] = useState("note");
  const [boardActions, setBoardActions] = useState([]);
  const unsavedBoardLayersRef = useRef(new Map());
  const activeBoardLayerRef = useRef(null);
  const skipDraftWriteRef = useRef(false);
  const [redoStack, setRedoStack] = useState([]);
  const [selectedBoardActionId, setSelectedBoardActionId] = useState(null);
  const [recordingActive, setRecordingActive] = useState(false);
  const [recordingWithAudio, setRecordingWithAudio] = useState(true);
  const [recordingBusy, setRecordingBusy] = useState(false);
  const [liveStartRequest, setLiveStartRequest] = useState(0);
  const [boardSyncRevision, setBoardSyncRevision] = useState(0);
  const [pointsSyncRevision, setPointsSyncRevision] = useState(0);
  const onlineEntryHandledRef = useRef(false);
  useEffect(() => {
    setBoardSyncRevision((value) => value + 1);
  }, [boardActions]);

  useEffect(() => {
    setPointsSyncRevision((value) => value + 1);
  }, [points]);

  useEffect(() => {
    if (!onlineEntry || onlineEntryHandledRef.current) return undefined;
    onlineEntryHandledRef.current = true;
    setManagementOpen(true);
    const timer = window.setTimeout(() => setLiveStartRequest(Date.now()), 80);
    return () => window.clearTimeout(timer);
  }, [onlineEntry]);

  const openOnlineClassPanel = () => {
    setManagementOpen(true);
    setLiveStartRequest(Date.now());
  };

  const [recordingPaused, setRecordingPaused] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [recordingBackend, setRecordingBackend] = useState("");
  const [hasPendingNativeRecording, setHasPendingNativeRecording] =
    useState(false);
  const mediaRecorderRef = useRef(null);
  const recordingChunksRef = useRef([]);
  const recordingStartedAtRef = useRef(0);
  const recordingCleanupRef = useRef(() => {});
  const recordingStopResolverRef = useRef(null);
  const recordingStopTimerRef = useRef(null);
  const recordingTimelineRef = useRef([]);
  const recordingBackendRef = useRef("");
  const recordingFinalizedRef = useRef(false);
  const pendingNativeRecordingRef = useRef(null);
  const stopRecordingOnUnmountRef = useRef(() => Promise.resolve());
  const latestDataRef = useRef(data);
  const latestLessonPayloadRef = useRef(null);
  const latestComposeBoardImageRef = useRef(null);
  latestDataRef.current = data;
  useEffect(() => {
    recordingBackendRef.current = recordingBackend;
  }, [recordingBackend]);
  useEffect(() => {
    if (!recordingActive || recordingPaused) return undefined;
    const timer = setInterval(
      () => setRecordingSeconds((value) => value + 1),
      1000,
    );
    return () => clearInterval(timer);
  }, [recordingActive, recordingPaused]);
  const [shapeKind, setShapeKind] = useState("rect");
  const [historicalSymbol, setHistoricalSymbol] = useState("pyramid");
  const [geographicalSymbol, setGeographicalSymbol] = useState("mountain");
  const [arrowMode, setArrowMode] = useState("right");
  const [boardText, setBoardText] = useState("");
  const [textStyle, setTextStyle] = useState("plain");
  const [fontFamily, setFontFamily] = useState("'Noto Naskh Arabic', 'Amiri', serif");
  const [fontSize, setFontSize] = useState(
    BOARD_TEXT_PRESET_MAP.explanation.size,
  );
  const [textPreset, setTextPreset] = useState("explanation");
  const [zoom, setZoom] = useState(1);
  const [mediaZoom, setMediaZoom] = useState(1);
  const resourcePageMemoryRef = useRef(new Map());
  const resourceZoomMemoryRef = useRef(new Map());
  const appliedPreferredResourceRef = useRef("");
  const [boardReady, setBoardReady] = useState(false);
  const PROJECT02_PDF_IMAGE_VIEWER_V1 = true;
  const [boardToolsExpanded, setBoardToolsExpanded] = useState(false);
  const [handwritingBusy, setHandwritingBusy] = useState(false);
  const [cardsDrawerOpen, setCardsDrawerOpen] = useState(false);
  const [cardDrawerSection, setCardDrawerSection] = useState("countries");
  const [countryCategory, setCountryCategory] = useState("arab");
  const [countryCardSearch, setCountryCardSearch] = useState("");
  const [fontReady, setFontReady] = useState(true);
  const [fontLoadFailed, setFontLoadFailed] = useState(false);
  const [fontAvailability, setFontAvailability] = useState(() =>
    Object.fromEntries(boardFontOptions.map((item) => [item.probe, null])),
  );
  const [shareNotice, setShareNotice] = useState("");
  const canvasTool = TEXT_TOOL_STYLES[tool] ? "text" : tool;
  const activeDrawTool = MEDIA_ANNOTATION_TOOL_KEYS.includes(canvasTool) ? canvasTool : "pen";
  const strokeWidth = Number(drawToolWidths[activeDrawTool] || drawToolWidths.pen || 4);
  const strokeSizeOptions = DRAW_TOOL_SIZE_OPTIONS[activeDrawTool] || DRAW_TOOL_SIZE_OPTIONS.pen;
  const updateActiveStrokeWidth = (value) => {
    const next = Number(value);
    if (!Number.isFinite(next)) return;
    setDrawToolWidths((current) => ({ ...current, [activeDrawTool]: next }));
  };
  const activeTextPreset =
    BOARD_TEXT_PRESET_MAP[textPreset] || BOARD_TEXT_PRESET_MAP.explanation;
  const fontWeight = activeTextPreset.weight;
  const activeFontOption =
    boardFontOptions.find((item) => item.value === fontFamily) ||
    { value: 'Tahoma, Arial, sans-serif', probe: 'System', label: 'خط الجهاز العربي — بديل' };

  useEffect(() => {
    if (!shareNotice) return undefined;
    const timer = window.setTimeout(() => setShareNotice(""), 4500);
    return () => window.clearTimeout(timer);
  }, [shareNotice]);

  useEffect(() => {
    let cancelled = false;
    const fonts = globalThis.document?.fonts;
    if (!fonts?.load) {
      setFontAvailability(
        Object.fromEntries(
          boardFontOptions.map((item, index) => [item.probe, index === 0]),
        ),
      );
      return undefined;
    }
    Promise.all(
      boardFontOptions.map(async (item) => {
        const spec = `700 34px "${item.probe}"`;
        const loaded = await isArabicBoardFontAvailable(item.probe);
        return [item.probe, loaded];
      }),
    ).then((entries) => {
      if (!cancelled) setFontAvailability(Object.fromEntries(entries));
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const fonts = globalThis.document?.fonts;
    if (!fonts?.load) return undefined;
    if (activeFontOption.probe === 'System') {
      setFontReady(true);
      setFontLoadFailed(false);
      return undefined;
    }
    const exactFamily = `"${activeFontOption.probe}"`;
    const fontSpec = `${fontWeight} ${fontSize}px ${exactFamily}`;
    setFontReady(false);
    setFontLoadFailed(false);
    Promise.resolve(fonts.load(fontSpec, "المبدع تاريخ وجغرافيا"))
      .then((loadedFaces) => {
        if (cancelled) return;
        const loaded =
          (Array.isArray(loadedFaces) ? loadedFaces.length > 0 : true) &&
          Boolean(fonts.check?.(fontSpec) ?? true);
        setFontReady(loaded);
        setFontLoadFailed(!loaded);
      })
      .catch(() => {
        if (!cancelled) {
          setFontReady(false);
          setFontLoadFailed(true);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [activeFontOption.probe, fontFamily, fontSize, fontWeight]);

  const updateSelectedTextFormatting = (patch) => {
    if (!selectedBoardActionId) return;
    setBoardActions((currentActions) =>
      currentActions.map((action) =>
        action.id === selectedBoardActionId && action.kind === "text"
          ? { ...action, ...patch }
          : action,
      ),
    );
    setRedoStack([]);
  };

  const adjustBoardTextSize = (delta) => {
    const nextSize = Math.max(
      18,
      Math.min(112, Number(fontSize || 46) + Number(delta || 0)),
    );
    setFontSize(nextSize);
    updateSelectedTextFormatting({ fontSize: nextSize, textPreset: "custom" });
    setTextPreset("custom");
  };

  const selectTextPreset = (key) => {
    const preset =
      BOARD_TEXT_PRESET_MAP[key] || BOARD_TEXT_PRESET_MAP.explanation;
    setTextPreset(preset.key);
    setFontSize(preset.size);
    updateSelectedTextFormatting({
      textPreset: preset.key,
      fontSize: preset.size,
      fontWeight: preset.weight,
      lineHeight: preset.lineHeight,
    });
  };

  const selectBoardFont = (value) => {
    setFontFamily(value);
    updateSelectedTextFormatting({ fontFamily: value });
  };

  useEffect(() => {
    if (fontAvailability[activeFontOption.probe] !== false) return;
    const replacement = boardFontOptions.find(
      (item) => fontAvailability[item.probe] === true,
    );
    const fallback = replacement?.value || 'Tahoma, Arial, sans-serif';
    if (fallback === fontFamily) return;
    setFontFamily(fallback);
    updateSelectedTextFormatting({ fontFamily: fallback });
  }, [fontAvailability, activeFontOption.probe, fontFamily]);

  const selectBoardAction = (id) => {
    setSelectedBoardActionId(id);
    if (!id) return;
    const action = boardActions.find((item) => item.id === id);
    if (action?.kind !== "text") return;
    if (action.fontFamily) setFontFamily(action.fontFamily);
    const preset =
      BOARD_TEXT_PRESET_MAP[action.textPreset] ||
      BOARD_TEXT_PRESETS.find((item) => item.size === Number(action.fontSize));
    if (preset) {
      setTextPreset(preset.key);
      setFontSize(preset.size);
    } else if (Number.isFinite(Number(action.fontSize))) {
      setTextPreset("custom");
      setFontSize(Number(action.fontSize));
    }
  };

  useEffect(() => {
    if (!lastPraise) return undefined;
    const timer = window.setTimeout(() => setLastPraise(""), 4200);
    return () => window.clearTimeout(timer);
  }, [lastPraise]);
  const [challengeMode, setChallengeMode] = useState("battle");
  const [challengePickIds, setChallengePickIds] = useState([]);
  const [challengeNotice, setChallengeNotice] = useState("");
  const [onlineGameStartRequest, setOnlineGameStartRequest] = useState(0);
  const boardRef = useRef(null);
  const sceneRef = useRef(null);

  const toggleFullscreen = async () => {
    const node = sceneRef.current;
    const activeElement = document.fullscreenElement || document.webkitFullscreenElement;
    if (fullscreen && !activeElement) {
      setFullscreen(false);
      return;
    }
    if (!node) {
      setFullscreen((value) => !value);
      return;
    }
    try {
      if (!activeElement) {
        const request = node.requestFullscreen || node.webkitRequestFullscreen;
        if (!request) throw new Error("fullscreen-unavailable");
        await request.call(node);
        await reinforceClassModeFullscreen();
      } else {
        const exit = document.exitFullscreen || document.webkitExitFullscreen;
        if (!exit) throw new Error("fullscreen-exit-unavailable");
        await exit.call(document);
      }
    } catch {
      // Fullscreen API unsupported or blocked (some Android WebViews) —
      // keep the CSS overlay as a functional fallback instead of hiding tools.
      setFullscreen((value) => !value);
      await reinforceClassModeFullscreen();
    }
  };

  useEffect(() => {
    const onFullscreenChange = () =>
      setFullscreen(Boolean(document.fullscreenElement || document.webkitFullscreenElement));
    document.addEventListener("fullscreenchange", onFullscreenChange);
    document.addEventListener?.("webkitfullscreenchange", onFullscreenChange);
    return () => {
      document.removeEventListener("fullscreenchange", onFullscreenChange);
      document.removeEventListener?.("webkitfullscreenchange", onFullscreenChange);
    };
  }, []);

  // Close the compact lesson navigation when the teacher touches the stage,
  // without leaving fullscreen or resetting the selected file/page.
  useEffect(() => {
    if (!classModeNavOpen) return undefined;
    const onOutsidePress = (event) => {
      if (!classModeNavigationRef.current?.contains(event.target)) {
        setClassModeNavOpen(false);
      }
    };
    document.addEventListener("pointerdown", onOutsidePress);
    return () => document.removeEventListener("pointerdown", onOutsidePress);
  }, [classModeNavOpen]);

  useEffect(() => {
    const onKeyDown = (event) => {
      if (event.key !== "Escape") return;
      if (classModeNavOpen) {
        setClassModeNavOpen(false);
        return;
      }
      if (stageFocus) setStageFocus(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [classModeNavOpen, stageFocus]);

  const selectedResource = useMemo(
    () =>
      resources.find(
        (item) => String(item.id) === String(selectedResourceId),
      ) ||
      resources[0] ||
      null,
    [resources, selectedResourceId],
  );
  const selectedStorageResource =
    selectedResource?.virtualLessonTextbook ||
    selectedResource?.virtualLessonExams ||
    selectedResource?.virtualLessonRecording
      ? activeLesson
      : selectedResource;
  const selectedResourceType = useMemo(
    () => resourceMediaType(selectedResource),
    [selectedResource],
  );
  const modeResources = useMemo(() => {
    const wantedTypes = modeResourceTypes[contentMode] || [];
    if (!wantedTypes.length) return [];
    return resources.filter((resource) =>
      wantedTypes.includes(resourceMediaType(resource)),
    );
  }, [contentMode, resources]);
  const displayResource = useMemo(() => {
    if (!modeResources.length) return null;
    const selected =
      modeResources.find(
        (resource) => String(resource.id) === String(selectedResourceId),
      ) || modeResources[0];
    return selected ? { ...selected, type: resourceMediaType(selected) } : null;
  }, [modeResources, selectedResourceId]);
  // Remember the teacher's last file in each type; switching types must not
  // silently return to the first PDF/video/image every time.
  useEffect(() => {
    if (displayResource) rememberModeResource(lastModeResourceRef.current, contentMode, displayResource);
  }, [contentMode, displayResource?.id, displayResource?.type]);
  const displayResourceSource = useAssetSource(
    displayResource?.assetId,
    displayResource?.url,
  );
  const displayResourceUrl = displayResourceSource.url;
  const selectedResourceSource = useAssetSource(
    selectedResource?.assetId,
    selectedResource?.url,
  );
  const selectedResourceUrl = selectedResourceSource.url;
  const selectedExamUrl = useAssetUrl(
    displayResource?.examAssetId || selectedResource?.examAssetId,
    displayResource?.examUrl || selectedResource?.examUrl,
  );
  const displayResourceIndex = Math.max(
    0,
    modeResources.findIndex(
      (resource) => String(resource.id) === String(displayResource?.id),
    ),
  );
  const cycleModeResource = (direction) => {
    if (modeResources.length < 2) return;
    const next =
      (displayResourceIndex + direction + modeResources.length) %
      modeResources.length;
    setSelectedResourceId(modeResources[next].id);
    setFlowIndex(0);
  };

  const [classPage, setClassPage] = useState(null);
  useEffect(() => {
    const resourceKey = String(displayResource?.id || selectedResource?.id || "");
    const viewResource = displayResource || selectedResource;
    const rememberedPage = resourceKey
      ? (resourcePageMemoryRef.current.get(resourceKey)
        ?? readResourceState('page', resourceKey, null))
      : null;
    setClassPage(
      clampLessonPage(
        rememberedPage ?? viewResource?.pageStart ?? 1,
        viewResource,
        Infinity,
      ),
    );
    const rememberedZoom = resourceKey
      ? (resourceZoomMemoryRef.current.get(resourceKey)
        ?? readResourceState('zoom', resourceKey, null))
      : null;
    setMediaZoom(
      Number.isFinite(Number(rememberedZoom)) ? Number(rememberedZoom) : 1,
    );
  }, [
    displayResource?.id,
    displayResource?.pageStart,
    displayResource?.pageEnd,
    selectedResource?.id,
    selectedResource?.pageStart,
    selectedResource?.pageEnd,
  ]);
  const relatedQuestions = useMemo(() => {
    const baseBank = [...questionBank, ...(data.customQuestionBank || [])];
    const ids = normalizeTags(
      selectedResource?.relatedQuestionIds ||
        selectedResource?.questionIds ||
        [],
    );
    const byIds = ids.length
      ? ids
          .map((id) =>
            baseBank.find((question) => String(question.id) === String(id)),
          )
          .filter(Boolean)
      : [];
    if (byIds.length) return byIds;
    const lessonId = String(
      activeLesson?.id || selectedResource?.lessonId || "",
    );
    const sourceId = String(
      selectedResource?.sourceResourceId || selectedResource?.id || "",
    );
    const lessonTitle = String(
      activeLesson?.title || selectedResource?.lesson || "",
    ).trim();
    return baseBank.filter((question) => {
      if (lessonId && String(question.lessonId || "") === lessonId) return true;
      if (
        sourceId &&
        [
          question.resourceId,
          question.sourceResourceId,
          question.sourceExamResourceId,
        ].some((value) => String(value || "") === sourceId)
      )
        return true;
      return Boolean(
        selectedResource &&
        question.grade === selectedResource.grade &&
        question.unit === selectedResource.unit &&
        (!lessonTitle || String(question.lesson || "").trim() === lessonTitle),
      );
    });
  }, [
    activeLesson?.id,
    activeLesson?.title,
    data.customQuestionBank,
    selectedResource,
  ]);

  const [project12QuestionScope, setProject12QuestionScope] = useState('page');
  const project12QuestionSets = useMemo(() => buildPageAwareQuestionSets({
    allQuestions: [...questionBank, ...(data.customQuestionBank || [])],
    relatedQuestions,
    resource: selectedResource || {},
    lesson: activeLesson || {},
    page: classPage || selectedResource?.pageStart || 1,
  }), [data.customQuestionBank, relatedQuestions, selectedResource, activeLesson, classPage]);
  const project12GameQuestions = useMemo(
    () => pickPageQuestionScope(project12QuestionSets, project12QuestionScope),
    [project12QuestionSets, project12QuestionScope],
  );
  const pageStateResourceRef = useRef('');
  const zoomStateResourceRef = useRef('');
  useEffect(() => {
    const resourceKey = String(displayResource?.id || selectedResource?.id || "");
    if (pageStateResourceRef.current !== resourceKey) {
      pageStateResourceRef.current = resourceKey;
      return; // old page belongs to the file that was just left
    }
    if (!resourceKey || !Number.isFinite(Number(classPage)) || Number(classPage) < 1) return;
    rememberBoundedViewState(resourcePageMemoryRef.current, resourceKey, Number(classPage));
    writeResourceState('page', resourceKey, Number(classPage));
  }, [displayResource?.id, selectedResource?.id, classPage]);
  useEffect(() => {
    const resourceKey = String(displayResource?.id || selectedResource?.id || "");
    if (zoomStateResourceRef.current !== resourceKey) {
      zoomStateResourceRef.current = resourceKey;
      return; // do not save the previous file's zoom under the next file
    }
    if (!resourceKey) return;
    rememberBoundedViewState(resourceZoomMemoryRef.current, resourceKey, Number(mediaZoom || 1));
    writeResourceState('zoom', resourceKey, Number(mediaZoom || 1));
  }, [displayResource?.id, selectedResource?.id, mediaZoom]);
  useEffect(() => {
    if (!recordingActive) return;
    const entry = {
      atSeconds: recordingSeconds,
      type: "content-change",
      contentMode,
      resourceId: selectedResource?.id || "",
      resourceTitle: selectedResource?.title || "",
      page: classPage || 1,
      createdAt: new Date().toISOString(),
    };
    const previous = recordingTimelineRef.current.at(-1);
    if (
      previous?.contentMode === entry.contentMode &&
      String(previous?.resourceId || "") === String(entry.resourceId) &&
      Number(previous?.page || 0) === Number(entry.page || 0)
    )
      return;
    recordingTimelineRef.current.push(entry);
  }, [
    recordingActive,
    contentMode,
    selectedResource?.id,
    selectedResource?.title,
    classPage,
  ]);
  const nativeRuntime = Boolean(globalThis.Capacitor?.isNativePlatform?.());
  const [webPdfState, setWebPdfState] = useState({
    dataUrl: "",
    pageCount: 0,
    loading: false,
    error: "",
  });
  useEffect(() => {
    setWebPdfState({ dataUrl: "", pageCount: 0, loading: false, error: "" });
  }, [displayResource?.id]);
  // Render once at a classroom-safe resolution. Pinch zoom is a GPU transform and
  // must not trigger an expensive PDF re-render on every gesture frame.
  const pdfRenderWidth = 3000;
  const nativePdfPage = usePdfPage(
    nativeRuntime &&
      contentMode === "pdf" &&
      ["pdf", "textbook"].includes(displayResource?.type)
      ? {
          blob: displayResourceSource.blob,
          url: displayResourceUrl,
          cacheKey:
            displayResource?.assetId ||
            displayResource?.id ||
            displayResourceUrl,
        }
      : null,
    classPage || 1,
    pdfRenderWidth,
  );
  const renderedPdf = nativeRuntime ? nativePdfPage : webPdfState;
  const boardLayerKey =
    contentMode === "board"
      ? `board:${current?.id || "session"}`
      : `${displayResource?.id || selectedResource?.id || "blank"}:${classPage || 1}`;
  const mediaAnnotationMode = Boolean(
    displayResource && ["pdf", "images", "slides"].includes(contentMode),
  );
  const boardToolsAvailable = contentMode === "board" || mediaAnnotationMode;
  const boardToolsVisible = boardToolsAvailable && boardControlsOpen;
  // Switching media/pages must not erase unsaved ink from the previous layer.
  // The in-session cache is independent of persistence: Save writes it to the
  // actual session/resource data, not to a stale React render snapshot.
  useEffect(() => {
    const previousKey = activeBoardLayerRef.current;
    if (previousKey === boardLayerKey) return;
    const saved = contentMode === "board"
      ? current?.boardLayers?.[boardLayerKey] || []
      : selectedStorageResource?.boardLayers?.[boardLayerKey] || [];
    activeBoardLayerRef.current = boardLayerKey;
    skipDraftWriteRef.current = true;
    setBoardActions(normalizeBoardLayerActions(
      unsavedBoardLayersRef.current.has(boardLayerKey)
        ? unsavedBoardLayersRef.current.get(boardLayerKey)
        : saved,
    ));
    setRedoStack([]);
    setSelectedBoardActionId(null);
  }, [boardLayerKey, contentMode, selectedStorageResource?.boardLayers, current?.boardLayers]);
  useEffect(() => {
    if (activeBoardLayerRef.current !== boardLayerKey) return;
    if (skipDraftWriteRef.current) { skipDraftWriteRef.current = false; return; }
    unsavedBoardLayersRef.current.set(boardLayerKey, boardActions.slice(-500));
    while (unsavedBoardLayersRef.current.size > 96) {
      unsavedBoardLayersRef.current.delete(unsavedBoardLayersRef.current.keys().next().value);
    }
  }, [boardActions, boardLayerKey]);
  useEffect(() => {
    if (!renderedPdf.pageCount) return;
    const upperBound = displayResource?.pageEnd
      ? Math.min(Number(displayResource.pageEnd), renderedPdf.pageCount)
      : renderedPdf.pageCount;
    if ((classPage || 1) > upperBound) setClassPage(upperBound);
  }, [classPage, renderedPdf.pageCount, displayResource?.pageEnd]);
  const sessionQueue = useMemo(() => {
    if (activeLesson && resources.length) return resources;
    const pinned = data.settings?.classResourceQueue || [];
    return pinned
      .map(
        (entry) =>
          resources.find((item) => String(item.id) === String(entry.id)) ||
          entry,
      )
      .filter(Boolean);
  }, [activeLesson, data.settings?.classResourceQueue, resources]);
  const sessionQueueIndex = sessionQueue.findIndex(
    (item) => String(item.id) === String(selectedResourceId),
  );
  const goToQueueStep = (direction) => {
    if (!sessionQueue.length) return;
    const base = sessionQueueIndex === -1 ? 0 : sessionQueueIndex;
    const next = (base + direction + sessionQueue.length) % sessionQueue.length;
    const nextResource = sessionQueue[next];
    setSelectedResourceId(nextResource.id);
    setContentMode(resourceContentMode(nextResource));
    setFlowIndex(0);
  };
  // Lesson cards may also be placed over PDF, images and PowerPoint pages.
  const canPlaceLessonCards = contentMode === "board" || Boolean(
    displayResource && ["pdf", "images", "slides"].includes(contentMode),
  );
  // The country library is opened from the viewport, not from the clipped
  // lesson stage. If the user is on maps/video/audio, open the writing board
  // first: placing a country card in an unsupported stage must never fail silently.
  const openCountryCardLibrary = () => {
    if (!canPlaceLessonCards) {
      setContentMode("board");
      setShareNotice("تم فتح السبورة لإضافة بطاقة دولة. يمكن أيضًا وضع البطاقات فوق PDF والصور وPowerPoint.");
    }
    setCardDrawerSection("countries");
    setCardsDrawerOpen(true);
  };
  useEffect(() => {
    if (!canPlaceLessonCards) setCardsDrawerOpen(false);
  }, [canPlaceLessonCards]);
  const switchContentMode = (mode) => {
    if (mode === "board" || mode === "maps" || mode === "games") {
      setContentMode(mode);
      return;
    }
    // Keep the teacher's previous file for each content kind. Resolve exam
    // documents as PDF and never select a file from an unrelated kind.
    const wantedTypes = modeResourceTypes[mode] || [];
    const candidates = resources.filter((item) => wantedTypes.includes(resourceMediaType(item)));
    const rememberedId = typeof lastModeResourceRef === "undefined"
      ? null : lastModeResourceRef.current.get(mode);
    const match = candidates.find((item) => rememberedId != null && String(item.id) === String(rememberedId))
      || candidates.find((item) => String(item.id) === String(selectedResourceId))
      || candidates[0];
    if (match && String(match.id) !== String(selectedResourceId)) {
      setSelectedResourceId(match.id);
    }
    // An empty media category still opens its own empty state, never the
    // previously selected resource masquerading as the requested type.
    setContentMode(mode);
  };
  const classModeNavigationItems = [
    { key: "pdf", label: "PDF", icon: FileText },
    { key: "board", label: "السبورة", icon: PenTool },
    { key: "maps", label: "الخرائط", icon: MapIcon },
    { key: "images", label: "الصور", icon: FileImage },
    { key: "videos", label: "الفيديو", icon: Video },
    { key: "audio", label: "الصوت", icon: Volume2 },
    { key: "slides", label: "PowerPoint", icon: Presentation },
    { key: "games", label: "الألعاب", icon: Gamepad2 },
  ];
  const selectClassModeNavigation = (mode) => {
    switchContentMode(mode);
    setClassModeNavOpen(false);
  };
  const activeClassModeLabel =
    classModeNavigationItems.find(({ key }) => key === contentMode)?.label || "السبورة";
  const flow = useMemo(
    () => normalizeSequence(selectedResource?.sequence),
    [selectedResource],
  );
  const activeFlow = flow[flowIndex] || flow[0] || "preview";
  const resourceAnnotations = useMemo(
    () => (Array.isArray(selectedResource?.annotations) ? selectedResource.annotations : []),
    [selectedResource?.annotations],
  );
  const rememberGameQuestions = async (questionIds) => {
    const ids = (
      Array.isArray(questionIds) ? questionIds : [questionIds]
    ).filter(Boolean);
    if (!ids.length) return;
    await updateData((latest) => ({
      ...latest,
      gameQuestionHistory: appendQuestionHistory(
        latest.gameQuestionHistory || [],
        ids,
        500,
      ),
    }));
  };
  const rememberGameQuestion = (questionId) =>
    rememberGameQuestions([questionId]);
  const onlineGameQuestions = useMemo(
    () =>
      selectQuestionRound(
        relatedQuestions,
        data.gameQuestionHistory || [],
        Math.min(10, relatedQuestions.length || 1),
      ),
    [data.gameQuestionHistory, relatedQuestions],
  );

  const recentRecordings = useMemo(
    () =>
      (data.lessonRecordings || [])
        .slice()
        .sort((left, right) =>
          String(right.createdAt || "").localeCompare(
            String(left.createdAt || ""),
          ),
        )
        .slice(0, 8),
    [data.lessonRecordings],
  );

  const saveSelectedResource = async (patch = {}) => {
    if (!selectedStorageResource) return;
    const normalizedPatch =
      selectedResource?.virtualLessonExams &&
      Object.prototype.hasOwnProperty.call(patch, "annotations")
        ? {
            ...patch,
            examAnnotations: patch.annotations,
            annotations: selectedStorageResource.annotations || [],
          }
        : patch;
    const targetId = selectedStorageResource.id;
    await updateData((latest) => ({
      ...latest,
      contentLibrary: (latest.contentLibrary || []).map((resource) =>
        String(resource.id) === String(targetId)
          ? {
              ...resource,
              ...normalizedPatch,
              updatedAt: new Date().toISOString(),
            }
          : resource,
      ),
    }));
  };

  const selectLesson = async (lessonId) => {
    const lesson =
      lessons.find((item) => String(item.id) === String(lessonId)) || null;
    if (!lesson) return;
    const nextResources = getLessonModeResources(data, currentGrade, lesson.id);
    setActiveLessonId(lesson.id);
    setSelectedResourceId(nextResources[0]?.id || "");
    setContentMode(
      nextResources.some((item) => ["pdf", "textbook"].includes(item.type))
        ? "pdf"
        : "board",
    );
    setFlowIndex(0);
    await updateData((latest) => ({
      ...latest,
      settings: {
        ...latest.settings,
        classLessonId: lesson.id,
        classResourceId: nextResources[0]?.id || "",
      },
    }));
  };

  const saveLessonMapState = useCallback(async (mapState) => {
    const lessonId = activeLesson?.id;
    if (!lessonId) return;
    await updateData((latest) => ({
      ...latest,
      contentLibrary: (latest.contentLibrary || []).map((resource) =>
        String(resource.id) === String(lessonId)
          ? { ...resource, mapState, updatedAt: new Date().toISOString() }
          : resource,
      ),
    }));
  }, [activeLesson?.id, updateData]);

  const composeBoardImage = async () => {
    try {
      await document.fonts?.ready;
    } catch {
      /* Export still works with the declared fallback fonts. */
    }
    const canvas = document.createElement("canvas");
    // Export in the exact logical coordinate space used by the live board/annotation layer.
    // This prevents 1536×864 ink/cards from being squeezed into the old 1200×800 board export.
    canvas.width = BOARD_CANVAS_WIDTH;
    canvas.height = BOARD_CANVAS_HEIGHT;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#f6f0e1";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    if (contentMode === "board") {
      await drawBoardIdentity(ctx, boardTemplate, canvas.width, canvas.height, {
        grade: currentGrade,
        lesson:
          activeLesson?.title || selectedResource?.lesson || current.title,
      });
    }

    const backgroundSource =
      contentMode === "images" && displayResource?.type === "image"
        ? displayResourceUrl
        : contentMode === "pdf" &&
            ["pdf", "textbook"].includes(displayResource?.type)
          ? renderedPdf.dataUrl
          : "";
    if (backgroundSource) {
      try {
        const image = await dataUrlToImage(backgroundSource);
        const ratio = Math.min(
          canvas.width / image.width,
          canvas.height / image.height,
        );
        const drawWidth = image.width * ratio;
        const drawHeight = image.height * ratio;
        ctx.drawImage(
          image,
          (canvas.width - drawWidth) / 2,
          (canvas.height - drawHeight) / 2,
          drawWidth,
          drawHeight,
        );
      } catch {
        // The drawing layer is still exported if the background cannot be decoded.
      }
    }
    // Draw ink on a transparent layer so the eraser removes annotations only;
    // it must never punch transparent holes through the PDF/image/board base.
    const inkCanvas = document.createElement("canvas");
    inkCanvas.width = BOARD_CANVAS_WIDTH;
    inkCanvas.height = BOARD_CANVAS_HEIGHT;
    const inkContext = inkCanvas.getContext("2d");
    boardActions
      .filter((action) => !["board-card", "country-card"].includes(action.kind))
      .forEach((action) => drawBoardAction(inkContext, action, false));
    // Export the editable card overlays from PDF/image/PPT pages as well as
    // from the plain board; they are not ink drawn on the canvas itself.
    if (canPlaceLessonCards) {
      for (const card of boardActions.filter(
        (action) => action.kind === "board-card",
      )) await drawBoardCardToCanvas(inkContext, card);
      for (const card of boardActions.filter(
        (action) => action.kind === "country-card",
      )) await drawCountryCardToCanvas(inkContext, card);
    }
    ctx.drawImage(inkCanvas, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/png");
  };

  const buildLessonPayload = ({ boardImage = "" } = {}) => ({
    kind: "lesson",
    sessionId: current?.id || null,
    sessionTitle: current?.title || "",
    group: current?.group || "",
    grade: currentGrade || "",
    date: today,
    teacher: identity.teacherName,
    lessonId: activeLesson?.id || null,
    title:
      activeLesson?.title || selectedResource?.title || current?.title || "",
    summary:
      notes.trim() || activeLesson?.notes || selectedResource?.notes || "",
    notes: notes.trim() || activeLesson?.notes || selectedResource?.notes || "",
    homework: activeLesson?.homework || "",
    mapState: activeLesson?.mapState || null,
    resource: selectedResource
      ? {
          id: selectedResource.id,
          title: selectedResource.title,
          type: selectedResource.type,
          unit: selectedResource.unit,
          lesson: selectedResource.lesson,
          grade: selectedResource.grade,
          url: selectedResource.url,
          assetId: selectedResource.assetId || "",
          fileName: selectedResource.fileName,
          notes: selectedResource.notes,
          sequence: normalizeSequence(selectedResource.sequence),
          tags: normalizeTags(selectedResource.tags),
          pageStart: selectedResource.pageStart,
          pageEnd: selectedResource.pageEnd,
          currentPage: classPage || 1,
        }
      : null,
    flow: flow.map((step) => step),
    selectedStudentId: selectedStudent?.id || null,
    selectedStudentName: selectedStudent?.name || "",
    attendance: students.map((student) => ({
      studentId: student.id,
      status: attendanceMap[student.id] || "pending",
    })),
    points,
    players: students.map((student) => ({
      id: student.id,
      name: student.name,
      code: student.code,
    })),
    challengeMode,
    challengePlayers: challengePickIds
      .map((id) => {
        const student = students.find((item) => item.id === id);
        return student
          ? { id: student.id, name: student.name, code: student.code }
          : null;
      })
      .filter(Boolean),
    questions: project12GameQuestions.map((question) => ({
      id: question.id,
      text: question.text,
      lesson: question.lesson,
      unit: question.unit,
      type: question.type,
      answer: question.answer,
      options: question.options,
    })),
    boardActions: boardActions.slice(-300),
    resourceAnnotations,
    boardTemplate,
    zoom,
    boardImage,
    storageResourceId: selectedStorageResource?.id || "",
    boardLayerKey,
    contentMode,
    createdAt: new Date().toISOString(),
  });
  latestLessonPayloadRef.current = buildLessonPayload;
  latestComposeBoardImageRef.current = composeBoardImage;

  const persistCurrentBoardLayer = async () => {
    const layer = boardActions.slice(-500);
    if (contentMode !== "board" && selectedResource) {
      const targetId = selectedStorageResource.id;
      await updateData((latest) => ({
        ...latest,
        contentLibrary: (latest.contentLibrary || []).map((resource) =>
          String(resource.id) === String(targetId)
            ? { ...resource, boardLayers: { ...(resource.boardLayers || {}), [boardLayerKey]: layer }, updatedAt: new Date().toISOString() }
            : resource,
        ),
      }));
    } else if (current) {
      const sessionId = current.id;
      await updateData((latest) => ({
        ...latest,
        sessions: (latest.sessions || []).map((session) =>
          session.id === sessionId
            ? {
                ...session,
                boardLayers: {
                  ...(session.boardLayers || {}),
                  [boardLayerKey]: layer,
                },
                updatedAt: new Date().toISOString(),
              }
            : session,
        ),
      }));
    }
    setShareNotice("تم حفظ طبقة الكتابة وربطها بالحصة.");
  };

  // Persist each completed drawing layer after idle, including the plain board.
  // A previous implementation only autosaved PDF/image/PPT, which meant
  // navigating away from ClassMode silently discarded ordinary board writing.
  useEffect(() => {
    if (!activeBoardLayerRef.current || activeBoardLayerRef.current !== boardLayerKey) return undefined;
    if (!unsavedBoardLayersRef.current.has(boardLayerKey)) return undefined;
    const targetResource = mediaAnnotationMode ? selectedStorageResource?.id : null;
    const targetSession = contentMode === 'board' ? current?.id : null;
    if (!targetResource && !targetSession) return undefined;
    const layer = unsavedBoardLayersRef.current.get(boardLayerKey)?.slice(-500) || [];
    const timer = window.setTimeout(() => {
      // Merge into latest data at commit time. Never copy a stale boardLayers map
      // from a React render over annotations from a different page/resource.
      void updateData((latest) => targetResource ? ({
        ...latest,
        contentLibrary: (latest.contentLibrary || []).map((resource) =>
          String(resource.id) === String(targetResource)
            ? { ...resource, boardLayers: { ...(resource.boardLayers || {}), [boardLayerKey]: layer }, updatedAt: new Date().toISOString() }
            : resource,
        ),
      }) : ({
        ...latest,
        sessions: (latest.sessions || []).map((session) =>
          String(session.id) === String(targetSession)
            ? { ...session, boardLayers: { ...(session.boardLayers || {}), [boardLayerKey]: layer }, updatedAt: new Date().toISOString() }
            : session,
        ),
      }));
    }, 550);
    return () => window.clearTimeout(timer);
  }, [
    mediaAnnotationMode, contentMode, selectedStorageResource?.id, current?.id,
    boardLayerKey, boardActions, updateData,
  ]);

  const recordLesson = async ({
    copyLink = false,
    screenRecording = null,
  } = {}) => {
    const boardImage = await (
      latestComposeBoardImageRef.current || composeBoardImage
    )();
    const payload = (latestLessonPayloadRef.current || buildLessonPayload)({
      boardImage,
    });
    const latestData = latestDataRef.current || data;
    let share = { url: "", token: null };
    let shareError = "";
    try {
      share = await buildShareLink("lesson", payload, {
        cloudSync: latestData.settings?.cloudSync,
      });
    } catch (error) {
      shareError = error?.message || "تعذر إنشاء رابط الحصة.";
    }
    const boardAsset = payload.boardImage
      ? await importLegacyDataUrl(payload.boardImage, {
          name: `board-${Date.now()}.png`,
          kind: "board",
        })
      : null;
    const recording = {
      id: Date.now(),
      ...payload,
      boardImage: "",
      boardAssetId: boardAsset?.id || "",
      videoAssetId: screenRecording?.id || "",
      videoFileName: screenRecording?.name || "",
      videoMimeType: screenRecording?.type || "",
      videoSize: Number(screenRecording?.size || 0),
      durationSeconds: Number(screenRecording?.durationSeconds || 0),
      microphoneEnabled: screenRecording?.microphoneEnabled !== false,
      timeline: Array.isArray(screenRecording?.timeline)
        ? screenRecording.timeline.slice(0, 1000)
        : [],
      shareToken: share.token || "",
      shareUrl: share.url || "",
      visibleToStudents: true,
      studentIds: students.map((student) => student.id),
      publishedAt: new Date().toISOString(),
    };
    let droppedRecordings = [];
    try {
      await updateData((latest) => {
        const allRecordings = [recording, ...(latest.lessonRecordings || [])];
        droppedRecordings = allRecordings.slice(120);
        const boardLayer = Array.isArray(payload.boardActions)
          ? payload.boardActions.slice(-500)
          : [];
        const nextSessions = (latest.sessions || []).map((session) =>
          String(session.id) === String(payload.sessionId)
            ? {
                ...session,
                summary: payload.summary,
                updatedAt: new Date().toISOString(),
                recordingId: recording.id,
                recordingShareUrl: share.url || "",
                boardLayers:
                  payload.contentMode !== "board" && payload.resource
                    ? session.boardLayers
                    : {
                        ...(session.boardLayers || {}),
                        [payload.boardLayerKey]: boardLayer,
                      },
              }
            : session,
        );
        const nextContentLibrary =
          payload.contentMode !== "board" && payload.storageResourceId
            ? (latest.contentLibrary || []).map((resource) =>
                String(resource.id) === String(payload.storageResourceId)
                  ? {
                      ...resource,
                      boardLayers: {
                        ...(resource.boardLayers || {}),
                        [payload.boardLayerKey]: boardLayer,
                      },
                      updatedAt: new Date().toISOString(),
                    }
                  : resource,
              )
            : latest.contentLibrary;
        return {
          ...latest,
          contentLibrary: nextContentLibrary,
          sessions: nextSessions,
          lessonRecordings: allRecordings.slice(0, 120),
          settings: {
            ...latest.settings,
            classLessonId: payload.lessonId || "",
            classResourceId: payload.resource?.id || "",
            classResourceTitle: payload.resource?.title || "",
            classResourceType: payload.resource?.type || "",
            classResourceFileName: payload.resource?.fileName || "",
            classResourcePinnedAt: new Date().toISOString(),
          },
        };
      });
    } catch (error) {
      if (boardAsset?.id) await deleteAsset(boardAsset.id).catch(() => {});
      setShareNotice(error?.message || "تعذر حفظ تسجيل الحصة.");
      return null;
    }
    await Promise.all(
      droppedRecordings.flatMap((item) =>
        [item.boardAssetId, item.videoAssetId]
          .filter(Boolean)
          .map((assetId) => deleteAsset(assetId).catch(() => {})),
      ),
    );
    if (copyLink) {
      if (!share.url) setShareNotice(`تم حفظ تسجيل الحصة، لكن ${shareError}`);
      else
        setShareNotice(
          (await copyToClipboard(share.url))
            ? "تم نسخ رابط الطالب بنجاح."
            : "تم تجهيز الرابط لكن تعذر نسخه.",
        );
    } else {
      setShareNotice(
        shareError
          ? `تم حفظ تسجيل الحصة دون رابط: ${shareError}`
          : "تم حفظ تسجيل الحصة والكتابة فوق المورد.",
      );
    }
    return { ...payload, share };
  };

  const buildChallengePayload = () => {
    const picked = challengePickIds
      .map((id) => students.find((student) => student.id === id))
      .filter(Boolean);
    const teamGold = picked.filter((_, index) => index % 2 === 0);
    const teamBlack = picked.filter((_, index) => index % 2 === 1);
    return {
      kind: "game",
      mode: challengeMode,
      roomTitle:
        challengeMode === "teams"
          ? "تحدي الفرق داخل الحصة"
          : "تحدي طالبين داخل الحصة",
      gradeKey: currentGrade?.includes("الرابع")
        ? "4"
        : currentGrade?.includes("الخامس")
          ? "5"
          : currentGrade?.includes("السادس")
            ? "6"
            : currentGrade?.includes("الأول الإعدادي")
              ? "7"
              : currentGrade?.includes("الثاني الإعدادي")
                ? "8"
                : "6",
      grade: currentGrade || current.title,
      unit: selectedResource?.unit || current.title || "",
      focusResourceId: selectedResource?.id || null,
      playerOne: picked[0]?.id || null,
      playerTwo: picked[1]?.id || null,
      playerIds: picked.map((student) => student.id),
      teamGold: teamGold.map((student) => ({
        id: student.id,
        name: student.name,
        code: student.code,
      })),
      teamBlack: teamBlack.map((student) => ({
        id: student.id,
        name: student.name,
        code: student.code,
      })),
      sessionId: current.id,
      sessionTitle: current.title,
      lessonId: activeLesson?.id || null,
      questionIds: project12GameQuestions.map((question) => question.id),
      questionCount: project12GameQuestions.length,
      sourceKind:
        selectedResource?.sourceKind ||
        (selectedResource?.virtualLessonTextbook
          ? "textbook"
          : selectedResource?.virtualLessonExams
            ? "exams"
            : selectedResource?.type || ""),
      sourceFileName:
        selectedResource?.fileName ||
        selectedResource?.sourceExamFileName ||
        "",
    };
  };

  const startClassChallenge = async ({ copyLink = false } = {}) => {
    if (
      !challengePickIds.length ||
      (challengeMode === "battle" && challengePickIds.length < 2)
    ) {
      setChallengeNotice("اختر طالبين على الأقل لبدء التحدي.");
      return;
    }
    try {
      const payload = buildChallengePayload();
      const share = await buildShareLink("game", payload, {
        cloudSync: data.settings?.cloudSync,
      });
      const nextSettings = {
        ...data.settings,
        pendingChallenge: payload,
      };
      await updateData({
        ...data,
        settings: nextSettings,
        gameRooms: [
          {
            id: share.token || `room-${Date.now()}`,
            ...payload,
            inviteCode: share.token || "",
            inviteUrl: share.url,
            status: "open",
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          },
          ...(data.gameRooms || []),
        ].slice(0, 40),
      });
      if (copyLink) {
        setChallengeNotice(
          (await copyToClipboard(share.url))
            ? "تم نسخ رابط التحدي."
            : "تم تجهيز الرابط ولم ينسخ.",
        );
      } else {
        setChallengeNotice("تم تجهيز تحدي الحصة داخل الألعاب.");
        if (typeof navigate === "function") navigate("games");
      }
    } catch (error) {
      setChallengeNotice(error?.message || "تعذر إنشاء تحدي الحصة.");
    }
  };

  const addAnnotation = async () => {
    if (!annotationText.trim() || !selectedResource) return;
    const next = [
      ...resourceAnnotations,
      {
        id: Date.now(),
        text: annotationText.trim(),
        color: annotationColor,
        mode: annotationMode,
        createdAt: new Date().toISOString(),
      },
    ];
    await saveSelectedResource({ annotations: next });
    setAnnotationText("");
  };

  const removeAnnotation = async (id) => {
    if (!selectedResource) return;
    const next = resourceAnnotations.filter((item) => item.id !== id);
    await saveSelectedResource({ annotations: next });
  };

  useEffect(() => {
    const preferredId = String(data.settings?.classLessonId || "");
    if (
      preferredId &&
      lessons.some((lesson) => String(lesson.id) === preferredId)
    ) {
      if (String(activeLessonId) !== preferredId)
        setActiveLessonId(preferredId);
      return;
    }
    if (!activeLesson && lessons.length) {
      setActiveLessonId(lessons[0].id);
      return;
    }
    if (activeLesson && String(activeLessonId) !== String(activeLesson.id))
      setActiveLessonId(activeLesson.id);
  }, [activeLesson, activeLessonId, data.settings?.classLessonId, lessons]);

  useEffect(() => {
    const preferredResourceId = String(data.settings?.classResourceId || "");
    if (
      !preferredResourceId ||
      !resources.some((item) => String(item.id) === preferredResourceId)
    )
      return;
    if (appliedPreferredResourceRef.current === preferredResourceId) return;
    appliedPreferredResourceRef.current = preferredResourceId;
    const preferred = resources.find(
      (item) => String(item.id) === preferredResourceId,
    );
    if (String(selectedResourceId) !== preferredResourceId)
      setSelectedResourceId(preferredResourceId);
    if (!["board", "maps", "games"].includes(contentMode))
      setContentMode(resourceContentMode(preferred));
  }, [
    data.settings?.classResourceId,
    resources,
    selectedResourceId,
    contentMode,
  ]);

  useEffect(() => {
    if (!resources.length) return;
    if (
      !selectedResource ||
      !resources.some((item) => String(item.id) === String(selectedResourceId))
    ) {
      setSelectedResourceId(resources[0].id);
      if (!["board", "maps", "games"].includes(contentMode))
        setContentMode(resourceContentMode(resources[0]));
    }
  }, [resources, selectedResource, selectedResourceId, contentMode]);

  useEffect(() => {
    setFlowIndex(0);
    setNotes(activeLesson?.notes || selectedResource?.notes || "");
  }, [activeLesson?.id, selectedResource?.id]);

  useEffect(() => {
    if (!running) return undefined;
    const timer = setInterval(() => setSeconds((value) => value + 1), 1000);
    return () => clearInterval(timer);
  }, [running]);

  const attendanceMap = useMemo(
    () =>
      Object.fromEntries(
        (Array.isArray(data.attendance) ? data.attendance : [])
          .filter(
            (item) => item.date === today && item.sessionId === current?.id,
          )
          .map((item) => [item.studentId, item.status]),
      ),
    [data.attendance, today, current?.id],
  );

  const counts = useMemo(
    () =>
      Object.values(attendanceMap).reduce((acc, status) => {
        acc[status] = (acc[status] || 0) + 1;
        return acc;
      }, {}),
    [attendanceMap],
  );

  const mark = (student, status) => {
    const session = current;
    updateData((latest) => {
      const existing = (latest.attendance || []).find(
        (item) =>
          item.studentId === student.id &&
          item.date === today &&
          item.sessionId === session?.id,
      );
      const attendance = existing
        ? (latest.attendance || []).map((item) =>
            item.id === existing.id ? { ...item, status } : item,
          )
        : [
            ...(latest.attendance || []),
            {
              id: Date.now() + Math.random(),
              studentId: student.id,
              sessionId: session?.id || null,
              date: today,
              status,
            },
          ];
      const next = { ...latest, attendance };
      return status === "absent"
        ? queueAbsenceNotification(next, student, session, today)
        : next;
    });
  };

  const testTabletArabicAudio = async () => {
    setShareNotice('جارٍ فحص محرك الصوت العربي وتشغيل جملة الاختبار…');
    const diagnostics = await diagnoseArabicVoice();
    const started = await speakClassroomArabic('اختبار الصوت العربي في وضع الحصة. هل تسمع هذه الجملة بوضوح؟', data.settings, 'normal');
    const source = diagnostics.native ? 'Android' : 'المتصفح';
    setShareNotice(started
      ? `بدأ النطق عبر ${source}. تأكد بنفسك أنك سمعت الجملة على التابلت؛ نجاح الكود لا يثبت أن الصوت مسموع.`
      : `تعذر بدء الصوت عبر ${source}. تحقق من مستوى الصوت وتثبيت صوت عربي في إعدادات الجهاز.`);
  };

  const praise = async (student, type) => {
    setSelectedStudent(student);
    const phrase = buildEncouragementPhrase(type, student.name);
    setLastPraise(phrase);
    const spoken = await speakClassroomArabic(
      phrase,
      data.settings,
      ["excellent", "correct", "success"].includes(type) ? "excited" : "normal",
    );
    if (!spoken) {
      setShareNotice(
        "تعذر تشغيل الصوت العربي. فعّل محرك تحويل النص إلى كلام باللغة العربية من إعدادات الجهاز.",
      );
    }
  };

  const savedPhrases = data.settings?.encouragementPhrases || [];
  const phrases = savedPhrases.length
    ? savedPhrases
    : defaultEncouragementPhrases;
  const correctivePhrases = data.settings?.correctivePhrases?.length
    ? data.settings.correctivePhrases
    : defaultCorrectivePhrases;
  const [newPhraseText, setNewPhraseText] = useState("");
  const [newCorrectivePhraseText, setNewCorrectivePhraseText] = useState("");

  const sayPhrase = async (phrase, tone = "excited") => {
    const text = selectedStudent
      ? `${String(phrase).replace(/[.!،,]+$/u, "")} يا ${selectedStudent.name}.`
      : phrase;
    setLastPraise(text);
    setPhraseMenu("");
    const spoken = await speakClassroomArabic(text, data.settings, tone);
    if (!spoken) {
      setShareNotice(
        "الصوت العربي غير جاهز على الجهاز. افتح إعدادات تحويل النص إلى كلام وثبّت صوتًا عربيًا.",
      );
    }
  };

  const savePhrase = async (kind, rawText) => {
    const text = String(rawText || "").trim();
    if (!text) return;
    const key =
      kind === "corrective" ? "correctivePhrases" : "encouragementPhrases";
    const currentPhrases = kind === "corrective" ? correctivePhrases : phrases;
    const next = [...new Set([...currentPhrases, text])];
    await updateData((latest) => ({
      ...latest,
      settings: { ...latest.settings, [key]: next },
    }));
    if (kind === "corrective") setNewCorrectivePhraseText("");
    else setNewPhraseText("");
  };

  const addEncouragementPhrase = async () =>
    savePhrase("positive", newPhraseText);

  const removeEncouragementPhrase = async (index) => {
    await updateData({
      ...data,
      settings: {
        ...data.settings,
        encouragementPhrases: phrases.filter((_, i) => i !== index),
      },
    });
  };

  const adjustPoints = (student, delta) => {
    if (!student?.id || !Number.isFinite(Number(delta))) return;
    const change = Number(delta);
    const studentId = String(student.id);
    // updateData calls its updater synchronously against its latest in-memory
    // snapshot and queues persistence. Never save an outdated render's points.
    void updateData((latest) => {
      const next = withClassPointAward({
        latest, studentId, change, sessionKey: pointSessionKey,
        session: current, today,
        group: current?.group || "",
        grade: currentGrade || current?.grade || "",
      });
      const changed = (next.students || []).find((item) => String(item.id) === studentId);
      if (next !== latest && changed) {
        pointsRef.current = { ...pointsRef.current, [studentId]: Math.max(0, Number(changed.points || 0)) };
        setPoints(pointsRef.current);
      }
      return next;
    }).catch((error) => {
      // App rolls back failed persistence to the last saved snapshot.
      // Do not leave an optimistic score displayed as though it was saved.
      // App.updateData rolls back to its last persisted snapshot on failure.
      // The students-data effect above restores that snapshot. Do NOT reset to
      // the student object captured at click time: rapid awards may have
      // successfully saved in between, and that would hide their valid points.
      setShareNotice(error?.message || 'تعذر حفظ نقاط الطالب؛ راجع الاتصال ثم أعد المحاولة.');
    });
    const phrasePool = change >= 0 ? phrases : correctivePhrases;
    const basePhrase = phrasePool[Math.floor(Math.random() * Math.max(1, phrasePool.length))] ||
      (change >= 0 ? "أحسنت" : "ركز أكثر في الخطوة القادمة");
    const spokenText = `${String(basePhrase).replace(/[.!،,]+$/u, "")} يا ${student.name}.`;
    setSelectedStudent(student);
    setLastPraise(spokenText);
    void speakClassroomArabic(spokenText, data.settings, change >= 0 ? "excited" : "calm").then((spoken) => {
      if (!spoken) setShareNotice("تم تسجيل التنبيه، وتعذر تشغيل الصوت العربي على هذا الجهاز.");
    });
  };

  const randomStudent = async (side = "right") => {
    const selectedSide = side === "left" ? "left" : "right";
    const railIndex = selectedSide === "left" ? 1 : 0;
    const railIds = new Set(studentRailColumns[railIndex].map((student) => String(student.id)));
    const pool = (displayedStudents.length ? displayedStudents : students)
      .filter((student) => railIds.has(String(student.id)));
    if (!pool.length) {
      setShareNotice("لا يوجد طلاب في هذه القائمة.");
      return;
    }
    const draw = drawRandomStudents(
      pool, 1, randomUsedBySideRef.current[selectedSide],
    );
    randomUsedBySideRef.current = {
      ...randomUsedBySideRef.current, [selectedSide]: draw.usedIds,
    };
    const student = draw.selected[0];
    if (!student) return;
    setSelectedStudent(student);
    setRandomPickedStudentId(String(student.id));
    const phrase = `تم اختيار الطالب ${student.name} من القائمة ${selectedSide === "left" ? "اليسرى" : "اليمنى"}.`;
    setLastPraise(phrase);
    setShareNotice(phrase + (draw.cycleReset ? " بدأت دورة اختيار جديدة." : ""));
    const spoken = await speakClassroomArabic(phrase, data.settings, "calm");
    if (!spoken) setShareNotice(phrase + " الصوت العربي غير متاح على هذا الجهاز.");
  };

  const openSelectedDocument = async () => {
    if (!selectedResource) return;
    try {
      setShareNotice("جارٍ تجهيز الملف للفتح…");
      await openResourceDocument(selectedResource, selectedResourceUrl);
      setShareNotice("تم إرسال الملف إلى عارض المستندات على الجهاز.");
    } catch (error) {
      setShareNotice(error?.message || "تعذر فتح الملف على هذا الجهاز.");
    }
  };  const saveBoard = async () => {
    const image = await composeBoardImage();
    const link = document.createElement('a');
    link.download = `شرح-${current?.title || 'الحصة'}-${today}.png`;
    link.href = image;
    link.click();
    setShareNotice('تم حفظ لقطة كاملة تشمل المورد والكتابة فوقه.');
  };

  const saveBoardForStudents = async () => {
    if (!activeLesson?.id) {
      setShareNotice('اختر درسًا أولًا حتى تُحفظ الصورة داخله وتظهر للطلاب.');
      return;
    }
    try {
      const image = await composeBoardImage();
      const asset = await importLegacyDataUrl(image, {
        name: `شرح-${activeLesson.title || current?.title || 'الدرس'}-${Date.now()}.png`,
        kind: 'lesson-image',
      });
      if (!asset?.id) throw new Error('تعذر إنشاء ملف الصورة.');
      const now = new Date().toISOString();
      const record = {
        id: `lesson-image:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`,
        kind: 'lesson-media',
        type: 'image',
        title: `شرح ${activeLesson.title || current?.title || 'الدرس'}`,
        assetId: asset.id,
        fileName: asset.name || 'lesson-image.png',
        mimeType: asset.type || 'image/png',
        fileSize: Number(asset.size || 0),
        lessonId: activeLesson.id,
        parentLessonId: activeLesson.id,
        grade: activeLesson.grade || currentGrade,
        term: activeLesson.term || '',
        unit: activeLesson.unit || '',
        lesson: activeLesson.title || '',
        studentVisible: true,
        source: 'classmode-snapshot',
        page: classPage || 1,
        createdAt: now,
        updatedAt: now,
      };
      await updateData((latest) => ({ ...latest, contentLibrary: [...(latest.contentLibrary || []), record] }));
      setShareNotice('تم حفظ صورة الشرح داخل الدرس، وستظهر للطلاب مع محتوى الدرس.');
    } catch (error) {
      setShareNotice(error?.message || 'تعذر حفظ صورة الشرح للطلاب.');
    }
  };

  const saveLessonState = async () => {
    if (!current) {
      setShareNotice('اختر حصة أولًا قبل حفظ ملخصها.');
      return;
    }
    try {
      await persistCurrentBoardLayer();
      await updateData((latest) => ({
      ...latest,
      sessions: (latest.sessions || []).map((session) => String(session.id) === String(current.id)
        ? { ...session, summary: notes.trim(), updatedAt: new Date().toISOString() }
        : session),
    }));
      setShareNotice('تم حفظ ملخص الحصة وطبقة الكتابة دون تسجيل فيديو.');
    } catch (error) {
      setShareNotice(error?.message || 'تعذر حفظ الحصة. لم يُعلن نجاح الحفظ.');
    }
  };

  const cleanupRecordingResources = () => {
    try {
      recordingCleanupRef.current?.();
    } catch {
      // Recording resources are best-effort cleanup only.
    }
    recordingCleanupRef.current = () => {};
  };

  const saveCapturedRecording = async ({
    blob = null,
    nativePath = "",
    name = "",
    type = "",
    durationSeconds = 0,
  } = {}) => {
    if (recordingFinalizedRef.current) return null;
    recordingFinalizedRef.current = true;
    let asset = null;
    try {
      if (blob?.size) {
        asset = await importAssetBlob(blob, {
          name:
            name || `تسجيل-${current?.title || "الحصة"}-${today}-${Date.now()}`,
          type: type || blob.type || "video/webm",
          kind: "lesson-recording",
        });
      }
      const saved = await recordLesson({
        copyLink: false,
        screenRecording: {
          ...(asset || {}),
          name: asset?.name || name,
          type: asset?.type || type,
          size: asset?.size || blob?.size || 0,
          durationSeconds: Math.max(
            1,
            Number(durationSeconds || recordingSeconds || 1),
          ),
          microphoneEnabled: recordingWithAudio,
          timeline: recordingTimelineRef.current,
        },
      });
      if (!saved) throw new Error("تعذر إضافة التسجيل إلى قائمة التسجيلات.");
      if (nativePath)
        await releaseNativeScreenRecording(nativePath).catch(() => null);
      return asset;
    } catch (error) {
      recordingFinalizedRef.current = false;
      if (asset?.id) await deleteAsset(asset.id).catch(() => null);
      throw error;
    }
  };

  const resetRecordingState = () => {
    setRecordingActive(false);
    setRecordingPaused(false);
    setRecordingBackend("");
    recordingBackendRef.current = "";
    mediaRecorderRef.current = null;
    if (recordingStopTimerRef.current) {
      clearTimeout(recordingStopTimerRef.current);
      recordingStopTimerRef.current = null;
    }
  };

  const stopActiveRecording = async () => {
    const backend = recordingBackendRef.current;
    if (backend === "native") {
      setShareNotice(
        "جارٍ إنهاء تسجيل Android وحفظ الفيديو داخل قائمة التسجيلات…",
      );
      let captured = null;
      try {
        captured = await stopNativeScreenRecording();
        await saveCapturedRecording(captured);
        pendingNativeRecordingRef.current = null;
        setHasPendingNativeRecording(false);
        setShareNotice(
          "تم حفظ فيديو الحصة داخل قائمة التسجيلات بالترتيب الزمني.",
        );
      } catch (error) {
        if (captured?.nativePath) {
          pendingNativeRecordingRef.current = {
            nativePath: captured.nativePath,
            name: captured.name,
            type: captured.type,
            durationSeconds: captured.durationSeconds,
          };
          setHasPendingNativeRecording(true);
          setShareNotice(
            `${error?.message || "تعذر إدخال الفيديو إلى مخزن المنصة."} ملف Android محفوظ مؤقتًا؛ اضغط «إعادة حفظ الفيديو».`,
          );
        } else {
          await saveCapturedRecording({
            durationSeconds: recordingSeconds,
          }).catch(() => null);
          setShareNotice(
            error?.message ||
              "تعذر إخراج ملف فيديو من Android؛ تم حفظ سجل الحصة الزمني فقط.",
          );
        }
      } finally {
        resetRecordingState();
        cleanupRecordingResources();
      }
      return;
    }

    const recorder = mediaRecorderRef.current;
    if (backend === "web" && recorder && recorder.state !== "inactive") {
      setShareNotice("جارٍ إنهاء تسجيل الشاشة وإضافته إلى قائمة التسجيلات…");
      await new Promise((resolve) => {
        recordingStopResolverRef.current = () => {
          if (recordingStopTimerRef.current)
            clearTimeout(recordingStopTimerRef.current);
          recordingStopTimerRef.current = null;
          resolve();
        };
        recordingStopTimerRef.current = setTimeout(resolve, 12000);
        try {
          if (recorder.state === "paused") recorder.resume();
          recorder.requestData?.();
          recorder.stop();
        } catch {
          resolve();
        }
      });
      if (!recordingFinalizedRef.current) {
        try {
          await saveCapturedRecording({ durationSeconds: recordingSeconds });
          setShareNotice(
            "تم حفظ سجل الحصة في قائمة التسجيلات؛ لم يكتمل ملف الفيديو من المتصفح.",
          );
        } finally {
          resetRecordingState();
          cleanupRecordingResources();
        }
      }
      return;
    }

    if (recordingActive || backend === "timeline") {
      try {
        await saveCapturedRecording({ durationSeconds: recordingSeconds });
        setShareNotice("تم حفظ سجل الحصة والسبورة بالترتيب الزمني.");
      } finally {
        resetRecordingState();
        cleanupRecordingResources();
      }
    }
  };

  const retryPendingNativeRecording = async () => {
    const pending = pendingNativeRecordingRef.current;
    if (!pending || recordingBusy) return;
    setRecordingBusy(true);
    setShareNotice(
      "جارٍ إعادة قراءة ملف Android المؤقت وحفظه داخل قائمة التسجيلات…",
    );
    try {
      const captured = await readNativeScreenRecording(pending);
      recordingFinalizedRef.current = false;
      await saveCapturedRecording(captured);
      pendingNativeRecordingRef.current = null;
      setHasPendingNativeRecording(false);
      setShareNotice("تمت إعادة حفظ فيديو الحصة وربطه بالصف والدرس والطلاب.");
    } catch (error) {
      setShareNotice(
        `${error?.message || "تعذرت إعادة حفظ الفيديو."} لم يُحذف ملف Android المؤقت ويمكن المحاولة مرة أخرى.`,
      );
    } finally {
      setRecordingBusy(false);
    }
  };

  const endClass = async () => {
    try {
      await persistCurrentBoardLayer();
      await updateData((latest) => ({
        ...latest,
        sessions: (latest.sessions || []).map((session) => String(session.id) === String(current.id)
          ? { ...session, summary: notes.trim(), updatedAt: new Date().toISOString() }
          : session),
      }));
    } catch (error) {
      setShareNotice(error?.message || 'تعذر حفظ آخر تغييرات الحصة.');
    }
    navigate('dashboard');
  };

  const toggleRecordingPause = async () => {
    const backend = recordingBackendRef.current;
    try {
      if (backend === "native") {
        if (recordingPaused) await resumeNativeScreenRecording();
        else await pauseNativeScreenRecording();
        setRecordingPaused((value) => !value);
        setShareNotice(
          recordingPaused
            ? "تم استكمال تسجيل الحصة."
            : "تم إيقاف تسجيل الحصة مؤقتًا.",
        );
        return;
      }
      const recorder = mediaRecorderRef.current;
      if (backend === "web" && recorder) {
        if (recorder.state === "recording") recorder.pause();
        else if (recorder.state === "paused") recorder.resume();
        return;
      }
      if (backend === "timeline") {
        setRecordingPaused((value) => !value);
        setShareNotice(
          recordingPaused
            ? "تم استكمال تسجيل سير الحصة."
            : "تم إيقاف تسجيل سير الحصة مؤقتًا.",
        );
      }
    } catch (error) {
      setShareNotice(error?.message || "تعذر تغيير حالة التسجيل.");
    }
  };

  const toggleClassRecording = async () => {
    if (recordingBusy) return;
    setRecordingBusy(true);
    try {
      if (recordingActive || recordingBackendRef.current) {
        await stopActiveRecording();
        return;
      }

      setRecordingSeconds(0);
      recordingFinalizedRef.current = false;
      recordingStartedAtRef.current = Date.now();
      recordingTimelineRef.current = [
        {
          atSeconds: 0,
          type: "recording-started",
          contentMode,
          resourceId: selectedResource?.id || "",
          resourceTitle: selectedResource?.title || "",
          page: classPage || 1,
          createdAt: new Date().toISOString(),
        },
      ];

      if (nativeScreenRecordingAvailable()) {
        try {
          await startNativeScreenRecording({
            title: activeLesson?.title || current?.title || "الحصة",
            withAudio: recordingWithAudio,
          });
          recordingBackendRef.current = "native";
          setRecordingBackend("native");
          setRecordingActive(true);
          setRecordingPaused(false);
          setShareNotice(
            recordingWithAudio
              ? "بدأ تسجيل شاشة تطبيق Android وصوت المعلم. اضغط مرة أخرى للإيقاف والحفظ."
              : "بدأ تسجيل شاشة تطبيق Android بدون ميكروفون. اضغط مرة أخرى للإيقاف والحفظ.",
          );
          return;
        } catch (error) {
          setShareNotice(
            error?.message ||
              "تعذر بدء تسجيل Android؛ سيتم استخدام التسجيل البديل.",
          );
        }
      }

      if (navigator.mediaDevices?.getDisplayMedia && globalThis.MediaRecorder) {
        try {
          const displayStream = await navigator.mediaDevices.getDisplayMedia({
            video: {
              width: { ideal: 1280, max: 1280 },
              height: { ideal: 720, max: 720 },
              frameRate: { ideal: 15, max: 18 },
            },
            audio: true,
          });
          let microphoneStream = null;
          if (recordingWithAudio) {
            try {
              microphoneStream = await navigator.mediaDevices.getUserMedia({
                audio: {
                  echoCancellation: true,
                  noiseSuppression: true,
                  autoGainControl: true,
                },
                video: false,
              });
            } catch {
              setShareNotice(
                "بدأ تسجيل الشاشة بدون ميكروفون المعلم؛ اسمح بالميكروفون لتسجيل الصوت.",
              );
            }
          }

          const combinedStream = new MediaStream();
          displayStream
            .getVideoTracks()
            .forEach((track) => combinedStream.addTrack(track));
          const AudioEngine =
            globalThis.AudioContext || globalThis.webkitAudioContext;
          const audioContext = AudioEngine ? new AudioEngine() : null;
          if (audioContext) {
            const mixedDestination =
              audioContext.createMediaStreamDestination();
            for (const stream of [displayStream, microphoneStream].filter(
              Boolean,
            )) {
              if (!stream.getAudioTracks().length) continue;
              audioContext
                .createMediaStreamSource(stream)
                .connect(mixedDestination);
            }
            mixedDestination.stream
              .getAudioTracks()
              .forEach((track) => combinedStream.addTrack(track));
          } else {
            const preferredAudio =
              microphoneStream?.getAudioTracks()?.[0] ||
              displayStream.getAudioTracks()?.[0];
            if (preferredAudio) combinedStream.addTrack(preferredAudio);
          }

          const mimeCandidates = [
            "video/webm;codecs=vp9,opus",
            "video/webm;codecs=vp8,opus",
            "video/webm",
          ];
          const mimeType =
            mimeCandidates.find((candidate) =>
              MediaRecorder.isTypeSupported(candidate),
            ) || "";
          const recorderOptions = {
            videoBitsPerSecond: 320_000,
            audioBitsPerSecond: 64_000,
            ...(mimeType ? { mimeType } : {}),
          };
          const recorder = new MediaRecorder(combinedStream, recorderOptions);
          recordingChunksRef.current = [];
          recorder.ondataavailable = (event) => {
            if (event.data?.size) recordingChunksRef.current.push(event.data);
          };
          recorder.onpause = () => setRecordingPaused(true);
          recorder.onresume = () => setRecordingPaused(false);
          recorder.onerror = () =>
            setShareNotice(
              "حدث خطأ أثناء تسجيل الشاشة؛ سيتم حفظ سجل الحصة المتاح.",
            );
          recorder.onstop = async () => {
            const durationSeconds = Math.max(
              1,
              Math.round((Date.now() - recordingStartedAtRef.current) / 1000),
            );
            if (recordingFinalizedRef.current) {
              recordingChunksRef.current = [];
              cleanupRecordingResources();
              resetRecordingState();
              recordingStopResolverRef.current?.();
              recordingStopResolverRef.current = null;
              return;
            }
            try {
              const blob = recordingChunksRef.current.length
                ? new Blob(recordingChunksRef.current, {
                    type: recorder.mimeType || "video/webm",
                  })
                : null;
              await saveCapturedRecording({
                blob,
                name: `تسجيل-${current?.title || "الحصة"}-${today}-${Date.now()}.webm`,
                type: blob?.type || "video/webm",
                durationSeconds,
              });
              setShareNotice(
                blob?.size
                  ? "تم حفظ فيديو الحصة داخل قائمة التسجيلات بالترتيب الزمني."
                  : "تم حفظ سجل الحصة، لكن لم ينتج ملف فيديو من الجهاز.",
              );
            } catch (error) {
              setShareNotice(error?.message || "تعذر حفظ فيديو الحصة.");
            } finally {
              recordingChunksRef.current = [];
              cleanupRecordingResources();
              resetRecordingState();
              recordingStopResolverRef.current?.();
              recordingStopResolverRef.current = null;
            }
          };
          const stopFromSystem = () => {
            if (recorder.state !== "inactive") recorder.stop();
          };
          displayStream
            .getVideoTracks()[0]
            ?.addEventListener("ended", stopFromSystem, { once: true });
          recordingCleanupRef.current = () => {
            displayStream.getTracks().forEach((track) => track.stop());
            microphoneStream?.getTracks().forEach((track) => track.stop());
            combinedStream.getTracks().forEach((track) => track.stop());
            audioContext?.close?.().catch(() => null);
          };
          recorder.start(1000);
          mediaRecorderRef.current = recorder;
          recordingBackendRef.current = "web";
          setRecordingBackend("web");
          setRecordingActive(true);
          setRecordingPaused(false);
          setShareNotice(
            recordingWithAudio
              ? "بدأ تسجيل شاشة الحصة وصوت المعلم."
              : "بدأ تسجيل شاشة الحصة بدون ميكروفون.",
          );
          return;
        } catch (error) {
          cleanupRecordingResources();
          setShareNotice(
            error?.name === "NotAllowedError"
              ? "لم يتم منح إذن تسجيل الشاشة؛ بدأ حفظ سير الحصة النصي والسبورة."
              : "تعذر تسجيل الشاشة؛ بدأ حفظ سير الحصة النصي والسبورة.",
          );
        }
      }

      recordingBackendRef.current = "timeline";
      setRecordingBackend("timeline");
      setRecordingActive(true);
      setRecordingPaused(false);
      setShareNotice(
        "بدأ تسجيل سير الحصة داخل المنصة. اضغط مرة أخرى للإيقاف والحفظ.",
      );
    } finally {
      setRecordingBusy(false);
    }
  };

  stopRecordingOnUnmountRef.current = stopActiveRecording;

  useEffect(
    () => () => {
      if (recordingBackendRef.current) {
        void stopRecordingOnUnmountRef.current?.();
        return;
      }
      try {
        recordingCleanupRef.current?.();
      } catch {
        // Ignore cleanup failures while unmounting the class screen.
      }
    },
    [],
  );

  const undoBoard = () => {
    setBoardActions((currentActions) => {
      if (!currentActions.length) return currentActions;
      const last = currentActions[currentActions.length - 1];
      setRedoStack((redo) => [last, ...redo]);
      setSelectedBoardActionId(null);
      if (
        last.kind === "text" &&
        Array.isArray(last.handwritingSourceStrokes) &&
        last.handwritingSourceStrokes.length
      ) {
        return [
          ...currentActions.slice(0, -1),
          ...last.handwritingSourceStrokes,
        ];
      }
      return currentActions.slice(0, -1);
    });
  };

  const redoBoard = () => {
    setRedoStack((currentRedo) => {
      if (!currentRedo.length) return currentRedo;
      const [next, ...rest] = currentRedo;
      setBoardActions((currentActions) => {
        if (
          next.kind === "text" &&
          Array.isArray(next.handwritingSourceStrokes) &&
          next.handwritingSourceStrokes.length
        ) {
          const sourceIds = new Set(
            next.handwritingSourceStrokes.map((stroke) => stroke.id),
          );
          return [
            ...currentActions.filter((action) => !sourceIds.has(action.id)),
            next,
          ];
        }
        return [...currentActions, next];
      });
      return rest;
    });
  };

  const clearBoard = () => {
    setBoardActions([]);
    setRedoStack([]);
    setSelectedBoardActionId(null);
  };

  const convertRecentHandwriting = async () => {
    if (handwritingBusy) return;
    const strokes = recentHandwritingStrokes(boardActions);
    if (!strokes.length) {
      setShareNotice(
        "اكتب كلمة أو جملة بالقلم أولًا، ثم اضغط «تصحيح خط اليد».",
      );
      return;
    }
    const snapshot = handwritingSnapshot(strokes);
    if (!snapshot) {
      setShareNotice("تعذر تجهيز الكتابة اليدوية للتحويل.");
      return;
    }
    setHandwritingBusy(true);
    setShareNotice("جارٍ قراءة خط اليد وتنظيمه…");
    try {
      const result = await recognizeHandwritingStrokes(
        strokes,
        snapshot.dataUrl,
        {
          onProgress: (progress) => {
            if (
              progress?.status === "recognizing text" &&
              Number.isFinite(progress.progress)
            ) {
              setShareNotice(
                `جارٍ قراءة خط اليد… ${Math.round(progress.progress * 100)}%`,
              );
            }
          },
        },
      );
      const recognizedText = String(result?.text || "")
        .replace(/\s+/g, " ")
        .trim();
      const sentenceCorrection = correctArabicSentence(recognizedText);
      const text = sentenceCorrection.text;
      const confidence =
        result?.confidence == null ? null : Number(result.confidence);
      if (!text || (Number.isFinite(confidence) && confidence < 22)) {
        setShareNotice(
          "التعرّف لم يكن واضحًا بما يكفي؛ أبقيت خط اليد كما هو حتى لا يضيع كلامك.",
        );
        return;
      }
      const correctedFontSize = Math.max(36, Number(fontSize || 46));
      try {
        await document.fonts?.load?.(
          `${fontWeight} ${correctedFontSize}px ${fontFamily}`,
          text,
        );
      } catch {
        /* keep the declared fallback */
      }
      const nextAction = {
        id: Date.now() + Math.random(),
        kind: "text",
        text,
        x: Math.min(BOARD_CANVAS_WIDTH - 24, snapshot.bounds.maxX),
        y: Math.max(20, snapshot.bounds.minY),
        color: annotationColor,
        fontSize: correctedFontSize,
        fontFamily,
        fontWeight,
        lineHeight: activeTextPreset.lineHeight,
        textPreset,
        textStyle: "plain",
        handwritingConfidence: Number.isFinite(confidence) ? confidence : null,
        autoCorrected: sentenceCorrection.changed,
        coordinateSpace: BOARD_COORD_SPACE,
        handwritingSourceStrokes: strokes.map((stroke) => stampBoardCoordinateSpace({
          ...stroke,
          points: (stroke.points || []).map((point) => ({ ...point })),
        })),
      };
      setBoardActions((current) => [
        ...current.filter((action) => !snapshot.ids.has(action.id)),
        nextAction,
      ]);
      setSelectedBoardActionId(nextAction.id);
      setRedoStack([]);
      setTextStyle("plain");
      setTool("pen");
      const presetLabel = activeTextPreset.label;
      const fontLabel =
        boardFontOptions.find((item) => item.value === fontFamily)?.label ||
        "الخط المختار";
      setShareNotice(
        `تمت قراءة خط اليد${sentenceCorrection.changed ? " وتصحيح الجملة تلقائيًا" : ""} كنمط «${presetLabel}» بخط «${fontLabel}»${Number.isFinite(confidence) ? ` — دقة ${Math.round(confidence)}%` : ""}.`,
      );
    } catch (error) {
      setShareNotice(
        error?.message || "تعذر تحويل خط اليد. أبقيت الكتابة الأصلية كما هي.",
      );
    } finally {
      setHandwritingBusy(false);
    }
  };

  const activateBoardTool = (nextTool) => {
    setTool(nextTool);
    if (TEXT_TOOL_STYLES[nextTool]) setTextStyle(TEXT_TOOL_STYLES[nextTool]);
    else if (nextTool !== "select" && nextTool !== "move")
      setTextStyle("plain");
    if (!["select", "move"].includes(nextTool)) setSelectedBoardActionId(null);
  };

  const activateStyledText = (style) => {
    setTextStyle(style);
    setTool(TEXT_STYLE_TO_TOOL[style] || "normal-text");
    setSelectedBoardActionId(null);
  };

  const addBoardCard = (
    templateKey,
    dropX = BOARD_CANVAS_WIDTH / 2,
    dropY = BOARD_CANVAS_HEIGHT / 2,
  ) => {
    if (!canPlaceLessonCards) return;
    const template = BOARD_CARD_TEMPLATE_MAP[templateKey];
    if (!template) return;
    const width = template.ratio < 1 ? 390 : 650;
    const height = width / template.ratio;
    const fields = Object.fromEntries(
      template.fields.map((field) => [field.key, ""]),
    );
    const next = {
      id: Date.now() + Math.random(),
      kind: "board-card",
      templateKey,
      fields,
      width,
      height,
      x: Math.max(0, Math.min(BOARD_CANVAS_WIDTH - width, dropX - width / 2)),
      y: Math.max(
        0,
        Math.min(BOARD_CANVAS_HEIGHT - height, dropY - height / 2),
      ),
    };
    setBoardActions((current) => [...current, next]);
    setSelectedBoardActionId(next.id);
    setRedoStack([]);
    setTool("pen");
    setTextStyle("plain");
    setCardsDrawerOpen(false);
  };

  const addCountryCard = (
    cardKey,
    dropX = BOARD_CANVAS_WIDTH / 2,
    dropY = BOARD_CANVAS_HEIGHT / 2,
  ) => {
    if (!canPlaceLessonCards) return;
    const card = getCountryCard(cardKey, countryCategory);
    if (!card) return;
    const width = 690;
    const height = width * 0.75;
    const fields = card.isDefault
      ? { info1: "", info2: "", info3: "", info4: "", title: "", capital: "", language: "" }
      : {
          info1: card.capital ? `العاصمة: ${card.capital}` : "",
          info2: card.region ? `الإقليم: ${card.region}` : "",
          info3: card.educationalFact || "",
          info4: card.language ? `اللغة: ${card.language}` : "",
        };
    const next = {
      id: Date.now() + Math.random(),
      kind: "country-card",
      cardKey,
      countryMeta: card.isDefault
        ? null
        : {
            iso: card.iso || "",
            name: card.name || "",
            capital: card.capital || "",
            region: card.region || "",
            fact: card.educationalFact || "",
            language: card.language || "",
            categoryKey: card.category || countryCategory,
          },
      fields,
      width,
      height,
      x: Math.max(0, Math.min(BOARD_CANVAS_WIDTH - width, dropX - width / 2)),
      y: Math.max(
        0,
        Math.min(BOARD_CANVAS_HEIGHT - height, dropY - height / 2),
      ),
    };
    setBoardActions((current) => [...current, next]);
    setSelectedBoardActionId(next.id);
    setRedoStack([]);
    setTool("pen");
    setTextStyle("plain");
    setCardsDrawerOpen(false);
  };

  const handleBoardAction = (action) => {
    const next = stampBoardCoordinateSpace({ ...action, id: Date.now() + Math.random() });
    setBoardActions((currentActions) => [...currentActions, next]);
    setSelectedBoardActionId(
      ["stroke", "text"].includes(action.kind) ? null : next.id,
    );
    setRedoStack([]);
    if (action.kind === "stroke") setTool(action.tool || "pen");
    if (
      ["historical-symbol", "geographical-symbol", "shape", "arrow"].includes(
        action.kind,
      )
    ) {
      setTool("pen");
      setTextStyle("plain");
    }
    if (
      action.kind === "text" &&
      action.textStyle &&
      action.textStyle !== "plain"
    ) {
      setTextStyle("plain");
      setBoardText("");
      setTool("pen");
      setShareNotice("تمت إضافة العنصر، وعادت السبورة إلى القلم للشرح مباشرة.");
    }
  };

  const moveBoardActionHandler = (updated) => {
    setBoardActions((currentActions) =>
      currentActions.map((action) =>
        action.id === updated.id ? updated : action,
      ),
    );
    setRedoStack([]);
  };

  const deleteSelectedBoardAction = () => {
    if (!selectedBoardActionId) return;
    setBoardActions((currentActions) =>
      currentActions.filter((action) => action.id !== selectedBoardActionId),
    );
    setSelectedBoardActionId(null);
    setRedoStack([]);
  };

  useEffect(() => {
    if (view === "students") {
      setView("board");
      setManagementOpen(true);
      if (students.length) setSelectedStudent((chosen) => chosen || students[0]);
    }
  }, [view, students]);

  useEffect(() => {
    if (!students.length) {
      setChallengePickIds([]);
      return;
    }
    setChallengePickIds((currentIds) => {
      const valid = currentIds.filter((id) =>
        students.some((student) => student.id === id),
      );
      if (valid.length) return valid;
      return students
        .slice(0, challengeMode === "teams" ? Math.min(4, students.length) : 2)
        .map((student) => student.id);
    });
  }, [students, challengeMode]);

  if (!current) {
    return (
      <section className="page class-mode-page">
        <div className="panel empty-state">
          <h2>لا توجد حصة حالية</h2>
          <p>حدد الحصة الحالية أولًا من قسم الحصص والمجموعات.</p>
          <button
            className="primary-btn"
            onClick={() => navigate("sessions")}
            type="button"
          >
            فتح الحصص
          </button>
        </div>
      </section>
    );
  }

  const boardStats = [
    { label: "الصف", value: currentGrade || "—" },
    {
      label: "الدرس",
      value:
        activeLesson?.title ||
        selectedResource?.lesson ||
        selectedResource?.title ||
        current.title,
    },
    { label: "خط سير الحصة", value: flowLabels[activeFlow] || activeFlow },
    { label: "التاريخ", value: formatDateAr(today) },
  ];

  const currentCount = students.length;

  return (
    <ClassModeViewport
      className={`page classmode-scene classmode-final-layout classmode-v9-structural ${fullscreen ? "fullscreen presentation-fullscreen stage-focus-mode" : ""} ${!fullscreen && stageFocus ? "stage-focus-mode" : ""} ${managementOpen ? "management-open" : "management-closed"} ${managementDrawerOpen ? "management-drawer-open" : "management-drawer-closed"}`}
      sceneRef={sceneRef}
    >
      <div
        className={`project12-classmode-dock classmode-user-bottom-dock ${classDockPosition ? "is-positioned" : ""}`}
        style={classDockPosition ? { "--class-dock-x": `${classDockPosition.x}px`, "--class-dock-y": `${classDockPosition.y}px` } : undefined}
        onPointerDown={beginClassDockDrag}
        onPointerMove={moveClassDock}
        onPointerUp={endClassDockDrag}
        onPointerCancel={endClassDockDrag}
        onClickCapture={suppressClassDockClickAfterDrag}
        onDoubleClick={() => setClassDockPosition(null)}
        title="اسحب لتحريك أزرار الطلاب والحفظ — ضغط مزدوج لإعادتها لمكانها"
      >
        <button
          type="button"
          className="classmode-dock-drag-handle"
          aria-label="تحريك شريط الطلاب والحفظ"
          title="اسحب من هنا لتحريك الشريط، أو اضغط مرتين لإعادته"
        >
          <Move size={18} />
        </button>
        <button
          type="button"
          className={`secondary-btn classmode-students-dock-toggle ${managementOpen ? "active" : ""}`}
          onClick={() => setManagementOpen((value) => !value)}
          aria-pressed={managementOpen}
          title={managementOpen ? "إخفاء قائمتي الطلاب" : "إظهار قائمتي الطلاب"}
          aria-label={managementOpen ? "إخفاء قائمتي الطلاب" : "إظهار قائمتي الطلاب"}
        >
          <Users size={18} />
        </button>
        <button
          type="button"
          className="secondary-btn classmode-dock-point-minus"
          disabled={!selectedStudent || !students.some((student) => String(student.id) === String(selectedStudent.id))}
          onClick={() => adjustPoints(selectedStudent, -1)}
          title="خصم نقطة من الطالب المحدد"
          aria-label="خصم نقطة من الطالب المحدد"
        >
          <Minus size={18} />
        </button>
        <button
          type="button"
          className="secondary-btn classmode-dock-point-plus"
          disabled={!selectedStudent || !students.some((student) => String(student.id) === String(selectedStudent.id))}
          onClick={() => adjustPoints(selectedStudent, 1)}
          title="إضافة نقطة للطالب المحدد"
          aria-label="إضافة نقطة للطالب المحدد"
        >
          <Plus size={18} />
        </button>
        <button
          type="button"
          className={`secondary-btn classmode-stage-focus-toggle ${contentMode === "board" ? "classmode-board-focus-toggle" : ""} ${stageFocus ? "active" : ""}`}
          onClick={() => setStageFocus((current) => !current)}
          aria-pressed={stageFocus}
          aria-label={stageFocus ? "إلغاء وضع التركيز" : contentMode === "board" ? "تركيز السبورة" : "تركيز مساحة العرض"}
          title={stageFocus ? "العودة للعرض العادي" : "إظهار المحتوى في وضع التركيز"}
        >
          <ScanLine size={18} />
        </button>
        <button
          type="button"
          className="secondary-btn classmode-bottom-save"
          onClick={saveLessonState}
          title="حفظ الحصة وطبقة الشرح والتعليقات"
          aria-label="حفظ الحصة وطبقة الشرح والتعليقات"
        >
          <Save size={18} />
        </button>
      </div>
      <button
        type="button"
        className="classmode-user-fullscreen"
        onClick={toggleFullscreen}
        title="ملء الشاشة"
        aria-label="ملء الشاشة"
      >
        <ArrowUpRight size={25} />
      </button>
      {boardToolsAvailable && (
        <button
          type="button"
          className={`classmode-board-tools-toggle classmode-section8-floating-tools ${boardControlsOpen ? "active" : ""}`}
          onClick={() => {
            setBoardControlsOpen((value) => {
              const next = !value;
              setBoardToolsExpanded(next);
              return next;
            });
          }}
          aria-expanded={boardControlsOpen}
          aria-label={boardControlsOpen ? "إخفاء أدوات السبورة" : "إظهار أدوات السبورة"}
          title={boardControlsOpen ? "إخفاء أدوات السبورة" : "إظهار أدوات السبورة"}
        >
          <LayoutGrid size={19} />
        </button>
      )}
      <div
        ref={classModeNavigationRef}
        className={`classmode-mode-navigation ${classModeNavOpen ? "open" : "closed"}`}
      >
        <button
          type="button"
          className={`classmode-user-navigation ${classModeNavOpen ? "active" : ""}`}
          onClick={() => setClassModeNavOpen((value) => !value)}
          title="التنقل داخل وضع الحصة"
          aria-label="التنقل داخل وضع الحصة"
          aria-expanded={classModeNavOpen}
          aria-controls="classmode-mode-navigation-menu"
        >
          <LayoutGrid size={20} />
        </button>
        {classModeNavOpen && (
          <div
            id="classmode-mode-navigation-menu"
            className="classmode-mode-navigation-menu"
            role="menu"
            aria-label="أقسام وضع الحصة"
          >
            <div className="classmode-section8-menu-heading" role="presentation">
              محتوى الحصة
            </div>
            {classModeNavigationItems.map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                type="button"
                role="menuitem"
                className={contentMode === key ? "active" : ""}
                aria-current={contentMode === key ? "page" : undefined}
                onClick={() => selectClassModeNavigation(key)}
                title={label}
                aria-label={`فتح ${label} داخل وضع الحصة`}
              >
                <Icon size={20} />
                <span>{label}</span>
              </button>
            ))}
          </div>
        )}
      </div>
      <Project12PageQuestionDock
        visible={contentMode === 'pdf' && Boolean(selectedResource)}
        page={classPage || selectedResource?.pageStart || 1}
        pageCount={project12QuestionSets.pageCount}
        lessonCount={project12QuestionSets.lessonCount}
        manualCount={project12QuestionSets.manual.length}
        scope={project12QuestionScope}
        onScope={setProject12QuestionScope}
        onPrepareGame={() => {
          setManagementOpen(true);
          setChallengeNotice(`تم تجهيز ${project12GameQuestions.length} سؤالًا. اختر الطلاب ثم ابدأ التحدي.`);
        }}
      />

      {/* Accessible even in true fullscreen, when the ordinary header is hidden. */}
      <button
        type="button"
        className="v8-country-library-launcher"
        data-testid="country-card-visible-entry"
        aria-label="فتح مكتبة بطاقات الدول"
        aria-controls="v8-country-card-library"
        aria-expanded={cardsDrawerOpen && cardDrawerSection === "countries"}
        onClick={openCountryCardLibrary}
      >
        <StickyNote size={18} aria-hidden="true" />
        <span>بطاقات الدول</span>
      </button>
      <ClassModeViewport.Header>
        <div className="classmode-top-header">
          <div className="classmode-header-brand">
            <img
              src={identity.logo || identity.icon}
              alt={identity.schoolName}
            />
            <div>
              <strong>{identity.schoolName}</strong>
              <small>
                {identity.teacherName} — {identity.teacherTitle}
              </small>
            </div>
          </div>
          <div className="classmode-section8-current-mode" aria-live="polite">
            <span>{activeClassModeLabel}</span>
          </div>
          <div className="classmode-header-meta">
            <div className="header-meta-item">
              <Clock size={18} />
              <div>
                <b>{clockTime}</b>
                <small>{formatDateAr(today)}</small>
              </div>
            </div>
            <div className="header-meta-item">
              <div>
                <b>{selectedResource?.unit || current.title}</b>
                <small>{selectedResource?.lesson || current.group}</small>
              </div>
            </div>
            <div className="header-meta-item book-icon">
              <BookOpen size={20} />
            </div>
          </div>
        </div>
      </ClassModeViewport.Header>
      <ClassModeViewport.Body>
        <ClassModeViewport.Stage>
          <button
            type="button"
            className="project10-online-class-entry"
            onClick={openOnlineClassPanel}
            data-testid="online-class-entry"
            title="فتح الحصة الأونلاين"
            aria-label="الحصة الأونلاين"
          >
            <Radio size={18} />
            <span className="project10-live-dot" aria-hidden="true" />
            <span className="project10-entry-copy">
              <strong>أونلاين</strong>
              <small>فتح الغرفة</small>
            </span>
          </button>
          <section className="classmode-board-panel">
            <div className="classmode-board-topbar">
              <div className="classmode-current-badge live-badge">
                ● حصة مباشرة
              </div>
              <div className="classmode-metrics">
                <div>
                  <Users size={17} />
                  <b>{currentCount}</b>
                  <span>الطلاب</span>
                </div>
                <div>
                  <b>{counts.present || 0}</b>
                  <span>حاضر</span>
                </div>
                <div>
                  <b>{counts.absent || 0}</b>
                  <span>غائب</span>
                </div>
                <div>
                  <b>
                    {Math.floor(seconds / 60)
                      .toString()
                      .padStart(2, "0")}
                    :{(seconds % 60).toString().padStart(2, "0")}
                  </b>
                  <span>مدة الحصة</span>
                </div>
              </div>
              <div className="classmode-top-actions">
                <button
                  className="icon-action"
                  onClick={() => navigate("dashboard")}
                  type="button"
                  title="الخروج من وضع الحصة"
                >
                  <X />
                </button>
                <button
                  className="icon-action"
                  onClick={() => setRunning((value) => !value)}
                  type="button"
                >
                  {running ? <CirclePause /> : <CirclePlay />}
                </button>
                <button
                  className="icon-action"
                  onClick={() => setSeconds(0)}
                  type="button"
                >
                  <TimerReset />
                </button>
                <button
                  className="secondary-btn classmode-online-entry"
                  onClick={openOnlineClassPanel}
                  type="button"
                  data-testid="online-class-top-action"
                  title="فتح الحصة الأونلاين"
                >
                  <Radio size={17} />
                  <span>الحصة الأونلاين</span>
                </button>
                <button className="danger-btn" onClick={endClass} type="button">
                  إنهاء الحصة
                </button>
              </div>
            </div>

            <div className="classmode-resource-card">
              <div>
                <span className="eyebrow">الدرس المرتبط بالحصة</span>
                {lessons.length > 0 ? (
                  <select
                    className="classmode-lesson-select"
                    value={activeLesson?.id || ""}
                    onChange={(event) => void selectLesson(event.target.value)}
                  >
                    {lessons.map((lesson) => (
                      <option key={lesson.id} value={lesson.id}>
                        {lesson.title}
                        {lesson.lessonDate ? ` — ${lesson.lessonDate}` : ""}
                      </option>
                    ))}
                  </select>
                ) : (
                  <h3>{selectedResource?.title || current.title}</h3>
                )}
                <p>
                  {activeLesson?.unit ||
                    selectedResource?.unit ||
                    current.group}{" "}
                  —{" "}
                  {activeLesson?.title ||
                    selectedResource?.lesson ||
                    current.title}
                </p>
              </div>
              <div className="classmode-flow-row">
                {flow.map((step, index) => (
                  <button
                    key={step}
                    className={index === flowIndex ? "active" : ""}
                    onClick={() => setFlowIndex(index)}
                    type="button"
                  >
                    {flowLabels[step] || step}
                  </button>
                ))}
              </div>
              <div className="classmode-resource-actions">
                <button
                  className="secondary-btn"
                  onClick={() => switchContentMode("board")}
                  type="button"
                >
                  <Presentation size={16} /> فتح السبورة
                </button>
                <button
                  className="secondary-btn"
                  onClick={openOnlineClassPanel}
                  type="button"
                >
                  <Radio size={16} /> الحصة الأونلاين
                </button>
              </div>
            </div>

            {sessionQueue.length > 0 && (
              <div className="classmode-session-plan">
                <span className="eyebrow">
                  خطة الحصة ({sessionQueue.length} عنصر)
                </span>
                <div className="classmode-session-plan-row">
                  <button
                    type="button"
                    className="icon-action"
                    onClick={() => goToQueueStep(-1)}
                    disabled={sessionQueue.length < 2}
                  >
                    <ArrowLeftRight size={16} />
                  </button>
                  <div className="classmode-session-plan-list">
                    {sessionQueue.map((item, index) => (
                      <button
                        key={item.id}
                        type="button"
                        className={
                          String(item.id) === String(selectedResourceId)
                            ? "active"
                            : ""
                        }
                        onClick={() => {
                          setSelectedResourceId(item.id);
                          setContentMode(resourceContentMode(item));
                          setFlowIndex(0);
                        }}
                      >
                        <span className="pin-order">{index + 1}</span>{" "}
                        {item.title}
                      </button>
                    ))}
                  </div>
                  <button
                    type="button"
                    className="icon-action"
                    onClick={() => goToQueueStep(1)}
                    disabled={sessionQueue.length < 2}
                  >
                    <ArrowLeftRight size={16} />
                  </button>
                </div>
              </div>
            )}

            <div className="classmode-board-frame">
              {displayResource && modeResources.length > 1 && (
                <div
                  className="classmode-media-edge-nav"
                  role="group"
                  aria-label="التبديل بين ملفات الدرس"
                >
                  <button
                    type="button"
                    className="previous"
                    onClick={() => cycleModeResource(-1)}
                    title="الملف السابق"
                    aria-label="الملف السابق"
                  >
                    ‹
                  </button>
                  <label className="classmode-section3-switcher">
                    <span className="visually-hidden">اختيار ملف من النوع الحالي</span>
                    <select
                      value={String(displayResource.id)}
                      aria-label="اختيار ملف آخر من النوع الحالي"
                      onChange={(event) => {
                        setSelectedResourceId(event.target.value);
                        setFlowIndex(0);
                      }}
                    >
                      {modeResources.map((item, index) => (
                        <option key={item.id} value={String(item.id)}>
                          {index + 1}. {item.title || item.fileName || 'ملف الدرس'}
                        </option>
                      ))}
                    </select>
                    <small className="classmode-media-edge-count" aria-live="polite">
                      {displayResourceIndex + 1}/{modeResources.length}
                    </small>
                  </label>
                  <button
                    type="button"
                    className="next"
                    onClick={() => cycleModeResource(1)}
                    title="الملف التالي"
                    aria-label="الملف التالي"
                  >
                    ›
                  </button>
                </div>
              )}
              {displayResource &&
                ["pdf", "textbook"].includes(displayResource.type) && (
                  <div
                    className="classmode-pdf-edge-nav"
                    role="group"
                    aria-label="التنقل بين صفحات PDF"
                  >
                    <button
                      type="button"
                      onClick={() =>
                        setClassPage((p) =>
                          clampLessonPage(
                            (p || 1) - 1,
                            displayResource,
                            renderedPdf.pageCount || Infinity,
                          ),
                        )
                      }
                      disabled={
                        (classPage || 1) <=
                        Number(displayResource.pageStart || 1)
                      }
                      title="الصفحة السابقة"
                      aria-label="الصفحة السابقة"
                    >
                      ‹
                    </button>
                    <span>
                      {classPage || 1}
                      {displayResource.pageEnd
                        ? ` / ${displayResource.pageEnd}`
                        : renderedPdf.pageCount
                          ? ` / ${renderedPdf.pageCount}`
                          : ""}
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setClassPage((p) =>
                          clampLessonPage(
                            (p || 1) + 1,
                            displayResource,
                            renderedPdf.pageCount || Infinity,
                          ),
                        )
                      }
                      disabled={
                        (classPage || 1) >=
                        Number(
                          displayResource.pageEnd ||
                            renderedPdf.pageCount ||
                            Infinity,
                        )
                      }
                      title="الصفحة التالية"
                      aria-label="الصفحة التالية"
                    >
                      ›
                    </button>
                  </div>
                )}
              {canPlaceLessonCards && (
                <button
                  type="button"
                  className={`classmode-card-drawer-toggle ${cardsDrawerOpen ? "active" : ""}`}
                  onClick={() => setCardsDrawerOpen((value) => !value)}
                  title="البطاقات التعليمية"
                >
                  <StickyNote size={17} />
                  <span>البطاقات</span>
                </button>
              )}

              <div
                className={`classmode-board-surface ${boardToolsVisible ? "with-tools" : ""}`}
              >
                {boardToolsVisible && (
                <button
                  type="button"
                  className="classmode-board-tool-toggle"
                  onClick={() => setBoardToolsExpanded((value) => !value)}
                  aria-expanded={boardToolsExpanded}
                  aria-label="أدوات السبورة"
                  title="أدوات السبورة"
                >
                  <LayoutGrid size={19} />
                </button>
              )}
              {boardToolsVisible && boardToolsExpanded && (
                <div
                    className={`classmode-board-sidebar-left ${contentMode !== "board" ? "media-annotation-tools" : ""}`}
                  >
                    {toolOptions.map(({ key, label, icon: Icon }) => (
                      <button
                        key={key}
                        type="button"
                        className={tool === key ? "active" : ""}
                        onClick={() => activateBoardTool(key)}
                        title={label}
                      >
                        <Icon size={19} />
                        <span>{label}</span>
                      </button>
                    ))}
                    {contentMode === "board" && (
                      <button
                        type="button"
                        className="classmode-handwriting-polish"
                        onClick={convertRecentHandwriting}
                        disabled={handwritingBusy}
                        title="حوّل آخر كتابة بالقلم إلى نص منسق بالخط المختار"
                      >
                        <Sparkles size={19} />
                        <span>
                          {handwritingBusy ? "جارٍ التحويل…" : "تصحيح خط اليد"}
                        </span>
                      </button>
                    )}
                    {contentMode !== "board" && (
                      <>
                        <div className="classmode-left-toolbar-divider" />
                        <button type="button" onClick={undoBoard} title="تراجع عن آخر كتابة">
                          <Undo2 size={19} />
                          <span>تراجع</span>
                        </button>
                        <button type="button" onClick={redoBoard} title="إعادة آخر كتابة">
                          <Redo2 size={19} />
                          <span>إعادة</span>
                        </button>
                        <button type="button" onClick={clearBoard} title="مسح كتابات الملف الحالي">
                          <RotateCcw size={19} />
                          <span>مسح</span>
                        </button>
                      </>
                    )}
                    {contentMode === "board" && (
                      <>
                        <div className="classmode-left-toolbar-divider" />
                        <button
                          type="button"
                          onClick={() =>
                            setZoom((value) => Math.min(2, value + 0.15))
                          }
                          title="تكبير"
                        >
                          <ZoomIn size={19} />
                          <span>تكبير</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setZoom((value) =>
                              Math.max(0.75, Number((value - 0.15).toFixed(2))),
                            )
                          }
                          title="تصغير"
                        >
                          <ZoomOut size={19} />
                          <span>تصغير</span>
                        </button>
                        <button type="button" onClick={undoBoard} title="تراجع">
                          <Undo2 size={19} />
                          <span>تراجع</span>
                        </button>
                        <button type="button" onClick={redoBoard} title="إعادة">
                          <Redo2 size={19} />
                          <span>إعادة</span>
                        </button>
                      </>
                    )}
                  </div>
                )}

                <div
                  className={`classmode-board-stage board-template-${boardTemplate} ${contentMode === "board" ? "has-lesson-ribbon" : ""} ${contentMode !== "board" && displayResource ? "has-display-resource" : ""}`}
                >
                  {contentMode === "board" && (
                    <BoardLessonRibbon
                      grade={currentGrade}
                      lesson={
                        activeLesson?.title ||
                        selectedResource?.lesson ||
                        current.title
                      }
                    />
                  )}
                  {contentMode === "games" ? (
                    <div className="classmode-games-stage">
                      <Suspense fallback={<div className="classmode-lazy-loading">جار تحميل اللعبة…</div>}>
                        <ClassroomGamePanel
                        questions={relatedQuestions}
                        students={students}
                        history={data.gameQuestionHistory || []}
                        selectedStudentId={selectedStudent?.id || ""}
                        onSelectStudent={(studentId) =>
                          setSelectedStudent(
                            students.find(
                              (student) =>
                                String(student.id) === String(studentId),
                            ) || null,
                          )
                        }
                        onAwardPoint={adjustPoints}
                        onQuestionUsed={rememberGameQuestion}
                        onCreateOnlineChallenge={() =>
                          setOnlineGameStartRequest((value) => value + 1)
                        }
                      />
                      </Suspense>
                      <Suspense fallback={<div className="classmode-lazy-loading">جار تحميل الحصة الأونلاين…</div>}>
                        <OnlineGameHostPanel
                        cloudSync={data.settings?.cloudSync}
                        title={`تحدي ${activeLesson?.title || current.title}`}
                        grade={currentGrade}
                        unit={
                          activeLesson?.unit || selectedResource?.unit || ""
                        }
                        lessonId={activeLesson?.id || ""}
                        sourceKind={
                          selectedResource?.sourceKind ||
                          selectedResource?.type ||
                          ""
                        }
                        sourceFileName={selectedResource?.fileName || ""}
                        questions={onlineGameQuestions}
                        startRequest={onlineGameStartRequest}
                        onNotice={setChallengeNotice}
                        onQuestionsUsed={rememberGameQuestions}
                        onOpenSettings={() =>
                          setShareNotice(
                            "اضبط رابط الحصة من لوحة الحصة الأونلاين داخل نفس الشاشة.",
                          )
                        }
                        onFinish={(result) =>
                          updateData((latest) => ({
                            ...latest,
                            gameResults: [
                              result,
                              ...(latest.gameResults || []),
                            ].slice(0, 300),
                          }))
                        }
                      />
                      </Suspense>
                    </div>
                  ) : contentMode === "maps" ? (
                    <div className="classmode-map-embed">
                      <Suspense fallback={<div className="classmode-lazy-loading">جار تحميل الخرائط…</div>}>
                        <LessonMapStudio
                        grade={currentGrade}
                        lesson={activeLesson}
                        onSaveState={saveLessonMapState}
                      />
                      </Suspense>
                    </div>
                  ) : (
                    <>
                      {contentMode !== "board" && displayResource && (
                        <div className="classmode-resource-preview">
                          <div className="resource-preview-head">
                            <strong>{displayResource.title}</strong>
                            <small>
                              {displayResource.fileName ||
                                displayResource.mimeType ||
                                displayResource.type}
                            </small>
                            {(displayResource.type === "pdf" ||
                              displayResource.type === "textbook") && (
                              <div className="classmode-page-nav classmode-pdf-view-controls" aria-label="تكبير صفحة PDF">
                                <span
                                  className="classmode-pdf-zoom-controls"
                                  role="group"
                                  aria-label="تكبير صفحة PDF"
                                >
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setMediaZoom((value) =>
                                        Math.max(
                                          1,
                                          Number((value - 0.15).toFixed(2)),
                                        ),
                                      )
                                    }
                                    disabled={mediaZoom <= 1}
                                    title="تصغير صفحة PDF"
                                  >
                                    <ZoomOut size={14} />
                                  </button>
                                  <b>{Math.round(mediaZoom * 100)}%</b>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setMediaZoom((value) =>
                                        Math.min(
                                          6,
                                          Number((value + 0.15).toFixed(2)),
                                        ),
                                      )
                                    }
                                    disabled={mediaZoom >= 6}
                                    title="تكبير صفحة PDF"
                                  >
                                    <ZoomIn size={14} />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setMediaZoom(1)}
                                    disabled={Math.abs(mediaZoom - 1) < 0.01}
                                    title="إعادة التكبير إلى 100%"
                                  >
                                    <RotateCcw size={14} />
                                  </button>
                                </span>
                                {displayResource.type === "textbook" && selectedExamUrl && (
                                  <a
                                    href={selectedExamUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="classmode-exam-link"
                                    title="فتح ملف الامتحانات"
                                  >
                                    <FileText size={14} /> الامتحانات
                                  </a>
                                )}
                              </div>
                            )}
                          </div>
                          <MediaRenderer
                            key={String(displayResource.id)}
                            resource={displayResource}
                            source={displayResourceSource}
                            pdfPage={renderedPdf}
                            page={classPage || 1}
                            annotations={resourceAnnotations}
                            onOpenExternal={openSelectedDocument}
                            onPdfStateChange={setWebPdfState}
                            zoom={mediaZoom}
                            onZoomChange={setMediaZoom}
                            onPreviousPage={() =>
                              setClassPage((page) =>
                                clampLessonPage(
                                  (page || 1) - 1,
                                  displayResource,
                                  renderedPdf.pageCount || Infinity,
                                ),
                              )
                            }
                            onNextPage={() =>
                              setClassPage((page) =>
                                clampLessonPage(
                                  (page || 1) + 1,
                                  displayResource,
                                  renderedPdf.pageCount || Infinity,
                                ),
                              )
                            }
                          />
                        </div>
                      )}

                      {contentMode !== "board" &&
                        !displayResource &&
                        contentMode !== "maps" && (
                          <div className="classmode-empty-resource">
                            <File size={46} />
                            <h3>لا يوجد محتوى من هذا النوع في مكتبة المنصة</h3>
                            <p>
                              أضف{" "}
                              {contentMode === "videos"
                                ? "فيديو"
                                : contentMode === "images"
                                  ? "صورة"
                                  : contentMode === "audio"
                                    ? "ملفًا صوتيًا"
                                    : contentMode === "slides"
                                      ? "عرض PowerPoint"
                                      : contentMode === "files"
                                        ? "ملفًا"
                                        : "ملف PDF"}{" "}
                              داخل الدرس في المكتبة ليظهر هنا تلقائيًا.
                            </p>
                            <button
                              type="button"
                              className="primary-btn"
                              onClick={() => navigate("contentLibrary")}
                            >
                              <BookOpen size={16} /> فتح المكتبة
                            </button>
                          </div>
                        )}

                      {(contentMode === "board" ||
                        (displayResource &&
                          ["pdf", "images", "slides"].includes(contentMode))) && (
                        <MemoCanvasOverlay
                          actions={boardActions}
                          onDrawAction={handleBoardAction}
                          onMoveAction={moveBoardActionHandler}
                          onSelectAction={selectBoardAction}
                          selectedActionId={selectedBoardActionId}
                          template={boardTemplate}
                          zoom={contentMode === "board" ? zoom : 1}
                          boardRef={boardRef}
                          tool={canvasTool}
                          selectedColor={annotationColor}
                          strokeWidth={strokeWidth}
                          shapeKind={shapeKind}
                          historicalSymbol={historicalSymbol}
                          geographicalSymbol={geographicalSymbol}
                          arrowMode={arrowMode}
                          textValue={boardText}
                          textStyle={textStyle}
                          fontFamily={fontFamily}
                          fontSize={fontSize}
                          fontWeight={fontWeight}
                          textPreset={textPreset}
                          boardReady={boardReady}
                          setBoardReady={setBoardReady}
                          hasResourceHeader={Boolean(displayResource)}
                          onAddCard={canPlaceLessonCards ? addBoardCard : undefined}
                          onAddCountryCard={canPlaceLessonCards ? addCountryCard : undefined}
                        />
                      )}
                    </>
                  )}{" "}
                </div>
              </div>
            </div>

            {boardToolsVisible && boardToolsExpanded && (
              <div
                className={`classmode-toolbar ${contentMode !== "board" ? "media-annotation-toolbar" : ""}`}
              >
                <div className="classmode-tool-group compact classmode-color-row">
                  {["#111827", "#ffffff", "#2563eb", "#06b6d4", "#16a34a", "#facc15", "#f97316", "#dc2626", "#ec4899", "#7c3aed"].map(
                    (c) => (
                      <button
                        key={c}
                        type="button"
                        className={`classmode-swatch ${annotationColor === c ? "active" : ""}`}
                        style={{ background: c }}
                        onClick={() => setAnnotationColor(c)}
                        title={c}
                      />
                    ),
                  )}
                  <input
                    type="color"
                    value={annotationColor}
                    onChange={(e) => setAnnotationColor(e.target.value)}
                    title="لون مخصص"
                  />
                  <label className="classmode-stroke-size-control">
                    <span>{DRAW_TOOL_SIZE_LABELS[activeDrawTool]}</span>
                    <select
                      value={strokeWidth}
                      onChange={(e) => updateActiveStrokeWidth(e.target.value)}
                      title={DRAW_TOOL_SIZE_LABELS[activeDrawTool]}
                      aria-label={DRAW_TOOL_SIZE_LABELS[activeDrawTool]}
                    >
                      {strokeSizeOptions.map((size) => (
                        <option key={`${activeDrawTool}-${size}`} value={size}>{size}px</option>
                      ))}
                    </select>
                  </label>
                  <select
                    className="classmode-font-select"
                    value={fontFamily}
                    onChange={(e) => selectBoardFont(e.target.value)}
                    title="نوع الخط العربي الحقيقي"
                  >
                    {(boardFontOptions.filter((item) => fontAvailability[item.probe] !== false).length
                      ? boardFontOptions.filter((item) => fontAvailability[item.probe] !== false)
                      : [{ value: 'Tahoma, Arial, sans-serif', probe: 'System', label: 'خط الجهاز العربي — بديل' }])
                      .map((item) => (
                        <option
                          key={item.value}
                          value={item.value}
                          style={{ fontFamily: item.value }}
                        >
                          {item.label}{fontAvailability[item.probe] === null ? " — جارٍ التحقق" : ""}
                        </option>
                      ))}
                  </select>
                  <span
                    className={`classmode-font-status ${fontReady ? "ready" : fontLoadFailed ? "failed" : "loading"}`}
                    title={
                      fontReady
                        ? "نوع الخط المحدد محمّل فعليًا"
                        : fontLoadFailed
                          ? "تعذر تحميل نوع الخط؛ يظهر خط بديل مؤقتًا"
                          : "جارٍ تحميل نوع الخط المحدد"
                    }
                  >
                    {fontReady
                      ? "✓ الخط فعلي"
                      : fontLoadFailed
                        ? "⚠ خط بديل"
                        : "… تحميل الخط"}
                  </span>
                </div>
                <div className="classmode-tool-group compact classmode-text-style-row">
                  {BOARD_TEXT_PRESETS.map((preset) => (
                    <button
                      key={preset.key}
                      className={textPreset === preset.key ? "active" : ""}
                      onClick={() => selectTextPreset(preset.key)}
                      type="button"
                      title={`حجم ${preset.label}: ${preset.size}px`}
                    >
                      {preset.label}
                    </button>
                  ))}
                  <button
                    type="button"
                    className="classmode-text-size-btn"
                    onClick={() => adjustBoardTextSize(-4)}
                    title="تصغير النص المحدد"
                  >
                    <Minus size={14} />
                  </button>
                  <span className="classmode-text-size-value">
                    {Math.round(fontSize)}px
                  </span>
                  <button
                    type="button"
                    className="classmode-text-size-btn"
                    onClick={() => adjustBoardTextSize(4)}
                    title="تكبير النص المحدد"
                  >
                    <Plus size={14} />
                  </button>
                  <button
                    className={
                      textStyle === "plain" && tool === "normal-text"
                        ? "active"
                        : ""
                    }
                    onClick={() => activateStyledText("plain")}
                    type="button"
                  >
                    <Type size={15} /> كتابة نصية
                  </button>
                  <button
                    className="classmode-handwriting-polish"
                    onClick={convertRecentHandwriting}
                    disabled={handwritingBusy}
                    type="button"
                    title="تحويل آخر خط يد إلى نص منظم بالحجم والنوع المختارين"
                  >
                    <Sparkles size={15} />
                    {handwritingBusy ? "جارٍ القراءة…" : "تصحيح خط اليد"}
                  </button>
                  <span className="classmode-auto-correct-status" title="التصحيح متاح عند الطلب فقط، ولا يُغيّر النص المكتوب تلقائيًا">
                    <Sparkles size={13} /> تصحيح اختياري
                  </span>
                  {contentMode === "board" && (
                    <button
                      type="button"
                      className={`classmode-open-card-drawer ${cardsDrawerOpen ? "active" : ""}`}
                      onClick={() => setCardsDrawerOpen(true)}
                    >
                      <StickyNote size={15} /> البطاقات
                    </button>
                  )}
                </div>
                <div className="classmode-tool-group compact classmode-historical-symbol-row">
                  {historicalSymbolOptions.map((item) => (
                    <button
                      key={item.key}
                      className={
                        tool === "historical-symbol" &&
                        historicalSymbol === item.key
                          ? "active"
                          : ""
                      }
                      onClick={() => {
                        setHistoricalSymbol(item.key);
                        activateBoardTool("historical-symbol");
                      }}
                      type="button"
                      title={item.label}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
                <div className="classmode-tool-group compact">
                  {boardTemplates.map(({ key, label, icon: Icon }) => (
                    <button
                      key={key}
                      className={boardTemplate === key ? "active" : ""}
                      onClick={() => setBoardTemplate(key)}
                      type="button"
                    >
                      <Icon size={17} />
                      {label}
                    </button>
                  ))}
                </div>
                <div className="classmode-tool-group compact">
                  {shapeOptions.map((shape) => (
                    <button
                      key={shape.key}
                      className={shapeKind === shape.key ? "active" : ""}
                      onClick={() => setShapeKind(shape.key)}
                      type="button"
                    >
                      {shape.label}
                    </button>
                  ))}
                  <button
                    className={arrowMode === "right" ? "active" : ""}
                    onClick={() => setArrowMode("right")}
                    type="button"
                  >
                    سهم يمين
                  </button>
                  <button
                    className={arrowMode === "down" ? "active" : ""}
                    onClick={() => setArrowMode("down")}
                    type="button"
                  >
                    سهم لأسفل
                  </button>
                </div>
                <div className="classmode-tool-group compact classmode-edit-actions">
                  <button onClick={undoBoard} type="button" title="تراجع">
                    <Undo2 size={17} /> تراجع
                  </button>
                  <button onClick={redoBoard} type="button" title="إعادة">
                    <Redo2 size={17} /> إعادة
                  </button>
                  <button
                    onClick={deleteSelectedBoardAction}
                    disabled={!selectedBoardActionId}
                    type="button"
                  >
                    <Eraser size={17} /> حذف المحدد
                  </button>
                  <button onClick={clearBoard} type="button">
                    <RotateCcw size={17} /> {contentMode === "board" ? "مسح الكل" : "مسح الكتابة"}
                  </button>
                </div>
              </div>
            )}
          </section>
        </ClassModeViewport.Stage>

        <ClassModeViewport.Students>
          <aside className="classmode-side-column">
            <article className="panel classmode-side-panel classmode-management-actions-panel">
              <div className="panel-heading compact">
                <div>
                  <span className="eyebrow">إدارة الحصة</span>
                  <h3>الأونلاين والتسجيل والحفظ</h3>
                </div>
                <LayoutGrid size={18} />
              </div>
              <div className="classmode-management-actions-grid">
                <button
                  type="button"
                  className={`secondary-btn ${recordingWithAudio ? "active" : ""}`}
                  disabled={recordingActive || recordingBusy}
                  onClick={() => setRecordingWithAudio((value) => !value)}
                >
                  {recordingWithAudio ? (
                    <Mic size={16} />
                  ) : (
                    <MicOff size={16} />
                  )}
                  <span>
                    {recordingWithAudio ? "المايك يعمل" : "المايك مغلق"}
                  </span>
                </button>
                <button
                  type="button"
                  className={`secondary-btn ${recordingActive ? "recording-active" : ""}`}
                  disabled={recordingBusy}
                  onClick={toggleClassRecording}
                >
                  <CircleDot size={16} />
                  <span>
                    {recordingBusy
                      ? "جارٍ التشغيل…"
                      : recordingActive
                        ? `إيقاف ${String(Math.floor(recordingSeconds / 60)).padStart(2, "0")}:${String(recordingSeconds % 60).padStart(2, "0")}`
                        : "تسجيل الحصة"}
                  </span>
                </button>
                {recordingActive && recordingBackend && (
                  <button
                    type="button"
                    className="secondary-btn"
                    onClick={toggleRecordingPause}
                  >
                    {recordingPaused ? (
                      <CirclePlay size={16} />
                    ) : (
                      <CirclePause size={16} />
                    )}
                    <span>
                      {recordingPaused ? "استكمال التسجيل" : "إيقاف مؤقت"}
                    </span>
                  </button>
                )}
                {hasPendingNativeRecording && (
                  <button
                    type="button"
                    className="secondary-btn"
                    disabled={recordingBusy}
                    onClick={retryPendingNativeRecording}
                  >
                    <Save size={16} />
                    <span>إعادة حفظ الفيديو</span>
                  </button>
                )}
                {contentMode === "board" && (
                  <>
                    <button
                      type="button"
                      className="secondary-btn"
                      onClick={saveBoard}
                    >
                      <Camera size={16} />
                      <span>لقطة شاشة</span>
                    </button>
                  </>
                )}
                <button
                  type="button"
                  className="secondary-btn classmode-live-shortcut"
                  onClick={openOnlineClassPanel}
                >
                  <Radio size={16} />
                  <span>الحصة أونلاين</span>
                </button>
                <button
                  type="button"
                  className="secondary-btn"
                  onClick={() => navigate("sessions")}
                >
                  <Presentation size={16} />
                  <span>التسجيلات</span>
                </button>
                <button
                  type="button"
                  className="secondary-btn"
                  onClick={() => navigate("contentLibrary")}
                >
                  <BookOpen size={16} />
                  <span>المكتبة</span>
                </button>
                <button
                  type="button"
                  className="secondary-btn"
                  onClick={() => navigate("settings")}
                >
                  <LayoutGrid size={16} />
                  <span>الإعدادات</span>
                </button>
              </div>
            </article>
            <Suspense fallback={<div className="classmode-lazy-loading">جار تحميل أدوات البث…</div>}>
              <TeacherLivePanel
              cloudSync={data.settings?.cloudSync}
              roomMeta={{
                title: activeLesson?.title || current.title,
                grade: currentGrade,
                lesson: activeLesson?.title || selectedResource?.lesson || "",
                sessionId: current.id,
                lessonId: activeLesson?.id || null,
              }}
              liveState={{
                contentMode,
                contentModeLabel:
                  contentMode === "board"
                    ? "السبورة"
                    : contentMode === "pdf"
                      ? "ملف PDF"
                      : contentMode === "images"
                        ? "الصور"
                        : contentMode === "videos"
                          ? "الفيديو"
                          : contentMode === "audio"
                            ? "الصوت"
                            : contentMode === "maps"
                              ? "الخرائط"
                              : contentMode === "slides"
                                ? "PowerPoint"
                                : contentMode === "games"
                                  ? "ألعاب الدرس"
                                  : "ملف الدرس",
                resourceId: selectedResource?.id || "",
                resourceTitle:
                  selectedResource?.title ||
                  activeLesson?.title ||
                  current.title,
                page: classPage || 1,
                boardRevision: boardSyncRevision,

                pointsRevision: pointsSyncRevision,
                elapsedSeconds: seconds,
              }}
              buildSnapshot={composeBoardImage}
              onNotice={setShareNotice}
              onOpenSettings={() => navigate("settings")}
              onSaveCloudSync={async (cloudSync) =>
                updateData({
                  ...data,
                  settings: { ...data.settings, cloudSync },
                })
              }
              startRequest={liveStartRequest}
            />
            </Suspense>
            <article className="panel classmode-side-panel classmode-phrases-panel">
              <div className="panel-heading compact">
                <div>
                  <span className="eyebrow">التشجيع</span>
                  <h3>الجمل التشجيعية</h3>
                </div>
                <Sparkles size={18} />
              </div>
              <div className="classmode-phrase-list">
                {phrases.map((phrase, index) => (
                  <div
                    key={`${phrase}-${index}`}
                    className="classmode-phrase-row"
                  >
                    <button type="button" onClick={() => sayPhrase(phrase)}>
                      {phrase}
                    </button>
                    <button
                      type="button"
                      className="icon-action phrase-remove"
                      onClick={() => removeEncouragementPhrase(index)}
                      title="حذف"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
              </div>
              <div className="classmode-phrase-add">
                <input
                  value={newPhraseText}
                  onChange={(e) => setNewPhraseText(e.target.value)}
                  placeholder="أضف جملة تشجيعية جديدة"
                  onKeyDown={(e) =>
                    e.key === "Enter" && addEncouragementPhrase()
                  }
                />
                <button
                  type="button"
                  className="secondary-btn"
                  onClick={addEncouragementPhrase}
                >
                  <Plus size={16} /> إضافة جملة جديدة
                </button>
              </div>
            </article>

            <article className="panel classmode-side-panel project13-legacy-recordings-panel">
              <div className="panel-heading compact">
                <div>
                  <span className="eyebrow">الأنشطة</span>
                  <h3>خطة سير الحصة</h3>
                </div>
                <MailCheck size={18} />
              </div>
              <div className="classmode-activity-list">
                {flow.map((step, index) => (
                  <button
                    key={step}
                    className={index === flowIndex ? "active" : ""}
                    onClick={() => setFlowIndex(index)}
                    type="button"
                  >
                    {flowLabels[step] || step}
                  </button>
                ))}
              </div>
              <div className="classmode-resource-summary">
                {activeLesson?.notes ||
                  selectedResource?.notes ||
                  "اختر موردًا لتظهر الملاحظات هنا."}
                {activeLesson?.homework && (
                  <>
                    <br />
                    <strong>الواجب: </strong>
                    {activeLesson.homework}
                  </>
                )}
              </div>
              <div className="classmode-resource-tags">
                {normalizeTags(selectedResource?.tags).map((tag) => (
                  <span key={tag}>#{tag}</span>
                ))}
              </div>
            </article>

            <article className="panel classmode-side-panel">
              <div className="panel-heading compact">
                <div>
                  <span className="eyebrow">المورد</span>
                  <h3>الملفات والوسائط</h3>
                </div>
                <File size={18} />
              </div>
              <div className="classmode-resource-list">
                {resources.map((resource) => (
                  <button
                    key={resource.id}
                    className={
                      String(selectedResourceId) === String(resource.id)
                        ? "active"
                        : ""
                    }
                    onClick={() => {
                      setSelectedResourceId(resource.id);
                      setContentMode(resourceContentMode(resource));
                    }}
                    type="button"
                  >
                    {resource.type === "image" ? (
                      <FileImage size={16} />
                    ) : resource.type === "video" ? (
                      <Video size={16} />
                    ) : resource.type === "map" ? (
                      <MapIcon size={16} />
                    ) : resource.type === "audio" ? (
                      <Volume2 size={16} />
                    ) : (
                      <FileText size={16} />
                    )}
                    <span>{resource.title}</span>
                    <small>{resource.lesson}</small>
                  </button>
                ))}
              </div>
            </article>

            <article className="panel classmode-side-panel">
              <div className="panel-heading compact">
                <div>
                  <span className="eyebrow">الكتابة</span>
                  <h3>ملاحظات فوق المورد</h3>
                </div>
                <StickyNote size={18} />
              </div>
              <div className="annotation-controls">
                <select
                  value={annotationMode}
                  onChange={(e) => setAnnotationMode(e.target.value)}
                >
                  <option value="note">ملاحظة</option>
                  <option value="highlight">تمييز</option>
                  <option value="question">سؤال</option>
                  <option value="answer">إجابة</option>
                </select>
                <input
                  value={annotationText}
                  onChange={(e) => setAnnotationText(e.target.value)}
                  placeholder="اكتب الملاحظة أو الشرح هنا"
                />
                <input
                  type="color"
                  value={annotationColor}
                  onChange={(e) => setAnnotationColor(e.target.value)}
                />
              </div>
              <div className="annotation-actions">
                <button
                  className="primary-btn"
                  onClick={addAnnotation}
                  type="button"
                >
                  <StickyNote size={16} /> إضافة
                </button>
                <button
                  className="secondary-btn"
                  onClick={() => setAnnotationText("")}
                  type="button"
                >
                  مسح النص
                </button>
              </div>
              <div className="annotation-list">
                {resourceAnnotations.length ? (
                  resourceAnnotations.map((note) => (
                    <div
                      className="annotation-chip"
                      key={note.id}
                      style={{ borderColor: note.color }}
                    >
                      <span style={{ background: note.color }}>
                        {note.mode === "highlight"
                          ? "تمييز"
                          : note.mode === "question"
                            ? "سؤال"
                            : note.mode === "answer"
                              ? "إجابة"
                              : "ملاحظة"}
                      </span>
                      <p>{note.text}</p>
                      <button
                        className="text-btn danger-text"
                        onClick={() => removeAnnotation(note.id)}
                        type="button"
                      >
                        حذف
                      </button>
                    </div>
                  ))
                ) : (
                  <small className="settings-help">
                    لا توجد ملاحظات فوق المورد بعد.
                  </small>
                )}
              </div>
            </article>

            <article className="panel classmode-side-panel">
              <div className="panel-heading compact">
                <div>
                  <span className="eyebrow">التسجيلات</span>
                  <h3>آخر الحصص</h3>
                </div>
                <Presentation size={18} />
              </div>
              <div className="classmode-recordings-list">
                {recentRecordings.length ? (
                  recentRecordings.map((recording) => (
                    <LessonRecordingItem
                      key={recording.id}
                      recording={recording}
                      onNotice={setShareNotice}
                    />
                  ))
                ) : (
                  <small className="settings-help">
                    لا توجد تسجيلات محفوظة بعد.
                  </small>
                )}
              </div>
            </article>

            <Project13LinkHub settings={data.settings} lesson={activeLesson} compact title="روابط المُبدع والدرس"/>

          <article className="panel classmode-side-panel classmode-challenge-panel">
              <div className="panel-heading compact">
                <div>
                  <span className="eyebrow">التحديات داخل الحصة</span>
                  <h3>طالبين أو فرق</h3>
                </div>
                <Gamepad2 size={18} />
              </div>
              <div className="classmode-challenge-switch">
                <button
                  type="button"
                  className={challengeMode === "battle" ? "active" : ""}
                  onClick={() => setChallengeMode("battle")}
                >
                  طالبين
                </button>
                <button
                  type="button"
                  className={challengeMode === "teams" ? "active" : ""}
                  onClick={() => setChallengeMode("teams")}
                >
                  فرق
                </button>
              </div>
              <div className="classmode-challenge-grid">
                {displayedStudents.map((student) => {
                  const active = challengePickIds.includes(student.id);
                  return (
                    <button
                      key={student.id}
                      type="button"
                      className={active ? "active" : ""}
                      onClick={() =>
                        setChallengePickIds((currentIds) => {
                          if (active)
                            return currentIds.filter((id) => id !== student.id);
                          if (
                            challengeMode === "battle" &&
                            currentIds.length >= 2
                          )
                            return [currentIds[1], student.id];
                          return [...currentIds, student.id];
                        })
                      }
                    >
                      <strong>{student.name}</strong>
                      <small>{student.code}</small>
                    </button>
                  );
                })}
              </div>
              <div className="classmode-challenge-summary">
                <span>المحددون: {challengePickIds.length}</span>
                <small>
                  {challengeMode === "teams"
                    ? "سيتم تقسيمهم إلى فريق ذهبي وفريق أسود"
                    : "سيبدأ التحدي بين طالبين داخل الحصة"}
                </small>
              </div>
              {challengeNotice && (
                <div className="settings-notice">{challengeNotice}</div>
              )}
              <div className="classmode-summary-actions">
                <button
                  className="primary-btn"
                  onClick={() => startClassChallenge({ copyLink: false })}
                  type="button"
                >
                  <Gamepad2 size={16} /> فتح داخل الألعاب
                </button>
                <button
                  className="secondary-btn"
                  onClick={() => startClassChallenge({ copyLink: true })}
                  type="button"
                >
                  نسخ الرابط
                </button>
              </div>
            </article>

            <article className="panel classmode-side-panel">
              <div className="panel-heading compact">
                <div>
                  <span className="eyebrow">ملخص</span>
                  <h3>تسجيل الحصة</h3>
                </div>
                <Save size={18} />
              </div>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="اكتب النقاط المهمة، الواجب، أو الطلاب المحتاجين للمتابعة..."
                rows="8"
              />
              <div className="classmode-summary-actions">
                <button
                  className="secondary-btn"
                  onClick={() => recordLesson({ copyLink: true })}
                  type="button"
                >
                  نسخ الرابط
                </button>
                <button
                  className="secondary-btn"
                  onClick={() => setNotes("")}
                  type="button"
                >
                  تفريغ
                </button>
              </div>
            </article>
          </aside>
        </ClassModeViewport.Students>
      </ClassModeViewport.Body>

      {managementOpen && (
        <div className="classmode-student-rails" aria-label="قوائم الطلاب">
          {[0, 1].map((column) => (
            <aside key={column} className={`classmode-student-rail ${column === 0 ? "right" : "left"}`}>
              <div className="classmode-student-rail-head">
                <strong>{column === 0 ? "الطلاب" : "متابعة الطلاب"}</strong>
                <div className="classmode-student-rail-head-actions">
                  <small>{studentRailColumns[column].length} طالب</small>
                  {column === 0 && (
                    <>
                      <div className="classmode-student-sort-toggle" role="group" aria-label="ترتيب الطلاب">
                        <button
                          type="button"
                          className={studentSortMode === "points" ? "active" : ""}
                          onClick={() => setStudentSortMode("points")}
                          title="ترتيب حسب أعلى النقاط"
                        >
                          الأعلى نقاطًا
                        </button>
                        <button
                          type="button"
                          className={studentSortMode === "improved" ? "active" : ""}
                          onClick={() => setStudentSortMode("improved")}
                          title="التحسن = نقاط هذه الحصة ناقص نقاط الحصة السابقة، وليس فرق الإجمالي التراكمي"
                        >
                          الأكثر تحسنًا
                        </button>
                      </div>
                      <button type="button" className="classmode-rail-random" onClick={randomStudent} title="اختيار طالب عشوائي من القائمة اليمنى" aria-label="اختيار طالب عشوائي من القائمة اليمنى">
                        <Dices size={15}/><span>عشوائي</span>
                      </button>
                    </>
                  )}
                  {column === 1 && (
                    <button type="button" className="classmode-rail-random" onClick={() => randomStudent("left")} title="اختيار طالب عشوائي من القائمة اليسرى" aria-label="اختيار طالب عشوائي من القائمة اليسرى">
                      <Dices size={15}/><span>عشوائي</span>
                    </button>
                  )}
                  {column === 1 && (
                    <button
                      type="button"
                      className={`classmode-rail-manage ${managementDrawerOpen ? "active" : ""}`}
                      onClick={() => setManagementDrawerOpen((value) => !value)}
                      title={managementDrawerOpen ? "إغلاق أدوات الإدارة" : "أدوات الإدارة"}
                      aria-label={managementDrawerOpen ? "إغلاق أدوات الإدارة" : "أدوات الإدارة"}
                    >
                      <LayoutGrid size={15}/><span>إدارة</span>
                    </button>
                  )}
                </div>
              </div>
              <div className="classmode-student-rail-list" role="list" aria-label={column === 0 ? "القائمة اليمنى للطلاب" : "القائمة اليسرى للطلاب"}>
                {studentRailColumns[column].map((student) => (
                  <article role="listitem" data-student-id={String(student.id)} key={`rail:${student.id}`} className={`classmode-student-rail-row ${selectedStudent?.id === student.id ? "selected" : ""} ${randomPickedStudentId === String(student.id) ? "random-picked" : ""}`}>
                    <button type="button" className="student-name" onClick={() => setSelectedStudent(student)}>
                      <span>{student.name}</span>
                      <small className="classmode-score-detail" title="نقاط الحصة والتحسن مقارنة بالحصة السابقة (لا تُقارن النقاط التراكمية)">
                        <span>الإجمالي: {Number(points[student.id] ?? student.points ?? 0)}</span>
                        <span>الحصة: {Number(studentProgress[student.id]?.earned ?? 0)}</span>
                        {studentProgress[student.id]?.hasPrevious ? (
                          <b className={`classmode-progress-delta ${Number(studentProgress[student.id]?.delta || 0) > 0 ? "positive" : Number(studentProgress[student.id]?.delta || 0) < 0 ? "negative" : "neutral"}`}>
                            التحسن: {Number(studentProgress[student.id]?.delta || 0) > 0 ? "+" : ""}{studentProgress[student.id]?.delta}
                            <span className="classmode-previous-score"> (السابقة: {studentProgress[student.id]?.previous})</span>
                          </b>
                        ) : <span className="classmode-progress-unavailable">التحسن: —</span>}
                      </small>
                    </button>
                    <div className="student-actions">
                      <button type="button" className="minus" onClick={() => adjustPoints(student, -1)} aria-label={`خصم نقطة من ${student.name}`}>−</button>
                      <button type="button" className="plus" onClick={() => adjustPoints(student, 1)} aria-label={`إضافة نقطة إلى ${student.name}`}>+</button>
                      <button type="button" onClick={() => { const phrase = phrases[Math.floor(Math.random() * phrases.length)] || "أحسنت"; const text = `${String(phrase).replace(/[.!،,]+$/u, "")} يا ${student.name}.`; setSelectedStudent(student); setLastPraise(text); void speakClassroomArabic(text, data.settings, "excited"); }} aria-label={`تشجيع ${student.name}`}><Sparkles size={14}/></button>
                      <button type="button" onClick={() => { const phrase = correctivePhrases[Math.floor(Math.random() * correctivePhrases.length)] || "ركز أكثر"; const text = `${String(phrase).replace(/[.!،,]+$/u, "")} يا ${student.name}.`; setSelectedStudent(student); setLastPraise(text); void speakClassroomArabic(text, data.settings, "calm"); }} aria-label={`تنبيه ${student.name}`}><MailCheck size={14}/></button>
                    </div>
                  </article>
                ))}
              </div>
            </aside>
          ))}
        </div>
      )}

      <ClassModeViewport.Footer>
        <div
          className="classmode-bottom-actions"
          role="toolbar"
          aria-label="أوامر وضع الحصة"
        >
          <button
            type="button"
            className="secondary-btn classmode-exit-btn"
            onClick={() => navigate("dashboard")}
            title="الخروج من وضع الحصة"
            aria-label="الخروج من وضع الحصة"
          >
            <X size={17} />
            <span className="action-label">خروج</span>
          </button>
          <div className="classmode-bottom-actions-mid">
            <button type="button" className="secondary-btn classmode-v8-voice-check"
              onClick={testTabletArabicAudio} title="تشغيل جملة عربية للتحقق من الصوت على الجهاز" aria-label="اختبار الصوت العربي">
              <Volume2 size={17}/><span className="action-label">اختبار الصوت</span>
            </button>
            <button type="button" className="secondary-btn classmode-v8-voice-stop"
              onClick={() => { void stopArabicSpeech(); setShareNotice('تم إرسال أمر إيقاف الصوت.'); }} title="إيقاف النطق العربي" aria-label="إيقاف النطق">
              <VolumeX size={17}/><span className="action-label">إيقاف النطق</span>
            </button>
            <button
              type="button"
              className={`secondary-btn classmode-mic-record-btn ${recordingWithAudio ? "active" : ""}`}
              disabled={recordingActive || recordingBusy}
              onClick={() => setRecordingWithAudio((value) => !value)}
              title={
                recordingActive
                  ? "لا يمكن تغيير الميكروفون بعد بدء التسجيل"
                  : recordingWithAudio
                    ? "الميكروفون مفعّل — اضغط لتعطيله قبل التسجيل"
                    : "الميكروفون متوقف — اضغط لتفعيله قبل التسجيل"
              }
              aria-label={
                recordingWithAudio
                  ? "تعطيل ميكروفون تسجيل الحصة"
                  : "تفعيل ميكروفون تسجيل الحصة"
              }
            >
              {recordingWithAudio ? <Mic size={17} /> : <MicOff size={17} />}
              <span className="action-label">
                {recordingWithAudio ? "المايك يعمل" : "المايك مغلق"}
              </span>
            </button>
            <button
              type="button"
              className={`secondary-btn classmode-record-btn ${recordingActive ? "recording-active" : ""}`}
              disabled={recordingBusy}
              onClick={toggleClassRecording}
              title={
                recordingActive ? "إيقاف التسجيل وحفظه" : "بدء تسجيل الحصة"
              }
              aria-label={
                recordingActive ? "إيقاف التسجيل وحفظه" : "بدء تسجيل الحصة"
              }
            >
              <CircleDot size={17} />
              <span className="action-label">
                {recordingBusy
                  ? "جارٍ التشغيل…"
                  : recordingActive
                    ? `إيقاف ${String(Math.floor(recordingSeconds / 60)).padStart(2, "0")}:${String(recordingSeconds % 60).padStart(2, "0")}`
                    : "تسجيل الحصة"}
              </span>
            </button>
            {recordingActive && recordingBackend && (
              <button
                type="button"
                className="secondary-btn classmode-pause-record-btn"
                onClick={toggleRecordingPause}
                title={
                  recordingPaused ? "استكمال التسجيل" : "إيقاف التسجيل مؤقتًا"
                }
                aria-label={
                  recordingPaused ? "استكمال التسجيل" : "إيقاف التسجيل مؤقتًا"
                }
              >
                {recordingPaused ? (
                  <CirclePlay size={17} />
                ) : (
                  <CirclePause size={17} />
                )}
                <span className="action-label">
                  {recordingPaused ? "استكمال" : "إيقاف مؤقت"}
                </span>
              </button>
            )}
            {hasPendingNativeRecording && (
              <button
                type="button"
                className="secondary-btn classmode-retry-record-btn"
                disabled={recordingBusy}
                onClick={retryPendingNativeRecording}
                title="إعادة حفظ ملف تسجيل Android المؤقت"
                aria-label="إعادة حفظ فيديو الحصة"
              >
                <Save size={17} />
                <span className="action-label">إعادة حفظ الفيديو</span>
              </button>
            )}
            <button
              type="button"
              className="secondary-btn project13-student-image-btn"
              onClick={saveBoardForStudents}
              title="حفظ صورة الشرح داخل الدرس للطلاب"
              aria-label="حفظ صورة للطلاب"
            >
              <Camera size={17} />
              <span className="action-label">صورة للطلاب</span>
            </button>
            <button
              type="button"
              className="secondary-btn"
              onClick={() => setManagementOpen(true)}
              title="عرض الطلاب"
              aria-label="عرض الطلاب"
            >
              <Users size={17} />
              <span className="action-label">الطلاب</span>
            </button>
            <button
              type="button"
              className="secondary-btn classmode-live-shortcut"
              onClick={openOnlineClassPanel}
              title="إنشاء أو نسخ رابط الحصة الأونلاين"
              aria-label="رابط الحصة الأونلاين"
            >
              <Radio size={17} />
              <span className="action-label">الحصة أونلاين</span>
            </button>
            <button
              type="button"
              className="secondary-btn"
              onClick={() => navigate("sessions")}
              title="قائمة تسجيلات الحصص"
              aria-label="قائمة تسجيلات الحصص"
            >
              <Presentation size={17} />
              <span className="action-label">التسجيلات</span>
            </button>
            <button
              type="button"
              className="secondary-btn"
              onClick={() => navigate("contentLibrary")}
              title="مكتبة المحتوى"
              aria-label="مكتبة المحتوى"
            >
              <BookOpen size={17} />
              <span className="action-label">المكتبة</span>
            </button>
            <button
              type="button"
              className="secondary-btn"
              onClick={() => navigate("settings")}
              title="إعدادات المنصة"
              aria-label="إعدادات المنصة"
            >
              <LayoutGrid size={17} />
              <span className="action-label">الإعدادات</span>
            </button>
          </div>
          <button
            type="button"
            className="danger-btn classmode-end-btn"
            onClick={endClass}
            title="إنهاء الحصة وحفظها"
            aria-label="إنهاء الحصة وحفظها"
          >
            <span className="action-label">إنهاء الحصة</span>
          </button>
        </div>
      </ClassModeViewport.Footer>
      <ClassModeViewport.Overlays>
        {canPlaceLessonCards && cardsDrawerOpen && (
                <aside
                  className="classmode-card-drawer"
                  id="v8-country-card-library"
                  data-testid="country-card-library"
                  dir="rtl"
                  aria-label="قائمة بطاقات السبورة"
                >
                  <div className="classmode-card-drawer-head">
                    <div>
                      <strong>
                        {cardDrawerSection === "countries"
                          ? "بطاقات الدول"
                          : "البطاقات التعليمية"}
                      </strong>
                      <small>
                        اسحب البطاقة إلى السبورة أو اضغط لإضافتها في المنتصف
                      </small>
                    </div>
                    <button
                      type="button"
                      onClick={() => setCardsDrawerOpen(false)}
                      aria-label="إغلاق"
                    >
                      <X size={18} />
                    </button>
                  </div>
                  <div
                    className="classmode-card-drawer-tabs"
                    role="tablist"
                    aria-label="نوع البطاقات"
                  >
                    <button
                      type="button"
                      className={
                        cardDrawerSection === "education" ? "active" : ""
                      }
                      onClick={() => setCardDrawerSection("education")}
                    >
                      بطاقات تعليمية
                    </button>
                    <button
                      type="button"
                      className={
                        cardDrawerSection === "countries" ? "active" : ""
                      }
                      onClick={() => setCardDrawerSection("countries")}
                    >
                      بطاقات الدول
                    </button>
                  </div>
                  {cardDrawerSection === "education" ? (
                    <div className="classmode-card-drawer-list">
                      {BOARD_CARD_TEMPLATES.map((card) => (
                        <button
                          key={card.key}
                          type="button"
                          className="classmode-card-template-item"
                          draggable
                          onDragStart={(event) => {
                            event.dataTransfer.setData(
                              "application/x-mobdea-board-card",
                              card.key,
                            );
                            event.dataTransfer.effectAllowed = "copy";
                          }}
                          onClick={() => addBoardCard(card.key)}
                        >
                          <img src={card.asset} alt="" />
                          <span>{card.label}</span>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <>
                      <div
                        className="country-card-category-tabs"
                        role="tablist"
                        aria-label="تصنيفات بطاقات الدول"
                      >
                        {COUNTRY_CARD_CATEGORIES.map((category) => (
                          <button
                            key={category.key}
                            type="button"
                            className={
                              countryCategory === category.key ? "active" : ""
                            }
                            onClick={() => setCountryCategory(category.key)}
                          >
                            {category.label}
                          </button>
                        ))}
                      </div>
                      <label className="country-card-search">
                        <span>ابحث عن دولة أو عاصمة</span>
                        <input
                          type="search"
                          value={countryCardSearch}
                          onChange={(event) => setCountryCardSearch(event.target.value)}
                          placeholder="اسم الدولة أو العاصمة"
                          dir="rtl"
                        />
                      </label>
                      <div className="classmode-card-drawer-list country-card-drawer-list">
                        <button
                          type="button"
                          className="classmode-card-template-item country-card-template-item default"
                          draggable
                          onDragStart={(event) => {
                            event.dataTransfer.setData(
                              "application/x-mobdea-country-card",
                              DEFAULT_COUNTRY_CARD.key,
                            );
                            event.dataTransfer.effectAllowed = "copy";
                          }}
                          onClick={() =>
                            addCountryCard(DEFAULT_COUNTRY_CARD.key)
                          }
                        >
                          <img src={DEFAULT_COUNTRY_CARD.asset} alt="قالب بطاقة دولة فارغة" onError={showCountryCardFallback} />
                          <span>بطاقة افتراضية</span>
                        </button>
                        {countryCardsForCategory(countryCategory, countryCardSearch).map(
                          (card) => (
                            <button
                              key={card.key}
                              type="button"
                              className="classmode-card-template-item country-card-template-item"
                              data-testid={`country-card-template-${card.key}`}
                              draggable
                              onDragStart={(event) => {
                                event.dataTransfer.setData(
                                  "application/x-mobdea-country-card",
                                  card.key,
                                );
                                event.dataTransfer.effectAllowed = "copy";
                              }}
                              onClick={() => addCountryCard(card.key)}
                            >
                              <img src={card.asset} alt={`نموذج بطاقة ${card.name}`} onError={showCountryCardFallback} />
                              <span>{card.name}</span>
                              <small>{card.capital} · {card.region}</small>
                            </button>
                          ),
                        )}
                        {countryCardsForCategory(countryCategory, countryCardSearch).length === 0 && (
                          <p role="status" className="country-card-no-results">لا توجد دولة بهذا الاسم أو بهذه العاصمة.</p>
                        )}
                      </div>
                    </>
                  )}
                </aside>
              )}
      <Project11ClassSyncBridge
        data={data}
        updateData={updateData}
        sessionId={current?.id || 'standalone-class'}
        group={current?.group || ''}
        grade={currentGrade || ''}
        lessonId={activeLesson?.id || activeLessonId || ''}
        resourceId={selectedResourceId || ''}
        contentMode={contentMode}
        page={classPage || 1}
        boardTemplate={boardTemplate}
        boardActions={boardActions}
        points={points}
        selectedStudentId={selectedStudent?.id || ''}
        students={students}
        setLessonId={setActiveLessonId}
        setResourceId={setSelectedResourceId}
        setContentMode={setContentMode}
        setPage={setClassPage}
        setBoardTemplate={setBoardTemplate}
        setBoardActions={setBoardActions}
        setPoints={setPoints}
        setSelectedStudent={setSelectedStudent}
        onNotice={setShareNotice}
      />

      {shareNotice && (
        <div className="spoken-banner">
          <span>{shareNotice}</span>
          <button type="button" onClick={() => setShareNotice("")} aria-label="إغلاق الرسالة">
            <X size={15} />
          </button>
        </div>
      )}
      </ClassModeViewport.Overlays>
    </ClassModeViewport>
  );
}
