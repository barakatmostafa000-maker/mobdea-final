const clean = (value) => String(value ?? '').trim();
const numeric = (value) => Number.isFinite(Number(value)) ? Number(value) : 0;
function sessionEarned(item, id, previous = null) {
  if (!item) return null;
  if (item.earned && Object.prototype.hasOwnProperty.call(item.earned, id)) return numeric(item.earned[id]);
  if (item.startPoints && item.points && Object.prototype.hasOwnProperty.call(item.startPoints, id) && Object.prototype.hasOwnProperty.call(item.points, id)) return numeric(item.points[id]) - numeric(item.startPoints[id]);
  if (previous?.points && item.points && Object.prototype.hasOwnProperty.call(previous.points, id) && Object.prototype.hasOwnProperty.call(item.points, id)) return numeric(item.points[id]) - numeric(previous.points[id]);
  return null;
}
export function withClassPointAward({ latest = {}, studentId, change = 0, sessionKey = '', session = null, today = '', group = '', grade = '' } = {}) {
  const id = String(studentId ?? '');
  const delta = numeric(change);
  if (!id || !delta) return latest;
  const students = Array.isArray(latest.students) ? latest.students : [];
  const index = students.findIndex((student) => String(student.id) === id);
  if (index < 0) return latest;
  const before = Math.max(0, numeric(students[index].points));
  const after = Math.max(0, before + delta);
  const nextStudents = students.slice();
  nextStudents[index] = { ...students[index], points: after };
  const sessions = Array.isArray(latest.classPointSessions) ? latest.classPointSessions.slice() : [];
  const key = clean(sessionKey) || `${clean(session?.id) || 'lesson'}:${clean(today)}`;
  let sIndex = sessions.findIndex((item) => String(item.id || item.sessionKey) === key);
  const prior = sIndex >= 0 ? sessions[sIndex] : {
    id: key, sessionKey: key, sessionId: session?.id || '', date: today || '',
    grade: grade || session?.grade || '', group: group || session?.group || '', startPoints: {}, points: {}, earned: {},
  };
  const startPoints = { ...(prior.startPoints || {}) };
  if (!Object.prototype.hasOwnProperty.call(startPoints, id)) startPoints[id] = before;
  const points = { ...(prior.points || {}), [id]: after };
  const earned = { ...(prior.earned || {}), [id]: after - numeric(startPoints[id]) };
  const updated = { ...prior, id: key, sessionKey: key, sessionId: prior.sessionId || session?.id || '', date: prior.date || today || '', grade: prior.grade || grade || session?.grade || '', group: prior.group || group || session?.group || '', startPoints, points, earned, updatedAt: new Date().toISOString() };
  if (sIndex >= 0) sessions[sIndex] = updated; else sessions.unshift(updated);
  return { ...latest, students: nextStudents, classPointSessions: sessions };
}
export function buildClassPointProgress({ students = [], livePoints = {}, sessions = [], sessionKey = '', group = '', grade = '' } = {}) {
  const wantedGroup = clean(group);
  const wantedGrade = clean(grade);
  const ordered = (Array.isArray(sessions) ? sessions : [])
    .filter((item) => (!wantedGroup || !item.group || clean(item.group) === wantedGroup)
      && (!wantedGrade || !item.grade || clean(item.grade) === wantedGrade))
    .slice()
    .sort((a,b) => clean(a.date || a.updatedAt).localeCompare(clean(b.date || b.updatedAt))
      || clean(a.updatedAt).localeCompare(clean(b.updatedAt)));
  const current = ordered.find((item) => String(item.id || item.sessionKey) === String(sessionKey)) || null;
  const result = {};
  for (const student of Array.isArray(students) ? students : []) {
    const id = String(student.id);
    const comparable = ordered.filter((item) => (item.earned && Object.prototype.hasOwnProperty.call(item.earned,id))
      || (item.points && Object.prototype.hasOwnProperty.call(item.points,id)));

    // Until the current lesson has a durable points snapshot there is no
    // evidence of improvement yet. Do not rank a pupil as "worse" merely
    // because today's earned score is still zero before the first award.
    if (!current || !comparable.includes(current)) {
      const previousItem = comparable.at(-1) || null;
      const previousBefore = previousItem ? comparable.at(-2) || null : null;
      const previous = sessionEarned(previousItem, id, previousBefore);
      result[id] = { earned: 0, previous: previous ?? 0, hasPrevious: false, delta: 0 };
      continue;
    }

    const currentIndex = comparable.indexOf(current);
    const previousItem = currentIndex > 0 ? comparable[currentIndex - 1] : null;
    const previousBefore = currentIndex > 1 ? comparable[currentIndex - 2] : null;
    const previous = sessionEarned(previousItem,id,previousBefore);
    let earned = sessionEarned(current,id,previousItem);
    if (earned === null) {
      const start = current?.startPoints && Object.prototype.hasOwnProperty.call(current.startPoints,id)
        ? numeric(current.startPoints[id]) : numeric(student.points);
      earned = numeric(livePoints?.[id] ?? student.points) - start;
    }
    result[id] = { earned, previous: previous ?? 0, hasPrevious: previous !== null, delta: previous === null ? 0 : earned - previous };
  }
  return result;
}

export function rankByClassImprovement(students = [], progress = {}) {
  return (Array.isArray(students) ? students : []).map((student,index) => ({student,index,row:progress?.[student.id] || progress?.[String(student.id)] || {}})).sort((a,b) => Number(Boolean(b.row.hasPrevious))-Number(Boolean(a.row.hasPrevious)) || numeric(b.row.delta)-numeric(a.row.delta) || numeric(b.row.earned)-numeric(a.row.earned) || a.index-b.index).map((entry)=>entry.student);
}
