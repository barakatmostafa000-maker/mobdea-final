import { createCredentialSecret, hasCredentialSecret, normalizePin, verifyCredentialSecret } from '../utils/security';
import { cloudConfigured, pushCloudData } from './cloudSync';

export const DEFAULT_STUDENT_PIN = '12345678';
export const STUDENT_PIN_POLICY_VERSION = 2;

function pinPolicySettings(settings = {}) {
  return {
    ...settings,
    studentPinDefaultVersion: STUDENT_PIN_POLICY_VERSION,
    studentPinDefaultLength: DEFAULT_STUDENT_PIN.length,
  };
}

async function persistAndSync(nextData, updateData, { onLocalCommitted } = {}) {
  const saved = await updateData(nextData);
  const current = saved || nextData;
  onLocalCommitted?.(current);
  if (!cloudConfigured(current.settings)) return { data: current, synced: false, syncError: '' };
  try {
    const remote = await pushCloudData(current);
    const syncedAt = new Date().toISOString();
    // Rebase cloud metadata onto the latest in-memory data so edits made while
    // the upload was pending are never overwritten by the migration snapshot.
    const synced = await updateData((latest) => ({
      ...(latest || current),
      settings: {
        ...(latest?.settings || current.settings),
        cloudSync: {
          ...(latest?.settings?.cloudSync || current.settings?.cloudSync || {}),
          revision: remote.revision || latest?.settings?.cloudSync?.revision || current.settings?.cloudSync?.revision || '',
          lastPushAt: syncedAt,
          lastAutoSyncAt: syncedAt,
          // Preserve a dirty marker created by an edit after the upload began.
          localChangedAt: latest?.settings?.cloudSync?.localChangedAt || '',
          autoSyncError: '',
        },
      },
    }));
    return { data: synced || current, synced: true, syncError: '' };
  } catch (error) {
    return {
      data: current,
      synced: false,
      syncError: error?.message || 'تعذر مزامنة PIN مع الخادم.',
    };
  }
}


export function needsUnifiedStudentPinMigration(data = {}) {
  return Number(data?.settings?.studentPinDefaultVersion || 0) < STUDENT_PIN_POLICY_VERSION;
}

export async function migrateAllStudentsToUnifiedDefaultPin(data, updateData, options = {}) {
  if (!data || typeof updateData !== 'function' || !needsUnifiedStudentPinMigration(data)) {
    return { changed: false, synced: false, syncError: '' };
  }
  const now = new Date().toISOString();
  const students = [];
  for (const student of data.students || []) {
    if (hasCredentialSecret(student, 'student')) {
      students.push(student);
      continue;
    }
    const legacyPin = normalizePin(student.studentPin);
    const preserveChangedPin = Boolean(
      student.studentPinChangedByStudentAt &&
      /^\d{6,10}$/.test(legacyPin) &&
      legacyPin !== DEFAULT_STUDENT_PIN
    );
    // Migrate a student's already-changed legacy PIN into a hashed credential
    // instead of resetting it. Every generated secret receives its own salt.
    const secret = await createCredentialSecret(
      preserveChangedPin ? legacyPin : DEFAULT_STUDENT_PIN,
      'student',
    );
    students.push({
      ...student,
      ...secret,
      studentPin: '',
      studentPinMustChange: !preserveChangedPin,
      studentPinDefaultVersion: STUDENT_PIN_POLICY_VERSION,
      studentPinChangedByStudentAt: preserveChangedPin
        ? student.studentPinChangedByStudentAt
        : '',
      studentPinResetAt: preserveChangedPin
        ? student.studentPinResetAt || ''
        : now,
      updatedAt: now,
    });
  }
  const nextData = {
    ...data,
    students,
    settings: pinPolicySettings(data.settings),
  };
  const result = await persistAndSync(nextData, updateData, options);
  return { changed: true, ...result };
}

export async function verifyLocalStudentPin(student = {}, pin = '') {
  const normalized = normalizePin(pin);
  if (!normalized) return { valid: false, mustChangePin: false };
  let valid = false;
  if (hasCredentialSecret(student, 'student')) {
    valid = await verifyCredentialSecret(normalized, student, 'student');
  } else {
    const legacyPin = normalizePin(student.studentPin);
    valid = Boolean(legacyPin) && legacyPin === normalized;
  }
  return {
    valid,
    mustChangePin: Boolean(valid && (student.studentPinMustChange === true || normalized === DEFAULT_STUDENT_PIN)),
  };
}


export async function resetStudentPinToDefault(data, studentId, updateData) {
  const secret = await createCredentialSecret(DEFAULT_STUDENT_PIN, 'student');
  const now = new Date().toISOString();
  const nextData = {
    ...data,
    students: (data.students || []).map((student) => String(student.id) === String(studentId)
      ? {
          ...student,
          ...secret,
          studentPinMustChange: true,
          studentPinDefaultVersion: STUDENT_PIN_POLICY_VERSION,
          studentPinChangedByStudentAt: '',
          studentPinResetAt: now,
          updatedAt: now,
        }
      : student),
    settings: pinPolicySettings(data.settings),
  };
  return persistAndSync(nextData, updateData);
}

export async function changeStudentPinAfterLogin(data, studentId, newPin, updateData) {
  const normalized = normalizePin(newPin);
  if (!/^\d{6,10}$/.test(normalized)) throw new Error('PIN الجديد يجب أن يكون من 6 إلى 10 أرقام.');
  if (normalized === DEFAULT_STUDENT_PIN) throw new Error('اختر PIN مختلفًا عن الرمز الأساسي 12345678.');
  const target = (data.students || []).find((student) => String(student.id) === String(studentId));
  if (!target) throw new Error('تعذر العثور على حساب الطالب الحالي.');
  const secret = await createCredentialSecret(normalized, 'student');
  const now = new Date().toISOString();
  const nextData = {
    ...data,
    students: (data.students || []).map((student) => String(student.id) === String(studentId)
      ? {
          ...student,
          ...secret,
          studentPinMustChange: false,
          studentPinDefaultVersion: STUDENT_PIN_POLICY_VERSION,
          studentPinChangedByStudentAt: now,
          updatedAt: now,
        }
      : student),
    settings: pinPolicySettings(data.settings),
  };
  return persistAndSync(nextData, updateData);
}
