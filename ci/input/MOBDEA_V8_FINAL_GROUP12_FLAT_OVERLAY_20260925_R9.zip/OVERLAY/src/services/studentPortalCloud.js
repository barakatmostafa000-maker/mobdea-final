import { buildCloudUrl, timeoutFetch } from './cloudTransport.js';
import { importAssetBlob } from './assetStore.js';
import { createCredentialSecret } from '../utils/security.js';
import { safeTrim } from '../utils/safety.js';
import { sha256Blob } from './incrementalSha256.js';
import { filterContentLibraryForRole } from './rolePortalAccess.js';

const STUDENT_TOKEN_HEADER = 'X-Mobdea-Student-Token';
const STUDENT_WORKSPACE_HEADER = 'X-Mobdea-Workspace';

function publicConfig(settings = {}) {
  const cloud = settings?.cloudSync || settings || {};
  const endpoint = String(cloud.endpoint || '').trim().replace(/\/$/, '');
  const workspaceId = safeTrim(cloud.workspaceId || '', 80).replace(/[^a-zA-Z0-9_-]/g, '');
  if (!/^https:\/\//i.test(endpoint)) throw new Error('رابط خادم الطلاب غير مضبوط على هذا الجهاز.');
  if (!/^[a-zA-Z0-9_-]{3,80}$/.test(workspaceId)) throw new Error('مساحة العمل غير مضبوطة على هذا الجهاز.');
  return { endpoint, workspaceId };
}

async function readError(response, fallback) {
  try {
    const body = await response.json();
    if (body?.error === 'student_not_found' || body?.error === 'invalid_credentials') return 'كود الطالب أو PIN غير صحيح.';
    if (body?.error === 'student_not_active') return 'حساب الطالب غير مفعّل. تواصل مع المعلم.';
    if (body?.error === 'rate_limited') return 'محاولات كثيرة؛ انتظر قليلًا ثم أعد المحاولة.';
    if (body?.error === 'workspace_not_ready') return 'بيانات الطلاب لم تُرفع إلى المنصة السحابية بعد.';
    return body?.message || body?.error || fallback;
  } catch {
    return fallback;
  }
}

function authHeaders(config, token = '', extra = {}) {
  return {
    'Content-Type': 'application/json',
    [STUDENT_WORKSPACE_HEADER]: config.workspaceId,
    ...(token ? { [STUDENT_TOKEN_HEADER]: token } : {}),
    ...extra,
  };
}

function recordKey(record = {}) {
  const id = record.id ?? record.studentId ?? record.sessionId ?? record.roomId ?? record.token;
  return id == null ? JSON.stringify(record) : String(id);
}

function mergeRecords(local = [], remote = []) {
  const map = new Map();
  for (const item of Array.isArray(local) ? local : []) map.set(recordKey(item), item);
  for (const item of Array.isArray(remote) ? remote : []) map.set(recordKey(item), { ...(map.get(recordKey(item)) || {}), ...item });
  return [...map.values()];
}

export async function loginStudentFromCloud(settings, code, pin) {
  const config = publicConfig(settings);
  const response = await timeoutFetch(buildCloudUrl(config.endpoint, '/student/login'), {
    method: 'POST',
    headers: authHeaders(config),
    body: JSON.stringify({ studentCode: safeTrim(code, 24), code: safeTrim(code, 24), pin: safeTrim(pin, 16) }),
  }, 25000);
  if (!response.ok) throw new Error(await readError(response, `تعذر دخول الطالب (${response.status}).`));
  const payload = await response.json();
  if (!payload?.student || !payload?.studentToken || !payload?.data) throw new Error('استجابة دخول الطالب غير مكتملة.');
  return { ...payload, endpoint: config.endpoint, workspaceId: config.workspaceId };
}

export async function refreshStudentPortalSnapshot(session = {}) {
  const config = publicConfig(session);
  const token = safeTrim(session.studentToken || session.token || '', 260);
  if (!token) throw new Error('جلسة الطالب غير موجودة. أعد تسجيل الدخول.');
  const response = await timeoutFetch(buildCloudUrl(config.endpoint, '/student/refresh'), {
    method: 'GET',
    headers: authHeaders(config, token),
  }, 25000);
  if (!response.ok) throw new Error(await readError(response, `تعذر تحديث حساب الطالب (${response.status}).`));
  return response.json();
}

export async function fetchStudentAsset(session = {}, assetId = '') {
  const config = publicConfig(session);
  const token = safeTrim(session.studentToken || session.token || '', 260);
  const id = safeTrim(assetId, 100);
  if (!token || !id) throw new Error('بيانات تنزيل الملف غير مكتملة.');
  const response = await timeoutFetch(buildCloudUrl(config.endpoint, `/student/assets/${encodeURIComponent(id)}`), {
    method: 'GET',
    headers: authHeaders(config, token, { Accept: '*/*' }),
  }, 300000);
  if (!response.ok) throw new Error(await readError(response, `تعذر تنزيل الملف (${response.status}).`));
  const blob = await response.blob();
  const sha256 = safeTrim(response.headers.get('X-Mobdea-Asset-Sha256') || '', 64).toLowerCase();
  const size = Number(response.headers.get('X-Mobdea-Asset-Size') || response.headers.get('Content-Length') || 0);
  if (!/^[a-f0-9]{64}$/.test(sha256) || !Number.isSafeInteger(size) || size <= 0) {
    throw new Error('بيانات التحقق من ملف الطالب غير مكتملة. حدّث خادم المزامنة.');
  }
  if (blob.size !== size) throw new Error('حجم ملف الطالب لا يطابق النسخة المتزامنة.');
  if (await sha256Blob(blob) !== sha256) throw new Error('فشل التحقق من سلامة ملف الطالب.');
  let name = 'student-file';
  try { name = decodeURIComponent(response.headers.get('X-Mobdea-Asset-Name') || name); } catch { /* keep safe fallback */ }
  return {
    blob,
    metadata: {
      id,
      name: safeTrim(name, 180) || 'student-file',
      type: blob.type || response.headers.get('Content-Type') || 'application/octet-stream',
      kind: safeTrim(response.headers.get('X-Mobdea-Asset-Kind') || 'student-resource', 40),
      sha256,
      size,
    },
  };
}

export async function fetchStudentAssetBlob(session = {}, assetId = '') {
  return (await fetchStudentAsset(session, assetId)).blob;
}

export async function ensureStudentAssetLocal(session, asset = {}) {
  const id = safeTrim(asset?.id || asset?.assetId || '', 100);
  if (!id) return null;
  const downloaded = await fetchStudentAsset(session, id);
  const { blob } = downloaded;
  const expectedSize = Number(asset.size || 0);
  const expectedHash = safeTrim(asset.sha256 || '', 64).toLowerCase();
  if (expectedSize > 0 && blob.size !== expectedSize) throw new Error('حجم ملف الطالب لا يطابق النسخة المتزامنة.');
  if (expectedHash) {
    if (!/^[a-f0-9]{64}$/.test(expectedHash)) throw new Error('بصمة ملف الطالب غير صالحة.');
    if (await sha256Blob(blob) !== expectedHash) throw new Error('فشل التحقق من سلامة ملف الطالب.');
  }
  return importAssetBlob(blob, {
    ...downloaded.metadata,
    id,
    name: asset.name || asset.fileName || downloaded.metadata.name,
    type: asset.type || asset.mimeType || downloaded.metadata.type,
    kind: asset.kind || downloaded.metadata.kind || 'student-resource',
    sha256: expectedHash || downloaded.metadata.sha256,
    size: expectedSize || blob.size,
  });
}

function sameIdentity(left, right) {
  if (!left || !right) return true;
  const leftId = left.id ?? left.studentId;
  const rightId = right.id ?? right.studentId;
  const leftCode = left.code ?? left.studentCode;
  const rightCode = right.code ?? right.studentCode;
  if (leftId != null && rightId != null && String(leftId) !== String(rightId)) return false;
  if (leftCode != null && rightCode != null && String(leftCode) !== String(rightCode)) return false;
  return true;
}

function studentOwnedRecords(records, student, extraIdFields = []) {
  const id = String(student?.id ?? '');
  const code = String(student?.code ?? '');
  return (Array.isArray(records) ? records : []).filter((item) => {
    const ownerId = item?.studentId ?? item?.pupilId;
    const ownerCode = item?.studentCode;
    const extraMatch = extraIdFields.some((field) => item?.[field] != null && String(item[field]) === id);
    // Student portal collections are private-by-default. A record without an
    // explicit owner must never leak from the teacher's local dataset into a
    // pupil snapshot merely because it lacks a mismatching id.
    if (ownerId == null && ownerCode == null) return extraMatch;
    if (ownerId != null && String(ownerId) !== id) return false;
    if (ownerCode != null && (!code || String(ownerCode) !== code)) return false;
    return true;
  });
}

function studentSessions(records, student) {
  const grade = String(student?.grade || '');
  const group = String(student?.group || '');
  return (Array.isArray(records) ? records : []).filter((item) =>
    (!item?.grade || !grade || String(item.grade) === grade) &&
    (!item?.group || !group || String(item.group) === group));
}

function studentPointSessions(records, student) {
  const id = String(student?.id ?? '');
  return studentSessions(records, student).map((item) => ({
    ...item,
    points: item?.points && Object.prototype.hasOwnProperty.call(item.points, id) ? { [id]: item.points[id] } : {},
    startPoints: item?.startPoints && Object.prototype.hasOwnProperty.call(item.startPoints, id) ? { [id]: item.startPoints[id] } : {},
    earned: item?.earned && Object.prototype.hasOwnProperty.call(item.earned, id) ? { [id]: item.earned[id] } : {},
  }));
}

function studentVisibleExams(records, student) {
  const grade = String(student?.grade || '');
  return (Array.isArray(records) ? records : []).filter((item) =>
    item?.published !== false && item?.archived !== true && (!item?.grade || !grade || String(item.grade) === grade));
}

function scopedStudentContent(data = {}, student = {}) {
  return filterContentLibraryForRole(
    { ...data, students: [student] },
    { role: 'student', studentId: student.id, studentCode: student.code },
  );
}

export function mergeStudentPortalSnapshot(localData = {}, payload = {}, sessionOverride = null) {
  const snapshot = payload.data || payload || {};
  const cloudStudent = payload.student || snapshot.students?.[0];
  if (!cloudStudent) throw new Error('لم تُرجع المنصة بيانات الطالب.');
  const localStudents = Array.isArray(localData.students) ? localData.students : [];
  const existing = localStudents.find((item) => String(item.id) === String(cloudStudent.id) || String(item.code) === String(cloudStudent.code)) || {};
  const student = { ...existing, ...cloudStudent };
  const currentSession = sessionOverride || localData.settings?.studentPortalSession || {};
  if (!sameIdentity(student, { id: currentSession.studentId, code: currentSession.studentCode })) {
    throw new Error('هوية الطالب في الاستجابة لا تطابق جلسة الدخول الحالية.');
  }
  const studentPortalSession = {
    ...currentSession,
    endpoint: payload.endpoint || currentSession.endpoint || localData.settings?.cloudSync?.endpoint || '',
    workspaceId: payload.workspaceId || currentSession.workspaceId || localData.settings?.cloudSync?.workspaceId || '',
    studentToken: payload.studentToken || currentSession.studentToken || '',
    expiresAt: payload.expiresAt || currentSession.expiresAt || '',
    studentId: student.id,
    studentCode: student.code,
    lastPullAt: new Date().toISOString(),
    lastError: '',
  };
  const localScopedContent = scopedStudentContent(localData, student);
  const remoteScopedContent = scopedStudentContent(snapshot, student);
  return {
    ...localData,
    // Student portal state contains only the authenticated pupil. Keeping the
    // teacher's complete local student roster here defeats the server-side
    // isolation even when the UI happens not to render it.
    students: [student],
    sessions: mergeRecords(studentSessions(localData.sessions, student), studentSessions(snapshot.sessions, student)),
    attendance: mergeRecords(studentOwnedRecords(localData.attendance, student), studentOwnedRecords(snapshot.attendance, student)),
    grades: mergeRecords(studentOwnedRecords(localData.grades, student), studentOwnedRecords(snapshot.grades, student)),
    detailedResults: mergeRecords(studentOwnedRecords(localData.detailedResults, student), studentOwnedRecords(snapshot.detailedResults, student)),
    payments: mergeRecords(studentOwnedRecords(localData.payments, student), studentOwnedRecords(snapshot.payments, student)),
    achievements: mergeRecords(studentOwnedRecords(localData.achievements, student), studentOwnedRecords(snapshot.achievements, student)),
    rewardRedemptions: mergeRecords(studentOwnedRecords(localData.rewardRedemptions, student), studentOwnedRecords(snapshot.rewardRedemptions, student)),
    gameResults: mergeRecords(studentOwnedRecords(localData.gameResults, student, ['secondStudentId']), studentOwnedRecords(snapshot.gameResults, student, ['secondStudentId'])),
    mapResults: mergeRecords(studentOwnedRecords(localData.mapResults, student), studentOwnedRecords(snapshot.mapResults, student)),
    notifications: mergeRecords(studentOwnedRecords(localData.notifications, student), studentOwnedRecords(snapshot.notifications, student)),
    messages: mergeRecords(studentOwnedRecords(localData.messages, student), studentOwnedRecords(snapshot.messages, student)),
    onlineGameResults: mergeRecords(studentOwnedRecords(localData.onlineGameResults, student, ['secondStudentId']), studentOwnedRecords(snapshot.onlineGameResults, student, ['secondStudentId'])),
    rewardCatalog: Array.isArray(snapshot.rewardCatalog) ? snapshot.rewardCatalog : Array.isArray(localData.rewardCatalog) ? localData.rewardCatalog : [],
    classPointSessions: mergeRecords(studentPointSessions(localData.classPointSessions, student), studentPointSessions(snapshot.classPointSessions, student)),
    exams: mergeRecords(studentVisibleExams(localData.exams, student), studentVisibleExams(snapshot.exams, student)),
    contentLibrary: mergeRecords(localScopedContent, remoteScopedContent),
    lessonRecordings: mergeRecords([], (snapshot.lessonRecordings || []).filter((item) => item?.published !== false && item?.archived !== true && (!item?.grade || String(item.grade) === String(student.grade || '')))),
    customQuestionBank: mergeRecords([], (snapshot.customQuestionBank || []).filter((item) => item?.approved !== false && (!item?.grade || String(item.grade) === String(student.grade || '')))),
    settings: {
      ...localData.settings,
      ...(snapshot.settings || {}),
      cloudSync: {
        ...(localData.settings?.cloudSync || {}),
        endpoint: studentPortalSession.endpoint,
        workspaceId: studentPortalSession.workspaceId,
        publicAppUrl: snapshot.settings?.cloudSync?.publicAppUrl || localData.settings?.cloudSync?.publicAppUrl || '',
        token: localData.settings?.cloudSync?.token || '',
      },
      studentPortalSession,
    },
  };
}

export async function mergeStudentLoginSnapshot(localData = {}, payload = {}, pin = '') {
  const snapshot = payload.data || {};
  const cloudStudent = payload.student || snapshot.students?.[0];
  if (!cloudStudent) throw new Error('لم تُرجع المنصة بيانات الطالب.');
  const localSecret = await createCredentialSecret(pin, 'student');
  const preparedPayload = {
    ...payload,
    student: { ...cloudStudent, ...localSecret, studentPin: '' },
  };
  return mergeStudentPortalSnapshot(localData, preparedPayload, {
    endpoint: payload.endpoint,
    workspaceId: payload.workspaceId,
    studentToken: payload.studentToken,
    expiresAt: payload.expiresAt || '',
  });
}
