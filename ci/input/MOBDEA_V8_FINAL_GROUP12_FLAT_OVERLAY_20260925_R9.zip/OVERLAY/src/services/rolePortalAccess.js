export const CONTENT_ACCESS_MODES = {
  PRIVATE: 'private',
  GRADE: 'grade',
  GROUP: 'group',
  STUDENTS: 'students',
  ALL_STUDENTS: 'allStudents',
  PUBLIC: 'public',
};

const list = (value) => Array.isArray(value)
  ? value.map((item) => String(item ?? '').trim()).filter(Boolean)
  : String(value ?? '').split(/[,\n،]/g).map((item) => item.trim()).filter(Boolean);

export function findStudentForAuth(data, auth) {
  const students = Array.isArray(data?.students) ? data.students : [];
  if (!auth) return null;
  const id = auth.studentId == null ? '' : String(auth.studentId).trim();
  const code = auth.studentCode == null ? '' : String(auth.studentCode).trim();
  if (!id && !code) return null;
  // A conflicting code must not silently switch an authenticated student to
  // another record. Both identifiers, when supplied, refer to the SAME child.
  const matches = students.filter((student) =>
    (!id || String(student.id ?? '') === id) &&
    (!code || String(student.code ?? '') === code)
  );
  // Reject duplicate student codes and ambiguous historical imports.
  return matches.length === 1 ? matches[0] : null;
}

export function linkedStudentsForGuardian(data, auth) {
  const students = Array.isArray(data?.students) ? data.students : [];
  if (auth?.role !== 'guardian') return [];
  const explicitIds = [
    auth?.studentId,
    ...(Array.isArray(auth?.studentIds) ? auth.studentIds : []),
    ...(Array.isArray(auth?.linkedStudentIds) ? auth.linkedStudentIds : []),
    ...(Array.isArray(auth?.childIds) ? auth.childIds : []),
  ].filter((value) => value !== null && value !== undefined).map(String);
  // A guardian phone number is not a verified authorization link: shared,
  // recycled and manually entered numbers must not grant access to a child.
  // Only student identifiers bound to an authenticated guardian session count.
  return students.filter((student) => explicitIds.includes(String(student.id)));
}

export function normalizeResourceAccess(resource = {}) {
  const raw = resource.access && typeof resource.access === 'object' ? resource.access : {};
  let mode = String(raw.mode || resource.accessMode || '').trim();
  if (!mode) {
    if (resource.publicVisible === true || resource.isPublic === true) mode = CONTENT_ACCESS_MODES.PUBLIC;
    else mode = CONTENT_ACCESS_MODES.PRIVATE;
  }
  return {
    mode,
    grade: String(raw.grade || resource.grade || '').trim(),
    groups: list(raw.groups || resource.accessGroups || resource.groups),
    studentIds: list(raw.studentIds || resource.accessStudentIds || resource.studentIds),
  };
}

export function canStudentAccessResource(resource, student) {
  if (!resource || !student || resource.published === false || resource.archived === true) return false;
  const access = normalizeResourceAccess(resource);
  if (access.mode === CONTENT_ACCESS_MODES.PUBLIC || access.mode === CONTENT_ACCESS_MODES.ALL_STUDENTS) return true;
  if (access.mode === CONTENT_ACCESS_MODES.GRADE) return Boolean(access.grade) && String(student.grade || '') === access.grade;
  if (access.mode === CONTENT_ACCESS_MODES.GROUP) return Boolean(access.groups.length) &&
    (!access.grade || String(student.grade || '') === access.grade) &&
    access.groups.includes(String(student.group || ''));
  if (access.mode === CONTENT_ACCESS_MODES.STUDENTS) {
    const id = String(student.id ?? '');
    const code = String(student.code ?? '');
    return access.studentIds.includes(id) || (code && access.studentIds.includes(code));
  }
  return false;
}

export function canRoleAccessResource(resource, data, auth) {
  // Missing/unknown roles are public visitors, NEVER implicit teachers.
  if (auth?.role === 'teacher' || auth?.role === 'admin') return true;
  if (!resource || resource.published === false || resource.archived === true) return false;
  const access = normalizeResourceAccess(resource);
  if (!['student', 'guardian'].includes(auth?.role)) return access.mode === CONTENT_ACCESS_MODES.PUBLIC;
  if (auth.role === 'student') return canStudentAccessResource(resource, findStudentForAuth(data, auth));
  if (auth.role === 'guardian') return linkedStudentsForGuardian(data, auth).some((student) => canStudentAccessResource(resource, student));
  return false;
}

export function filterContentLibraryForRole(data, auth) {
  const library = Array.isArray(data?.contentLibrary) ? data.contentLibrary : [];
  if (auth?.role === 'teacher' || auth?.role === 'admin') return library;
  const permittedLessons = library.filter((item) => item?.type === 'lesson' && canRoleAccessResource(item, data, auth));
  const permittedLessonIds = new Set(permittedLessons.map((item) => String(item.id)));
  const roleStudents = auth?.role === 'student'
    ? [findStudentForAuth(data, auth)].filter(Boolean)
    : auth?.role === 'guardian' ? linkedStudentsForGuardian(data, auth) : [];
  const supportGrades = new Set(roleStudents.map((student) => String(student.grade || '').trim()).filter(Boolean));
  const hasAssignedLessonForGrade = (grade) => permittedLessons.some((lesson) => {
    const lessonGrade = String(lesson?.grade || '').trim();
    return !grade || !lessonGrade || lessonGrade === grade;
  });

  return library.flatMap((item) => {
    if (item?.published === false || item?.archived === true) return [];
    if (canRoleAccessResource(item, data, auth)) return [item];

    const itemType = String(item?.type || '').toLowerCase();
    const itemGrade = String(item?.grade || '').trim();
    // A private grade textbook may be retained only as an INTERNAL lesson
    // support source after the teacher has explicitly assigned at least one
    // lesson for the same pupil/grade. It stays marked roleSupportOnly so the
    // student cannot browse/download the teacher's private library directly.
    if (itemType === 'textbook' && roleStudents.length &&
        (!itemGrade || supportGrades.has(itemGrade)) &&
        hasAssignedLessonForGrade(itemGrade)) {
      return [{ ...item, roleSupportOnly: true }];
    }

    const lessonId = String(item?.lessonId || item?.parentLessonId || '');
    // A reference to a visible lesson is NOT permission to release its whole
    // private book, exam or arbitrary attached file. Inheritance is opt-in
    // per attachment, and only for explicitly published teaching attachments.
    const explicitlyInherited = item?.inheritLessonAccess === true &&
      ['image', 'video', 'audio', 'ppt', 'pptx', 'pdf-page', 'lesson-attachment']
        .includes(itemType);
    if (explicitlyInherited && lessonId && permittedLessonIds.has(lessonId)) return [item];
    return [];
  });
}

export function roleDashboardProfile(data, auth) {
  if (auth?.role === 'teacher' || auth?.role === 'admin') return { role: auth.role, students: data?.students || [] };
  if (auth?.role === 'student') {
    const student = findStudentForAuth(data, auth);
    return { role: 'student', student, students: student ? [student] : [] };
  }
  if (auth?.role === 'guardian') {
    const students = linkedStudentsForGuardian(data, auth);
    return { role: 'guardian', student: students[0] || null, students };
  }
  return { role: 'visitor', student: null, students: [] };
}


export function scopeReadOnlyDataForRole(data, auth) {
  if (auth?.role === 'teacher' || auth?.role === 'admin') return data;
  const profile = roleDashboardProfile(data, auth);
  const studentPublicView = (student) => {
    if (!student) return student;
    const { studentPin: _studentPin, guardianPin: _guardianPin,
      studentPinHash: _studentPinHash, guardianPinHash: _guardianPinHash,
      studentPinSalt: _studentPinSalt, guardianPinSalt: _guardianPinSalt,
      studentPinIterations: _studentPinIterations, guardianPinIterations: _guardianPinIterations,
      studentPinChangedByStudentAt: _studentPinChangedByStudentAt,
      studentPinResetAt: _studentPinResetAt, ...safe } = student;
    return safe;
  };
  const ids = new Set(profile.students.map((student) => String(student.id)));
  const groupKeys = new Set(profile.students
    .filter((student) => String(student.group || '').trim())
    .map((student) => `${String(student.grade || '').trim()}|${String(student.group || '').trim()}`));
  const ambiguousGroups = new Set();
  const gradesByGroup = new Map();
  for (const student of data?.students || []) {
    const group = String(student.group || '').trim();
    if (!group) continue;
    const knownGrades = gradesByGroup.get(group) || new Set();
    knownGrades.add(String(student.grade || '').trim());
    gradesByGroup.set(group, knownGrades);
  }
  for (const [group, grades] of gradesByGroup) if (grades.size !== 1) ambiguousGroups.add(group);
  const owns = (item) => ids.has(String(item?.studentId ?? ''));
  // This projection is used by the global search/navigation shell. Do not
  // spread the teacher's full dataset into a student/guardian/visitor view:
  // that would retain unrelated answers, credentials, records and book assets.
  return {
    students: profile.students.map(studentPublicView),
    attendance: (data?.attendance || []).filter(owns),
    grades: (data?.grades || []).filter(owns),
    detailedResults: (data?.detailedResults || []).filter(owns),
    payments: (data?.payments || []).filter(owns),
    notifications: !['student', 'guardian'].includes(auth?.role) ? [] : (data?.notifications || []).filter(owns),
    achievements: !['student', 'guardian'].includes(auth?.role) ? [] : (data?.achievements || []).filter(owns),
    contentLibrary: filterContentLibraryForRole(data, auth),
    sessions: !['student', 'guardian'].includes(auth?.role) || !groupKeys.size ? [] : (data?.sessions || []).filter((session) => {
      const group = String(session.group || '').trim();
      const grade = String(session.grade || '').trim();
      return grade ? groupKeys.has(`${grade}|${group}`)
        : group && !ambiguousGroups.has(group) && groupKeys.has(`${[...(gradesByGroup.get(group) || [])][0] || ''}|${group}`);
    }),
  };
}

export const VISITOR_TRIAL_LIMITS = Object.freeze({
  games: 5,
  maps: 5,
  multiplayer: 3,
});

const VISITOR_TRIAL_KEY = 'mobdea_visitor_trial_v1';

function readTrial() {
  try {
    const raw = globalThis.localStorage?.getItem(VISITOR_TRIAL_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return {
      games: Math.max(0, Number(parsed.games || 0)),
      maps: Math.max(0, Number(parsed.maps || 0)),
      multiplayer: Math.max(0, Number(parsed.multiplayer || 0)),
    };
  } catch {
    return { games: 0, maps: 0, multiplayer: 0 };
  }
}

function writeTrial(value) {
  try { globalThis.localStorage?.setItem(VISITOR_TRIAL_KEY, JSON.stringify(value)); } catch {}
}

export function getVisitorTrialStatus() {
  const used = readTrial();
  return {
    used,
    limits: VISITOR_TRIAL_LIMITS,
    remaining: {
      games: Math.max(0, VISITOR_TRIAL_LIMITS.games - used.games),
      maps: Math.max(0, VISITOR_TRIAL_LIMITS.maps - used.maps),
      multiplayer: Math.max(0, VISITOR_TRIAL_LIMITS.multiplayer - used.multiplayer),
    },
  };
}

export function consumeVisitorTrial(kind) {
  // LEGACY: a browser-owned counter cannot grant a real free trial or payment.
  // Game and map entry points call claimVisitorTrial on the server instead.
  const key = Object.hasOwn(VISITOR_TRIAL_LIMITS, kind) ? kind : 'games';
  return { allowed: false, kind: key, status: getVisitorTrialStatus(), serverRequired: true };
}

export function subscriptionMessage() {
  return 'انتهت التجارب المجانية. اشترك في منصة المُبدع للحصول على الألعاب وتحديات الخرائط والمحتوى الكامل.';
}
