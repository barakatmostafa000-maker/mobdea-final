import assert from 'node:assert/strict';
import fs from 'node:fs';
import test from 'node:test';
import { filterContentLibraryForRole } from '../src/services/rolePortalAccess.js';
import { structureOcrQuestions } from '../src/services/ocrQuestionParser.js';

const source = (file) => fs.readFileSync(file, 'utf8');

test('R9 student content remains explicit opt-in and private textbook is support-only', () => {
  const data = {
    students: [{ id: 's1', code: '101', grade: '5', group: 'A' }],
    contentLibrary: [
      { id: 'lesson-public', type: 'lesson', published: true, access: { mode: 'students', studentIds: ['s1'] }, grade: '5' },
      { id: 'private-book', type: 'textbook', published: true, grade: '5' },
      { id: 'private-exam', type: 'exam', published: true, grade: '5' },
      { id: 'other-student', type: 'lesson', published: true, access: { mode: 'students', studentIds: ['s2'] }, grade: '5' },
    ],
  };
  const visible = filterContentLibraryForRole(data, { role: 'student', studentId: 's1', studentCode: '101' });
  assert.deepEqual(visible.map((item) => item.id), ['lesson-public', 'private-book']);
  assert.equal(visible.find((item) => item.id === 'private-book')?.roleSupportOnly, true);
});

test('R9 legacy student PIN migration preserves changed plaintext PINs instead of resetting them', () => {
  const code = source('src/services/studentPinPolicy.js');
  assert.match(code, /preserveChangedPin/);
  assert.match(code, /studentPinChangedByStudentAt/);
  assert.match(code, /preserveChangedPin \? legacyPin : DEFAULT_STUDENT_PIN/);
  assert.match(code, /studentPinMustChange: !preserveChangedPin/);
  assert.match(code, /studentPin: ''/);
});

test('R9 OCR round-trip keeps the explicit option label while retaining resolved answer text', () => {
  const parsed = structureOcrQuestions('1- ما عاصمة مصر؟\nأ) القاهرة\nب) الإسكندرية\nالإجابة: أ');
  assert.equal(parsed.questions[0].answer, 'القاهرة');
  assert.equal(parsed.questions[0].answerIndex, 0);
  assert.match(parsed.questionText, /الإجابة: أ/);
});

test('R9 student portal merge source is private-by-default and uses Project12 routes', () => {
  const code = source('src/services/studentPortalCloud.js');
  assert.match(code, /body: JSON\.stringify\(\{ studentCode:/);
  assert.match(code, /'\/student\/refresh'/);
  assert.match(code, /if \(ownerId == null && ownerCode == null\) return extraMatch/);
  assert.match(code, /students: \[student\]/);
  assert.match(code, /detailedResults: mergeRecords\(studentOwnedRecords/);
  assert.match(code, /rewardRedemptions: mergeRecords\(studentOwnedRecords/);
  assert.match(code, /classPointSessions: mergeRecords\(studentPointSessions/);
  assert.match(code, /contentLibrary: mergeRecords\(localScopedContent, remoteScopedContent\)/);
});

test('R9 bundles every selectable Arabic font and missing fallback cards locally', () => {
  const files = [
    'public/fonts/Amiri-Bold.ttf',
    'public/fonts/Amiri-Regular.ttf',
    'public/fonts/ArefRuqaa-Bold.ttf',
    'public/fonts/ArefRuqaa-Regular.ttf',
    'public/fonts/NotoKufiArabic-Variable.ttf',
    'public/fonts/NotoNaskhArabic-Variable.ttf',
    'public/fonts/ReemKufi-Variable.ttf',
    'public/whiteboard/cards/v8-geographical-term-fallback.svg',
    'public/whiteboard/cards/v8-historical-term-fallback.svg',
  ];
  for (const file of files) assert.ok(fs.statSync(file).size > 0, `${file} must be bundled`);
});

test('R9 pinned worker patch enforces current PIN and server-side content authorization', () => {
  const patch = source('scripts/patch-pinned-base-r9.py');
  assert.match(patch, /PROJECT12_DEFAULT_STUDENT_PIN='12345678'/);
  assert.match(patch, /body\.studentCode\|\|body\.code/);
  assert.match(patch, /project12StudentContentLibrary\(data,student\)/);
  assert.match(patch, /studentPinDefaultVersion:2/);
  assert.match(patch, /student session grade\/group isolation/);
  assert.match(patch, /student exam grade isolation/);
  assert.match(patch, /student class-point session isolation/);
});
